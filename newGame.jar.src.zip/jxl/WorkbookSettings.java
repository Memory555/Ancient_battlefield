/*     */ package jxl;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import jxl.biff.CountryCode;
/*     */ import jxl.biff.formula.FunctionNames;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WorkbookSettings
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(WorkbookSettings.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   private int initialFileSize = 5242880;
/* 170 */   private int arrayGrowSize = 1048576;
/* 171 */   private HashMap localeFunctionNames = new HashMap();
/* 172 */   private String excelDisplayLanguage = CountryCode.USA.getCode(); private boolean drawingsDisabled; private boolean namesDisabled;
/* 173 */   private String excelRegionalSettings = CountryCode.UK.getCode();
/*     */   private boolean formulaReferenceAdjustDisabled;
/*     */   
/*     */   public WorkbookSettings() {
/*     */     try {
/* 178 */       boolean suppressWarnings = Boolean.getBoolean("jxl.nowarnings");
/* 179 */       setSuppressWarnings(suppressWarnings);
/* 180 */       this.drawingsDisabled = Boolean.getBoolean("jxl.nodrawings");
/* 181 */       this.namesDisabled = Boolean.getBoolean("jxl.nonames");
/* 182 */       this.gcDisabled = Boolean.getBoolean("jxl.nogc");
/* 183 */       this.rationalizationDisabled = Boolean.getBoolean("jxl.norat");
/* 184 */       this.formulaReferenceAdjustDisabled = Boolean.getBoolean("jxl.noformulaadjust");
/*     */       
/* 186 */       this.propertySetsDisabled = Boolean.getBoolean("jxl.nopropertysets");
/* 187 */       this.ignoreBlankCells = Boolean.getBoolean("jxl.ignoreblanks");
/*     */       
/* 189 */       this.encoding = System.getProperty("file.encoding");
/*     */     }
/* 191 */     catch (SecurityException e) {
/*     */       
/* 193 */       logger.warn("Error accessing system properties.", e);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 199 */       if (System.getProperty("jxl.lang") == null || System.getProperty("jxl.country") == null) {
/*     */ 
/*     */         
/* 202 */         this.locale = Locale.getDefault();
/*     */       }
/*     */       else {
/*     */         
/* 206 */         this.locale = new Locale(System.getProperty("jxl.lang"), System.getProperty("jxl.country"));
/*     */       } 
/*     */ 
/*     */       
/* 210 */       if (System.getProperty("jxl.encoding") != null)
/*     */       {
/* 212 */         this.encoding = System.getProperty("jxl.encoding");
/*     */       }
/*     */     }
/* 215 */     catch (SecurityException e) {
/*     */       
/* 217 */       logger.warn("Error accessing system properties.", e);
/* 218 */       this.locale = Locale.getDefault();
/*     */     } 
/*     */   }
/*     */   private boolean gcDisabled;
/*     */   private boolean rationalizationDisabled;
/*     */   private boolean propertySetsDisabled;
/*     */   private boolean ignoreBlankCells;
/*     */   private Locale locale;
/*     */   private FunctionNames functionNames;
/*     */   private String encoding;
/*     */   private int characterSet;
/*     */   private static final int defaultInitialFileSize = 5242880;
/*     */   private static final int defaultArrayGrowSize = 1048576;
/*     */   
/*     */   public void setArrayGrowSize(int sz) {
/* 233 */     this.arrayGrowSize = sz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getArrayGrowSize() {
/* 243 */     return this.arrayGrowSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitialFileSize(int sz) {
/* 256 */     this.initialFileSize = sz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getInitialFileSize() {
/* 266 */     return this.initialFileSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDrawingsDisabled() {
/* 276 */     return this.drawingsDisabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getGCDisabled() {
/* 286 */     return this.gcDisabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getNamesDisabled() {
/* 296 */     return this.namesDisabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNamesDisabled(boolean b) {
/* 306 */     this.namesDisabled = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDrawingsDisabled(boolean b) {
/* 316 */     this.drawingsDisabled = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRationalization(boolean r) {
/* 327 */     this.rationalizationDisabled = !r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getRationalizationDisabled() {
/* 337 */     return this.rationalizationDisabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPropertySets(boolean r) {
/* 350 */     this.propertySetsDisabled = !r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getPropertySetsDisabled() {
/* 360 */     return this.propertySetsDisabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuppressWarnings(boolean w) {
/* 372 */     logger.setSuppressWarnings(w);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFormulaAdjust() {
/* 383 */     return !this.formulaReferenceAdjustDisabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormulaAdjust(boolean b) {
/* 393 */     this.formulaReferenceAdjustDisabled = !b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocale(Locale l) {
/* 405 */     this.locale = l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Locale getLocale() {
/* 415 */     return this.locale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEncoding() {
/* 425 */     return this.encoding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncoding(String enc) {
/* 435 */     this.encoding = enc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FunctionNames getFunctionNames() {
/* 447 */     if (this.functionNames == null) {
/*     */       
/* 449 */       this.functionNames = (FunctionNames)this.localeFunctionNames.get(this.locale);
/*     */ 
/*     */ 
/*     */       
/* 453 */       if (this.functionNames == null) {
/*     */         
/* 455 */         this.functionNames = new FunctionNames(this.locale);
/* 456 */         this.localeFunctionNames.put(this.locale, this.functionNames);
/*     */       } 
/*     */     } 
/*     */     
/* 460 */     return this.functionNames;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCharacterSet() {
/* 471 */     return this.characterSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharacterSet(int cs) {
/* 482 */     this.characterSet = cs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGCDisabled(boolean disabled) {
/* 492 */     this.gcDisabled = disabled;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreBlanks(boolean ignoreBlanks) {
/* 502 */     this.ignoreBlankCells = ignoreBlanks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getIgnoreBlanks() {
/* 512 */     return this.ignoreBlankCells;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExcelDisplayLanguage() {
/* 521 */     return this.excelDisplayLanguage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getExcelRegionalSettings() {
/* 530 */     return this.excelRegionalSettings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExcelDisplayLanguage(String code) {
/* 540 */     this.excelDisplayLanguage = code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setExcelRegionalSettings(String code) {
/* 550 */     this.excelRegionalSettings = code;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\WorkbookSettings.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
package jxl;

import jxl.format.CellFormat;

public interface Cell {
  int getRow();
  
  int getColumn();
  
  CellType getType();
  
  boolean isHidden();
  
  String getContents();
  
  CellFormat getCellFormat();
  
  CellFeatures getCellFeatures();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\Cell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
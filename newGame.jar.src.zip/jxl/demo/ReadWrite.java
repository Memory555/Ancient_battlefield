/*     */ package jxl.demo;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import jxl.CellType;
/*     */ import jxl.Sheet;
/*     */ import jxl.Workbook;
/*     */ import jxl.biff.DisplayFormat;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.UnderlineStyle;
/*     */ import jxl.read.biff.BiffException;
/*     */ import jxl.write.DateFormat;
/*     */ import jxl.write.DateFormats;
/*     */ import jxl.write.DateTime;
/*     */ import jxl.write.Formula;
/*     */ import jxl.write.Label;
/*     */ import jxl.write.Number;
/*     */ import jxl.write.NumberFormat;
/*     */ import jxl.write.WritableCell;
/*     */ import jxl.write.WritableCellFeatures;
/*     */ import jxl.write.WritableCellFormat;
/*     */ import jxl.write.WritableFont;
/*     */ import jxl.write.WritableHyperlink;
/*     */ import jxl.write.WritableImage;
/*     */ import jxl.write.WritableSheet;
/*     */ import jxl.write.WritableWorkbook;
/*     */ import jxl.write.WriteException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadWrite
/*     */ {
/*  78 */   private static Logger logger = Logger.getLogger(ReadWrite.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File inputWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File outputWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ReadWrite(String input, String output) {
/*  97 */     this.inputWorkbook = new File(input);
/*  98 */     this.outputWorkbook = new File(output);
/*  99 */     logger.setSuppressWarnings(Boolean.getBoolean("jxl.nowarnings"));
/* 100 */     logger.info("Input file:  " + input);
/* 101 */     logger.info("Output file:  " + output);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readWrite() throws IOException, BiffException, WriteException {
/* 112 */     logger.info("Reading...");
/* 113 */     Workbook w1 = Workbook.getWorkbook(this.inputWorkbook);
/*     */     
/* 115 */     Sheet s = w1.getSheet(0);
/*     */     
/* 117 */     logger.info("Copying...");
/* 118 */     WritableWorkbook w2 = Workbook.createWorkbook(this.outputWorkbook, w1);
/*     */     
/* 120 */     if (this.inputWorkbook.getName().equals("jxlrwtest.xls"))
/*     */     {
/* 122 */       modify(w2);
/*     */     }
/*     */     
/* 125 */     w2.write();
/* 126 */     w2.close();
/* 127 */     logger.info("Done");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void modify(WritableWorkbook w) throws WriteException {
/* 138 */     logger.info("Modifying...");
/*     */     
/* 140 */     WritableSheet sheet = w.getSheet("modified");
/*     */     
/* 142 */     WritableCell cell = null;
/* 143 */     CellFormat cf = null;
/* 144 */     Label l = null;
/*     */ 
/*     */     
/* 147 */     cell = sheet.getWritableCell(1, 3);
/* 148 */     WritableFont bold = new WritableFont(WritableFont.ARIAL, 10, WritableFont.BOLD);
/*     */ 
/*     */     
/* 151 */     WritableCellFormat writableCellFormat1 = new WritableCellFormat(bold);
/* 152 */     cell.setCellFormat((CellFormat)writableCellFormat1);
/*     */ 
/*     */     
/* 155 */     cell = sheet.getWritableCell(1, 4);
/* 156 */     WritableFont underline = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.SINGLE);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     writableCellFormat1 = new WritableCellFormat(underline);
/* 162 */     cell.setCellFormat((CellFormat)writableCellFormat1);
/*     */ 
/*     */     
/* 165 */     cell = sheet.getWritableCell(1, 5);
/* 166 */     WritableFont tenpoint = new WritableFont(WritableFont.ARIAL, 10);
/* 167 */     writableCellFormat1 = new WritableCellFormat(tenpoint);
/* 168 */     cell.setCellFormat((CellFormat)writableCellFormat1);
/*     */ 
/*     */     
/* 171 */     cell = sheet.getWritableCell(1, 6);
/* 172 */     if (cell.getType() == CellType.LABEL) {
/*     */       
/* 174 */       Label lc = (Label)cell;
/* 175 */       lc.setString(lc.getString() + " - mod");
/*     */     } 
/*     */ 
/*     */     
/* 179 */     cell = sheet.getWritableCell(1, 9);
/* 180 */     NumberFormat sevendps = new NumberFormat("#.0000000");
/* 181 */     writableCellFormat1 = new WritableCellFormat((DisplayFormat)sevendps);
/* 182 */     cell.setCellFormat((CellFormat)writableCellFormat1);
/*     */ 
/*     */ 
/*     */     
/* 186 */     cell = sheet.getWritableCell(1, 10);
/* 187 */     NumberFormat exp4 = new NumberFormat("0.####E0");
/* 188 */     writableCellFormat1 = new WritableCellFormat((DisplayFormat)exp4);
/* 189 */     cell.setCellFormat((CellFormat)writableCellFormat1);
/*     */ 
/*     */     
/* 192 */     cell = sheet.getWritableCell(1, 11);
/* 193 */     cell.setCellFormat((CellFormat)WritableWorkbook.NORMAL_STYLE);
/*     */ 
/*     */     
/* 196 */     cell = sheet.getWritableCell(1, 12);
/* 197 */     if (cell.getType() == CellType.NUMBER) {
/*     */       
/* 199 */       Number number = (Number)cell;
/* 200 */       number.setValue(42.0D);
/*     */     } 
/*     */ 
/*     */     
/* 204 */     cell = sheet.getWritableCell(1, 13);
/* 205 */     if (cell.getType() == CellType.NUMBER) {
/*     */       
/* 207 */       Number number = (Number)cell;
/* 208 */       number.setValue(number.getValue() + 0.1D);
/*     */     } 
/*     */ 
/*     */     
/* 212 */     cell = sheet.getWritableCell(1, 16);
/* 213 */     DateFormat df = new DateFormat("dd MMM yyyy HH:mm:ss");
/* 214 */     writableCellFormat1 = new WritableCellFormat((DisplayFormat)df);
/* 215 */     cell.setCellFormat((CellFormat)writableCellFormat1);
/*     */ 
/*     */     
/* 218 */     cell = sheet.getWritableCell(1, 17);
/* 219 */     writableCellFormat1 = new WritableCellFormat(DateFormats.FORMAT9);
/* 220 */     cell.setCellFormat((CellFormat)writableCellFormat1);
/*     */ 
/*     */     
/* 223 */     cell = sheet.getWritableCell(1, 18);
/* 224 */     if (cell.getType() == CellType.DATE) {
/*     */       
/* 226 */       DateTime dt = (DateTime)cell;
/* 227 */       Calendar cal = Calendar.getInstance();
/* 228 */       cal.set(1998, 1, 18, 11, 23, 28);
/* 229 */       Date d = cal.getTime();
/* 230 */       dt.setDate(d);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 235 */     cell = sheet.getWritableCell(1, 22);
/* 236 */     if (cell.getType() == CellType.NUMBER) {
/*     */       
/* 238 */       Number number = (Number)cell;
/* 239 */       number.setValue(6.8D);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 244 */     cell = sheet.getWritableCell(1, 29);
/* 245 */     if (cell.getType() == CellType.LABEL) {
/*     */       
/* 247 */       l = (Label)cell;
/* 248 */       l.setString("Modified string contents");
/*     */     } 
/*     */     
/* 251 */     sheet.insertRow(34);
/*     */ 
/*     */     
/* 254 */     sheet.removeRow(38);
/*     */ 
/*     */     
/* 257 */     sheet.insertColumn(9);
/*     */ 
/*     */     
/* 260 */     sheet.removeColumn(11);
/*     */ 
/*     */ 
/*     */     
/* 264 */     sheet.removeRow(43);
/* 265 */     sheet.insertRow(43);
/*     */ 
/*     */     
/* 268 */     WritableHyperlink[] hyperlinks = sheet.getWritableHyperlinks();
/*     */     
/* 270 */     for (int i = 0; i < hyperlinks.length; i++) {
/*     */       
/* 272 */       WritableHyperlink wh = hyperlinks[i];
/* 273 */       if (wh.getColumn() == 1 && wh.getRow() == 39) {
/*     */         
/*     */         try
/*     */         {
/*     */           
/* 278 */           wh.setURL(new URL("http://www.andykhan.com/jexcelapi/index.html"));
/*     */         }
/* 280 */         catch (MalformedURLException e)
/*     */         {
/* 282 */           logger.warn(e.toString());
/*     */         }
/*     */       
/* 285 */       } else if (wh.getColumn() == 1 && wh.getRow() == 40) {
/*     */         
/* 287 */         wh.setFile(new File("../jexcelapi/docs/overview-summary.html"));
/*     */       }
/* 289 */       else if (wh.getColumn() == 1 && wh.getRow() == 41) {
/*     */         
/* 291 */         wh.setFile(new File("d:/home/jexcelapi/docs/jxl/package-summary.html"));
/*     */       }
/* 293 */       else if (wh.getColumn() == 1 && wh.getRow() == 44) {
/*     */ 
/*     */         
/* 296 */         sheet.removeHyperlink(wh);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 301 */     WritableCell c = sheet.getWritableCell(5, 30);
/* 302 */     WritableCellFormat newFormat = new WritableCellFormat(c.getCellFormat());
/* 303 */     newFormat.setBackground(Colour.RED);
/* 304 */     c.setCellFormat((CellFormat)newFormat);
/*     */ 
/*     */     
/* 307 */     l = new Label(0, 49, "Modified merged cells");
/* 308 */     sheet.addCell((WritableCell)l);
/*     */ 
/*     */     
/* 311 */     Number n = (Number)sheet.getWritableCell(0, 70);
/* 312 */     n.setValue(9.0D);
/*     */     
/* 314 */     n = (Number)sheet.getWritableCell(0, 71);
/* 315 */     n.setValue(10.0D);
/*     */     
/* 317 */     n = (Number)sheet.getWritableCell(0, 73);
/* 318 */     n.setValue(4.0D);
/*     */ 
/*     */     
/* 321 */     Formula f = new Formula(1, 80, "ROUND(COS(original!B10),2)");
/* 322 */     sheet.addCell((WritableCell)f);
/*     */ 
/*     */     
/* 325 */     f = new Formula(1, 83, "value1+value2");
/* 326 */     sheet.addCell((WritableCell)f);
/*     */ 
/*     */     
/* 329 */     f = new Formula(1, 84, "AVERAGE(value1,value1*4,value2)");
/* 330 */     sheet.addCell((WritableCell)f);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 336 */     Label label = new Label(0, 88, "Some copied cells", (CellFormat)writableCellFormat1);
/* 337 */     sheet.addCell((WritableCell)label);
/*     */     
/* 339 */     label = new Label(0, 89, "Number from B9");
/* 340 */     sheet.addCell((WritableCell)label);
/*     */     
/* 342 */     WritableCell wc = sheet.getWritableCell(1, 9).copyTo(1, 89);
/* 343 */     sheet.addCell(wc);
/*     */     
/* 345 */     label = new Label(0, 90, "Label from B4 (modified format)");
/* 346 */     sheet.addCell((WritableCell)label);
/*     */     
/* 348 */     wc = sheet.getWritableCell(1, 3).copyTo(1, 90);
/* 349 */     sheet.addCell(wc);
/*     */     
/* 351 */     label = new Label(0, 91, "Date from B17");
/* 352 */     sheet.addCell((WritableCell)label);
/*     */     
/* 354 */     wc = sheet.getWritableCell(1, 16).copyTo(1, 91);
/* 355 */     sheet.addCell(wc);
/*     */     
/* 357 */     label = new Label(0, 92, "Boolean from E16");
/* 358 */     sheet.addCell((WritableCell)label);
/*     */     
/* 360 */     wc = sheet.getWritableCell(4, 15).copyTo(1, 92);
/* 361 */     sheet.addCell(wc);
/*     */     
/* 363 */     label = new Label(0, 93, "URL from B40");
/* 364 */     sheet.addCell((WritableCell)label);
/*     */     
/* 366 */     wc = sheet.getWritableCell(1, 39).copyTo(1, 93);
/* 367 */     sheet.addCell(wc);
/*     */ 
/*     */     
/* 370 */     for (int j = 0; j < 6; j++) {
/*     */       
/* 372 */       Number number = new Number(1, 94 + j, (j + 1) + j / 8.0D);
/* 373 */       sheet.addCell((WritableCell)number);
/*     */     } 
/*     */     
/* 376 */     label = new Label(0, 100, "Formula from B27");
/* 377 */     sheet.addCell((WritableCell)label);
/*     */     
/* 379 */     wc = sheet.getWritableCell(1, 26).copyTo(1, 100);
/* 380 */     sheet.addCell(wc);
/*     */     
/* 382 */     label = new Label(0, 101, "A brand new formula");
/* 383 */     sheet.addCell((WritableCell)label);
/*     */     
/* 385 */     Formula formula = new Formula(1, 101, "SUM(B94:B96)");
/* 386 */     sheet.addCell((WritableCell)formula);
/*     */     
/* 388 */     label = new Label(0, 102, "A copy of it");
/* 389 */     sheet.addCell((WritableCell)label);
/*     */     
/* 391 */     wc = sheet.getWritableCell(1, 101).copyTo(1, 102);
/* 392 */     sheet.addCell(wc);
/*     */ 
/*     */     
/* 395 */     WritableImage wi = sheet.getImage(1);
/* 396 */     sheet.removeImage(wi);
/*     */     
/* 398 */     wi = new WritableImage(1.0D, 116.0D, 2.0D, 9.0D, new File("resources/littlemoretonhall.png"));
/*     */     
/* 400 */     sheet.addImage(wi);
/*     */ 
/*     */     
/* 403 */     cell = sheet.getWritableCell(0, 156);
/* 404 */     l = (Label)cell;
/* 405 */     l.setString("Label text modified");
/*     */     
/* 407 */     cell = sheet.getWritableCell(0, 157);
/* 408 */     WritableCellFeatures wcf = cell.getWritableCellFeatures();
/* 409 */     wcf.setComment("modified comment text");
/*     */     
/* 411 */     cell = sheet.getWritableCell(0, 158);
/* 412 */     wcf = cell.getWritableCellFeatures();
/* 413 */     wcf.removeComment();
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\demo\ReadWrite.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
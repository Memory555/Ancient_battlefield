/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import jxl.Cell;
/*     */ import jxl.CellFeatures;
/*     */ import jxl.CellReferenceHelper;
/*     */ import jxl.Sheet;
/*     */ import jxl.Workbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Features
/*     */ {
/*     */   public Features(Workbook w, OutputStream out, String encoding) throws IOException {
/*  56 */     if (encoding == null || !encoding.equals("UnicodeBig"))
/*     */     {
/*  58 */       encoding = "UTF8";
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  63 */       OutputStreamWriter osw = new OutputStreamWriter(out, encoding);
/*  64 */       BufferedWriter bw = new BufferedWriter(osw);
/*     */       
/*  66 */       ArrayList parseErrors = new ArrayList();
/*     */       
/*  68 */       for (int sheet = 0; sheet < w.getNumberOfSheets(); sheet++) {
/*     */         
/*  70 */         Sheet s = w.getSheet(sheet);
/*     */         
/*  72 */         bw.write(s.getName());
/*  73 */         bw.newLine();
/*     */         
/*  75 */         Cell[] row = null;
/*  76 */         Cell c = null;
/*     */         
/*  78 */         for (int i = 0; i < s.getRows(); i++) {
/*     */           
/*  80 */           row = s.getRow(i);
/*     */           
/*  82 */           for (int j = 0; j < row.length; j++) {
/*     */             
/*  84 */             c = row[j];
/*  85 */             if (c.getCellFeatures() != null) {
/*     */               
/*  87 */               CellFeatures features = c.getCellFeatures();
/*  88 */               StringBuffer sb = new StringBuffer();
/*  89 */               CellReferenceHelper.getCellReference(c.getColumn(), c.getRow(), sb);
/*     */ 
/*     */               
/*  92 */               bw.write("Cell " + sb.toString() + " contents:  " + c.getContents());
/*     */               
/*  94 */               bw.flush();
/*  95 */               bw.write(" comment: " + features.getComment());
/*  96 */               bw.flush();
/*  97 */               bw.newLine();
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 102 */       bw.flush();
/* 103 */       bw.close();
/*     */     }
/* 105 */     catch (UnsupportedEncodingException e) {
/*     */       
/* 107 */       System.err.println(e.toString());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\demo\Features.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
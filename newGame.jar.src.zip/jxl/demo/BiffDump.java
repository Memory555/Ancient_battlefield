/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.util.HashMap;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.Type;
/*     */ import jxl.read.biff.BiffException;
/*     */ import jxl.read.biff.BiffRecordReader;
/*     */ import jxl.read.biff.File;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BiffDump
/*     */ {
/*     */   private BufferedWriter writer;
/*     */   private BiffRecordReader reader;
/*     */   private HashMap recordNames;
/*     */   private int xfIndex;
/*     */   private int fontIndex;
/*     */   private int bofs;
/*     */   private static final int bytesPerLine = 16;
/*     */   
/*     */   public BiffDump(File file, OutputStream os) throws IOException, BiffException {
/*  64 */     this.writer = new BufferedWriter(new OutputStreamWriter(os));
/*  65 */     FileInputStream fis = new FileInputStream(file);
/*  66 */     File f = new File(fis, new WorkbookSettings());
/*  67 */     this.reader = new BiffRecordReader(f);
/*     */     
/*  69 */     buildNameHash();
/*  70 */     dump();
/*     */     
/*  72 */     this.writer.flush();
/*  73 */     this.writer.close();
/*  74 */     fis.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void buildNameHash() {
/*  82 */     this.recordNames = new HashMap(50);
/*     */     
/*  84 */     this.recordNames.put(Type.BOF, "BOF");
/*  85 */     this.recordNames.put(Type.EOF, "EOF");
/*  86 */     this.recordNames.put(Type.FONT, "FONT");
/*  87 */     this.recordNames.put(Type.SST, "SST");
/*  88 */     this.recordNames.put(Type.LABELSST, "LABELSST");
/*  89 */     this.recordNames.put(Type.WRITEACCESS, "WRITEACCESS");
/*  90 */     this.recordNames.put(Type.FORMULA, "FORMULA");
/*  91 */     this.recordNames.put(Type.FORMULA2, "FORMULA");
/*  92 */     this.recordNames.put(Type.XF, "XF");
/*  93 */     this.recordNames.put(Type.MULRK, "MULRK");
/*  94 */     this.recordNames.put(Type.NUMBER, "NUMBER");
/*  95 */     this.recordNames.put(Type.BOUNDSHEET, "BOUNDSHEET");
/*  96 */     this.recordNames.put(Type.CONTINUE, "CONTINUE");
/*  97 */     this.recordNames.put(Type.FORMAT, "FORMAT");
/*  98 */     this.recordNames.put(Type.EXTERNSHEET, "EXTERNSHEET");
/*  99 */     this.recordNames.put(Type.INDEX, "INDEX");
/* 100 */     this.recordNames.put(Type.DIMENSION, "DIMENSION");
/* 101 */     this.recordNames.put(Type.ROW, "ROW");
/* 102 */     this.recordNames.put(Type.DBCELL, "DBCELL");
/* 103 */     this.recordNames.put(Type.BLANK, "BLANK");
/* 104 */     this.recordNames.put(Type.MULBLANK, "MULBLANK");
/* 105 */     this.recordNames.put(Type.RK, "RK");
/* 106 */     this.recordNames.put(Type.RK2, "RK");
/* 107 */     this.recordNames.put(Type.COLINFO, "COLINFO");
/* 108 */     this.recordNames.put(Type.LABEL, "LABEL");
/* 109 */     this.recordNames.put(Type.SHAREDFORMULA, "SHAREDFORMULA");
/* 110 */     this.recordNames.put(Type.CODEPAGE, "CODEPAGE");
/* 111 */     this.recordNames.put(Type.WINDOW1, "WINDOW1");
/* 112 */     this.recordNames.put(Type.WINDOW2, "WINDOW2");
/* 113 */     this.recordNames.put(Type.MERGEDCELLS, "MERGEDCELLS");
/* 114 */     this.recordNames.put(Type.HLINK, "HLINK");
/* 115 */     this.recordNames.put(Type.HEADER, "HEADER");
/* 116 */     this.recordNames.put(Type.FOOTER, "FOOTER");
/* 117 */     this.recordNames.put(Type.INTERFACEHDR, "INTERFACEHDR");
/* 118 */     this.recordNames.put(Type.MMS, "MMS");
/* 119 */     this.recordNames.put(Type.INTERFACEEND, "INTERFACEEND");
/* 120 */     this.recordNames.put(Type.DSF, "DSF");
/* 121 */     this.recordNames.put(Type.FNGROUPCOUNT, "FNGROUPCOUNT");
/* 122 */     this.recordNames.put(Type.COUNTRY, "COUNTRY");
/* 123 */     this.recordNames.put(Type.TABID, "TABID");
/* 124 */     this.recordNames.put(Type.PROTECT, "PROTECT");
/* 125 */     this.recordNames.put(Type.SCENPROTECT, "SCENPROTECT");
/* 126 */     this.recordNames.put(Type.OBJPROTECT, "OBJPROTECT");
/* 127 */     this.recordNames.put(Type.WINDOWPROTECT, "WINDOWPROTECT");
/* 128 */     this.recordNames.put(Type.PASSWORD, "PASSWORD");
/* 129 */     this.recordNames.put(Type.PROT4REV, "PROT4REV");
/* 130 */     this.recordNames.put(Type.PROT4REVPASS, "PROT4REVPASS");
/* 131 */     this.recordNames.put(Type.BACKUP, "BACKUP");
/* 132 */     this.recordNames.put(Type.HIDEOBJ, "HIDEOBJ");
/* 133 */     this.recordNames.put(Type.NINETEENFOUR, "1904");
/* 134 */     this.recordNames.put(Type.PRECISION, "PRECISION");
/* 135 */     this.recordNames.put(Type.BOOKBOOL, "BOOKBOOL");
/* 136 */     this.recordNames.put(Type.STYLE, "STYLE");
/* 137 */     this.recordNames.put(Type.EXTSST, "EXTSST");
/* 138 */     this.recordNames.put(Type.REFRESHALL, "REFRESHALL");
/* 139 */     this.recordNames.put(Type.CALCMODE, "CALCMODE");
/* 140 */     this.recordNames.put(Type.CALCCOUNT, "CALCCOUNT");
/* 141 */     this.recordNames.put(Type.NAME, "NAME");
/* 142 */     this.recordNames.put(Type.MSODRAWINGGROUP, "MSODRAWINGGROUP");
/* 143 */     this.recordNames.put(Type.MSODRAWING, "MSODRAWING");
/* 144 */     this.recordNames.put(Type.OBJ, "OBJ");
/* 145 */     this.recordNames.put(Type.USESELFS, "USESELFS");
/* 146 */     this.recordNames.put(Type.SUPBOOK, "SUPBOOK");
/* 147 */     this.recordNames.put(Type.LEFTMARGIN, "LEFTMARGIN");
/* 148 */     this.recordNames.put(Type.RIGHTMARGIN, "RIGHTMARGIN");
/* 149 */     this.recordNames.put(Type.TOPMARGIN, "TOPMARGIN");
/* 150 */     this.recordNames.put(Type.BOTTOMMARGIN, "BOTTOMMARGIN");
/* 151 */     this.recordNames.put(Type.HCENTER, "HCENTER");
/* 152 */     this.recordNames.put(Type.VCENTER, "VCENTER");
/* 153 */     this.recordNames.put(Type.ITERATION, "ITERATION");
/* 154 */     this.recordNames.put(Type.DELTA, "DELTA");
/* 155 */     this.recordNames.put(Type.SAVERECALC, "SAVERECALC");
/* 156 */     this.recordNames.put(Type.PRINTHEADERS, "PRINTHEADERS");
/* 157 */     this.recordNames.put(Type.PRINTGRIDLINES, "PRINTGRIDLINES");
/* 158 */     this.recordNames.put(Type.SETUP, "SETUP");
/* 159 */     this.recordNames.put(Type.SELECTION, "SELECTION");
/* 160 */     this.recordNames.put(Type.STRING, "STRING");
/* 161 */     this.recordNames.put(Type.FONTX, "FONTX");
/* 162 */     this.recordNames.put(Type.IFMT, "IFMT");
/* 163 */     this.recordNames.put(Type.WSBOOL, "WSBOOL");
/* 164 */     this.recordNames.put(Type.GRIDSET, "GRIDSET");
/* 165 */     this.recordNames.put(Type.REFMODE, "REFMODE");
/* 166 */     this.recordNames.put(Type.GUTS, "GUTS");
/* 167 */     this.recordNames.put(Type.EXTERNNAME, "EXTERNNAME");
/* 168 */     this.recordNames.put(Type.FBI, "FBI");
/* 169 */     this.recordNames.put(Type.CRN, "CRN");
/* 170 */     this.recordNames.put(Type.HORIZONTALPAGEBREAKS, "HORIZONTALPAGEBREAKS");
/* 171 */     this.recordNames.put(Type.DEFAULTROWHEIGHT, "DEFAULTROWHEIGHT");
/* 172 */     this.recordNames.put(Type.TEMPLATE, "TEMPLATE");
/* 173 */     this.recordNames.put(Type.PANE, "PANE");
/* 174 */     this.recordNames.put(Type.SCL, "SCL");
/* 175 */     this.recordNames.put(Type.PALETTE, "PALETTE");
/* 176 */     this.recordNames.put(Type.PLS, "PLS");
/* 177 */     this.recordNames.put(Type.OBJPROJ, "OBJPROJ");
/* 178 */     this.recordNames.put(Type.DEFCOLWIDTH, "DEFCOLWIDTH");
/* 179 */     this.recordNames.put(Type.ARRAY, "ARRAY");
/* 180 */     this.recordNames.put(Type.WEIRD1, "WEIRD1");
/* 181 */     this.recordNames.put(Type.BOOLERR, "BOOLERR");
/* 182 */     this.recordNames.put(Type.SORT, "SORT");
/* 183 */     this.recordNames.put(Type.BUTTONPROPERTYSET, "BUTTONPROPERTYSET");
/* 184 */     this.recordNames.put(Type.NOTE, "NOTE");
/* 185 */     this.recordNames.put(Type.TXO, "TXO");
/* 186 */     this.recordNames.put(Type.DV, "DV");
/* 187 */     this.recordNames.put(Type.DVAL, "DVAL");
/*     */ 
/*     */     
/* 190 */     this.recordNames.put(Type.UNKNOWN, "???");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void dump() throws IOException {
/* 197 */     Record r = null;
/* 198 */     boolean cont = true;
/* 199 */     while (this.reader.hasNext() && cont) {
/*     */       
/* 201 */       r = this.reader.next();
/* 202 */       cont = writeRecord(r);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean writeRecord(Record r) throws IOException {
/* 214 */     boolean cont = true;
/* 215 */     int pos = this.reader.getPos();
/* 216 */     int code = r.getCode();
/*     */     
/* 218 */     if (this.bofs == 0)
/*     */     {
/* 220 */       cont = (r.getType() == Type.BOF);
/*     */     }
/*     */     
/* 223 */     if (!cont)
/*     */     {
/* 225 */       return cont;
/*     */     }
/*     */     
/* 228 */     if (r.getType() == Type.BOF)
/*     */     {
/* 230 */       this.bofs++;
/*     */     }
/*     */     
/* 233 */     if (r.getType() == Type.EOF)
/*     */     {
/* 235 */       this.bofs--;
/*     */     }
/*     */     
/* 238 */     StringBuffer buf = new StringBuffer();
/*     */ 
/*     */     
/* 241 */     writeSixDigitValue(pos, buf);
/* 242 */     buf.append(" [");
/* 243 */     buf.append(this.recordNames.get(r.getType()));
/* 244 */     buf.append("]");
/* 245 */     buf.append("  (0x");
/* 246 */     buf.append(Integer.toHexString(code));
/* 247 */     buf.append(")");
/*     */     
/* 249 */     if (code == Type.XF.value) {
/*     */       
/* 251 */       buf.append(" (0x");
/* 252 */       buf.append(Integer.toHexString(this.xfIndex));
/* 253 */       buf.append(")");
/* 254 */       this.xfIndex++;
/*     */     } 
/*     */     
/* 257 */     if (code == Type.FONT.value) {
/*     */       
/* 259 */       if (this.fontIndex == 4)
/*     */       {
/* 261 */         this.fontIndex++;
/*     */       }
/*     */       
/* 264 */       buf.append(" (0x");
/* 265 */       buf.append(Integer.toHexString(this.fontIndex));
/* 266 */       buf.append(")");
/* 267 */       this.fontIndex++;
/*     */     } 
/*     */     
/* 270 */     this.writer.write(buf.toString());
/* 271 */     this.writer.newLine();
/*     */     
/* 273 */     byte[] standardData = new byte[4];
/* 274 */     standardData[0] = (byte)(code & 0xFF);
/* 275 */     standardData[1] = (byte)((code & 0xFF00) >> 8);
/* 276 */     standardData[2] = (byte)(r.getLength() & 0xFF);
/* 277 */     standardData[3] = (byte)((r.getLength() & 0xFF00) >> 8);
/* 278 */     byte[] recordData = r.getData();
/* 279 */     byte[] data = new byte[standardData.length + recordData.length];
/* 280 */     System.arraycopy(standardData, 0, data, 0, standardData.length);
/* 281 */     System.arraycopy(recordData, 0, data, standardData.length, recordData.length);
/*     */ 
/*     */     
/* 284 */     int byteCount = 0;
/* 285 */     int lineBytes = 0;
/*     */     
/* 287 */     while (byteCount < data.length) {
/*     */       
/* 289 */       buf = new StringBuffer();
/* 290 */       writeSixDigitValue(pos + byteCount, buf);
/* 291 */       buf.append("   ");
/*     */       
/* 293 */       lineBytes = Math.min(16, data.length - byteCount);
/*     */       int i;
/* 295 */       for (i = 0; i < lineBytes; i++) {
/*     */         
/* 297 */         writeByte(data[i + byteCount], buf);
/* 298 */         buf.append(' ');
/*     */       } 
/*     */ 
/*     */       
/* 302 */       if (lineBytes < 16)
/*     */       {
/* 304 */         for (i = 0; i < 16 - lineBytes; i++)
/*     */         {
/* 306 */           buf.append("   ");
/*     */         }
/*     */       }
/*     */       
/* 310 */       buf.append("  ");
/*     */       
/* 312 */       for (i = 0; i < lineBytes; i++) {
/*     */         
/* 314 */         char c = (char)data[i + byteCount];
/* 315 */         if (c < ' ' || c > 'z')
/*     */         {
/* 317 */           c = '.';
/*     */         }
/* 319 */         buf.append(c);
/*     */       } 
/*     */       
/* 322 */       byteCount += lineBytes;
/*     */       
/* 324 */       this.writer.write(buf.toString());
/* 325 */       this.writer.newLine();
/*     */     } 
/*     */     
/* 328 */     return cont;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeSixDigitValue(int pos, StringBuffer buf) {
/* 336 */     String val = Integer.toHexString(pos);
/*     */     
/* 338 */     for (int i = 6; i > val.length(); i--)
/*     */     {
/* 340 */       buf.append('0');
/*     */     }
/* 342 */     buf.append(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeByte(byte val, StringBuffer buf) {
/* 350 */     String sv = Integer.toHexString(val & 0xFF);
/*     */     
/* 352 */     if (sv.length() == 1)
/*     */     {
/* 354 */       buf.append('0');
/*     */     }
/* 356 */     buf.append(sv);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\demo\BiffDump.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.BaseCompoundFile;
/*     */ import jxl.read.biff.BiffException;
/*     */ import jxl.read.biff.CompoundFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PropertySetsReader
/*     */ {
/*     */   private BufferedWriter writer;
/*     */   private CompoundFile compoundFile;
/*     */   
/*     */   public PropertySetsReader(File file, String propertySet, OutputStream os) throws IOException, BiffException {
/*  54 */     this.writer = new BufferedWriter(new OutputStreamWriter(os));
/*  55 */     FileInputStream fis = new FileInputStream(file);
/*     */     
/*  57 */     int initialFileSize = 1048576;
/*  58 */     int arrayGrowSize = 1048576;
/*     */     
/*  60 */     byte[] d = new byte[initialFileSize];
/*  61 */     int bytesRead = fis.read(d);
/*  62 */     int pos = bytesRead;
/*     */     
/*  64 */     while (bytesRead != -1) {
/*     */       
/*  66 */       if (pos >= d.length) {
/*     */ 
/*     */         
/*  69 */         byte[] newArray = new byte[d.length + arrayGrowSize];
/*  70 */         System.arraycopy(d, 0, newArray, 0, d.length);
/*  71 */         d = newArray;
/*     */       } 
/*  73 */       bytesRead = fis.read(d, pos, d.length - pos);
/*  74 */       pos += bytesRead;
/*     */     } 
/*     */     
/*  77 */     bytesRead = pos + 1;
/*     */     
/*  79 */     this.compoundFile = new CompoundFile(d, new WorkbookSettings());
/*  80 */     fis.close();
/*     */     
/*  82 */     if (propertySet == null) {
/*     */       
/*  84 */       displaySets();
/*     */     }
/*     */     else {
/*     */       
/*  88 */       displayPropertySet(propertySet, os);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void displaySets() throws IOException {
/*  97 */     String[] sets = this.compoundFile.getPropertySetNames();
/*     */     
/*  99 */     for (int i = 0; i < sets.length; i++) {
/*     */       
/* 101 */       BaseCompoundFile.PropertyStorage ps = this.compoundFile.getPropertySet(sets[i]);
/* 102 */       this.writer.write(Integer.toString(i));
/* 103 */       this.writer.write(") ");
/* 104 */       this.writer.write(sets[i]);
/* 105 */       this.writer.write("(type ");
/* 106 */       this.writer.write(Integer.toString(ps.type));
/* 107 */       this.writer.write(" size ");
/* 108 */       this.writer.write(Integer.toString(ps.size));
/* 109 */       this.writer.write(" prev ");
/* 110 */       this.writer.write(Integer.toString(ps.previous));
/* 111 */       this.writer.write(" next ");
/* 112 */       this.writer.write(Integer.toString(ps.next));
/* 113 */       this.writer.write(" child ");
/* 114 */       this.writer.write(Integer.toString(ps.child));
/* 115 */       this.writer.write(" start block ");
/* 116 */       this.writer.write(Integer.toString(ps.startBlock));
/* 117 */       this.writer.write(")");
/* 118 */       this.writer.newLine();
/*     */     } 
/*     */     
/* 121 */     this.writer.flush();
/* 122 */     this.writer.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void displayPropertySet(String ps, OutputStream os) throws IOException, BiffException {
/* 131 */     if (ps.equalsIgnoreCase("SummaryInformation")) {
/*     */       
/* 133 */       ps = "\005SummaryInformation";
/*     */     }
/* 135 */     else if (ps.equalsIgnoreCase("DocumentSummaryInformation")) {
/*     */       
/* 137 */       ps = "\005DocumentSummaryInformation";
/*     */     }
/* 139 */     else if (ps.equalsIgnoreCase("CompObj")) {
/*     */       
/* 141 */       ps = "\001CompObj";
/*     */     } 
/*     */     
/* 144 */     byte[] stream = this.compoundFile.getStream(ps);
/* 145 */     os.write(stream);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\demo\PropertySetsReader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
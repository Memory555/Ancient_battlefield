/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.FormulaCell;
/*     */ import jxl.Sheet;
/*     */ import jxl.Workbook;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Formulas
/*     */ {
/*     */   public Formulas(Workbook w, OutputStream out, String encoding) throws IOException {
/*  61 */     if (encoding == null || !encoding.equals("UnicodeBig"))
/*     */     {
/*  63 */       encoding = "UTF8";
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  68 */       OutputStreamWriter osw = new OutputStreamWriter(out, encoding);
/*  69 */       BufferedWriter bw = new BufferedWriter(osw);
/*     */       
/*  71 */       ArrayList parseErrors = new ArrayList();
/*     */       
/*  73 */       for (int sheet = 0; sheet < w.getNumberOfSheets(); sheet++) {
/*     */         
/*  75 */         Sheet s = w.getSheet(sheet);
/*     */         
/*  77 */         bw.write(s.getName());
/*  78 */         bw.newLine();
/*     */         
/*  80 */         Cell[] row = null;
/*  81 */         Cell c = null;
/*     */         
/*  83 */         for (int i = 0; i < s.getRows(); i++) {
/*     */           
/*  85 */           row = s.getRow(i);
/*     */           
/*  87 */           for (int j = 0; j < row.length; j++) {
/*     */             
/*  89 */             c = row[j];
/*  90 */             if (c.getType() == CellType.NUMBER_FORMULA || c.getType() == CellType.STRING_FORMULA || c.getType() == CellType.BOOLEAN_FORMULA || c.getType() == CellType.DATE_FORMULA || c.getType() == CellType.FORMULA_ERROR) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*  96 */               System.out.println("cell type " + c.getClass().getName());
/*  97 */               FormulaCell nfc = (FormulaCell)c;
/*  98 */               StringBuffer sb = new StringBuffer();
/*  99 */               CellReferenceHelper.getCellReference(c.getColumn(), c.getRow(), sb);
/*     */ 
/*     */ 
/*     */               
/*     */               try {
/* 104 */                 bw.write("Formula in " + sb.toString() + " value:  " + c.getContents());
/*     */                 
/* 106 */                 bw.flush();
/* 107 */                 bw.write(" formula: " + nfc.getFormula());
/* 108 */                 bw.flush();
/* 109 */                 bw.newLine();
/*     */               }
/* 111 */               catch (FormulaException e) {
/*     */                 
/* 113 */                 bw.newLine();
/* 114 */                 parseErrors.add(s.getName() + '!' + sb.toString() + ": " + e.getMessage());
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 121 */       bw.flush();
/* 122 */       bw.close();
/*     */       
/* 124 */       if (parseErrors.size() > 0)
/*     */       {
/* 126 */         System.err.println();
/* 127 */         System.err.println("There were " + parseErrors.size() + " errors");
/*     */         
/* 129 */         Iterator i = parseErrors.iterator();
/* 130 */         while (i.hasNext())
/*     */         {
/* 132 */           System.err.println(i.next());
/*     */         }
/*     */       }
/*     */     
/* 136 */     } catch (UnsupportedEncodingException e) {
/*     */       
/* 138 */       System.err.println(e.toString());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\demo\Formulas.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
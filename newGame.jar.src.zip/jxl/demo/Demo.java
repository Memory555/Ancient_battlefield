/*     */ package jxl.demo;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import jxl.Cell;
/*     */ import jxl.Range;
/*     */ import jxl.Workbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Demo
/*     */ {
/*     */   private static final int CSVFormat = 13;
/*     */   private static final int XMLFormat = 14;
/*  48 */   private static Logger logger = Logger.getLogger(Demo.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void displayHelp() {
/*  55 */     System.err.println("Command format:  Demo [-unicode] [-csv] [-hide] excelfile");
/*     */     
/*  57 */     System.err.println("                 Demo -xml [-format]  excelfile");
/*  58 */     System.err.println("                 Demo -readwrite|-rw excelfile output");
/*  59 */     System.err.println("                 Demo -biffdump | -bd | -wa | -write | -formulas | -features excelfile");
/*  60 */     System.err.println("                 Demo -ps excelfile [property] [output]");
/*  61 */     System.err.println("                 Demo -version | -logtest | -h | -help");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*  74 */     if (args.length == 0) {
/*     */       
/*  76 */       displayHelp();
/*  77 */       System.exit(1);
/*     */     } 
/*     */     
/*  80 */     if (args[0].equals("-help") || args[0].equals("-h")) {
/*     */       
/*  82 */       displayHelp();
/*  83 */       System.exit(1);
/*     */     } 
/*     */     
/*  86 */     if (args[0].equals("-version")) {
/*     */       
/*  88 */       System.out.println("v" + Workbook.getVersion());
/*  89 */       System.exit(0);
/*     */     } 
/*     */     
/*  92 */     if (args[0].equals("-logtest")) {
/*     */       
/*  94 */       logger.debug("A sample \"debug\" message");
/*  95 */       logger.info("A sample \"info\" message");
/*  96 */       logger.warn("A sample \"warning\" message");
/*  97 */       logger.error("A sample \"error\" message");
/*  98 */       logger.fatal("A sample \"fatal\" message");
/*  99 */       System.exit(0);
/*     */     } 
/*     */     
/* 102 */     boolean write = false;
/* 103 */     boolean readwrite = false;
/* 104 */     boolean formulas = false;
/* 105 */     boolean biffdump = false;
/* 106 */     boolean jxlversion = false;
/* 107 */     boolean propertysets = false;
/* 108 */     boolean features = false;
/* 109 */     String file = args[0];
/* 110 */     String outputFile = null;
/* 111 */     String propertySet = null;
/*     */     
/* 113 */     if (args[0].equals("-write")) {
/*     */       
/* 115 */       write = true;
/* 116 */       file = args[1];
/*     */     }
/* 118 */     else if (args[0].equals("-formulas")) {
/*     */       
/* 120 */       formulas = true;
/* 121 */       file = args[1];
/*     */     }
/* 123 */     else if (args[0].equals("-features")) {
/*     */       
/* 125 */       features = true;
/* 126 */       file = args[1];
/*     */     }
/* 128 */     else if (args[0].equals("-biffdump") || args[0].equals("-bd")) {
/*     */       
/* 130 */       biffdump = true;
/* 131 */       file = args[1];
/*     */     }
/* 133 */     else if (args[0].equals("-wa")) {
/*     */       
/* 135 */       jxlversion = true;
/* 136 */       file = args[1];
/*     */     }
/* 138 */     else if (args[0].equals("-ps")) {
/*     */       
/* 140 */       propertysets = true;
/* 141 */       file = args[1];
/*     */       
/* 143 */       if (args.length > 2)
/*     */       {
/* 145 */         propertySet = args[2];
/*     */       }
/*     */       
/* 148 */       if (args.length == 4)
/*     */       {
/* 150 */         outputFile = args[3];
/*     */       }
/*     */     }
/* 153 */     else if (args[0].equals("-readwrite") || args[0].equals("-rw")) {
/*     */       
/* 155 */       readwrite = true;
/* 156 */       file = args[1];
/* 157 */       outputFile = args[2];
/*     */     }
/*     */     else {
/*     */       
/* 161 */       file = args[args.length - 1];
/*     */     } 
/*     */     
/* 164 */     String encoding = "UTF8";
/* 165 */     int format = 13;
/* 166 */     boolean formatInfo = false;
/* 167 */     boolean hideCells = false;
/*     */     
/* 169 */     if (!write && !readwrite && !formulas && !biffdump && !jxlversion && !propertysets && !features)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 177 */       for (int i = 0; i < args.length - 1; i++) {
/*     */         
/* 179 */         if (args[i].equals("-unicode")) {
/*     */           
/* 181 */           encoding = "UnicodeBig";
/*     */         }
/* 183 */         else if (args[i].equals("-xml")) {
/*     */           
/* 185 */           format = 14;
/*     */         }
/* 187 */         else if (args[i].equals("-csv")) {
/*     */           
/* 189 */           format = 13;
/*     */         }
/* 191 */         else if (args[i].equals("-format")) {
/*     */           
/* 193 */           formatInfo = true;
/*     */         }
/* 195 */         else if (args[i].equals("-hide")) {
/*     */           
/* 197 */           hideCells = true;
/*     */         }
/*     */         else {
/*     */           
/* 201 */           System.err.println("Command format:  CSV [-unicode] [-xml|-csv] excelfile");
/*     */           
/* 203 */           System.exit(1);
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 210 */       if (write)
/*     */       {
/* 212 */         Write w = new Write(file);
/* 213 */         w.write();
/*     */       }
/* 215 */       else if (readwrite)
/*     */       {
/* 217 */         ReadWrite rw = new ReadWrite(file, outputFile);
/* 218 */         rw.readWrite();
/*     */       }
/* 220 */       else if (formulas)
/*     */       {
/* 222 */         Workbook w = Workbook.getWorkbook(new File(file));
/* 223 */         Formulas f = new Formulas(w, System.out, encoding);
/* 224 */         w.close();
/*     */       }
/* 226 */       else if (features)
/*     */       {
/* 228 */         Workbook w = Workbook.getWorkbook(new File(file));
/* 229 */         Features f = new Features(w, System.out, encoding);
/* 230 */         w.close();
/*     */       }
/* 232 */       else if (biffdump)
/*     */       {
/* 234 */         BiffDump bd = new BiffDump(new File(file), System.out);
/*     */       }
/* 236 */       else if (jxlversion)
/*     */       {
/* 238 */         WriteAccess bd = new WriteAccess(new File(file));
/*     */       }
/* 240 */       else if (propertysets)
/*     */       {
/* 242 */         OutputStream os = System.out;
/* 243 */         if (outputFile != null)
/*     */         {
/* 245 */           os = new FileOutputStream(outputFile);
/*     */         }
/* 247 */         PropertySetsReader psr = new PropertySetsReader(new File(file), propertySet, os);
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */         
/* 253 */         Workbook w = Workbook.getWorkbook(new File(file));
/*     */ 
/*     */ 
/*     */         
/* 257 */         if (format == 13) {
/*     */           
/* 259 */           CSV csv = new CSV(w, System.out, encoding, hideCells);
/*     */         }
/* 261 */         else if (format == 14) {
/*     */           
/* 263 */           XML xml = new XML(w, System.out, encoding, formatInfo);
/*     */         } 
/*     */         
/* 266 */         w.close();
/*     */       }
/*     */     
/* 269 */     } catch (Throwable t) {
/*     */       
/* 271 */       System.out.println(t.toString());
/* 272 */       t.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void findTest(Workbook w) {
/* 281 */     logger.info("Find test");
/*     */     
/* 283 */     Cell c = w.findCellByName("named1");
/* 284 */     if (c != null)
/*     */     {
/* 286 */       logger.info("named1 contents:  " + c.getContents());
/*     */     }
/*     */     
/* 289 */     c = w.findCellByName("named2");
/* 290 */     if (c != null)
/*     */     {
/* 292 */       logger.info("named2 contents:  " + c.getContents());
/*     */     }
/*     */     
/* 295 */     c = w.findCellByName("namedrange");
/* 296 */     if (c != null)
/*     */     {
/* 298 */       logger.info("named2 contents:  " + c.getContents());
/*     */     }
/*     */     
/* 301 */     Range[] range = w.findByName("namedrange");
/* 302 */     if (range != null) {
/*     */       
/* 304 */       c = range[0].getTopLeft();
/* 305 */       logger.info("namedrange top left contents:  " + c.getContents());
/*     */       
/* 307 */       c = range[0].getBottomRight();
/* 308 */       logger.info("namedrange bottom right contents:  " + c.getContents());
/*     */     } 
/*     */     
/* 311 */     range = w.findByName("nonadjacentrange");
/* 312 */     if (range != null)
/*     */     {
/* 314 */       for (int i = 0; i < range.length; i++) {
/*     */         
/* 316 */         c = range[i].getTopLeft();
/* 317 */         logger.info("nonadjacent top left contents:  " + c.getContents());
/*     */         
/* 319 */         c = range[i].getBottomRight();
/* 320 */         logger.info("nonadjacent bottom right contents:  " + c.getContents());
/*     */       } 
/*     */     }
/*     */     
/* 324 */     range = w.findByName("horizontalnonadjacentrange");
/* 325 */     if (range != null)
/*     */     {
/* 327 */       for (int i = 0; i < range.length; i++) {
/*     */         
/* 329 */         c = range[i].getTopLeft();
/* 330 */         logger.info("horizontalnonadjacent top left contents:  " + c.getContents());
/*     */ 
/*     */         
/* 333 */         c = range[i].getBottomRight();
/* 334 */         logger.info("horizontalnonadjacent bottom right contents:  " + c.getContents());
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\demo\Demo.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
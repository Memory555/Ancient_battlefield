/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.Sheet;
/*     */ import jxl.Workbook;
/*     */ import jxl.format.Border;
/*     */ import jxl.format.BorderLineStyle;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.Font;
/*     */ import jxl.format.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XML
/*     */ {
/*     */   private OutputStream out;
/*     */   private String encoding;
/*     */   private Workbook workbook;
/*     */   
/*     */   public XML(Workbook w, OutputStream out, String enc, boolean f) throws IOException {
/*  77 */     this.encoding = enc;
/*  78 */     this.workbook = w;
/*  79 */     this.out = out;
/*     */     
/*  81 */     if (this.encoding == null || !this.encoding.equals("UnicodeBig"))
/*     */     {
/*  83 */       this.encoding = "UTF8";
/*     */     }
/*     */     
/*  86 */     if (f) {
/*     */       
/*  88 */       writeFormattedXML();
/*     */     }
/*     */     else {
/*     */       
/*  92 */       writeXML();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeXML() throws IOException {
/*     */     try {
/* 104 */       OutputStreamWriter osw = new OutputStreamWriter(this.out, this.encoding);
/* 105 */       BufferedWriter bw = new BufferedWriter(osw);
/*     */       
/* 107 */       bw.write("<?xml version=\"1.0\" ?>");
/* 108 */       bw.newLine();
/* 109 */       bw.write("<!DOCTYPE workbook SYSTEM \"workbook.dtd\">");
/* 110 */       bw.newLine();
/* 111 */       bw.newLine();
/* 112 */       bw.write("<workbook>");
/* 113 */       bw.newLine();
/* 114 */       for (int sheet = 0; sheet < this.workbook.getNumberOfSheets(); sheet++) {
/*     */         
/* 116 */         Sheet s = this.workbook.getSheet(sheet);
/*     */         
/* 118 */         bw.write("  <sheet>");
/* 119 */         bw.newLine();
/* 120 */         bw.write("    <name><![CDATA[" + s.getName() + "]]></name>");
/* 121 */         bw.newLine();
/*     */         
/* 123 */         Cell[] row = null;
/*     */         
/* 125 */         for (int i = 0; i < s.getRows(); i++) {
/*     */           
/* 127 */           bw.write("    <row number=\"" + i + "\">");
/* 128 */           bw.newLine();
/* 129 */           row = s.getRow(i);
/*     */           
/* 131 */           for (int j = 0; j < row.length; j++) {
/*     */             
/* 133 */             if (row[j].getType() != CellType.EMPTY) {
/*     */               
/* 135 */               bw.write("      <col number=\"" + j + "\">");
/* 136 */               bw.write("<![CDATA[" + row[j].getContents() + "]]>");
/* 137 */               bw.write("</col>");
/* 138 */               bw.newLine();
/*     */             } 
/*     */           } 
/* 141 */           bw.write("    </row>");
/* 142 */           bw.newLine();
/*     */         } 
/* 144 */         bw.write("  </sheet>");
/* 145 */         bw.newLine();
/*     */       } 
/*     */       
/* 148 */       bw.write("</workbook>");
/* 149 */       bw.newLine();
/*     */       
/* 151 */       bw.flush();
/* 152 */       bw.close();
/*     */     }
/* 154 */     catch (UnsupportedEncodingException e) {
/*     */       
/* 156 */       System.err.println(e.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeFormattedXML() throws IOException {
/*     */     try {
/* 167 */       OutputStreamWriter osw = new OutputStreamWriter(this.out, this.encoding);
/* 168 */       BufferedWriter bw = new BufferedWriter(osw);
/*     */       
/* 170 */       bw.write("<?xml version=\"1.0\" ?>");
/* 171 */       bw.newLine();
/* 172 */       bw.write("<!DOCTYPE workbook SYSTEM \"formatworkbook.dtd\">");
/* 173 */       bw.newLine();
/* 174 */       bw.newLine();
/* 175 */       bw.write("<workbook>");
/* 176 */       bw.newLine();
/* 177 */       for (int sheet = 0; sheet < this.workbook.getNumberOfSheets(); sheet++) {
/*     */         
/* 179 */         Sheet s = this.workbook.getSheet(sheet);
/*     */         
/* 181 */         bw.write("  <sheet>");
/* 182 */         bw.newLine();
/* 183 */         bw.write("    <name><![CDATA[" + s.getName() + "]]></name>");
/* 184 */         bw.newLine();
/*     */         
/* 186 */         Cell[] row = null;
/* 187 */         CellFormat format = null;
/* 188 */         Font font = null;
/*     */         
/* 190 */         for (int i = 0; i < s.getRows(); i++) {
/*     */           
/* 192 */           bw.write("    <row number=\"" + i + "\">");
/* 193 */           bw.newLine();
/* 194 */           row = s.getRow(i);
/*     */           
/* 196 */           for (int j = 0; j < row.length; j++) {
/*     */ 
/*     */             
/* 199 */             if (row[j].getType() != CellType.EMPTY || row[j].getCellFormat() != null) {
/*     */ 
/*     */               
/* 202 */               format = row[j].getCellFormat();
/* 203 */               bw.write("      <col number=\"" + j + "\">");
/* 204 */               bw.newLine();
/* 205 */               bw.write("        <data>");
/* 206 */               bw.write("<![CDATA[" + row[j].getContents() + "]]>");
/* 207 */               bw.write("</data>");
/* 208 */               bw.newLine();
/*     */               
/* 210 */               if (row[j].getCellFormat() != null) {
/*     */                 
/* 212 */                 bw.write("        <format wrap=\"" + format.getWrap() + "\"");
/* 213 */                 bw.newLine();
/* 214 */                 bw.write("                align=\"" + format.getAlignment().getDescription() + "\"");
/*     */                 
/* 216 */                 bw.newLine();
/* 217 */                 bw.write("                valign=\"" + format.getVerticalAlignment().getDescription() + "\"");
/*     */                 
/* 219 */                 bw.newLine();
/* 220 */                 bw.write("                orientation=\"" + format.getOrientation().getDescription() + "\"");
/*     */                 
/* 222 */                 bw.write(">");
/* 223 */                 bw.newLine();
/*     */ 
/*     */                 
/* 226 */                 font = format.getFont();
/* 227 */                 bw.write("          <font name=\"" + font.getName() + "\"");
/* 228 */                 bw.newLine();
/* 229 */                 bw.write("                point_size=\"" + font.getPointSize() + "\"");
/*     */                 
/* 231 */                 bw.newLine();
/* 232 */                 bw.write("                bold_weight=\"" + font.getBoldWeight() + "\"");
/*     */                 
/* 234 */                 bw.newLine();
/* 235 */                 bw.write("                italic=\"" + font.isItalic() + "\"");
/* 236 */                 bw.newLine();
/* 237 */                 bw.write("                underline=\"" + font.getUnderlineStyle().getDescription() + "\"");
/*     */                 
/* 239 */                 bw.newLine();
/* 240 */                 bw.write("                colour=\"" + font.getColour().getDescription() + "\"");
/*     */                 
/* 242 */                 bw.newLine();
/* 243 */                 bw.write("                script=\"" + font.getScriptStyle().getDescription() + "\"");
/*     */                 
/* 245 */                 bw.write(" />");
/* 246 */                 bw.newLine();
/*     */ 
/*     */ 
/*     */                 
/* 250 */                 if (format.getBackgroundColour() != Colour.DEFAULT_BACKGROUND || format.getPattern() != Pattern.NONE) {
/*     */ 
/*     */                   
/* 253 */                   bw.write("          <background colour=\"" + format.getBackgroundColour().getDescription() + "\"");
/*     */                   
/* 255 */                   bw.newLine();
/* 256 */                   bw.write("                      pattern=\"" + format.getPattern().getDescription() + "\"");
/*     */                   
/* 258 */                   bw.write(" />");
/* 259 */                   bw.newLine();
/*     */                 } 
/*     */ 
/*     */ 
/*     */                 
/* 264 */                 if (format.getBorder(Border.TOP) != BorderLineStyle.NONE || format.getBorder(Border.BOTTOM) != BorderLineStyle.NONE || format.getBorder(Border.LEFT) != BorderLineStyle.NONE || format.getBorder(Border.RIGHT) != BorderLineStyle.NONE) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 270 */                   bw.write("          <border top=\"" + format.getBorder(Border.TOP).getDescription() + "\"");
/*     */                   
/* 272 */                   bw.newLine();
/* 273 */                   bw.write("                  bottom=\"" + format.getBorder(Border.BOTTOM).getDescription() + "\"");
/*     */ 
/*     */                   
/* 276 */                   bw.newLine();
/* 277 */                   bw.write("                  left=\"" + format.getBorder(Border.LEFT).getDescription() + "\"");
/*     */                   
/* 279 */                   bw.newLine();
/* 280 */                   bw.write("                  right=\"" + format.getBorder(Border.RIGHT).getDescription() + "\"");
/*     */                   
/* 282 */                   bw.write(" />");
/* 283 */                   bw.newLine();
/*     */                 } 
/*     */ 
/*     */                 
/* 287 */                 if (!format.getFormat().getFormatString().equals("")) {
/*     */                   
/* 289 */                   bw.write("          <format_string string=\"");
/* 290 */                   bw.write(format.getFormat().getFormatString());
/* 291 */                   bw.write("\" />");
/* 292 */                   bw.newLine();
/*     */                 } 
/*     */                 
/* 295 */                 bw.write("        </format>");
/* 296 */                 bw.newLine();
/*     */               } 
/*     */               
/* 299 */               bw.write("      </col>");
/* 300 */               bw.newLine();
/*     */             } 
/*     */           } 
/* 303 */           bw.write("    </row>");
/* 304 */           bw.newLine();
/*     */         } 
/* 306 */         bw.write("  </sheet>");
/* 307 */         bw.newLine();
/*     */       } 
/*     */       
/* 310 */       bw.write("</workbook>");
/* 311 */       bw.newLine();
/*     */       
/* 313 */       bw.flush();
/* 314 */       bw.close();
/*     */     }
/* 316 */     catch (UnsupportedEncodingException e) {
/*     */       
/* 318 */       System.err.println(e.toString());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\demo\XML.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
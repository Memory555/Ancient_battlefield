/*      */ package jxl.demo;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import jxl.CellReferenceHelper;
/*      */ import jxl.CellView;
/*      */ import jxl.HeaderFooter;
/*      */ import jxl.Range;
/*      */ import jxl.Workbook;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.DisplayFormat;
/*      */ import jxl.format.Alignment;
/*      */ import jxl.format.Border;
/*      */ import jxl.format.BorderLineStyle;
/*      */ import jxl.format.CellFormat;
/*      */ import jxl.format.Colour;
/*      */ import jxl.format.Orientation;
/*      */ import jxl.format.PageOrientation;
/*      */ import jxl.format.PaperSize;
/*      */ import jxl.format.ScriptStyle;
/*      */ import jxl.format.UnderlineStyle;
/*      */ import jxl.write.Boolean;
/*      */ import jxl.write.DateFormat;
/*      */ import jxl.write.DateFormats;
/*      */ import jxl.write.DateTime;
/*      */ import jxl.write.Formula;
/*      */ import jxl.write.Label;
/*      */ import jxl.write.Number;
/*      */ import jxl.write.NumberFormat;
/*      */ import jxl.write.NumberFormats;
/*      */ import jxl.write.WritableCell;
/*      */ import jxl.write.WritableCellFeatures;
/*      */ import jxl.write.WritableCellFormat;
/*      */ import jxl.write.WritableFont;
/*      */ import jxl.write.WritableHyperlink;
/*      */ import jxl.write.WritableImage;
/*      */ import jxl.write.WritableSheet;
/*      */ import jxl.write.WritableWorkbook;
/*      */ import jxl.write.WriteException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Write
/*      */ {
/*      */   private String filename;
/*      */   private WritableWorkbook workbook;
/*      */   
/*      */   public Write(String fn) {
/*   89 */     this.filename = fn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write() throws IOException, WriteException {
/*  100 */     WorkbookSettings ws = new WorkbookSettings();
/*  101 */     ws.setLocale(new Locale("en", "EN"));
/*  102 */     this.workbook = Workbook.createWorkbook(new File(this.filename), ws);
/*      */ 
/*      */     
/*  105 */     WritableSheet s2 = this.workbook.createSheet("Number Formats", 0);
/*  106 */     WritableSheet s3 = this.workbook.createSheet("Date Formats", 1);
/*  107 */     WritableSheet s1 = this.workbook.createSheet("Label Formats", 2);
/*  108 */     WritableSheet s4 = this.workbook.createSheet("Borders", 3);
/*  109 */     WritableSheet s5 = this.workbook.createSheet("Labels", 4);
/*  110 */     WritableSheet s6 = this.workbook.createSheet("Formulas", 5);
/*  111 */     WritableSheet s7 = this.workbook.createSheet("Images", 6);
/*      */ 
/*      */ 
/*      */     
/*  115 */     writeLabelFormatSheet(s1);
/*  116 */     writeNumberFormatSheet(s2);
/*  117 */     writeDateFormatSheet(s3);
/*  118 */     writeBordersSheet(s4);
/*  119 */     writeLabelsSheet(s5);
/*  120 */     writeFormulaSheet(s6);
/*  121 */     writeImageSheet(s7);
/*      */ 
/*      */     
/*  124 */     this.workbook.setColourRGB(Colour.LIME, 255, 0, 0);
/*      */ 
/*      */     
/*  127 */     this.workbook.addNameArea("namedrange", s4, 1, 11, 5, 14);
/*      */     
/*  129 */     this.workbook.write();
/*  130 */     this.workbook.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeNumberFormatSheet(WritableSheet s) throws WriteException {
/*  140 */     WritableCellFormat wrappedText = new WritableCellFormat(WritableWorkbook.ARIAL_10_PT);
/*      */     
/*  142 */     wrappedText.setWrap(true);
/*      */     
/*  144 */     s.setColumnView(0, 20);
/*  145 */     s.setColumnView(4, 20);
/*  146 */     s.setColumnView(5, 20);
/*  147 */     s.setColumnView(6, 20);
/*      */ 
/*      */     
/*  150 */     Label l = new Label(0, 0, "+/- Pi - default format", (CellFormat)wrappedText);
/*  151 */     s.addCell((WritableCell)l);
/*      */     
/*  153 */     Number n = new Number(1, 0, 3.1415926535D);
/*  154 */     s.addCell((WritableCell)n);
/*      */     
/*  156 */     n = new Number(2, 0, -3.1415926535D);
/*  157 */     s.addCell((WritableCell)n);
/*      */     
/*  159 */     l = new Label(0, 1, "+/- Pi - integer format", (CellFormat)wrappedText);
/*  160 */     s.addCell((WritableCell)l);
/*      */     
/*  162 */     WritableCellFormat cf1 = new WritableCellFormat(NumberFormats.INTEGER);
/*  163 */     n = new Number(1, 1, 3.1415926535D, (CellFormat)cf1);
/*  164 */     s.addCell((WritableCell)n);
/*      */     
/*  166 */     n = new Number(2, 1, -3.1415926535D, (CellFormat)cf1);
/*  167 */     s.addCell((WritableCell)n);
/*      */     
/*  169 */     l = new Label(0, 2, "+/- Pi - float 2dps", (CellFormat)wrappedText);
/*  170 */     s.addCell((WritableCell)l);
/*      */     
/*  172 */     WritableCellFormat cf2 = new WritableCellFormat(NumberFormats.FLOAT);
/*  173 */     n = new Number(1, 2, 3.1415926535D, (CellFormat)cf2);
/*  174 */     s.addCell((WritableCell)n);
/*      */     
/*  176 */     n = new Number(2, 2, -3.1415926535D, (CellFormat)cf2);
/*  177 */     s.addCell((WritableCell)n);
/*      */     
/*  179 */     l = new Label(0, 3, "+/- Pi - custom 3dps", (CellFormat)wrappedText);
/*      */     
/*  181 */     s.addCell((WritableCell)l);
/*      */     
/*  183 */     NumberFormat dp3 = new NumberFormat("#.###");
/*  184 */     WritableCellFormat dp3cell = new WritableCellFormat((DisplayFormat)dp3);
/*  185 */     n = new Number(1, 3, 3.1415926535D, (CellFormat)dp3cell);
/*  186 */     s.addCell((WritableCell)n);
/*      */     
/*  188 */     n = new Number(2, 3, -3.1415926535D, (CellFormat)dp3cell);
/*  189 */     s.addCell((WritableCell)n);
/*      */     
/*  191 */     l = new Label(0, 4, "+/- Pi - custom &3.14", (CellFormat)wrappedText);
/*      */     
/*  193 */     s.addCell((WritableCell)l);
/*      */     
/*  195 */     NumberFormat pounddp2 = new NumberFormat("&#.00");
/*  196 */     WritableCellFormat pounddp2cell = new WritableCellFormat((DisplayFormat)pounddp2);
/*  197 */     n = new Number(1, 4, 3.1415926535D, (CellFormat)pounddp2cell);
/*  198 */     s.addCell((WritableCell)n);
/*      */     
/*  200 */     n = new Number(2, 4, -3.1415926535D, (CellFormat)pounddp2cell);
/*  201 */     s.addCell((WritableCell)n);
/*      */     
/*  203 */     l = new Label(0, 5, "+/- Pi - custom Text #.### Text", (CellFormat)wrappedText);
/*      */     
/*  205 */     s.addCell((WritableCell)l);
/*      */     
/*  207 */     NumberFormat textdp4 = new NumberFormat("Text#.####Text");
/*  208 */     WritableCellFormat textdp4cell = new WritableCellFormat((DisplayFormat)textdp4);
/*  209 */     n = new Number(1, 5, 3.1415926535D, (CellFormat)textdp4cell);
/*  210 */     s.addCell((WritableCell)n);
/*      */     
/*  212 */     n = new Number(2, 5, -3.1415926535D, (CellFormat)textdp4cell);
/*  213 */     s.addCell((WritableCell)n);
/*      */ 
/*      */     
/*  216 */     l = new Label(4, 0, "+/- Bilko default format");
/*  217 */     s.addCell((WritableCell)l);
/*  218 */     n = new Number(5, 0, 1.5042699E7D);
/*  219 */     s.addCell((WritableCell)n);
/*  220 */     n = new Number(6, 0, -1.5042699E7D);
/*  221 */     s.addCell((WritableCell)n);
/*      */     
/*  223 */     l = new Label(4, 1, "+/- Bilko float format");
/*  224 */     s.addCell((WritableCell)l);
/*  225 */     WritableCellFormat cfi1 = new WritableCellFormat(NumberFormats.FLOAT);
/*  226 */     n = new Number(5, 1, 1.5042699E7D, (CellFormat)cfi1);
/*  227 */     s.addCell((WritableCell)n);
/*  228 */     n = new Number(6, 1, -1.5042699E7D, (CellFormat)cfi1);
/*  229 */     s.addCell((WritableCell)n);
/*      */     
/*  231 */     l = new Label(4, 2, "+/- Thousands separator");
/*  232 */     s.addCell((WritableCell)l);
/*  233 */     WritableCellFormat cfi2 = new WritableCellFormat(NumberFormats.THOUSANDS_INTEGER);
/*      */     
/*  235 */     n = new Number(5, 2, 1.5042699E7D, (CellFormat)cfi2);
/*  236 */     s.addCell((WritableCell)n);
/*  237 */     n = new Number(6, 2, -1.5042699E7D, (CellFormat)cfi2);
/*  238 */     s.addCell((WritableCell)n);
/*      */     
/*  240 */     l = new Label(4, 3, "+/- Accounting red - added 0.01");
/*  241 */     s.addCell((WritableCell)l);
/*  242 */     WritableCellFormat cfi3 = new WritableCellFormat(NumberFormats.ACCOUNTING_RED_FLOAT);
/*      */     
/*  244 */     n = new Number(5, 3, 1.504269901E7D, (CellFormat)cfi3);
/*  245 */     s.addCell((WritableCell)n);
/*  246 */     n = new Number(6, 3, -1.504269901E7D, (CellFormat)cfi3);
/*  247 */     s.addCell((WritableCell)n);
/*      */     
/*  249 */     l = new Label(4, 4, "+/- Percent");
/*  250 */     s.addCell((WritableCell)l);
/*  251 */     WritableCellFormat cfi4 = new WritableCellFormat(NumberFormats.PERCENT_INTEGER);
/*      */     
/*  253 */     n = new Number(5, 4, 1.5042699E7D, (CellFormat)cfi4);
/*  254 */     s.addCell((WritableCell)n);
/*  255 */     n = new Number(6, 4, -1.5042699E7D, (CellFormat)cfi4);
/*  256 */     s.addCell((WritableCell)n);
/*      */     
/*  258 */     l = new Label(4, 5, "+/- Exponential - 2dps");
/*  259 */     s.addCell((WritableCell)l);
/*  260 */     WritableCellFormat cfi5 = new WritableCellFormat(NumberFormats.EXPONENTIAL);
/*      */     
/*  262 */     n = new Number(5, 5, 1.5042699E7D, (CellFormat)cfi5);
/*  263 */     s.addCell((WritableCell)n);
/*  264 */     n = new Number(6, 5, -1.5042699E7D, (CellFormat)cfi5);
/*  265 */     s.addCell((WritableCell)n);
/*      */     
/*  267 */     l = new Label(4, 6, "+/- Custom exponentional - 3dps", (CellFormat)wrappedText);
/*  268 */     s.addCell((WritableCell)l);
/*  269 */     NumberFormat edp3 = new NumberFormat("0.000E0");
/*  270 */     WritableCellFormat edp3Cell = new WritableCellFormat((DisplayFormat)edp3);
/*  271 */     n = new Number(5, 6, 1.5042699E7D, (CellFormat)edp3Cell);
/*  272 */     s.addCell((WritableCell)n);
/*  273 */     n = new Number(6, 6, -1.5042699E7D, (CellFormat)edp3Cell);
/*  274 */     s.addCell((WritableCell)n);
/*      */     
/*  276 */     l = new Label(4, 7, "Custom neg brackets", (CellFormat)wrappedText);
/*  277 */     s.addCell((WritableCell)l);
/*  278 */     NumberFormat negbracks = new NumberFormat("#,##0;(#,##0)");
/*  279 */     WritableCellFormat negbrackscell = new WritableCellFormat((DisplayFormat)negbracks);
/*  280 */     n = new Number(5, 7, 1.5042699E7D, (CellFormat)negbrackscell);
/*  281 */     s.addCell((WritableCell)n);
/*  282 */     n = new Number(6, 7, -1.5042699E7D, (CellFormat)negbrackscell);
/*  283 */     s.addCell((WritableCell)n);
/*      */     
/*  285 */     l = new Label(4, 8, "Custom neg brackets 2", (CellFormat)wrappedText);
/*  286 */     s.addCell((WritableCell)l);
/*  287 */     NumberFormat negbracks2 = new NumberFormat("#,##0;(#,##0)a");
/*  288 */     WritableCellFormat negbrackscell2 = new WritableCellFormat((DisplayFormat)negbracks2);
/*  289 */     n = new Number(5, 8, 1.5042699E7D, (CellFormat)negbrackscell2);
/*  290 */     s.addCell((WritableCell)n);
/*  291 */     n = new Number(6, 8, -1.5042699E7D, (CellFormat)negbrackscell2);
/*  292 */     s.addCell((WritableCell)n);
/*      */     
/*  294 */     l = new Label(4, 9, "Custom percent", (CellFormat)wrappedText);
/*  295 */     s.addCell((WritableCell)l);
/*  296 */     NumberFormat cuspercent = new NumberFormat("0.0%");
/*  297 */     WritableCellFormat cuspercentf = new WritableCellFormat((DisplayFormat)cuspercent);
/*  298 */     n = new Number(5, 9, 3.14159265D, (CellFormat)cuspercentf);
/*  299 */     s.addCell((WritableCell)n);
/*      */ 
/*      */ 
/*      */     
/*  303 */     l = new Label(0, 10, "Boolean - TRUE");
/*  304 */     s.addCell((WritableCell)l);
/*  305 */     Boolean b = new Boolean(1, 10, true);
/*  306 */     s.addCell((WritableCell)b);
/*      */     
/*  308 */     l = new Label(0, 11, "Boolean - FALSE");
/*  309 */     s.addCell((WritableCell)l);
/*  310 */     b = new Boolean(1, 11, false);
/*  311 */     s.addCell((WritableCell)b);
/*      */     
/*  313 */     l = new Label(0, 12, "A hidden cell->");
/*  314 */     s.addCell((WritableCell)l);
/*  315 */     n = new Number(1, 12, 17.0D, (CellFormat)WritableWorkbook.HIDDEN_STYLE);
/*  316 */     s.addCell((WritableCell)n);
/*      */     
/*      */     int row;
/*      */     
/*  320 */     for (row = 0; row < 100; row++) {
/*      */       
/*  322 */       for (int col = 8; col < 108; col++) {
/*      */         
/*  324 */         n = new Number(col, row, (col + row));
/*  325 */         s.addCell((WritableCell)n);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  330 */     for (row = 101; row < 3000; row++) {
/*      */       
/*  332 */       for (int col = 0; col < 25; col++) {
/*      */         
/*  334 */         n = new Number(col, row, (col + row));
/*  335 */         s.addCell((WritableCell)n);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeDateFormatSheet(WritableSheet s) throws WriteException {
/*  347 */     WritableCellFormat wrappedText = new WritableCellFormat(WritableWorkbook.ARIAL_10_PT);
/*      */     
/*  349 */     wrappedText.setWrap(true);
/*      */     
/*  351 */     s.setColumnView(0, 20);
/*  352 */     s.setColumnView(2, 20);
/*  353 */     s.setColumnView(3, 20);
/*  354 */     s.setColumnView(4, 20);
/*      */     
/*  356 */     s.getSettings().setFitWidth(2);
/*  357 */     s.getSettings().setFitHeight(2);
/*      */     
/*  359 */     Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/*  360 */     c.set(1975, 4, 31, 15, 21, 45);
/*  361 */     c.set(14, 660);
/*  362 */     Date date = c.getTime();
/*  363 */     c.set(1900, 0, 1, 0, 0, 0);
/*  364 */     c.set(14, 0);
/*      */     
/*  366 */     Date date2 = c.getTime();
/*  367 */     c.set(1970, 0, 1, 0, 0, 0);
/*  368 */     Date date3 = c.getTime();
/*  369 */     c.set(1918, 10, 11, 11, 0, 0);
/*  370 */     Date date4 = c.getTime();
/*  371 */     c.set(1900, 0, 2, 0, 0, 0);
/*  372 */     Date date5 = c.getTime();
/*  373 */     c.set(1901, 0, 1, 0, 0, 0);
/*  374 */     Date date6 = c.getTime();
/*  375 */     c.set(1900, 4, 31, 0, 0, 0);
/*  376 */     Date date7 = c.getTime();
/*  377 */     c.set(1900, 1, 1, 0, 0, 0);
/*  378 */     Date date8 = c.getTime();
/*  379 */     c.set(1900, 0, 31, 0, 0, 0);
/*  380 */     Date date9 = c.getTime();
/*  381 */     c.set(1900, 2, 1, 0, 0, 0);
/*  382 */     Date date10 = c.getTime();
/*  383 */     c.set(1900, 1, 27, 0, 0, 0);
/*  384 */     Date date11 = c.getTime();
/*  385 */     c.set(1900, 1, 28, 0, 0, 0);
/*  386 */     Date date12 = c.getTime();
/*  387 */     c.set(1980, 5, 31, 12, 0, 0);
/*  388 */     Date date13 = c.getTime();
/*  389 */     c.set(1066, 9, 14, 0, 0, 0);
/*  390 */     Date date14 = c.getTime();
/*      */ 
/*      */     
/*  393 */     SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy HH:mm:ss.SSS");
/*  394 */     sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
/*  395 */     Label l = new Label(0, 0, "All dates are " + sdf.format(date), (CellFormat)wrappedText);
/*      */     
/*  397 */     s.addCell((WritableCell)l);
/*      */     
/*  399 */     l = new Label(0, 1, "Built in formats", (CellFormat)wrappedText);
/*      */     
/*  401 */     s.addCell((WritableCell)l);
/*      */     
/*  403 */     l = new Label(2, 1, "Custom formats");
/*  404 */     s.addCell((WritableCell)l);
/*      */     
/*  406 */     WritableCellFormat cf1 = new WritableCellFormat(DateFormats.FORMAT1);
/*  407 */     DateTime dt = new DateTime(0, 2, date, (CellFormat)cf1, DateTime.GMT);
/*  408 */     s.addCell((WritableCell)dt);
/*      */     
/*  410 */     cf1 = new WritableCellFormat(DateFormats.FORMAT2);
/*  411 */     dt = new DateTime(0, 3, date, (CellFormat)cf1, DateTime.GMT);
/*  412 */     s.addCell((WritableCell)dt);
/*      */     
/*  414 */     cf1 = new WritableCellFormat(DateFormats.FORMAT3);
/*  415 */     dt = new DateTime(0, 4, date, (CellFormat)cf1);
/*  416 */     s.addCell((WritableCell)dt);
/*      */     
/*  418 */     cf1 = new WritableCellFormat(DateFormats.FORMAT4);
/*  419 */     dt = new DateTime(0, 5, date, (CellFormat)cf1);
/*  420 */     s.addCell((WritableCell)dt);
/*      */     
/*  422 */     cf1 = new WritableCellFormat(DateFormats.FORMAT5);
/*  423 */     dt = new DateTime(0, 6, date, (CellFormat)cf1);
/*  424 */     s.addCell((WritableCell)dt);
/*      */     
/*  426 */     cf1 = new WritableCellFormat(DateFormats.FORMAT6);
/*  427 */     dt = new DateTime(0, 7, date, (CellFormat)cf1);
/*  428 */     s.addCell((WritableCell)dt);
/*      */     
/*  430 */     cf1 = new WritableCellFormat(DateFormats.FORMAT7);
/*  431 */     dt = new DateTime(0, 8, date, (CellFormat)cf1, DateTime.GMT);
/*  432 */     s.addCell((WritableCell)dt);
/*      */     
/*  434 */     cf1 = new WritableCellFormat(DateFormats.FORMAT8);
/*  435 */     dt = new DateTime(0, 9, date, (CellFormat)cf1, DateTime.GMT);
/*  436 */     s.addCell((WritableCell)dt);
/*      */     
/*  438 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  439 */     dt = new DateTime(0, 10, date, (CellFormat)cf1, DateTime.GMT);
/*  440 */     s.addCell((WritableCell)dt);
/*      */     
/*  442 */     cf1 = new WritableCellFormat(DateFormats.FORMAT10);
/*  443 */     dt = new DateTime(0, 11, date, (CellFormat)cf1, DateTime.GMT);
/*  444 */     s.addCell((WritableCell)dt);
/*      */     
/*  446 */     cf1 = new WritableCellFormat(DateFormats.FORMAT11);
/*  447 */     dt = new DateTime(0, 12, date, (CellFormat)cf1, DateTime.GMT);
/*  448 */     s.addCell((WritableCell)dt);
/*      */     
/*  450 */     cf1 = new WritableCellFormat(DateFormats.FORMAT12);
/*  451 */     dt = new DateTime(0, 13, date, (CellFormat)cf1, DateTime.GMT);
/*  452 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  455 */     DateFormat df = new DateFormat("dd MM yyyy");
/*  456 */     cf1 = new WritableCellFormat((DisplayFormat)df);
/*  457 */     l = new Label(2, 2, "dd MM yyyy");
/*  458 */     s.addCell((WritableCell)l);
/*      */     
/*  460 */     dt = new DateTime(3, 2, date, (CellFormat)cf1, DateTime.GMT);
/*  461 */     s.addCell((WritableCell)dt);
/*      */     
/*  463 */     df = new DateFormat("dd MMM yyyy");
/*  464 */     cf1 = new WritableCellFormat((DisplayFormat)df);
/*  465 */     l = new Label(2, 3, "dd MMM yyyy");
/*  466 */     s.addCell((WritableCell)l);
/*      */     
/*  468 */     dt = new DateTime(3, 3, date, (CellFormat)cf1, DateTime.GMT);
/*  469 */     s.addCell((WritableCell)dt);
/*      */     
/*  471 */     df = new DateFormat("hh:mm");
/*  472 */     cf1 = new WritableCellFormat((DisplayFormat)df);
/*  473 */     l = new Label(2, 4, "hh:mm");
/*  474 */     s.addCell((WritableCell)l);
/*      */     
/*  476 */     dt = new DateTime(3, 4, date, (CellFormat)cf1, DateTime.GMT);
/*  477 */     s.addCell((WritableCell)dt);
/*      */     
/*  479 */     df = new DateFormat("hh:mm:ss");
/*  480 */     cf1 = new WritableCellFormat((DisplayFormat)df);
/*  481 */     l = new Label(2, 5, "hh:mm:ss");
/*  482 */     s.addCell((WritableCell)l);
/*      */     
/*  484 */     dt = new DateTime(3, 5, date, (CellFormat)cf1, DateTime.GMT);
/*  485 */     s.addCell((WritableCell)dt);
/*      */     
/*  487 */     df = new DateFormat("H:mm:ss a");
/*  488 */     cf1 = new WritableCellFormat((DisplayFormat)df);
/*  489 */     l = new Label(2, 5, "H:mm:ss a");
/*  490 */     s.addCell((WritableCell)l);
/*      */     
/*  492 */     dt = new DateTime(3, 5, date, (CellFormat)cf1, DateTime.GMT);
/*  493 */     s.addCell((WritableCell)dt);
/*  494 */     dt = new DateTime(4, 5, date13, (CellFormat)cf1, DateTime.GMT);
/*  495 */     s.addCell((WritableCell)dt);
/*      */     
/*  497 */     df = new DateFormat("mm:ss.SSS");
/*  498 */     cf1 = new WritableCellFormat((DisplayFormat)df);
/*  499 */     l = new Label(2, 6, "mm:ss.SSS");
/*  500 */     s.addCell((WritableCell)l);
/*      */     
/*  502 */     dt = new DateTime(3, 6, date, (CellFormat)cf1, DateTime.GMT);
/*  503 */     s.addCell((WritableCell)dt);
/*      */     
/*  505 */     df = new DateFormat("hh:mm:ss a");
/*  506 */     cf1 = new WritableCellFormat((DisplayFormat)df);
/*  507 */     l = new Label(2, 7, "hh:mm:ss a");
/*  508 */     s.addCell((WritableCell)l);
/*      */     
/*  510 */     dt = new DateTime(4, 7, date13, (CellFormat)cf1, DateTime.GMT);
/*  511 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */ 
/*      */     
/*  515 */     l = new Label(0, 16, "Zero date " + sdf.format(date2), (CellFormat)wrappedText);
/*      */     
/*  517 */     s.addCell((WritableCell)l);
/*      */     
/*  519 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  520 */     dt = new DateTime(0, 17, date2, (CellFormat)cf1, DateTime.GMT);
/*  521 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  524 */     l = new Label(3, 16, "Zero date + 1 " + sdf.format(date5), (CellFormat)wrappedText);
/*      */     
/*  526 */     s.addCell((WritableCell)l);
/*      */     
/*  528 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  529 */     dt = new DateTime(3, 17, date5, (CellFormat)cf1, DateTime.GMT);
/*  530 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  533 */     l = new Label(3, 19, sdf.format(date6), (CellFormat)wrappedText);
/*      */     
/*  535 */     s.addCell((WritableCell)l);
/*      */     
/*  537 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  538 */     dt = new DateTime(3, 20, date6, (CellFormat)cf1, DateTime.GMT);
/*  539 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  542 */     l = new Label(3, 22, sdf.format(date7), (CellFormat)wrappedText);
/*      */     
/*  544 */     s.addCell((WritableCell)l);
/*      */     
/*  546 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  547 */     dt = new DateTime(3, 23, date7, (CellFormat)cf1, DateTime.GMT);
/*  548 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  551 */     l = new Label(3, 25, sdf.format(date8), (CellFormat)wrappedText);
/*      */     
/*  553 */     s.addCell((WritableCell)l);
/*      */     
/*  555 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  556 */     dt = new DateTime(3, 26, date8, (CellFormat)cf1, DateTime.GMT);
/*  557 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  560 */     l = new Label(3, 28, sdf.format(date9), (CellFormat)wrappedText);
/*      */     
/*  562 */     s.addCell((WritableCell)l);
/*      */     
/*  564 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  565 */     dt = new DateTime(3, 29, date9, (CellFormat)cf1, DateTime.GMT);
/*  566 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  569 */     l = new Label(3, 28, sdf.format(date9), (CellFormat)wrappedText);
/*      */     
/*  571 */     s.addCell((WritableCell)l);
/*      */     
/*  573 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  574 */     dt = new DateTime(3, 29, date9, (CellFormat)cf1, DateTime.GMT);
/*  575 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  578 */     l = new Label(3, 31, sdf.format(date10), (CellFormat)wrappedText);
/*      */     
/*  580 */     s.addCell((WritableCell)l);
/*      */     
/*  582 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  583 */     dt = new DateTime(3, 32, date10, (CellFormat)cf1, DateTime.GMT);
/*  584 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  587 */     l = new Label(3, 34, sdf.format(date11), (CellFormat)wrappedText);
/*      */     
/*  589 */     s.addCell((WritableCell)l);
/*      */     
/*  591 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  592 */     dt = new DateTime(3, 35, date11, (CellFormat)cf1, DateTime.GMT);
/*  593 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  596 */     l = new Label(3, 37, sdf.format(date12), (CellFormat)wrappedText);
/*      */     
/*  598 */     s.addCell((WritableCell)l);
/*      */     
/*  600 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  601 */     dt = new DateTime(3, 38, date12, (CellFormat)cf1, DateTime.GMT);
/*  602 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  605 */     l = new Label(0, 19, "Zero UTC date " + sdf.format(date3), (CellFormat)wrappedText);
/*      */     
/*  607 */     s.addCell((WritableCell)l);
/*      */     
/*  609 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  610 */     dt = new DateTime(0, 20, date3, (CellFormat)cf1, DateTime.GMT);
/*  611 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  614 */     l = new Label(0, 22, "Armistice date " + sdf.format(date4), (CellFormat)wrappedText);
/*      */     
/*  616 */     s.addCell((WritableCell)l);
/*      */     
/*  618 */     cf1 = new WritableCellFormat(DateFormats.FORMAT9);
/*  619 */     dt = new DateTime(0, 23, date4, (CellFormat)cf1, DateTime.GMT);
/*  620 */     s.addCell((WritableCell)dt);
/*      */ 
/*      */     
/*  623 */     l = new Label(0, 25, "Battle of Hastings " + sdf.format(date14), (CellFormat)wrappedText);
/*      */     
/*  625 */     s.addCell((WritableCell)l);
/*      */     
/*  627 */     cf1 = new WritableCellFormat(DateFormats.FORMAT2);
/*  628 */     dt = new DateTime(0, 26, date14, (CellFormat)cf1, DateTime.GMT);
/*  629 */     s.addCell((WritableCell)dt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeLabelFormatSheet(WritableSheet s1) throws WriteException {
/*  640 */     s1.setColumnView(0, 60);
/*      */     
/*  642 */     Label lr = new Label(0, 0, "Arial Fonts");
/*  643 */     s1.addCell((WritableCell)lr);
/*      */     
/*  645 */     lr = new Label(1, 0, "10pt");
/*  646 */     s1.addCell((WritableCell)lr);
/*      */     
/*  648 */     lr = new Label(2, 0, "Normal");
/*  649 */     s1.addCell((WritableCell)lr);
/*      */     
/*  651 */     lr = new Label(3, 0, "12pt");
/*  652 */     s1.addCell((WritableCell)lr);
/*      */     
/*  654 */     WritableFont arial12pt = new WritableFont(WritableFont.ARIAL, 12);
/*  655 */     WritableCellFormat arial12format = new WritableCellFormat(arial12pt);
/*  656 */     arial12format.setWrap(true);
/*  657 */     lr = new Label(4, 0, "Normal", (CellFormat)arial12format);
/*  658 */     s1.addCell((WritableCell)lr);
/*      */     
/*  660 */     WritableFont arial10ptBold = new WritableFont(WritableFont.ARIAL, 10, WritableFont.BOLD);
/*      */     
/*  662 */     WritableCellFormat arial10BoldFormat = new WritableCellFormat(arial10ptBold);
/*      */     
/*  664 */     lr = new Label(2, 2, "BOLD", (CellFormat)arial10BoldFormat);
/*  665 */     s1.addCell((WritableCell)lr);
/*      */     
/*  667 */     WritableFont arial12ptBold = new WritableFont(WritableFont.ARIAL, 12, WritableFont.BOLD);
/*      */     
/*  669 */     WritableCellFormat arial12BoldFormat = new WritableCellFormat(arial12ptBold);
/*      */     
/*  671 */     lr = new Label(4, 2, "BOLD", (CellFormat)arial12BoldFormat);
/*  672 */     s1.addCell((WritableCell)lr);
/*      */     
/*  674 */     WritableFont arial10ptItalic = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, true);
/*      */     
/*  676 */     WritableCellFormat arial10ItalicFormat = new WritableCellFormat(arial10ptItalic);
/*      */     
/*  678 */     lr = new Label(2, 4, "Italic", (CellFormat)arial10ItalicFormat);
/*  679 */     s1.addCell((WritableCell)lr);
/*      */     
/*  681 */     WritableFont arial12ptItalic = new WritableFont(WritableFont.ARIAL, 12, WritableFont.NO_BOLD, true);
/*      */     
/*  683 */     WritableCellFormat arial12ptItalicFormat = new WritableCellFormat(arial12ptItalic);
/*      */     
/*  685 */     lr = new Label(4, 4, "Italic", (CellFormat)arial12ptItalicFormat);
/*  686 */     s1.addCell((WritableCell)lr);
/*      */     
/*  688 */     WritableFont times10pt = new WritableFont(WritableFont.TIMES, 10);
/*  689 */     WritableCellFormat times10format = new WritableCellFormat(times10pt);
/*  690 */     lr = new Label(0, 7, "Times Fonts", (CellFormat)times10format);
/*  691 */     s1.addCell((WritableCell)lr);
/*      */     
/*  693 */     lr = new Label(1, 7, "10pt", (CellFormat)times10format);
/*  694 */     s1.addCell((WritableCell)lr);
/*      */     
/*  696 */     lr = new Label(2, 7, "Normal", (CellFormat)times10format);
/*  697 */     s1.addCell((WritableCell)lr);
/*      */     
/*  699 */     lr = new Label(3, 7, "12pt", (CellFormat)times10format);
/*  700 */     s1.addCell((WritableCell)lr);
/*      */     
/*  702 */     WritableFont times12pt = new WritableFont(WritableFont.TIMES, 12);
/*  703 */     WritableCellFormat times12format = new WritableCellFormat(times12pt);
/*  704 */     lr = new Label(4, 7, "Normal", (CellFormat)times12format);
/*  705 */     s1.addCell((WritableCell)lr);
/*      */     
/*  707 */     WritableFont times10ptBold = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD);
/*      */     
/*  709 */     WritableCellFormat times10BoldFormat = new WritableCellFormat(times10ptBold);
/*      */     
/*  711 */     lr = new Label(2, 9, "BOLD", (CellFormat)times10BoldFormat);
/*  712 */     s1.addCell((WritableCell)lr);
/*      */     
/*  714 */     WritableFont times12ptBold = new WritableFont(WritableFont.TIMES, 12, WritableFont.BOLD);
/*      */     
/*  716 */     WritableCellFormat times12BoldFormat = new WritableCellFormat(times12ptBold);
/*      */     
/*  718 */     lr = new Label(4, 9, "BOLD", (CellFormat)times12BoldFormat);
/*  719 */     s1.addCell((WritableCell)lr);
/*      */ 
/*      */     
/*  722 */     s1.setColumnView(6, 22);
/*  723 */     s1.setColumnView(7, 22);
/*  724 */     s1.setColumnView(8, 22);
/*  725 */     s1.setColumnView(9, 22);
/*      */     
/*  727 */     lr = new Label(0, 11, "Underlining");
/*  728 */     s1.addCell((WritableCell)lr);
/*      */     
/*  730 */     WritableFont arial10ptUnderline = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.SINGLE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  736 */     WritableCellFormat arialUnderline = new WritableCellFormat(arial10ptUnderline);
/*      */     
/*  738 */     lr = new Label(6, 11, "Underline", (CellFormat)arialUnderline);
/*  739 */     s1.addCell((WritableCell)lr);
/*      */     
/*  741 */     WritableFont arial10ptDoubleUnderline = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.DOUBLE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  747 */     WritableCellFormat arialDoubleUnderline = new WritableCellFormat(arial10ptDoubleUnderline);
/*      */     
/*  749 */     lr = new Label(7, 11, "Double Underline", (CellFormat)arialDoubleUnderline);
/*  750 */     s1.addCell((WritableCell)lr);
/*      */     
/*  752 */     WritableFont arial10ptSingleAcc = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.SINGLE_ACCOUNTING);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  758 */     WritableCellFormat arialSingleAcc = new WritableCellFormat(arial10ptSingleAcc);
/*      */     
/*  760 */     lr = new Label(8, 11, "Single Accounting Underline", (CellFormat)arialSingleAcc);
/*  761 */     s1.addCell((WritableCell)lr);
/*      */     
/*  763 */     WritableFont arial10ptDoubleAcc = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.DOUBLE_ACCOUNTING);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  769 */     WritableCellFormat arialDoubleAcc = new WritableCellFormat(arial10ptDoubleAcc);
/*      */     
/*  771 */     lr = new Label(9, 11, "Double Accounting Underline", (CellFormat)arialDoubleAcc);
/*  772 */     s1.addCell((WritableCell)lr);
/*      */     
/*  774 */     WritableFont times14ptBoldUnderline = new WritableFont(WritableFont.TIMES, 14, WritableFont.BOLD, false, UnderlineStyle.SINGLE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  780 */     WritableCellFormat timesBoldUnderline = new WritableCellFormat(times14ptBoldUnderline);
/*      */     
/*  782 */     lr = new Label(6, 12, "Times 14 Bold Underline", (CellFormat)timesBoldUnderline);
/*  783 */     s1.addCell((WritableCell)lr);
/*      */     
/*  785 */     WritableFont arial18ptBoldItalicUnderline = new WritableFont(WritableFont.ARIAL, 18, WritableFont.BOLD, true, UnderlineStyle.SINGLE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  791 */     WritableCellFormat arialBoldItalicUnderline = new WritableCellFormat(arial18ptBoldItalicUnderline);
/*      */     
/*  793 */     lr = new Label(6, 13, "Arial 18 Bold Italic Underline", (CellFormat)arialBoldItalicUnderline);
/*      */     
/*  795 */     s1.addCell((WritableCell)lr);
/*      */     
/*  797 */     lr = new Label(0, 15, "Script styles");
/*  798 */     s1.addCell((WritableCell)lr);
/*      */     
/*  800 */     WritableFont superscript = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.SUPERSCRIPT);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  808 */     WritableCellFormat superscriptFormat = new WritableCellFormat(superscript);
/*      */     
/*  810 */     lr = new Label(1, 15, "superscript", (CellFormat)superscriptFormat);
/*  811 */     s1.addCell((WritableCell)lr);
/*      */     
/*  813 */     WritableFont subscript = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.SUBSCRIPT);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  821 */     WritableCellFormat subscriptFormat = new WritableCellFormat(subscript);
/*      */     
/*  823 */     lr = new Label(2, 15, "subscript", (CellFormat)subscriptFormat);
/*  824 */     s1.addCell((WritableCell)lr);
/*      */     
/*  826 */     lr = new Label(0, 17, "Colours");
/*  827 */     s1.addCell((WritableCell)lr);
/*      */     
/*  829 */     WritableFont red = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.RED);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  835 */     WritableCellFormat redFormat = new WritableCellFormat(red);
/*  836 */     lr = new Label(2, 17, "Red", (CellFormat)redFormat);
/*  837 */     s1.addCell((WritableCell)lr);
/*      */     
/*  839 */     WritableFont blue = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLUE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  845 */     WritableCellFormat blueFormat = new WritableCellFormat(blue);
/*  846 */     lr = new Label(2, 18, "Blue", (CellFormat)blueFormat);
/*  847 */     s1.addCell((WritableCell)lr);
/*      */     
/*  849 */     WritableFont lime = new WritableFont(WritableFont.ARIAL);
/*  850 */     lime.setColour(Colour.LIME);
/*  851 */     WritableCellFormat limeFormat = new WritableCellFormat(lime);
/*  852 */     limeFormat.setWrap(true);
/*  853 */     lr = new Label(4, 18, "Modified palette - was lime, now red", (CellFormat)limeFormat);
/*  854 */     s1.addCell((WritableCell)lr);
/*      */     
/*  856 */     WritableCellFormat greyBackground = new WritableCellFormat();
/*  857 */     greyBackground.setWrap(true);
/*  858 */     greyBackground.setBackground(Colour.GRAY_50);
/*  859 */     lr = new Label(2, 19, "Grey background", (CellFormat)greyBackground);
/*  860 */     s1.addCell((WritableCell)lr);
/*      */     
/*  862 */     WritableFont yellow = new WritableFont(WritableFont.ARIAL, 10, WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.YELLOW);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  868 */     WritableCellFormat yellowOnBlue = new WritableCellFormat(yellow);
/*  869 */     yellowOnBlue.setWrap(true);
/*  870 */     yellowOnBlue.setBackground(Colour.BLUE);
/*  871 */     lr = new Label(2, 20, "Blue background, yellow foreground", (CellFormat)yellowOnBlue);
/*  872 */     s1.addCell((WritableCell)lr);
/*      */     
/*  874 */     lr = new Label(0, 22, "Null label");
/*  875 */     s1.addCell((WritableCell)lr);
/*      */     
/*  877 */     lr = new Label(2, 22, null);
/*  878 */     s1.addCell((WritableCell)lr);
/*      */     
/*  880 */     lr = new Label(0, 24, "A very long label, more than 255 characters\nRejoice O shores\nSing O bells\nBut I with mournful tread\nWalk the deck my captain lies\nFallen cold and dead\nSummer surprised, coming over the Starnbergersee\nWith a shower of rain. We stopped in the Colonnade\nA very long label, more than 255 characters\nRejoice O shores\nSing O bells\nBut I with mournful tread\nWalk the deck my captain lies\nFallen cold and dead\nSummer surprised, coming over the Starnbergersee\nWith a shower of rain. We stopped in the Colonnade\nA very long label, more than 255 characters\nRejoice O shores\nSing O bells\nBut I with mournful tread\nWalk the deck my captain lies\nFallen cold and dead\nSummer surprised, coming over the Starnbergersee\nWith a shower of rain. We stopped in the Colonnade\nA very long label, more than 255 characters\nRejoice O shores\nSing O bells\nBut I with mournful tread\nWalk the deck my captain lies\nFallen cold and dead\nSummer surprised, coming over the Starnbergersee\nWith a shower of rain. We stopped in the Colonnade\nAnd sat and drank coffee an talked for an hour\n", (CellFormat)arial12format);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  913 */     s1.addCell((WritableCell)lr);
/*      */     
/*  915 */     WritableCellFormat vertical = new WritableCellFormat();
/*  916 */     vertical.setOrientation(Orientation.VERTICAL);
/*  917 */     lr = new Label(0, 26, "Vertical orientation", (CellFormat)vertical);
/*  918 */     s1.addCell((WritableCell)lr);
/*      */ 
/*      */     
/*  921 */     WritableCellFormat plus_90 = new WritableCellFormat();
/*  922 */     plus_90.setOrientation(Orientation.PLUS_90);
/*  923 */     lr = new Label(1, 26, "Plus 90", (CellFormat)plus_90);
/*  924 */     s1.addCell((WritableCell)lr);
/*      */ 
/*      */     
/*  927 */     WritableCellFormat minus_90 = new WritableCellFormat();
/*  928 */     minus_90.setOrientation(Orientation.MINUS_90);
/*  929 */     lr = new Label(2, 26, "Minus 90", (CellFormat)minus_90);
/*  930 */     s1.addCell((WritableCell)lr);
/*      */     
/*  932 */     lr = new Label(0, 28, "Modified row height");
/*  933 */     s1.addCell((WritableCell)lr);
/*  934 */     s1.setRowView(28, 24);
/*      */     
/*  936 */     lr = new Label(0, 29, "Collapsed row");
/*  937 */     s1.addCell((WritableCell)lr);
/*  938 */     s1.setRowView(29, true);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  943 */       Label label = new Label(0, 30, "Hyperlink to home page");
/*  944 */       s1.addCell((WritableCell)label);
/*      */       
/*  946 */       URL url = new URL("http://www.andykhan.com/jexcelapi");
/*  947 */       WritableHyperlink wh = new WritableHyperlink(0, 30, 8, 31, url);
/*  948 */       s1.addHyperlink(wh);
/*      */ 
/*      */       
/*  951 */       WritableHyperlink wh2 = new WritableHyperlink(7, 30, 9, 31, url);
/*  952 */       s1.addHyperlink(wh2);
/*      */       
/*  954 */       label = new Label(4, 2, "File hyperlink to documentation");
/*  955 */       s1.addCell((WritableCell)label);
/*      */       
/*  957 */       File file = new File("../jexcelapi/docs/index.html");
/*  958 */       wh = new WritableHyperlink(0, 32, 8, 32, file);
/*  959 */       s1.addHyperlink(wh);
/*      */ 
/*      */       
/*  962 */       wh = new WritableHyperlink(0, 34, 8, 34, "Link to another cell", s1, 0, 180, 1, 181);
/*      */ 
/*      */ 
/*      */       
/*  966 */       s1.addHyperlink(wh);
/*      */       
/*  968 */       file = new File("\\\\localhost\\file.txt");
/*  969 */       wh = new WritableHyperlink(0, 36, 8, 36, file);
/*  970 */       s1.addHyperlink(wh);
/*      */ 
/*      */       
/*  973 */       url = new URL("http://www.amazon.co.uk/exec/obidos/ASIN/0571058086/qid=1099836249/sr=1-3/ref=sr_1_11_3/202-6017285-1620664");
/*      */       
/*  975 */       wh = new WritableHyperlink(0, 38, 0, 38, url);
/*  976 */       s1.addHyperlink(wh);
/*      */     }
/*  978 */     catch (MalformedURLException e) {
/*      */       
/*  980 */       System.err.println(e.toString());
/*      */     } 
/*      */ 
/*      */     
/*  984 */     Label l = new Label(5, 35, "Merged cells", (CellFormat)timesBoldUnderline);
/*  985 */     s1.mergeCells(5, 35, 8, 37);
/*  986 */     s1.addCell((WritableCell)l);
/*      */     
/*  988 */     l = new Label(5, 38, "More merged cells");
/*  989 */     s1.addCell((WritableCell)l);
/*  990 */     Range r = s1.mergeCells(5, 38, 8, 41);
/*  991 */     s1.insertRow(40);
/*  992 */     s1.removeRow(39);
/*  993 */     s1.unmergeCells(r);
/*      */ 
/*      */     
/*  996 */     WritableCellFormat wcf = new WritableCellFormat();
/*  997 */     wcf.setAlignment(Alignment.CENTRE);
/*  998 */     l = new Label(5, 42, "Centred across merged cells", (CellFormat)wcf);
/*  999 */     s1.addCell((WritableCell)l);
/* 1000 */     s1.mergeCells(5, 42, 10, 42);
/*      */     
/* 1002 */     wcf = new WritableCellFormat();
/* 1003 */     wcf.setBorder(Border.ALL, BorderLineStyle.THIN);
/* 1004 */     wcf.setBackground(Colour.GRAY_25);
/* 1005 */     l = new Label(3, 44, "Merged with border", (CellFormat)wcf);
/* 1006 */     s1.addCell((WritableCell)l);
/* 1007 */     s1.mergeCells(3, 44, 4, 46);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1024 */     WritableFont courier10ptFont = new WritableFont(WritableFont.COURIER, 10);
/* 1025 */     WritableCellFormat courier10pt = new WritableCellFormat(courier10ptFont);
/* 1026 */     l = new Label(0, 49, "Courier fonts", (CellFormat)courier10pt);
/* 1027 */     s1.addCell((WritableCell)l);
/*      */     
/* 1029 */     WritableFont tahoma12ptFont = new WritableFont(WritableFont.TAHOMA, 12);
/* 1030 */     WritableCellFormat tahoma12pt = new WritableCellFormat(tahoma12ptFont);
/* 1031 */     l = new Label(0, 50, "Tahoma fonts", (CellFormat)tahoma12pt);
/* 1032 */     s1.addCell((WritableCell)l);
/*      */     
/* 1034 */     WritableFont.FontName wingdingsFont = WritableFont.createFont("Wingdings 2");
/*      */     
/* 1036 */     WritableFont wingdings210ptFont = new WritableFont(wingdingsFont, 10);
/* 1037 */     WritableCellFormat wingdings210pt = new WritableCellFormat(wingdings210ptFont);
/*      */     
/* 1039 */     l = new Label(0, 51, "Bespoke Windgdings 2", (CellFormat)wingdings210pt);
/* 1040 */     s1.addCell((WritableCell)l);
/*      */     
/* 1042 */     WritableCellFormat shrinkToFit = new WritableCellFormat(times12pt);
/* 1043 */     shrinkToFit.setShrinkToFit(true);
/* 1044 */     l = new Label(3, 53, "Shrunk to fit", (CellFormat)shrinkToFit);
/* 1045 */     s1.addCell((WritableCell)l);
/*      */     
/* 1047 */     l = new Label(3, 55, "Some long wrapped text in a merged cell", (CellFormat)arial12format);
/*      */     
/* 1049 */     s1.addCell((WritableCell)l);
/* 1050 */     s1.mergeCells(3, 55, 4, 55);
/*      */     
/* 1052 */     l = new Label(0, 57, "A cell with a comment");
/* 1053 */     WritableCellFeatures cellFeatures = new WritableCellFeatures();
/* 1054 */     cellFeatures.setComment("the cell comment");
/* 1055 */     l.setCellFeatures(cellFeatures);
/* 1056 */     s1.addCell((WritableCell)l);
/*      */     
/* 1058 */     l = new Label(0, 59, "A cell with a long comment");
/*      */     
/* 1060 */     cellFeatures = new WritableCellFeatures();
/* 1061 */     cellFeatures.setComment("a very long cell comment indeed that won't fit inside a standard comment box, so a larger comment box is used instead", 5.0D, 6.0D);
/*      */ 
/*      */ 
/*      */     
/* 1065 */     l.setCellFeatures(cellFeatures);
/* 1066 */     s1.addCell((WritableCell)l);
/*      */     
/* 1068 */     WritableCellFormat indented = new WritableCellFormat(times12pt);
/* 1069 */     indented.setIndentation(4);
/* 1070 */     l = new Label(0, 61, "Some indented text", (CellFormat)indented);
/* 1071 */     s1.addCell((WritableCell)l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeBordersSheet(WritableSheet s) throws WriteException {
/* 1082 */     s.getSettings().setProtected(true);
/*      */     
/* 1084 */     s.setColumnView(1, 15);
/* 1085 */     s.setColumnView(2, 15);
/* 1086 */     s.setColumnView(4, 15);
/* 1087 */     WritableCellFormat thickLeft = new WritableCellFormat();
/* 1088 */     thickLeft.setBorder(Border.LEFT, BorderLineStyle.THICK);
/* 1089 */     Label lr = new Label(1, 0, "Thick left", (CellFormat)thickLeft);
/* 1090 */     s.addCell((WritableCell)lr);
/*      */     
/* 1092 */     WritableCellFormat dashedRight = new WritableCellFormat();
/* 1093 */     dashedRight.setBorder(Border.RIGHT, BorderLineStyle.DASHED);
/* 1094 */     lr = new Label(2, 0, "Dashed right", (CellFormat)dashedRight);
/* 1095 */     s.addCell((WritableCell)lr);
/*      */     
/* 1097 */     WritableCellFormat doubleTop = new WritableCellFormat();
/* 1098 */     doubleTop.setBorder(Border.TOP, BorderLineStyle.DOUBLE);
/* 1099 */     lr = new Label(1, 2, "Double top", (CellFormat)doubleTop);
/* 1100 */     s.addCell((WritableCell)lr);
/*      */     
/* 1102 */     WritableCellFormat hairBottom = new WritableCellFormat();
/* 1103 */     hairBottom.setBorder(Border.BOTTOM, BorderLineStyle.HAIR);
/* 1104 */     lr = new Label(2, 2, "Hair bottom", (CellFormat)hairBottom);
/* 1105 */     s.addCell((WritableCell)lr);
/*      */     
/* 1107 */     WritableCellFormat allThin = new WritableCellFormat();
/* 1108 */     allThin.setBorder(Border.ALL, BorderLineStyle.THIN);
/* 1109 */     lr = new Label(4, 2, "All thin", (CellFormat)allThin);
/* 1110 */     s.addCell((WritableCell)lr);
/*      */     
/* 1112 */     WritableCellFormat twoBorders = new WritableCellFormat();
/* 1113 */     twoBorders.setBorder(Border.TOP, BorderLineStyle.THICK);
/* 1114 */     twoBorders.setBorder(Border.LEFT, BorderLineStyle.THICK);
/* 1115 */     lr = new Label(6, 2, "Two borders", (CellFormat)twoBorders);
/* 1116 */     s.addCell((WritableCell)lr);
/*      */ 
/*      */     
/* 1119 */     lr = new Label(20, 20, "Dislocated cell - after a page break");
/* 1120 */     s.addCell((WritableCell)lr);
/*      */ 
/*      */     
/* 1123 */     s.getSettings().setPaperSize(PaperSize.A3);
/* 1124 */     s.getSettings().setOrientation(PageOrientation.LANDSCAPE);
/* 1125 */     s.getSettings().setHeaderMargin(2.0D);
/* 1126 */     s.getSettings().setFooterMargin(2.0D);
/*      */     
/* 1128 */     s.getSettings().setTopMargin(3.0D);
/* 1129 */     s.getSettings().setBottomMargin(3.0D);
/*      */ 
/*      */     
/* 1132 */     HeaderFooter header = new HeaderFooter();
/* 1133 */     header.getCentre().append("Page Header");
/* 1134 */     s.getSettings().setHeader(header);
/*      */     
/* 1136 */     HeaderFooter footer = new HeaderFooter();
/* 1137 */     footer.getRight().append("page ");
/* 1138 */     footer.getRight().appendPageNumber();
/* 1139 */     s.getSettings().setFooter(footer);
/*      */ 
/*      */     
/* 1142 */     s.addRowPageBreak(18);
/* 1143 */     s.insertRow(17);
/* 1144 */     s.insertRow(17);
/* 1145 */     s.removeRow(17);
/*      */ 
/*      */     
/* 1148 */     s.addRowPageBreak(30);
/*      */ 
/*      */     
/* 1151 */     lr = new Label(10, 1, "Hidden column");
/* 1152 */     s.addCell((WritableCell)lr);
/*      */     
/* 1154 */     lr = new Label(3, 8, "Hidden row");
/* 1155 */     s.addCell((WritableCell)lr);
/* 1156 */     s.setRowView(8, true);
/*      */     
/* 1158 */     WritableCellFormat allThickRed = new WritableCellFormat();
/* 1159 */     allThickRed.setBorder(Border.ALL, BorderLineStyle.THICK, Colour.RED);
/* 1160 */     lr = new Label(1, 5, "All thick red", (CellFormat)allThickRed);
/* 1161 */     s.addCell((WritableCell)lr);
/*      */     
/* 1163 */     WritableCellFormat topBottomBlue = new WritableCellFormat();
/* 1164 */     topBottomBlue.setBorder(Border.TOP, BorderLineStyle.THIN, Colour.BLUE);
/* 1165 */     topBottomBlue.setBorder(Border.BOTTOM, BorderLineStyle.THIN, Colour.BLUE);
/* 1166 */     lr = new Label(4, 5, "Top and bottom blue", (CellFormat)topBottomBlue);
/* 1167 */     s.addCell((WritableCell)lr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeLabelsSheet(WritableSheet ws) throws WriteException {
/* 1175 */     ws.getSettings().setProtected(true);
/* 1176 */     ws.getSettings().setPassword("jxl");
/* 1177 */     ws.getSettings().setVerticalFreeze(5);
/*      */     
/* 1179 */     WritableFont wf = new WritableFont(WritableFont.ARIAL, 12);
/* 1180 */     wf.setItalic(true);
/*      */     
/* 1182 */     WritableCellFormat wcf = new WritableCellFormat(wf);
/*      */     
/* 1184 */     CellView cv = new CellView();
/* 1185 */     cv.setSize(6400);
/* 1186 */     cv.setFormat((CellFormat)wcf);
/* 1187 */     ws.setColumnView(0, cv);
/* 1188 */     ws.setColumnView(1, 15);
/*      */     
/* 1190 */     for (int i = 0; i < 61; i++) {
/*      */       
/* 1192 */       Label l1 = new Label(0, i, "Common Label");
/* 1193 */       Label l2 = new Label(1, i, "Distinct label number " + i);
/* 1194 */       ws.addCell((WritableCell)l1);
/* 1195 */       ws.addCell((WritableCell)l2);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1201 */     Label l3 = new Label(0, 61, "Common Label", (CellFormat)wcf);
/* 1202 */     Label l4 = new Label(1, 61, "1-1234567890", (CellFormat)wcf);
/* 1203 */     Label l5 = new Label(2, 61, "2-1234567890", (CellFormat)wcf);
/* 1204 */     ws.addCell((WritableCell)l3);
/* 1205 */     ws.addCell((WritableCell)l4);
/* 1206 */     ws.addCell((WritableCell)l5);
/*      */     
/* 1208 */     for (int j = 62; j < 200; j++) {
/*      */       
/* 1210 */       Label l1 = new Label(0, j, "Common Label");
/* 1211 */       Label l2 = new Label(1, j, "Distinct label number " + j);
/* 1212 */       ws.addCell((WritableCell)l1);
/* 1213 */       ws.addCell((WritableCell)l2);
/*      */     } 
/*      */ 
/*      */     
/* 1217 */     wf = new WritableFont(WritableFont.TIMES, 10, WritableFont.BOLD);
/* 1218 */     wf.setColour(Colour.RED);
/* 1219 */     wcf = new WritableCellFormat(wf);
/* 1220 */     wcf.setWrap(true);
/* 1221 */     Label l = new Label(0, 205, "Different format", (CellFormat)wcf);
/* 1222 */     ws.addCell((WritableCell)l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeFormulaSheet(WritableSheet ws) throws WriteException {
/* 1231 */     Number nc = new Number(0, 0, 15.0D);
/* 1232 */     ws.addCell((WritableCell)nc);
/*      */     
/* 1234 */     nc = new Number(0, 1, 16.0D);
/* 1235 */     ws.addCell((WritableCell)nc);
/*      */     
/* 1237 */     nc = new Number(0, 2, 10.0D);
/* 1238 */     ws.addCell((WritableCell)nc);
/*      */     
/* 1240 */     nc = new Number(0, 3, 12.0D);
/* 1241 */     ws.addCell((WritableCell)nc);
/*      */     
/* 1243 */     ws.setColumnView(2, 20);
/* 1244 */     WritableCellFormat wcf = new WritableCellFormat();
/* 1245 */     wcf.setAlignment(Alignment.RIGHT);
/* 1246 */     wcf.setWrap(true);
/* 1247 */     CellView cv = new CellView();
/* 1248 */     cv.setSize(6400);
/* 1249 */     cv.setFormat((CellFormat)wcf);
/* 1250 */     ws.setColumnView(3, cv);
/*      */ 
/*      */     
/* 1253 */     Formula f = null;
/* 1254 */     Label l = null;
/*      */     
/* 1256 */     f = new Formula(2, 0, "A1+A2");
/* 1257 */     ws.addCell((WritableCell)f);
/* 1258 */     l = new Label(3, 0, "a1+a2");
/* 1259 */     ws.addCell((WritableCell)l);
/*      */     
/* 1261 */     f = new Formula(2, 1, "A2 * 3");
/* 1262 */     ws.addCell((WritableCell)f);
/* 1263 */     l = new Label(3, 1, "A2 * 3");
/* 1264 */     ws.addCell((WritableCell)l);
/*      */     
/* 1266 */     f = new Formula(2, 2, "A2+A1/2.5");
/* 1267 */     ws.addCell((WritableCell)f);
/* 1268 */     l = new Label(3, 2, "A2+A1/2.5");
/* 1269 */     ws.addCell((WritableCell)l);
/*      */     
/* 1271 */     f = new Formula(2, 3, "3+(a1+a2)/2.5");
/* 1272 */     ws.addCell((WritableCell)f);
/* 1273 */     l = new Label(3, 3, "3+(a1+a2)/2.5");
/* 1274 */     ws.addCell((WritableCell)l);
/*      */     
/* 1276 */     f = new Formula(2, 4, "(a1+a2)/2.5");
/* 1277 */     ws.addCell((WritableCell)f);
/* 1278 */     l = new Label(3, 4, "(a1+a2)/2.5");
/* 1279 */     ws.addCell((WritableCell)l);
/*      */     
/* 1281 */     f = new Formula(2, 5, "15+((a1+a2)/2.5)*17");
/* 1282 */     ws.addCell((WritableCell)f);
/* 1283 */     l = new Label(3, 5, "15+((a1+a2)/2.5)*17");
/* 1284 */     ws.addCell((WritableCell)l);
/*      */     
/* 1286 */     f = new Formula(2, 6, "SUM(a1:a4)");
/* 1287 */     ws.addCell((WritableCell)f);
/* 1288 */     l = new Label(3, 6, "SUM(a1:a4)");
/* 1289 */     ws.addCell((WritableCell)l);
/*      */     
/* 1291 */     f = new Formula(2, 7, "SUM(a1:a4)/4");
/* 1292 */     ws.addCell((WritableCell)f);
/* 1293 */     l = new Label(3, 7, "SUM(a1:a4)/4");
/* 1294 */     ws.addCell((WritableCell)l);
/*      */     
/* 1296 */     f = new Formula(2, 8, "AVERAGE(A1:A4)");
/* 1297 */     ws.addCell((WritableCell)f);
/* 1298 */     l = new Label(3, 8, "AVERAGE(a1:a4)");
/* 1299 */     ws.addCell((WritableCell)l);
/*      */     
/* 1301 */     f = new Formula(2, 9, "MIN(5,4,1,2,3)");
/* 1302 */     ws.addCell((WritableCell)f);
/* 1303 */     l = new Label(3, 9, "MIN(5,4,1,2,3)");
/* 1304 */     ws.addCell((WritableCell)l);
/*      */     
/* 1306 */     f = new Formula(2, 10, "ROUND(3.14159265, 3)");
/* 1307 */     ws.addCell((WritableCell)f);
/* 1308 */     l = new Label(3, 10, "ROUND(3.14159265, 3)");
/* 1309 */     ws.addCell((WritableCell)l);
/*      */     
/* 1311 */     f = new Formula(2, 11, "MAX(SUM(A1:A2), A1*A2, POWER(A1, 2))");
/* 1312 */     ws.addCell((WritableCell)f);
/* 1313 */     l = new Label(3, 11, "MAX(SUM(A1:A2), A1*A2, POWER(A1, 2))");
/* 1314 */     ws.addCell((WritableCell)l);
/*      */     
/* 1316 */     f = new Formula(2, 12, "IF(A2>A1, \"A2 bigger\", \"A1 bigger\")");
/* 1317 */     ws.addCell((WritableCell)f);
/* 1318 */     l = new Label(3, 12, "IF(A2>A1, \"A2 bigger\", \"A1 bigger\")");
/* 1319 */     ws.addCell((WritableCell)l);
/*      */     
/* 1321 */     f = new Formula(2, 13, "IF(A2<=A1, \"A2 smaller\", \"A1 smaller\")");
/* 1322 */     ws.addCell((WritableCell)f);
/* 1323 */     l = new Label(3, 13, "IF(A2<=A1, \"A2 smaller\", \"A1 smaller\")");
/* 1324 */     ws.addCell((WritableCell)l);
/*      */     
/* 1326 */     f = new Formula(2, 14, "IF(A3<=10, \"<= 10\")");
/* 1327 */     ws.addCell((WritableCell)f);
/* 1328 */     l = new Label(3, 14, "IF(A3<=10, \"<= 10\")");
/* 1329 */     ws.addCell((WritableCell)l);
/*      */     
/* 1331 */     f = new Formula(2, 15, "SUM(1,2,3,4,5)");
/* 1332 */     ws.addCell((WritableCell)f);
/* 1333 */     l = new Label(3, 15, "SUM(1,2,3,4,5)");
/* 1334 */     ws.addCell((WritableCell)l);
/*      */     
/* 1336 */     f = new Formula(2, 16, "HYPERLINK(\"http://www.andykhan.com/jexcelapi\", \"JExcelApi Home Page\")");
/* 1337 */     ws.addCell((WritableCell)f);
/* 1338 */     l = new Label(3, 16, "HYPERLINK(\"http://www.andykhan.com/jexcelapi\", \"JExcelApi Home Page\")");
/* 1339 */     ws.addCell((WritableCell)l);
/*      */     
/* 1341 */     f = new Formula(2, 17, "3*4+5");
/* 1342 */     ws.addCell((WritableCell)f);
/* 1343 */     l = new Label(3, 17, "3*4+5");
/* 1344 */     ws.addCell((WritableCell)l);
/*      */     
/* 1346 */     f = new Formula(2, 18, "\"Plain text formula\"");
/* 1347 */     ws.addCell((WritableCell)f);
/* 1348 */     l = new Label(3, 18, "Plain text formula");
/* 1349 */     ws.addCell((WritableCell)l);
/*      */     
/* 1351 */     f = new Formula(2, 19, "SUM(a1,a2,-a3,a4)");
/* 1352 */     ws.addCell((WritableCell)f);
/* 1353 */     l = new Label(3, 19, "SUM(a1,a2,-a3,a4)");
/* 1354 */     ws.addCell((WritableCell)l);
/*      */     
/* 1356 */     f = new Formula(2, 20, "2*-(a1+a2)");
/* 1357 */     ws.addCell((WritableCell)f);
/* 1358 */     l = new Label(3, 20, "2*-(a1+a2)");
/* 1359 */     ws.addCell((WritableCell)l);
/*      */     
/* 1361 */     f = new Formula(2, 21, "Number Formats!B1/2");
/* 1362 */     ws.addCell((WritableCell)f);
/* 1363 */     l = new Label(3, 21, "Number Formats!B1/2");
/* 1364 */     ws.addCell((WritableCell)l);
/*      */     
/* 1366 */     f = new Formula(2, 22, "IF(F22=0, 0, F21/F22)");
/* 1367 */     ws.addCell((WritableCell)f);
/* 1368 */     l = new Label(3, 22, "IF(F22=0, 0, F21/F22)");
/* 1369 */     ws.addCell((WritableCell)l);
/*      */     
/* 1371 */     f = new Formula(2, 23, "RAND()");
/* 1372 */     ws.addCell((WritableCell)f);
/* 1373 */     l = new Label(3, 23, "RAND()");
/* 1374 */     ws.addCell((WritableCell)l);
/*      */     
/* 1376 */     StringBuffer buf = new StringBuffer();
/* 1377 */     buf.append("'");
/* 1378 */     buf.append(this.workbook.getSheet(0).getName());
/* 1379 */     buf.append("'!");
/* 1380 */     buf.append(CellReferenceHelper.getCellReference(9, 18));
/* 1381 */     buf.append("*25");
/* 1382 */     f = new Formula(2, 24, buf.toString());
/* 1383 */     ws.addCell((WritableCell)f);
/* 1384 */     l = new Label(3, 24, buf.toString());
/* 1385 */     ws.addCell((WritableCell)l);
/*      */     
/* 1387 */     wcf = new WritableCellFormat(DateFormats.DEFAULT);
/* 1388 */     f = new Formula(2, 25, "NOW()", (CellFormat)wcf);
/* 1389 */     ws.addCell((WritableCell)f);
/* 1390 */     l = new Label(3, 25, "NOW()");
/* 1391 */     ws.addCell((WritableCell)l);
/*      */     
/* 1393 */     f = new Formula(2, 26, "$A$2+A3");
/* 1394 */     ws.addCell((WritableCell)f);
/* 1395 */     l = new Label(3, 26, "$A$2+A3");
/* 1396 */     ws.addCell((WritableCell)l);
/*      */     
/* 1398 */     f = new Formula(2, 27, "IF(COUNT(A1:A9,B1:B9)=0,\"\",COUNT(A1:A9,B1:B9))");
/* 1399 */     ws.addCell((WritableCell)f);
/* 1400 */     l = new Label(3, 27, "IF(COUNT(A1:A9,B1:B9)=0,\"\",COUNT(A1:A9,B1:B9))");
/* 1401 */     ws.addCell((WritableCell)l);
/*      */     
/* 1403 */     f = new Formula(2, 28, "SUM(A1,A2,A3,A4)");
/* 1404 */     ws.addCell((WritableCell)f);
/* 1405 */     l = new Label(3, 28, "SUM(A1,A2,A3,A4)");
/* 1406 */     ws.addCell((WritableCell)l);
/*      */     
/* 1408 */     l = new Label(1, 29, "a1");
/* 1409 */     ws.addCell((WritableCell)l);
/* 1410 */     f = new Formula(2, 29, "SUM(INDIRECT(ADDRESS(2,29)):A4)");
/* 1411 */     ws.addCell((WritableCell)f);
/* 1412 */     l = new Label(3, 29, "SUM(INDIRECT(ADDRESS(2,29):A4)");
/* 1413 */     ws.addCell((WritableCell)l);
/*      */     
/* 1415 */     f = new Formula(2, 30, "COUNTIF(A1:A4, \">=12\")");
/* 1416 */     ws.addCell((WritableCell)f);
/* 1417 */     l = new Label(3, 30, "COUNTIF(A1:A4, \">=12\")");
/* 1418 */     ws.addCell((WritableCell)l);
/*      */     
/* 1420 */     f = new Formula(2, 31, "MAX($A$1:$A$4)");
/* 1421 */     ws.addCell((WritableCell)f);
/* 1422 */     l = new Label(3, 31, "MAX($A$1:$A$4)");
/* 1423 */     ws.addCell((WritableCell)l);
/*      */     
/* 1425 */     f = new Formula(2, 32, "OR(A1,TRUE)");
/* 1426 */     ws.addCell((WritableCell)f);
/* 1427 */     l = new Label(3, 32, "OR(A1,TRUE)");
/* 1428 */     ws.addCell((WritableCell)l);
/*      */     
/* 1430 */     f = new Formula(2, 33, "ROWS(A1:C14)");
/* 1431 */     ws.addCell((WritableCell)f);
/* 1432 */     l = new Label(3, 33, "ROWS(A1:C14)");
/* 1433 */     ws.addCell((WritableCell)l);
/*      */     
/* 1435 */     f = new Formula(2, 34, "COUNTBLANK(A1:C14)");
/* 1436 */     ws.addCell((WritableCell)f);
/* 1437 */     l = new Label(3, 34, "COUNTBLANK(A1:C14)");
/* 1438 */     ws.addCell((WritableCell)l);
/*      */     
/* 1440 */     f = new Formula(2, 35, "IF(((F1=\"Not Found\")*(F2=\"Not Found\")*(F3=\"\")*(F4=\"\")*(F5=\"\")),1,0)");
/* 1441 */     ws.addCell((WritableCell)f);
/* 1442 */     l = new Label(3, 35, "IF(((F1=\"Not Found\")*(F2=\"Not Found\")*(F3=\"\")*(F4=\"\")*(F5=\"\")),1,0)");
/* 1443 */     ws.addCell((WritableCell)l);
/*      */     
/* 1445 */     f = new Formula(2, 36, "HYPERLINK(\"http://www.amazon.co.uk/exec/obidos/ASIN/0571058086qid=1099836249/sr=1-3/ref=sr_1_11_3/202-6017285-1620664\",  \"Long hyperlink\")");
/*      */     
/* 1447 */     ws.addCell((WritableCell)f);
/*      */     
/* 1449 */     f = new Formula(2, 37, "1234567+2699");
/* 1450 */     ws.addCell((WritableCell)f);
/* 1451 */     l = new Label(3, 37, "1234567+2699");
/* 1452 */     ws.addCell((WritableCell)l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeImageSheet(WritableSheet ws) throws WriteException {
/* 1479 */     Label l = new Label(0, 0, "Weald & Downland Open Air Museum, Sussex");
/* 1480 */     ws.addCell((WritableCell)l);
/*      */     
/* 1482 */     WritableImage wi = new WritableImage(0.0D, 3.0D, 5.0D, 7.0D, new File("resources/wealdanddownland.png"));
/*      */     
/* 1484 */     ws.addImage(wi);
/*      */     
/* 1486 */     l = new Label(0, 12, "Merchant Adventurers Hall, York");
/* 1487 */     ws.addCell((WritableCell)l);
/*      */     
/* 1489 */     wi = new WritableImage(5.0D, 12.0D, 4.0D, 10.0D, new File("resources/merchantadventurers.png"));
/*      */     
/* 1491 */     ws.addImage(wi);
/*      */   }
/*      */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\demo\Write.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
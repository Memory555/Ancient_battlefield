/*     */ package jxl.demo;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import jxl.Cell;
/*     */ import jxl.Sheet;
/*     */ import jxl.Workbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CSV
/*     */ {
/*     */   public CSV(Workbook w, OutputStream out, String encoding, boolean hide) throws IOException {
/*  53 */     if (encoding == null || !encoding.equals("UnicodeBig"))
/*     */     {
/*  55 */       encoding = "UTF8";
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  60 */       OutputStreamWriter osw = new OutputStreamWriter(out, encoding);
/*  61 */       BufferedWriter bw = new BufferedWriter(osw);
/*     */       
/*  63 */       for (int sheet = 0; sheet < w.getNumberOfSheets(); sheet++) {
/*     */         
/*  65 */         Sheet s = w.getSheet(sheet);
/*     */         
/*  67 */         if (!hide || !s.getSettings().isHidden()) {
/*     */           
/*  69 */           bw.write(s.getName());
/*  70 */           bw.newLine();
/*     */           
/*  72 */           Cell[] row = null;
/*     */           
/*  74 */           for (int i = 0; i < s.getRows(); i++) {
/*     */             
/*  76 */             row = s.getRow(i);
/*     */             
/*  78 */             if (row.length > 0) {
/*     */               
/*  80 */               if (!hide || !row[0].isHidden())
/*     */               {
/*  82 */                 bw.write(row[0].getContents());
/*     */               }
/*     */ 
/*     */ 
/*     */               
/*  87 */               for (int j = 1; j < row.length; j++) {
/*     */                 
/*  89 */                 bw.write(44);
/*  90 */                 if (!hide || !row[j].isHidden())
/*     */                 {
/*  92 */                   bw.write(row[j].getContents());
/*     */                 }
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/*  98 */             bw.newLine();
/*     */           } 
/*     */         } 
/*     */       } 
/* 102 */       bw.flush();
/* 103 */       bw.close();
/*     */     }
/* 105 */     catch (UnsupportedEncodingException e) {
/*     */       
/* 107 */       System.err.println(e.toString());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\demo\CSV.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
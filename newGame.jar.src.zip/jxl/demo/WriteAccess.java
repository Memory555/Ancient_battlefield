/*    */ package jxl.demo;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import jxl.WorkbookSettings;
/*    */ import jxl.biff.StringHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.read.biff.BiffException;
/*    */ import jxl.read.biff.BiffRecordReader;
/*    */ import jxl.read.biff.File;
/*    */ import jxl.read.biff.Record;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WriteAccess
/*    */ {
/*    */   private BiffRecordReader reader;
/*    */   
/*    */   public WriteAccess(File file) throws IOException, BiffException {
/* 44 */     WorkbookSettings ws = new WorkbookSettings();
/* 45 */     FileInputStream fis = new FileInputStream(file);
/* 46 */     File f = new File(fis, ws);
/* 47 */     this.reader = new BiffRecordReader(f);
/*    */     
/* 49 */     display(ws);
/* 50 */     fis.close();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void display(WorkbookSettings ws) throws IOException {
/* 58 */     Record r = null;
/* 59 */     boolean found = false;
/* 60 */     while (this.reader.hasNext() && !found) {
/*    */       
/* 62 */       r = this.reader.next();
/* 63 */       if (r.getType() == Type.WRITEACCESS)
/*    */       {
/* 65 */         found = true;
/*    */       }
/*    */     } 
/*    */     
/* 69 */     if (!found) {
/*    */       
/* 71 */       System.err.println("Warning:  could not find write access record");
/*    */       
/*    */       return;
/*    */     } 
/* 75 */     byte[] data = r.getData();
/*    */     
/* 77 */     String s = null;
/*    */     
/* 79 */     s = StringHelper.getString(data, data.length, 0, ws);
/*    */     
/* 81 */     System.out.println(s);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\demo\WriteAccess.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
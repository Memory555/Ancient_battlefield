package jxl;

import java.text.DateFormat;
import java.util.Date;

public interface DateCell extends Cell {
  Date getDate();
  
  boolean isTime();
  
  DateFormat getDateFormat();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\DateCell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
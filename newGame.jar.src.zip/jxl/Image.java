package jxl;

import java.io.File;

public interface Image {
  double getColumn();
  
  double getRow();
  
  double getWidth();
  
  double getHeight();
  
  File getImageFile();
  
  byte[] getImageData();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\Image.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
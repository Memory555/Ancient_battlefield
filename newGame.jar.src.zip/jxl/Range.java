package jxl;

public interface Range {
  Cell getTopLeft();
  
  Cell getBottomRight();
  
  int getFirstSheetIndex();
  
  int getLastSheetIndex();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\Range.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
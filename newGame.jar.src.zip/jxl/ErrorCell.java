package jxl;

public interface ErrorCell extends Cell {
  int getErrorCode();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\ErrorCell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
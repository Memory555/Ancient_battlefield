/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LeftMarginRecord
/*    */   extends MarginRecord
/*    */ {
/*    */   LeftMarginRecord(Record r) {
/* 36 */     super(Type.LEFTMARGIN, r);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\LeftMarginRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
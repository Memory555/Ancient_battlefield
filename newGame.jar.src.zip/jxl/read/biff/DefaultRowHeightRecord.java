/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultRowHeightRecord
/*    */   extends RecordData
/*    */ {
/*    */   private int height;
/*    */   
/*    */   public DefaultRowHeightRecord(Record t) {
/* 42 */     super(t);
/* 43 */     byte[] data = t.getData();
/*    */     
/* 45 */     if (data.length > 2)
/*    */     {
/* 47 */       this.height = IntegerHelper.getInt(data[2], data[3]);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getHeight() {
/* 58 */     return this.height;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\DefaultRowHeightRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
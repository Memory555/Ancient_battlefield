/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.BaseCompoundFile;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CompoundFile
/*     */   extends BaseCompoundFile
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(CompoundFile.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int numBigBlockDepotBlocks;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int sbdStartBlock;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int rootStartBlock;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int extensionBlock;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int numExtensionBlocks;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] rootEntry;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] bigBlockChain;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] smallBlockChain;
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] bigBlockDepotBlocks;
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList propertySets;
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings settings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CompoundFile(byte[] d, WorkbookSettings ws) throws BiffException {
/* 103 */     this.data = d;
/* 104 */     this.settings = ws;
/*     */ 
/*     */     
/* 107 */     for (int i = 0; i < IDENTIFIER.length; i++) {
/*     */       
/* 109 */       if (this.data[i] != IDENTIFIER[i])
/*     */       {
/* 111 */         throw new BiffException(BiffException.unrecognizedOLEFile);
/*     */       }
/*     */     } 
/*     */     
/* 115 */     this.propertySets = new ArrayList();
/* 116 */     this.numBigBlockDepotBlocks = IntegerHelper.getInt(this.data[44], this.data[45], this.data[46], this.data[47]);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     this.sbdStartBlock = IntegerHelper.getInt(this.data[60], this.data[61], this.data[62], this.data[63]);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     this.rootStartBlock = IntegerHelper.getInt(this.data[48], this.data[49], this.data[50], this.data[51]);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 131 */     this.extensionBlock = IntegerHelper.getInt(this.data[68], this.data[69], this.data[70], this.data[71]);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     this.numExtensionBlocks = IntegerHelper.getInt(this.data[72], this.data[73], this.data[74], this.data[75]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     this.bigBlockDepotBlocks = new int[this.numBigBlockDepotBlocks];
/*     */     
/* 144 */     int pos = 76;
/*     */     
/* 146 */     int bbdBlocks = this.numBigBlockDepotBlocks;
/*     */     
/* 148 */     if (this.numExtensionBlocks != 0)
/*     */     {
/* 150 */       bbdBlocks = 109;
/*     */     }
/*     */     
/* 153 */     for (int k = 0; k < bbdBlocks; k++) {
/*     */       
/* 155 */       this.bigBlockDepotBlocks[k] = IntegerHelper.getInt(d[pos], d[pos + 1], d[pos + 2], d[pos + 3]);
/*     */       
/* 157 */       pos += 4;
/*     */     } 
/*     */     
/* 160 */     for (int j = 0; j < this.numExtensionBlocks; j++) {
/*     */       
/* 162 */       pos = (this.extensionBlock + 1) * 512;
/* 163 */       int blocksToRead = Math.min(this.numBigBlockDepotBlocks - bbdBlocks, 127);
/*     */ 
/*     */       
/* 166 */       for (int m = bbdBlocks; m < bbdBlocks + blocksToRead; m++) {
/*     */         
/* 168 */         this.bigBlockDepotBlocks[m] = IntegerHelper.getInt(d[pos], d[pos + 1], d[pos + 2], d[pos + 3]);
/*     */         
/* 170 */         pos += 4;
/*     */       } 
/*     */       
/* 173 */       bbdBlocks += blocksToRead;
/* 174 */       if (bbdBlocks < this.numBigBlockDepotBlocks)
/*     */       {
/* 176 */         this.extensionBlock = IntegerHelper.getInt(d[pos], d[pos + 1], d[pos + 2], d[pos + 3]);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 181 */     readBigBlockDepot();
/* 182 */     readSmallBlockDepot();
/*     */     
/* 184 */     this.rootEntry = readData(this.rootStartBlock);
/* 185 */     readPropertySets();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readBigBlockDepot() {
/* 193 */     int pos = 0;
/* 194 */     int index = 0;
/* 195 */     this.bigBlockChain = new int[this.numBigBlockDepotBlocks * 512 / 4];
/*     */     
/* 197 */     for (int i = 0; i < this.numBigBlockDepotBlocks; i++) {
/*     */       
/* 199 */       pos = (this.bigBlockDepotBlocks[i] + 1) * 512;
/*     */       
/* 201 */       for (int j = 0; j < 128; j++) {
/*     */         
/* 203 */         this.bigBlockChain[index] = IntegerHelper.getInt(this.data[pos], this.data[pos + 1], this.data[pos + 2], this.data[pos + 3]);
/*     */         
/* 205 */         pos += 4;
/* 206 */         index++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readSmallBlockDepot() {
/* 216 */     int pos = 0;
/* 217 */     int index = 0;
/* 218 */     int sbdBlock = this.sbdStartBlock;
/* 219 */     this.smallBlockChain = new int[0];
/*     */     
/* 221 */     while (sbdBlock != -2) {
/*     */ 
/*     */       
/* 224 */       int[] oldChain = this.smallBlockChain;
/* 225 */       this.smallBlockChain = new int[this.smallBlockChain.length + 128];
/* 226 */       System.arraycopy(oldChain, 0, this.smallBlockChain, 0, oldChain.length);
/*     */       
/* 228 */       pos = (sbdBlock + 1) * 512;
/*     */       
/* 230 */       for (int j = 0; j < 128; j++) {
/*     */         
/* 232 */         this.smallBlockChain[index] = IntegerHelper.getInt(this.data[pos], this.data[pos + 1], this.data[pos + 2], this.data[pos + 3]);
/*     */         
/* 234 */         pos += 4;
/* 235 */         index++;
/*     */       } 
/*     */       
/* 238 */       sbdBlock = this.bigBlockChain[sbdBlock];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readPropertySets() {
/* 247 */     int offset = 0;
/* 248 */     byte[] d = null;
/*     */     
/* 250 */     while (offset < this.rootEntry.length) {
/*     */       
/* 252 */       d = new byte[128];
/* 253 */       System.arraycopy(this.rootEntry, offset, d, 0, d.length);
/* 254 */       BaseCompoundFile.PropertyStorage ps = new BaseCompoundFile.PropertyStorage(this, d);
/*     */ 
/*     */ 
/*     */       
/* 258 */       if (ps.name == null || ps.name.length() == 0)
/*     */       {
/* 260 */         if (ps.type == 5) {
/*     */           
/* 262 */           ps.name = "Root Entry";
/* 263 */           logger.warn("Property storage name for " + ps.type + " is empty - setting to " + "Root Entry");
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 268 */         else if (ps.size != 0) {
/*     */           
/* 270 */           logger.warn("Property storage type " + ps.type + " is non-empty and has no associated name");
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 276 */       this.propertySets.add(ps);
/* 277 */       offset += 128;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getStream(String streamName) throws BiffException {
/* 290 */     BaseCompoundFile.PropertyStorage ps = getPropertyStorage(streamName);
/*     */     
/* 292 */     if (ps.size >= 4096 || streamName.equalsIgnoreCase("Root Entry"))
/*     */     {
/*     */       
/* 295 */       return getBigBlockStream(ps);
/*     */     }
/*     */ 
/*     */     
/* 299 */     return getSmallBlockStream(ps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BaseCompoundFile.PropertyStorage getPropertyStorage(String name) throws BiffException {
/* 313 */     Iterator i = this.propertySets.iterator();
/* 314 */     boolean found = false;
/* 315 */     BaseCompoundFile.PropertyStorage ps = null;
/* 316 */     while (!found && i.hasNext()) {
/*     */       
/* 318 */       ps = i.next();
/* 319 */       if (ps.name.equalsIgnoreCase(name))
/*     */       {
/* 321 */         found = true;
/*     */       }
/*     */     } 
/*     */     
/* 325 */     if (!found)
/*     */     {
/* 327 */       throw new BiffException(BiffException.streamNotFound);
/*     */     }
/*     */     
/* 330 */     return ps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getBigBlockStream(BaseCompoundFile.PropertyStorage ps) {
/* 341 */     int numBlocks = ps.size / 512;
/* 342 */     if (ps.size % 512 != 0)
/*     */     {
/* 344 */       numBlocks++;
/*     */     }
/*     */     
/* 347 */     byte[] streamData = new byte[numBlocks * 512];
/*     */     
/* 349 */     int block = ps.startBlock;
/*     */     
/* 351 */     int count = 0;
/* 352 */     int pos = 0;
/* 353 */     while (block != -2 && count < numBlocks) {
/*     */       
/* 355 */       pos = (block + 1) * 512;
/* 356 */       System.arraycopy(this.data, pos, streamData, count * 512, 512);
/*     */       
/* 358 */       count++;
/* 359 */       block = this.bigBlockChain[block];
/*     */     } 
/*     */     
/* 362 */     if (block != -2 && count == numBlocks)
/*     */     {
/* 364 */       logger.warn("Property storage size inconsistent with block chain.");
/*     */     }
/*     */     
/* 367 */     return streamData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getSmallBlockStream(BaseCompoundFile.PropertyStorage ps) throws BiffException {
/* 379 */     BaseCompoundFile.PropertyStorage rootps = null;
/*     */     
/*     */     try {
/* 382 */       rootps = getPropertyStorage("Root Entry");
/*     */     }
/* 384 */     catch (BiffException e) {
/*     */       
/* 386 */       rootps = this.propertySets.get(0);
/*     */     } 
/*     */     
/* 389 */     byte[] rootdata = readData(rootps.startBlock);
/* 390 */     byte[] sbdata = new byte[0];
/*     */     
/* 392 */     int block = ps.startBlock;
/* 393 */     int pos = 0;
/*     */     
/* 395 */     while (block != -2) {
/*     */ 
/*     */       
/* 398 */       byte[] olddata = sbdata;
/* 399 */       sbdata = new byte[olddata.length + 64];
/* 400 */       System.arraycopy(olddata, 0, sbdata, 0, olddata.length);
/*     */ 
/*     */       
/* 403 */       pos = block * 64;
/* 404 */       System.arraycopy(rootdata, pos, sbdata, olddata.length, 64);
/*     */       
/* 406 */       block = this.smallBlockChain[block];
/*     */       
/* 408 */       if (block == -1) {
/*     */         
/* 410 */         logger.warn("Incorrect terminator for small block stream " + ps.name);
/* 411 */         block = -2;
/*     */       } 
/*     */     } 
/*     */     
/* 415 */     return sbdata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] readData(int bl) throws BiffException {
/* 427 */     int block = bl;
/* 428 */     int pos = 0;
/* 429 */     byte[] entry = new byte[0];
/*     */     
/* 431 */     while (block != -2) {
/*     */ 
/*     */       
/* 434 */       byte[] oldEntry = entry;
/* 435 */       entry = new byte[oldEntry.length + 512];
/* 436 */       System.arraycopy(oldEntry, 0, entry, 0, oldEntry.length);
/* 437 */       pos = (block + 1) * 512;
/* 438 */       System.arraycopy(this.data, pos, entry, oldEntry.length, 512);
/*     */       
/* 440 */       if (this.bigBlockChain[block] == block)
/*     */       {
/* 442 */         throw new BiffException(BiffException.corruptFileFormat);
/*     */       }
/* 444 */       block = this.bigBlockChain[block];
/*     */     } 
/* 446 */     return entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getPropertySetNames() {
/* 455 */     String[] sets = new String[this.propertySets.size()];
/* 456 */     for (int i = 0; i < sets.length; i++) {
/*     */       
/* 458 */       BaseCompoundFile.PropertyStorage ps = this.propertySets.get(i);
/* 459 */       sets[i] = ps.name;
/*     */     } 
/*     */     
/* 462 */     return sets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseCompoundFile.PropertyStorage getPropertySet(String ps) {
/* 473 */     boolean found = false;
/* 474 */     BaseCompoundFile.PropertyStorage propertySet = null;
/* 475 */     for (Iterator i = this.propertySets.iterator(); i.hasNext() && !found; ) {
/*     */       
/* 477 */       propertySet = i.next();
/* 478 */       if (propertySet.name.equalsIgnoreCase(ps))
/*     */       {
/* 480 */         found = true;
/*     */       }
/*     */     } 
/*     */     
/* 484 */     return found ? propertySet : null;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\CompoundFile.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
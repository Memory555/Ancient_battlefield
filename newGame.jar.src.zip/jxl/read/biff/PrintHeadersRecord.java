/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PrintHeadersRecord
/*    */   extends RecordData
/*    */ {
/*    */   private boolean printHeaders;
/*    */   
/*    */   public PrintHeadersRecord(Record ph) {
/* 41 */     super(ph);
/* 42 */     byte[] data = ph.getData();
/*    */     
/* 44 */     this.printHeaders = (data[0] == 1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getPrintHeaders() {
/* 54 */     return this.printHeaders;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\PrintHeadersRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.biff.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PasswordRecord
/*    */   extends RecordData
/*    */ {
/*    */   private String password;
/*    */   private int passwordHash;
/*    */   
/*    */   public PasswordRecord(Record t) {
/* 47 */     super(Type.PASSWORD);
/*    */     
/* 49 */     byte[] data = t.getData();
/* 50 */     this.passwordHash = IntegerHelper.getInt(data[0], data[1]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPasswordHash() {
/* 60 */     return this.passwordHash;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\PasswordRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ProtectRecord
/*    */   extends RecordData
/*    */ {
/*    */   private boolean prot;
/*    */   
/*    */   ProtectRecord(Record t) {
/* 42 */     super(t);
/* 43 */     byte[] data = getRecord().getData();
/*    */     
/* 45 */     int protflag = IntegerHelper.getInt(data[0], data[1]);
/*    */     
/* 47 */     this.prot = (protflag == 1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean isProtected() {
/* 57 */     return this.prot;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\ProtectRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NineteenFourRecord
/*    */   extends RecordData
/*    */ {
/*    */   private boolean nineteenFour;
/*    */   
/*    */   public NineteenFourRecord(Record t) {
/* 41 */     super(t);
/*    */     
/* 43 */     byte[] data = getRecord().getData();
/*    */     
/* 45 */     this.nineteenFour = (data[0] == 1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean is1904() {
/* 58 */     return this.nineteenFour;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\NineteenFourRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
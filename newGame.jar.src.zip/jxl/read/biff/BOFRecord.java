/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BOFRecord
/*     */   extends RecordData
/*     */ {
/*     */   private static final int Biff8 = 1536;
/*     */   private static final int Biff7 = 1280;
/*     */   private static final int WorkbookGlobals = 5;
/*     */   private static final int Worksheet = 16;
/*     */   private static final int Chart = 32;
/*     */   private static final int MacroSheet = 64;
/*     */   private int version;
/*     */   private int substreamType;
/*     */   
/*     */   BOFRecord(Record t) {
/*  72 */     super(t);
/*  73 */     byte[] data = getRecord().getData();
/*  74 */     this.version = IntegerHelper.getInt(data[0], data[1]);
/*  75 */     this.substreamType = IntegerHelper.getInt(data[2], data[3]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBiff8() {
/*  85 */     return (this.version == 1536);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBiff7() {
/*  95 */     return (this.version == 1280);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isWorkbookGlobals() {
/* 108 */     return (this.substreamType == 5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWorksheet() {
/* 119 */     return (this.substreamType == 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMacroSheet() {
/* 130 */     return (this.substreamType == 64);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isChart() {
/* 141 */     return (this.substreamType == 32);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getLength() {
/* 151 */     return getRecord().getLength();
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\BOFRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FooterRecord
/*     */   extends RecordData
/*     */ {
/*     */   private String footer;
/*     */   
/*     */   private static class Biff7
/*     */   {
/*     */     private Biff7() {}
/*     */   }
/*     */   
/*  41 */   public static Biff7 biff7 = new Biff7();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FooterRecord(Record t, WorkbookSettings ws) {
/*  51 */     super(t);
/*  52 */     byte[] data = getRecord().getData();
/*     */     
/*  54 */     if (data.length == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  59 */     int chars = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/*  61 */     boolean unicode = (data[2] == 1);
/*     */     
/*  63 */     if (unicode) {
/*     */       
/*  65 */       this.footer = StringHelper.getUnicodeString(data, chars, 3);
/*     */     }
/*     */     else {
/*     */       
/*  69 */       this.footer = StringHelper.getString(data, chars, 3, ws);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FooterRecord(Record t, WorkbookSettings ws, Biff7 dummy) {
/*  82 */     super(t);
/*  83 */     byte[] data = getRecord().getData();
/*     */     
/*  85 */     if (data.length == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  90 */     int chars = data[0];
/*  91 */     this.footer = StringHelper.getString(data, chars, 1, ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getFooter() {
/* 101 */     return this.footer;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\FooterRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
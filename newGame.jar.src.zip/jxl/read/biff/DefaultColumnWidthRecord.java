/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultColumnWidthRecord
/*    */   extends RecordData
/*    */ {
/*    */   private int width;
/*    */   
/*    */   public DefaultColumnWidthRecord(Record t) {
/* 42 */     super(t);
/* 43 */     byte[] data = t.getData();
/*    */     
/* 45 */     this.width = IntegerHelper.getInt(data[0], data[1]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getWidth() {
/* 56 */     return this.width;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\DefaultColumnWidthRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.CellType;
/*    */ import jxl.biff.FormattingRecords;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlankCell
/*    */   extends CellValue
/*    */ {
/*    */   BlankCell(Record t, FormattingRecords fr, SheetImpl si) {
/* 40 */     super(t, fr, si);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getContents() {
/* 50 */     return "";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CellType getType() {
/* 60 */     return CellType.EMPTY;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\BlankCell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExternalSheetRecord
/*     */   extends RecordData
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(ExternalSheetRecord.class);
/*     */   
/*     */   private static class Biff7 {
/*     */     private Biff7() {}
/*     */   }
/*     */   
/*  43 */   public static Biff7 biff7 = new Biff7();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private XTI[] xtiArray;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class XTI
/*     */   {
/*     */     int supbookIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int firstTab;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     int lastTab;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     XTI(int s, int f, int l) {
/*  72 */       this.supbookIndex = s;
/*  73 */       this.firstTab = f;
/*  74 */       this.lastTab = l;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExternalSheetRecord(Record t, WorkbookSettings ws) {
/*  91 */     super(t);
/*  92 */     byte[] data = getRecord().getData();
/*     */     
/*  94 */     int numxtis = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/*  96 */     if (data.length < numxtis * 6 + 2) {
/*     */       
/*  98 */       this.xtiArray = new XTI[0];
/*  99 */       logger.warn("Could not process external sheets.  Formulas may be compromised.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 104 */     this.xtiArray = new XTI[numxtis];
/*     */     
/* 106 */     int pos = 2;
/* 107 */     for (int i = 0; i < numxtis; i++) {
/*     */       
/* 109 */       int s = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 110 */       int f = IntegerHelper.getInt(data[pos + 2], data[pos + 3]);
/* 111 */       int l = IntegerHelper.getInt(data[pos + 4], data[pos + 5]);
/* 112 */       this.xtiArray[i] = new XTI(s, f, l);
/* 113 */       pos += 6;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExternalSheetRecord(Record t, WorkbookSettings settings, Biff7 dummy) {
/* 127 */     super(t);
/*     */     
/* 129 */     logger.warn("External sheet record for Biff 7 not supported");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumRecords() {
/* 138 */     return (this.xtiArray != null) ? this.xtiArray.length : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSupbookIndex(int index) {
/* 148 */     return (this.xtiArray[index]).supbookIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstTabIndex(int index) {
/* 159 */     return (this.xtiArray[index]).firstTab;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastTabIndex(int index) {
/* 170 */     return (this.xtiArray[index]).lastTab;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 180 */     return getRecord().getData();
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\ExternalSheetRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
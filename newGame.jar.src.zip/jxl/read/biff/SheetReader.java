/*      */ package jxl.read.biff;
/*      */ 
/*      */ import common.Assert;
/*      */ import common.Logger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import jxl.Cell;
/*      */ import jxl.CellFeatures;
/*      */ import jxl.CellReferenceHelper;
/*      */ import jxl.CellType;
/*      */ import jxl.DateCell;
/*      */ import jxl.HeaderFooter;
/*      */ import jxl.Range;
/*      */ import jxl.SheetSettings;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.ContinueRecord;
/*      */ import jxl.biff.FormattingRecords;
/*      */ import jxl.biff.Type;
/*      */ import jxl.biff.WorkspaceInformationRecord;
/*      */ import jxl.biff.drawing.Button;
/*      */ import jxl.biff.drawing.Chart;
/*      */ import jxl.biff.drawing.Comment;
/*      */ import jxl.biff.drawing.Drawing;
/*      */ import jxl.biff.drawing.DrawingData;
/*      */ import jxl.biff.drawing.MsoDrawingRecord;
/*      */ import jxl.biff.drawing.NoteRecord;
/*      */ import jxl.biff.drawing.ObjRecord;
/*      */ import jxl.biff.drawing.TextObjectRecord;
/*      */ import jxl.biff.formula.FormulaException;
/*      */ import jxl.format.PageOrientation;
/*      */ import jxl.format.PaperSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class SheetReader
/*      */ {
/*   65 */   private static Logger logger = Logger.getLogger(SheetReader.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private File excelFile;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SSTRecord sharedStrings;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BOFRecord sheetBof;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BOFRecord workbookBof;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FormattingRecords formattingRecords;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int numRows;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int numCols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Cell[][] cells;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int startPosition;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList rowProperties;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList columnInfosArray;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList sharedFormulas;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList hyperlinks;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Range[] mergedCells;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DataValidation dataValidation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList charts;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList drawings;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DrawingData drawingData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean nineteenFour;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PLSRecord plsRecord;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WorkspaceInformationRecord workspaceOptions;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] rowBreaks;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SheetSettings settings;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WorkbookSettings workbookSettings;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WorkbookParser workbook;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SheetImpl sheet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SheetReader(File f, SSTRecord sst, FormattingRecords fr, BOFRecord sb, BOFRecord wb, boolean nf, WorkbookParser wp, int sp, SheetImpl sh) {
/*  228 */     this.excelFile = f;
/*  229 */     this.sharedStrings = sst;
/*  230 */     this.formattingRecords = fr;
/*  231 */     this.sheetBof = sb;
/*  232 */     this.workbookBof = wb;
/*  233 */     this.columnInfosArray = new ArrayList();
/*  234 */     this.sharedFormulas = new ArrayList();
/*  235 */     this.hyperlinks = new ArrayList();
/*  236 */     this.rowProperties = new ArrayList(10);
/*  237 */     this.charts = new ArrayList();
/*  238 */     this.drawings = new ArrayList();
/*  239 */     this.nineteenFour = nf;
/*  240 */     this.workbook = wp;
/*  241 */     this.startPosition = sp;
/*  242 */     this.sheet = sh;
/*  243 */     this.settings = new SheetSettings();
/*  244 */     this.workbookSettings = this.workbook.getSettings();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addCell(Cell cell) {
/*  257 */     if (cell.getRow() < this.numRows && cell.getColumn() < this.numCols) {
/*      */       
/*  259 */       if (this.cells[cell.getRow()][cell.getColumn()] != null) {
/*      */         
/*  261 */         StringBuffer sb = new StringBuffer();
/*  262 */         CellReferenceHelper.getCellReference(cell.getColumn(), cell.getRow(), sb);
/*      */         
/*  264 */         logger.warn("Cell " + sb.toString() + " already contains data");
/*      */       } 
/*      */       
/*  267 */       this.cells[cell.getRow()][cell.getColumn()] = cell;
/*      */     }
/*      */     else {
/*      */       
/*  271 */       logger.warn("Cell " + CellReferenceHelper.getCellReference(cell.getColumn(), cell.getRow()) + " exceeds defined cell boundaries in Dimension record " + "(" + this.numCols + "x" + this.numRows + ")");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void read() {
/*  284 */     Record r = null;
/*  285 */     BaseSharedFormulaRecord sharedFormula = null;
/*  286 */     boolean sharedFormulaAdded = false;
/*      */     
/*  288 */     boolean cont = true;
/*      */ 
/*      */     
/*  291 */     this.excelFile.setPos(this.startPosition);
/*      */ 
/*      */     
/*  294 */     MsoDrawingRecord msoRecord = null;
/*  295 */     ObjRecord objRecord = null;
/*  296 */     boolean firstMsoRecord = true;
/*      */ 
/*      */     
/*  299 */     Window2Record window2Record = null;
/*      */ 
/*      */     
/*  302 */     PrintGridLinesRecord printGridLinesRecord = null;
/*      */ 
/*      */     
/*  305 */     PrintHeadersRecord printHeadersRecord = null;
/*      */ 
/*      */ 
/*      */     
/*  309 */     HashMap comments = new HashMap();
/*      */     
/*  311 */     while (cont) {
/*      */       
/*  313 */       r = this.excelFile.next();
/*      */       
/*  315 */       if (r.getType() == Type.UNKNOWN && r.getCode() == 0) {
/*      */         
/*  317 */         logger.warn("Biff code zero found");
/*      */ 
/*      */         
/*  320 */         if (r.getLength() == 10) {
/*      */           
/*  322 */           logger.warn("Biff code zero found - trying a dimension record.");
/*  323 */           r.setType(Type.DIMENSION);
/*      */         }
/*      */         else {
/*      */           
/*  327 */           logger.warn("Biff code zero found - Ignoring.");
/*      */         } 
/*      */       } 
/*      */       
/*  331 */       if (r.getType() == Type.DIMENSION) {
/*      */         
/*  333 */         DimensionRecord dr = null;
/*      */         
/*  335 */         if (this.workbookBof.isBiff8()) {
/*      */           
/*  337 */           dr = new DimensionRecord(r);
/*      */         }
/*      */         else {
/*      */           
/*  341 */           dr = new DimensionRecord(r, DimensionRecord.biff7);
/*      */         } 
/*  343 */         this.numRows = dr.getNumberOfRows();
/*  344 */         this.numCols = dr.getNumberOfColumns();
/*  345 */         this.cells = new Cell[this.numRows][this.numCols]; continue;
/*      */       } 
/*  347 */       if (r.getType() == Type.LABELSST) {
/*      */         
/*  349 */         LabelSSTRecord label = new LabelSSTRecord(r, this.sharedStrings, this.formattingRecords, this.sheet);
/*      */ 
/*      */ 
/*      */         
/*  353 */         addCell(label); continue;
/*      */       } 
/*  355 */       if (r.getType() == Type.RK || r.getType() == Type.RK2) {
/*      */         
/*  357 */         RKRecord rkr = new RKRecord(r, this.formattingRecords, this.sheet);
/*      */         
/*  359 */         if (this.formattingRecords.isDate(rkr.getXFIndex())) {
/*      */           
/*  361 */           DateCell dc = new DateRecord(rkr, rkr.getXFIndex(), this.formattingRecords, this.nineteenFour, this.sheet);
/*      */           
/*  363 */           addCell((Cell)dc);
/*      */           
/*      */           continue;
/*      */         } 
/*  367 */         addCell(rkr);
/*      */         continue;
/*      */       } 
/*  370 */       if (r.getType() == Type.HLINK) {
/*      */         
/*  372 */         HyperlinkRecord hr = new HyperlinkRecord(r, this.sheet, this.workbookSettings);
/*  373 */         this.hyperlinks.add(hr); continue;
/*      */       } 
/*  375 */       if (r.getType() == Type.MERGEDCELLS) {
/*      */         
/*  377 */         MergedCellsRecord mc = new MergedCellsRecord(r, this.sheet);
/*  378 */         if (this.mergedCells == null) {
/*      */           
/*  380 */           this.mergedCells = mc.getRanges();
/*      */           
/*      */           continue;
/*      */         } 
/*  384 */         Range[] newMergedCells = new Range[this.mergedCells.length + (mc.getRanges()).length];
/*      */         
/*  386 */         System.arraycopy(this.mergedCells, 0, newMergedCells, 0, this.mergedCells.length);
/*      */         
/*  388 */         System.arraycopy(mc.getRanges(), 0, newMergedCells, this.mergedCells.length, (mc.getRanges()).length);
/*      */ 
/*      */ 
/*      */         
/*  392 */         this.mergedCells = newMergedCells;
/*      */         continue;
/*      */       } 
/*  395 */       if (r.getType() == Type.MULRK) {
/*      */         
/*  397 */         MulRKRecord mulrk = new MulRKRecord(r);
/*      */ 
/*      */         
/*  400 */         int num = mulrk.getNumberOfColumns();
/*  401 */         int ixf = 0;
/*  402 */         for (int j = 0; j < num; j++) {
/*      */           
/*  404 */           ixf = mulrk.getXFIndex(j);
/*      */           
/*  406 */           NumberValue nv = new NumberValue(mulrk.getRow(), mulrk.getFirstColumn() + j, RKHelper.getDouble(mulrk.getRKNumber(j)), ixf, this.formattingRecords, this.sheet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  415 */           if (this.formattingRecords.isDate(ixf)) {
/*      */             
/*  417 */             DateCell dc = new DateRecord(nv, ixf, this.formattingRecords, this.nineteenFour, this.sheet);
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  422 */             addCell((Cell)dc);
/*      */           }
/*      */           else {
/*      */             
/*  426 */             nv.setNumberFormat(this.formattingRecords.getNumberFormat(ixf));
/*  427 */             addCell((Cell)nv);
/*      */           } 
/*      */         }  continue;
/*      */       } 
/*  431 */       if (r.getType() == Type.NUMBER) {
/*      */         
/*  433 */         NumberRecord nr = new NumberRecord(r, this.formattingRecords, this.sheet);
/*      */         
/*  435 */         if (this.formattingRecords.isDate(nr.getXFIndex())) {
/*      */           
/*  437 */           DateCell dc = new DateRecord(nr, nr.getXFIndex(), this.formattingRecords, this.nineteenFour, this.sheet);
/*      */ 
/*      */ 
/*      */           
/*  441 */           addCell((Cell)dc);
/*      */           
/*      */           continue;
/*      */         } 
/*  445 */         addCell(nr);
/*      */         continue;
/*      */       } 
/*  448 */       if (r.getType() == Type.BOOLERR) {
/*      */         
/*  450 */         BooleanRecord br = new BooleanRecord(r, this.formattingRecords, this.sheet);
/*      */         
/*  452 */         if (br.isError()) {
/*      */           
/*  454 */           ErrorRecord er = new ErrorRecord(br.getRecord(), this.formattingRecords, this.sheet);
/*      */           
/*  456 */           addCell(er);
/*      */           
/*      */           continue;
/*      */         } 
/*  460 */         addCell(br);
/*      */         continue;
/*      */       } 
/*  463 */       if (r.getType() == Type.PRINTGRIDLINES) {
/*      */         
/*  465 */         printGridLinesRecord = new PrintGridLinesRecord(r);
/*  466 */         this.settings.setPrintGridLines(printGridLinesRecord.getPrintGridLines()); continue;
/*      */       } 
/*  468 */       if (r.getType() == Type.PRINTHEADERS) {
/*      */         
/*  470 */         printHeadersRecord = new PrintHeadersRecord(r);
/*  471 */         this.settings.setPrintHeaders(printHeadersRecord.getPrintHeaders()); continue;
/*      */       } 
/*  473 */       if (r.getType() == Type.WINDOW2) {
/*      */         
/*  475 */         window2Record = new Window2Record(r);
/*      */         
/*  477 */         this.settings.setShowGridLines(window2Record.getShowGridLines());
/*  478 */         this.settings.setDisplayZeroValues(window2Record.getDisplayZeroValues());
/*  479 */         this.settings.setSelected(true); continue;
/*      */       } 
/*  481 */       if (r.getType() == Type.PANE) {
/*      */         
/*  483 */         PaneRecord pr = new PaneRecord(r);
/*      */         
/*  485 */         if (window2Record != null && window2Record.getFrozen()) {
/*      */ 
/*      */           
/*  488 */           this.settings.setVerticalFreeze(pr.getRowsVisible());
/*  489 */           this.settings.setHorizontalFreeze(pr.getColumnsVisible());
/*      */         }  continue;
/*      */       } 
/*  492 */       if (r.getType() == Type.CONTINUE) {
/*      */         continue;
/*      */       }
/*      */       
/*  496 */       if (r.getType() == Type.NOTE) {
/*      */         
/*  498 */         if (!this.workbookSettings.getDrawingsDisabled()) {
/*      */           
/*  500 */           NoteRecord nr = new NoteRecord(r);
/*      */ 
/*      */           
/*  503 */           Comment comment = (Comment)comments.remove(new Integer(nr.getObjectId()));
/*      */ 
/*      */           
/*  506 */           if (comment == null) {
/*      */             
/*  508 */             logger.warn(" cannot find comment for note id " + nr.getObjectId() + "...ignoring");
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/*  513 */           comment.setNote(nr);
/*      */           
/*  515 */           this.drawings.add(comment);
/*      */           
/*  517 */           addCellComment(comment.getColumn(), comment.getRow(), comment.getText(), comment.getWidth(), comment.getHeight());
/*      */         } 
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */ 
/*      */       
/*  525 */       if (r.getType() == Type.ARRAY) {
/*      */         continue;
/*      */       }
/*      */       
/*  529 */       if (r.getType() == Type.PROTECT) {
/*      */         
/*  531 */         ProtectRecord pr = new ProtectRecord(r);
/*  532 */         this.settings.setProtected(pr.isProtected()); continue;
/*      */       } 
/*  534 */       if (r.getType() == Type.SHAREDFORMULA) {
/*      */         
/*  536 */         if (sharedFormula == null) {
/*      */           
/*  538 */           logger.warn("Shared template formula is null - trying most recent formula template");
/*      */           
/*  540 */           SharedFormulaRecord lastSharedFormula = this.sharedFormulas.get(this.sharedFormulas.size() - 1);
/*      */ 
/*      */           
/*  543 */           if (lastSharedFormula != null)
/*      */           {
/*  545 */             sharedFormula = lastSharedFormula.getTemplateFormula();
/*      */           }
/*      */         } 
/*      */         
/*  549 */         SharedFormulaRecord sfr = new SharedFormulaRecord(r, sharedFormula, this.workbook, this.workbook, this.sheet);
/*      */         
/*  551 */         this.sharedFormulas.add(sfr);
/*  552 */         sharedFormula = null; continue;
/*      */       } 
/*  554 */       if (r.getType() == Type.FORMULA || r.getType() == Type.FORMULA2) {
/*      */         DateFormulaRecord dateFormulaRecord;
/*  556 */         FormulaRecord fr = new FormulaRecord(r, this.excelFile, this.formattingRecords, this.workbook, this.workbook, this.sheet, this.workbookSettings);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  564 */         if (fr.isShared()) {
/*      */           
/*  566 */           BaseSharedFormulaRecord prevSharedFormula = sharedFormula;
/*  567 */           sharedFormula = (BaseSharedFormulaRecord)fr.getFormula();
/*      */ 
/*      */           
/*  570 */           sharedFormulaAdded = addToSharedFormulas(sharedFormula);
/*      */           
/*  572 */           if (sharedFormulaAdded)
/*      */           {
/*  574 */             sharedFormula = prevSharedFormula;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*  579 */           if (!sharedFormulaAdded && prevSharedFormula != null)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  586 */             addCell(revertSharedFormula(prevSharedFormula));
/*      */           }
/*      */           
/*      */           continue;
/*      */         } 
/*  591 */         Cell cell = fr.getFormula();
/*      */ 
/*      */         
/*      */         try {
/*  595 */           if (fr.getFormula().getType() == CellType.NUMBER_FORMULA) {
/*      */             
/*  597 */             NumberFormulaRecord nfr = (NumberFormulaRecord)fr.getFormula();
/*  598 */             if (this.formattingRecords.isDate(nfr.getXFIndex()))
/*      */             {
/*  600 */               dateFormulaRecord = new DateFormulaRecord(nfr, this.formattingRecords, this.workbook, this.workbook, this.nineteenFour, this.sheet);
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  609 */           addCell((Cell)dateFormulaRecord);
/*      */         }
/*  611 */         catch (FormulaException e) {
/*      */ 
/*      */ 
/*      */           
/*  615 */           logger.warn(CellReferenceHelper.getCellReference(dateFormulaRecord.getColumn(), dateFormulaRecord.getRow()) + " " + e.getMessage());
/*      */         } 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/*  621 */       if (r.getType() == Type.LABEL) {
/*      */         
/*  623 */         LabelRecord lr = null;
/*      */         
/*  625 */         if (this.workbookBof.isBiff8()) {
/*      */           
/*  627 */           lr = new LabelRecord(r, this.formattingRecords, this.sheet, this.workbookSettings);
/*      */         }
/*      */         else {
/*      */           
/*  631 */           lr = new LabelRecord(r, this.formattingRecords, this.sheet, this.workbookSettings, LabelRecord.biff7);
/*      */         } 
/*      */         
/*  634 */         addCell(lr); continue;
/*      */       } 
/*  636 */       if (r.getType() == Type.RSTRING) {
/*      */         
/*  638 */         RStringRecord lr = null;
/*      */ 
/*      */         
/*  641 */         Assert.verify(!this.workbookBof.isBiff8());
/*  642 */         lr = new RStringRecord(r, this.formattingRecords, this.sheet, this.workbookSettings, RStringRecord.biff7);
/*      */ 
/*      */         
/*  645 */         addCell(lr); continue;
/*      */       } 
/*  647 */       if (r.getType() == Type.NAME) {
/*      */         continue;
/*      */       }
/*      */       
/*  651 */       if (r.getType() == Type.PASSWORD) {
/*      */         
/*  653 */         PasswordRecord pr = new PasswordRecord(r);
/*  654 */         this.settings.setPasswordHash(pr.getPasswordHash()); continue;
/*      */       } 
/*  656 */       if (r.getType() == Type.ROW) {
/*      */         
/*  658 */         RowRecord rr = new RowRecord(r);
/*      */ 
/*      */         
/*  661 */         if (!rr.isDefaultHeight() || !rr.matchesDefaultFontHeight() || rr.isCollapsed() || rr.hasDefaultFormat())
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  666 */           this.rowProperties.add(rr); } 
/*      */         continue;
/*      */       } 
/*  669 */       if (r.getType() == Type.BLANK) {
/*      */         
/*  671 */         if (!this.workbookSettings.getIgnoreBlanks()) {
/*      */           
/*  673 */           BlankCell bc = new BlankCell(r, this.formattingRecords, this.sheet);
/*  674 */           addCell(bc);
/*      */         }  continue;
/*      */       } 
/*  677 */       if (r.getType() == Type.MULBLANK) {
/*      */         
/*  679 */         if (!this.workbookSettings.getIgnoreBlanks()) {
/*      */           
/*  681 */           MulBlankRecord mulblank = new MulBlankRecord(r);
/*      */ 
/*      */           
/*  684 */           int num = mulblank.getNumberOfColumns();
/*      */           
/*  686 */           for (int j = 0; j < num; j++) {
/*      */             
/*  688 */             int ixf = mulblank.getXFIndex(j);
/*      */             
/*  690 */             MulBlankCell mbc = new MulBlankCell(mulblank.getRow(), mulblank.getFirstColumn() + j, ixf, this.formattingRecords, this.sheet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  697 */             addCell(mbc);
/*      */           } 
/*      */         }  continue;
/*      */       } 
/*  701 */       if (r.getType() == Type.SCL) {
/*      */         
/*  703 */         SCLRecord scl = new SCLRecord(r);
/*  704 */         this.settings.setZoomFactor(scl.getZoomFactor()); continue;
/*      */       } 
/*  706 */       if (r.getType() == Type.COLINFO) {
/*      */         
/*  708 */         ColumnInfoRecord cir = new ColumnInfoRecord(r);
/*  709 */         this.columnInfosArray.add(cir); continue;
/*      */       } 
/*  711 */       if (r.getType() == Type.HEADER) {
/*      */         
/*  713 */         HeaderRecord hr = null;
/*  714 */         if (this.workbookBof.isBiff8()) {
/*      */           
/*  716 */           hr = new HeaderRecord(r, this.workbookSettings);
/*      */         }
/*      */         else {
/*      */           
/*  720 */           hr = new HeaderRecord(r, this.workbookSettings, HeaderRecord.biff7);
/*      */         } 
/*      */         
/*  723 */         HeaderFooter header = new HeaderFooter(hr.getHeader());
/*  724 */         this.settings.setHeader(header); continue;
/*      */       } 
/*  726 */       if (r.getType() == Type.FOOTER) {
/*      */         
/*  728 */         FooterRecord fr = null;
/*  729 */         if (this.workbookBof.isBiff8()) {
/*      */           
/*  731 */           fr = new FooterRecord(r, this.workbookSettings);
/*      */         }
/*      */         else {
/*      */           
/*  735 */           fr = new FooterRecord(r, this.workbookSettings, FooterRecord.biff7);
/*      */         } 
/*      */         
/*  738 */         HeaderFooter footer = new HeaderFooter(fr.getFooter());
/*  739 */         this.settings.setFooter(footer); continue;
/*      */       } 
/*  741 */       if (r.getType() == Type.SETUP) {
/*      */         
/*  743 */         SetupRecord sr = new SetupRecord(r);
/*  744 */         if (sr.isPortrait()) {
/*      */           
/*  746 */           this.settings.setOrientation(PageOrientation.PORTRAIT);
/*      */         }
/*      */         else {
/*      */           
/*  750 */           this.settings.setOrientation(PageOrientation.LANDSCAPE);
/*      */         } 
/*  752 */         this.settings.setPaperSize(PaperSize.getPaperSize(sr.getPaperSize()));
/*  753 */         this.settings.setHeaderMargin(sr.getHeaderMargin());
/*  754 */         this.settings.setFooterMargin(sr.getFooterMargin());
/*  755 */         this.settings.setScaleFactor(sr.getScaleFactor());
/*  756 */         this.settings.setPageStart(sr.getPageStart());
/*  757 */         this.settings.setFitWidth(sr.getFitWidth());
/*  758 */         this.settings.setFitHeight(sr.getFitHeight());
/*  759 */         this.settings.setHorizontalPrintResolution(sr.getHorizontalPrintResolution());
/*      */         
/*  761 */         this.settings.setVerticalPrintResolution(sr.getVerticalPrintResolution());
/*  762 */         this.settings.setCopies(sr.getCopies());
/*      */         
/*  764 */         if (this.workspaceOptions != null)
/*      */         {
/*  766 */           this.settings.setFitToPages(this.workspaceOptions.getFitToPages()); } 
/*      */         continue;
/*      */       } 
/*  769 */       if (r.getType() == Type.WSBOOL) {
/*      */         
/*  771 */         this.workspaceOptions = new WorkspaceInformationRecord(r); continue;
/*      */       } 
/*  773 */       if (r.getType() == Type.DEFCOLWIDTH) {
/*      */         
/*  775 */         DefaultColumnWidthRecord dcwr = new DefaultColumnWidthRecord(r);
/*  776 */         this.settings.setDefaultColumnWidth(dcwr.getWidth()); continue;
/*      */       } 
/*  778 */       if (r.getType() == Type.DEFAULTROWHEIGHT) {
/*      */         
/*  780 */         DefaultRowHeightRecord drhr = new DefaultRowHeightRecord(r);
/*  781 */         if (drhr.getHeight() != 0)
/*      */         {
/*  783 */           this.settings.setDefaultRowHeight(drhr.getHeight()); } 
/*      */         continue;
/*      */       } 
/*  786 */       if (r.getType() == Type.LEFTMARGIN) {
/*      */         
/*  788 */         MarginRecord m = new LeftMarginRecord(r);
/*  789 */         this.settings.setLeftMargin(m.getMargin()); continue;
/*      */       } 
/*  791 */       if (r.getType() == Type.RIGHTMARGIN) {
/*      */         
/*  793 */         MarginRecord m = new RightMarginRecord(r);
/*  794 */         this.settings.setRightMargin(m.getMargin()); continue;
/*      */       } 
/*  796 */       if (r.getType() == Type.TOPMARGIN) {
/*      */         
/*  798 */         MarginRecord m = new TopMarginRecord(r);
/*  799 */         this.settings.setTopMargin(m.getMargin()); continue;
/*      */       } 
/*  801 */       if (r.getType() == Type.BOTTOMMARGIN) {
/*      */         
/*  803 */         MarginRecord m = new BottomMarginRecord(r);
/*  804 */         this.settings.setBottomMargin(m.getMargin()); continue;
/*      */       } 
/*  806 */       if (r.getType() == Type.HORIZONTALPAGEBREAKS) {
/*      */         
/*  808 */         HorizontalPageBreaksRecord dr = null;
/*      */         
/*  810 */         if (this.workbookBof.isBiff8()) {
/*      */           
/*  812 */           dr = new HorizontalPageBreaksRecord(r);
/*      */         }
/*      */         else {
/*      */           
/*  816 */           dr = new HorizontalPageBreaksRecord(r, HorizontalPageBreaksRecord.biff7);
/*      */         } 
/*      */         
/*  819 */         this.rowBreaks = dr.getRowBreaks(); continue;
/*      */       } 
/*  821 */       if (r.getType() == Type.PLS) {
/*      */         
/*  823 */         this.plsRecord = new PLSRecord(r); continue;
/*      */       } 
/*  825 */       if (r.getType() == Type.DVAL) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  832 */       if (r.getType() == Type.HCENTER) {
/*      */         
/*  834 */         CentreRecord hr = new CentreRecord(r);
/*  835 */         this.settings.setHorizontalCentre(hr.isCentre()); continue;
/*      */       } 
/*  837 */       if (r.getType() == Type.VCENTER) {
/*      */         
/*  839 */         CentreRecord vc = new CentreRecord(r);
/*  840 */         this.settings.setVerticalCentre(vc.isCentre()); continue;
/*      */       } 
/*  842 */       if (r.getType() == Type.DV) {
/*      */         continue;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  849 */       if (r.getType() == Type.OBJ) {
/*      */         
/*  851 */         objRecord = new ObjRecord(r);
/*      */         
/*  853 */         if (!this.workbookSettings.getDrawingsDisabled())
/*      */         {
/*  855 */           handleObjectRecord(objRecord, msoRecord, comments);
/*      */         }
/*      */ 
/*      */         
/*  859 */         if (objRecord.getType() != ObjRecord.CHART) {
/*      */           
/*  861 */           objRecord = null;
/*  862 */           msoRecord = null;
/*      */         }  continue;
/*      */       } 
/*  865 */       if (r.getType() == Type.MSODRAWING) {
/*      */         
/*  867 */         if (!this.workbookSettings.getDrawingsDisabled()) {
/*      */           
/*  869 */           if (msoRecord != null)
/*      */           {
/*      */ 
/*      */             
/*  873 */             this.drawingData.addRawData(msoRecord.getData());
/*      */           }
/*  875 */           msoRecord = new MsoDrawingRecord(r);
/*      */           
/*  877 */           if (firstMsoRecord) {
/*      */             
/*  879 */             msoRecord.setFirst();
/*  880 */             firstMsoRecord = false;
/*      */           } 
/*      */         }  continue;
/*      */       } 
/*  884 */       if (r.getType() == Type.BUTTONPROPERTYSET) {
/*      */         
/*  886 */         this.buttonPropertySet = new ButtonPropertySetRecord(r); continue;
/*      */       } 
/*  888 */       if (r.getType() == Type.BOF) {
/*      */         
/*  890 */         BOFRecord br = new BOFRecord(r);
/*  891 */         Assert.verify(!br.isWorksheet());
/*      */         
/*  893 */         int startpos = this.excelFile.getPos() - r.getLength() - 4;
/*      */ 
/*      */ 
/*      */         
/*  897 */         Record r2 = this.excelFile.next();
/*  898 */         while (r2.getCode() != Type.EOF.value)
/*      */         {
/*  900 */           r2 = this.excelFile.next();
/*      */         }
/*      */         
/*  903 */         if (br.isChart()) {
/*      */           
/*  905 */           if (!this.workbook.getWorkbookBof().isBiff8()) {
/*      */             
/*  907 */             logger.warn("only biff8 charts are supported");
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  912 */             if (this.drawingData == null)
/*      */             {
/*  914 */               this.drawingData = new DrawingData();
/*      */             }
/*      */             
/*  917 */             if (!this.workbookSettings.getDrawingsDisabled()) {
/*      */               
/*  919 */               Chart chart = new Chart(msoRecord, objRecord, this.drawingData, startpos, this.excelFile.getPos(), this.excelFile, this.workbookSettings);
/*      */ 
/*      */               
/*  922 */               this.charts.add(chart);
/*      */               
/*  924 */               if (this.workbook.getDrawingGroup() != null)
/*      */               {
/*  926 */                 this.workbook.getDrawingGroup().add(chart);
/*      */               }
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*  932 */           msoRecord = null;
/*  933 */           objRecord = null;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  938 */         if (this.sheetBof.isChart())
/*      */         {
/*  940 */           cont = false; } 
/*      */         continue;
/*      */       } 
/*  943 */       if (r.getType() == Type.EOF)
/*      */       {
/*  945 */         cont = false;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  950 */     this.excelFile.restorePos();
/*      */ 
/*      */     
/*  953 */     Iterator i = this.sharedFormulas.iterator();
/*      */     
/*  955 */     while (i.hasNext()) {
/*      */       
/*  957 */       SharedFormulaRecord sfr = i.next();
/*      */       
/*  959 */       Cell[] sfnr = sfr.getFormulas(this.formattingRecords, this.nineteenFour);
/*      */       
/*  961 */       for (int sf = 0; sf < sfnr.length; sf++)
/*      */       {
/*  963 */         addCell(sfnr[sf]);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  969 */     if (!sharedFormulaAdded && sharedFormula != null)
/*      */     {
/*  971 */       addCell(revertSharedFormula(sharedFormula));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  976 */     if (msoRecord != null && this.workbook.getDrawingGroup() != null)
/*      */     {
/*  978 */       this.workbook.getDrawingGroup().setDrawingsOmitted(msoRecord, objRecord);
/*      */     }
/*      */ 
/*      */     
/*  982 */     if (!comments.isEmpty())
/*      */     {
/*  984 */       logger.warn("Not all comments have a corresponding Note record");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean addToSharedFormulas(BaseSharedFormulaRecord fr) {
/*  997 */     Iterator i = this.sharedFormulas.iterator();
/*  998 */     boolean added = false;
/*  999 */     SharedFormulaRecord sfr = null;
/*      */     
/* 1001 */     while (i.hasNext() && !added) {
/*      */       
/* 1003 */       sfr = i.next();
/* 1004 */       added = sfr.add(fr);
/*      */     } 
/*      */     
/* 1007 */     return added;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Cell revertSharedFormula(BaseSharedFormulaRecord f) {
/* 1023 */     int pos = this.excelFile.getPos();
/* 1024 */     this.excelFile.setPos(f.getFilePos());
/*      */     
/* 1026 */     FormulaRecord fr = new FormulaRecord(f.getRecord(), this.excelFile, this.formattingRecords, this.workbook, this.workbook, FormulaRecord.ignoreSharedFormula, this.sheet, this.workbookSettings);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*      */       DateFormulaRecord dateFormulaRecord;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1037 */       Cell cell = fr.getFormula();
/*      */ 
/*      */       
/* 1040 */       if (fr.getFormula().getType() == CellType.NUMBER_FORMULA) {
/*      */         
/* 1042 */         NumberFormulaRecord nfr = (NumberFormulaRecord)fr.getFormula();
/* 1043 */         if (this.formattingRecords.isDate(fr.getXFIndex()))
/*      */         {
/* 1045 */           dateFormulaRecord = new DateFormulaRecord(nfr, this.formattingRecords, this.workbook, this.workbook, this.nineteenFour, this.sheet);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1054 */       this.excelFile.setPos(pos);
/* 1055 */       return (Cell)dateFormulaRecord;
/*      */     }
/* 1057 */     catch (FormulaException e) {
/*      */ 
/*      */ 
/*      */       
/* 1061 */       logger.warn(CellReferenceHelper.getCellReference(fr.getColumn(), fr.getRow()) + " " + e.getMessage());
/*      */ 
/*      */ 
/*      */       
/* 1065 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int getNumRows() {
/* 1077 */     return this.numRows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int getNumCols() {
/* 1087 */     return this.numCols;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Cell[][] getCells() {
/* 1097 */     return this.cells;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ArrayList getRowProperties() {
/* 1107 */     return this.rowProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ArrayList getColumnInfosArray() {
/* 1117 */     return this.columnInfosArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ArrayList getHyperlinks() {
/* 1127 */     return this.hyperlinks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ArrayList getCharts() {
/* 1137 */     return this.charts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ArrayList getDrawings() {
/* 1147 */     return this.drawings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final DataValidation getDataValidation() {
/* 1157 */     return this.dataValidation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Range[] getMergedCells() {
/* 1167 */     return this.mergedCells;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final SheetSettings getSettings() {
/* 1177 */     return this.settings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int[] getRowBreaks() {
/* 1187 */     return this.rowBreaks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final WorkspaceInformationRecord getWorkspaceOptions() {
/* 1197 */     return this.workspaceOptions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final PLSRecord getPLS() {
/* 1207 */     return this.plsRecord;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ButtonPropertySetRecord getButtonPropertySet() {
/* 1217 */     return this.buttonPropertySet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addCellComment(int col, int row, String text, double width, double height) {
/* 1233 */     Cell c = this.cells[row][col];
/* 1234 */     if (c == null) {
/*      */       
/* 1236 */       logger.warn("Cell at " + CellReferenceHelper.getCellReference(col, row) + " not present - adding a blank");
/*      */       
/* 1238 */       MulBlankCell mbc = new MulBlankCell(row, col, 0, this.formattingRecords, this.sheet);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1243 */       CellFeatures cf = new CellFeatures();
/* 1244 */       cf.setReadComment(text, width, height);
/* 1245 */       mbc.setCellFeatures(cf);
/* 1246 */       addCell(mbc);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1251 */     if (c instanceof CellFeaturesAccessor) {
/*      */       
/* 1253 */       CellFeaturesAccessor cv = (CellFeaturesAccessor)c;
/* 1254 */       CellFeatures cf = cv.getCellFeatures();
/*      */       
/* 1256 */       if (cf == null) {
/*      */         
/* 1258 */         cf = new CellFeatures();
/* 1259 */         cv.setCellFeatures(cf);
/*      */       } 
/*      */       
/* 1262 */       cf.setReadComment(text, width, height);
/*      */     }
/*      */     else {
/*      */       
/* 1266 */       logger.warn("Not able to add comment to cell type " + c.getClass().getName() + " at " + CellReferenceHelper.getCellReference(col, row));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleObjectRecord(ObjRecord objRecord, MsoDrawingRecord msoRecord, HashMap comments) {
/* 1283 */     if (msoRecord == null) {
/*      */       
/* 1285 */       logger.warn("Object record is not associated with a drawing  record - ignoring");
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1291 */     if (objRecord.getType() == ObjRecord.PICTURE) {
/*      */       
/* 1293 */       if (this.drawingData == null)
/*      */       {
/* 1295 */         this.drawingData = new DrawingData();
/*      */       }
/*      */       
/* 1298 */       Drawing drawing = new Drawing(msoRecord, objRecord, this.drawingData, this.workbook.getDrawingGroup());
/*      */ 
/*      */ 
/*      */       
/* 1302 */       this.drawings.add(drawing);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1307 */     if (objRecord.getType() == ObjRecord.EXCELNOTE) {
/*      */       
/* 1309 */       if (this.drawingData == null)
/*      */       {
/* 1311 */         this.drawingData = new DrawingData();
/*      */       }
/*      */       
/* 1314 */       Comment comment = new Comment(msoRecord, objRecord, this.drawingData, this.workbook.getDrawingGroup(), this.workbookSettings);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1320 */       Record r2 = this.excelFile.next();
/* 1321 */       if (r2.getType() == Type.MSODRAWING) {
/*      */         
/* 1323 */         MsoDrawingRecord mso = new MsoDrawingRecord(r2);
/* 1324 */         comment.addMso(mso);
/* 1325 */         r2 = this.excelFile.next();
/*      */       } 
/* 1327 */       Assert.verify((r2.getType() == Type.TXO));
/* 1328 */       TextObjectRecord txo = new TextObjectRecord(r2);
/* 1329 */       comment.setTextObject(txo);
/*      */       
/* 1331 */       r2 = this.excelFile.next();
/* 1332 */       Assert.verify((r2.getType() == Type.CONTINUE));
/* 1333 */       ContinueRecord text = new ContinueRecord(r2);
/* 1334 */       comment.setText(text);
/*      */       
/* 1336 */       r2 = this.excelFile.next();
/* 1337 */       if (r2.getType() == Type.CONTINUE) {
/*      */         
/* 1339 */         ContinueRecord formatting = new ContinueRecord(r2);
/* 1340 */         comment.setFormatting(formatting);
/*      */       } 
/*      */       
/* 1343 */       comments.put(new Integer(comment.getObjectId()), comment);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1348 */     if (objRecord.getType() == ObjRecord.BUTTON) {
/*      */       
/* 1350 */       if (this.drawingData == null)
/*      */       {
/* 1352 */         this.drawingData = new DrawingData();
/*      */       }
/*      */       
/* 1355 */       Button button = new Button(msoRecord, objRecord, this.drawingData, this.workbook.getDrawingGroup(), this.workbookSettings);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1361 */       Record r2 = this.excelFile.next();
/* 1362 */       if (r2.getType() == Type.MSODRAWING) {
/*      */         
/* 1364 */         MsoDrawingRecord mso = new MsoDrawingRecord(r2);
/* 1365 */         button.addMso(mso);
/* 1366 */         r2 = this.excelFile.next();
/*      */       } 
/* 1368 */       Assert.verify((r2.getType() == Type.TXO));
/* 1369 */       TextObjectRecord txo = new TextObjectRecord(r2);
/* 1370 */       button.setTextObject(txo);
/*      */       
/* 1372 */       r2 = this.excelFile.next();
/* 1373 */       Assert.verify((r2.getType() == Type.CONTINUE));
/* 1374 */       ContinueRecord text = new ContinueRecord(r2);
/* 1375 */       button.setText(text);
/*      */       
/* 1377 */       r2 = this.excelFile.next();
/* 1378 */       if (r2.getType() == Type.CONTINUE) {
/*      */         
/* 1380 */         ContinueRecord formatting = new ContinueRecord(r2);
/* 1381 */         button.setFormatting(formatting);
/*      */       } 
/*      */       
/* 1384 */       this.drawings.add(button);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1390 */     if (objRecord.getType() != ObjRecord.CHART) {
/*      */       
/* 1392 */       logger.warn(objRecord.getType() + " on sheet \"" + this.sheet.getName() + "\" not supported - omitting");
/*      */ 
/*      */       
/* 1395 */       if (this.drawingData == null)
/*      */       {
/* 1397 */         this.drawingData = new DrawingData();
/*      */       }
/*      */       
/* 1400 */       this.drawingData.addData(msoRecord.getData());
/*      */       
/* 1402 */       if (this.workbook.getDrawingGroup() != null)
/*      */       {
/* 1404 */         this.workbook.getDrawingGroup().setDrawingsOmitted(msoRecord, objRecord);
/*      */       }
/*      */       return;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\SheetReader.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
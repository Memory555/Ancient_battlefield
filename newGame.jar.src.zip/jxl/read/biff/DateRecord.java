/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.TimeZone;
/*     */ import jxl.CellFeatures;
/*     */ import jxl.CellType;
/*     */ import jxl.DateCell;
/*     */ import jxl.NumberCell;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DateRecord
/*     */   implements DateCell, CellFeaturesAccessor
/*     */ {
/*  45 */   private static Logger logger = Logger.getLogger(DateRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Date date;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean time;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DateFormat format;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CellFormat cellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int xfIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FormattingRecords formattingRecords;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SheetImpl sheet;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CellFeatures features;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized;
/*     */ 
/*     */ 
/*     */   
/* 103 */   private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
/*     */ 
/*     */   
/* 106 */   private static final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int nonLeapDay = 61;
/*     */ 
/*     */ 
/*     */   
/* 115 */   private static final TimeZone gmtZone = TimeZone.getTimeZone("GMT");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int utcOffsetDays = 25569;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int utcOffsetDays1904 = 24107;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long msInADay = 86400000L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateRecord(NumberCell num, int xfi, FormattingRecords fr, boolean nf, SheetImpl si) {
/* 141 */     this.row = num.getRow();
/* 142 */     this.column = num.getColumn();
/* 143 */     this.xfIndex = xfi;
/* 144 */     this.formattingRecords = fr;
/* 145 */     this.sheet = si;
/* 146 */     this.initialized = false;
/*     */     
/* 148 */     this.format = this.formattingRecords.getDateFormat(this.xfIndex);
/*     */ 
/*     */     
/* 151 */     double numValue = num.getValue();
/*     */     
/* 153 */     if (Math.abs(numValue) < 1.0D) {
/*     */       
/* 155 */       if (this.format == null)
/*     */       {
/* 157 */         this.format = timeFormat;
/*     */       }
/* 159 */       this.time = true;
/*     */     }
/*     */     else {
/*     */       
/* 163 */       if (this.format == null)
/*     */       {
/* 165 */         this.format = dateFormat;
/*     */       }
/* 167 */       this.time = false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 174 */     if (!nf && !this.time && numValue < 61.0D)
/*     */     {
/* 176 */       numValue++;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 181 */     this.format.setTimeZone(gmtZone);
/*     */ 
/*     */     
/* 184 */     int offsetDays = nf ? 24107 : 25569;
/* 185 */     double utcDays = numValue - offsetDays;
/*     */ 
/*     */ 
/*     */     
/* 189 */     long utcValue = Math.round(utcDays * 8.64E7D);
/*     */     
/* 191 */     this.date = new Date(utcValue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRow() {
/* 201 */     return this.row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getColumn() {
/* 211 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Date getDate() {
/* 221 */     return this.date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 232 */     return this.format.format(this.date);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 242 */     return CellType.DATE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTime() {
/* 253 */     return this.time;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateFormat getDateFormat() {
/* 266 */     Assert.verify((this.format != null));
/*     */     
/* 268 */     return this.format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellFormat getCellFormat() {
/* 279 */     if (!this.initialized) {
/*     */       
/* 281 */       this.cellFormat = (CellFormat)this.formattingRecords.getXFRecord(this.xfIndex);
/* 282 */       this.initialized = true;
/*     */     } 
/*     */     
/* 285 */     return this.cellFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHidden() {
/* 295 */     ColumnInfoRecord cir = this.sheet.getColumnInfo(this.column);
/*     */     
/* 297 */     if (cir != null && cir.getWidth() == 0)
/*     */     {
/* 299 */       return true;
/*     */     }
/*     */     
/* 302 */     RowRecord rr = this.sheet.getRowInfo(this.row);
/*     */     
/* 304 */     if (rr != null && (rr.getRowHeight() == 0 || rr.isCollapsed()))
/*     */     {
/* 306 */       return true;
/*     */     }
/*     */     
/* 309 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final SheetImpl getSheet() {
/* 319 */     return this.sheet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellFeatures getCellFeatures() {
/* 329 */     return this.features;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCellFeatures(CellFeatures cf) {
/* 339 */     this.features = cf;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\DateRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
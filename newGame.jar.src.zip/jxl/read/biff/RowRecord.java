/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RowRecord
/*     */   extends RecordData
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(RowRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int rowNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int rowHeight;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean collapsed;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean defaultFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matchesDefFontHeight;
/*     */ 
/*     */ 
/*     */   
/*     */   private int xfIndex;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int defaultHeightIndicator = 255;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RowRecord(Record t) {
/*  74 */     super(t);
/*     */     
/*  76 */     byte[] data = getRecord().getData();
/*  77 */     this.rowNumber = IntegerHelper.getInt(data[0], data[1]);
/*  78 */     this.rowHeight = IntegerHelper.getInt(data[6], data[7]);
/*     */     
/*  80 */     int options = IntegerHelper.getInt(data[12], data[13], data[14], data[15]);
/*     */ 
/*     */     
/*  83 */     this.collapsed = ((options & 0x20) != 0);
/*  84 */     this.matchesDefFontHeight = ((options & 0x40) == 0);
/*  85 */     this.defaultFormat = ((options & 0x80) != 0);
/*  86 */     this.xfIndex = (options & 0xFFF0000) >> 16;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isDefaultHeight() {
/*  96 */     return (this.rowHeight == 255);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean matchesDefaultFontHeight() {
/* 106 */     return this.matchesDefFontHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowNumber() {
/* 116 */     return this.rowNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowHeight() {
/* 126 */     return this.rowHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCollapsed() {
/* 136 */     return this.collapsed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getXFIndex() {
/* 146 */     return this.xfIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDefaultFormat() {
/* 156 */     return this.defaultFormat;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\RowRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
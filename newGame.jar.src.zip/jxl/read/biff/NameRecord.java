/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import java.util.ArrayList;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NameRecord
/*     */   extends RecordData
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(NameRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int index;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   private int sheetRef = 0;
/*     */   
/*     */   private boolean isbiff8;
/*     */ 
/*     */   
/*     */   private static class Biff7
/*     */   {
/*     */     private Biff7() {}
/*     */   }
/*     */ 
/*     */   
/*  68 */   public static Biff7 biff7 = new Biff7();
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int commandMacro = 12;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int builtIn = 32;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int cellReference = 58;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int areaReference = 59;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int subExpression = 41;
/*     */ 
/*     */   
/*     */   private static final int union = 16;
/*     */ 
/*     */   
/*     */   private ArrayList ranges;
/*     */ 
/*     */ 
/*     */   
/*     */   public class NameRange
/*     */   {
/*     */     private int columnFirst;
/*     */ 
/*     */     
/*     */     private int rowFirst;
/*     */ 
/*     */     
/*     */     private int columnLast;
/*     */ 
/*     */     
/*     */     private int rowLast;
/*     */ 
/*     */     
/*     */     private int externalSheet;
/*     */ 
/*     */     
/*     */     private final NameRecord this$0;
/*     */ 
/*     */ 
/*     */     
/*     */     NameRange(NameRecord this$0, int s1, int c1, int r1, int c2, int r2) {
/* 120 */       this.this$0 = this$0;
/* 121 */       this.columnFirst = c1;
/* 122 */       this.rowFirst = r1;
/* 123 */       this.columnLast = c2;
/* 124 */       this.rowLast = r2;
/* 125 */       this.externalSheet = s1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getFirstColumn() {
/* 135 */       return this.columnFirst;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getFirstRow() {
/* 145 */       return this.rowFirst;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getLastColumn() {
/* 155 */       return this.columnLast;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getLastRow() {
/* 165 */       return this.rowLast;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getExternalSheet() {
/* 175 */       return this.externalSheet;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   private static final String[] builtInNames = new String[] { "Consolidate_Area", "Auto_Open", "Auto_Close", "Extract", "Database", "Criteria", "Print_Area", "Print_Titles", "Recorder", "Data_Form", "Auto_Activate", "Auto_Deactivate", "Sheet_Title", "_FilterDatabase" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NameRecord(Record t, WorkbookSettings ws, int ind) {
/* 212 */     super(t);
/* 213 */     this.index = ind;
/* 214 */     this.isbiff8 = true;
/*     */ 
/*     */     
/*     */     try {
/* 218 */       this.ranges = new ArrayList();
/*     */       
/* 220 */       byte[] data = getRecord().getData();
/* 221 */       int option = IntegerHelper.getInt(data[0], data[1]);
/* 222 */       int length = data[3];
/* 223 */       this.sheetRef = IntegerHelper.getInt(data[8], data[9]);
/*     */       
/* 225 */       if ((option & 0x20) != 0) {
/*     */ 
/*     */         
/* 228 */         this.name = (data[15] < 13) ? builtInNames[data[15]] : ("Builtin_" + Integer.toString(data[15], 16));
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 233 */       this.name = StringHelper.getString(data, length, 15, ws);
/*     */       
/* 235 */       if ((option & 0xC) != 0) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 241 */       int pos = length + 15;
/*     */       
/* 243 */       if (data[pos] == 58) {
/*     */         
/* 245 */         int sheet = IntegerHelper.getInt(data[pos + 1], data[pos + 2]);
/* 246 */         int row = IntegerHelper.getInt(data[pos + 3], data[pos + 4]);
/* 247 */         int columnMask = IntegerHelper.getInt(data[pos + 5], data[pos + 6]);
/* 248 */         int column = columnMask & 0xFF;
/*     */ 
/*     */         
/* 251 */         Assert.verify(((columnMask & 0xC0000) == 0));
/*     */         
/* 253 */         NameRange r = new NameRange(this, sheet, column, row, column, row);
/* 254 */         this.ranges.add(r);
/*     */       }
/* 256 */       else if (data[pos] == 59) {
/*     */         
/* 258 */         int sheet1 = 0;
/* 259 */         int sheet2 = 0;
/* 260 */         int r1 = 0;
/* 261 */         int columnMask = 0;
/* 262 */         int c1 = 0;
/* 263 */         int r2 = 0;
/* 264 */         int c2 = 0;
/* 265 */         NameRange range = null;
/*     */         
/* 267 */         while (pos < data.length)
/*     */         {
/* 269 */           sheet1 = IntegerHelper.getInt(data[pos + 1], data[pos + 2]);
/* 270 */           r1 = IntegerHelper.getInt(data[pos + 3], data[pos + 4]);
/* 271 */           r2 = IntegerHelper.getInt(data[pos + 5], data[pos + 6]);
/*     */           
/* 273 */           columnMask = IntegerHelper.getInt(data[pos + 7], data[pos + 8]);
/* 274 */           c1 = columnMask & 0xFF;
/*     */ 
/*     */           
/* 277 */           Assert.verify(((columnMask & 0xC0000) == 0));
/*     */           
/* 279 */           columnMask = IntegerHelper.getInt(data[pos + 9], data[pos + 10]);
/* 280 */           c2 = columnMask & 0xFF;
/*     */ 
/*     */           
/* 283 */           Assert.verify(((columnMask & 0xC0000) == 0));
/*     */           
/* 285 */           range = new NameRange(this, sheet1, c1, r1, c2, r2);
/* 286 */           this.ranges.add(range);
/*     */           
/* 288 */           pos += 11;
/*     */         }
/*     */       
/* 291 */       } else if (data[pos] == 41) {
/*     */         
/* 293 */         int sheet1 = 0;
/* 294 */         int sheet2 = 0;
/* 295 */         int r1 = 0;
/* 296 */         int columnMask = 0;
/* 297 */         int c1 = 0;
/* 298 */         int r2 = 0;
/* 299 */         int c2 = 0;
/* 300 */         NameRange range = null;
/*     */ 
/*     */         
/* 303 */         if (pos < data.length && data[pos] != 58 && data[pos] != 59)
/*     */         {
/*     */ 
/*     */           
/* 307 */           if (data[pos] == 41) {
/*     */             
/* 309 */             pos += 3;
/*     */           }
/* 311 */           else if (data[pos] == 16) {
/*     */             
/* 313 */             pos++;
/*     */           } 
/*     */         }
/*     */         
/* 317 */         while (pos < data.length) {
/*     */           
/* 319 */           sheet1 = IntegerHelper.getInt(data[pos + 1], data[pos + 2]);
/* 320 */           r1 = IntegerHelper.getInt(data[pos + 3], data[pos + 4]);
/* 321 */           r2 = IntegerHelper.getInt(data[pos + 5], data[pos + 6]);
/*     */           
/* 323 */           columnMask = IntegerHelper.getInt(data[pos + 7], data[pos + 8]);
/* 324 */           c1 = columnMask & 0xFF;
/*     */ 
/*     */           
/* 327 */           Assert.verify(((columnMask & 0xC0000) == 0));
/*     */           
/* 329 */           columnMask = IntegerHelper.getInt(data[pos + 9], data[pos + 10]);
/* 330 */           c2 = columnMask & 0xFF;
/*     */ 
/*     */           
/* 333 */           Assert.verify(((columnMask & 0xC0000) == 0));
/*     */           
/* 335 */           range = new NameRange(this, sheet1, c1, r1, c2, r2);
/* 336 */           this.ranges.add(range);
/*     */           
/* 338 */           pos += 11;
/*     */ 
/*     */           
/* 341 */           if (pos < data.length && data[pos] != 58 && data[pos] != 59)
/*     */           {
/*     */ 
/*     */             
/* 345 */             if (data[pos] == 41) {
/*     */               
/* 347 */               pos += 3; continue;
/*     */             } 
/* 349 */             if (data[pos] == 16)
/*     */             {
/* 351 */               pos++;
/*     */             }
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 357 */     } catch (Throwable t1) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 362 */       logger.warn("Cannot read name");
/* 363 */       this.name = "ERROR";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NameRecord(Record t, WorkbookSettings ws, int ind, Biff7 dummy) {
/* 377 */     super(t);
/* 378 */     this.index = ind;
/* 379 */     this.isbiff8 = false;
/*     */ 
/*     */     
/*     */     try {
/* 383 */       this.ranges = new ArrayList();
/* 384 */       byte[] data = getRecord().getData();
/* 385 */       int length = data[3];
/* 386 */       this.sheetRef = IntegerHelper.getInt(data[8], data[9]);
/* 387 */       this.name = StringHelper.getString(data, length, 14, ws);
/*     */       
/* 389 */       int pos = length + 14;
/*     */       
/* 391 */       if (pos >= data.length) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 397 */       if (data[pos] == 58) {
/*     */         
/* 399 */         int sheet = IntegerHelper.getInt(data[pos + 11], data[pos + 12]);
/* 400 */         int row = IntegerHelper.getInt(data[pos + 15], data[pos + 16]);
/* 401 */         int column = data[pos + 17];
/*     */         
/* 403 */         NameRange r = new NameRange(this, sheet, column, row, column, row);
/* 404 */         this.ranges.add(r);
/*     */       }
/* 406 */       else if (data[pos] == 59) {
/*     */         
/* 408 */         int sheet1 = 0;
/* 409 */         int sheet2 = 0;
/* 410 */         int r1 = 0;
/* 411 */         int c1 = 0;
/* 412 */         int r2 = 0;
/* 413 */         int c2 = 0;
/* 414 */         NameRange range = null;
/*     */         
/* 416 */         while (pos < data.length)
/*     */         {
/* 418 */           sheet1 = IntegerHelper.getInt(data[pos + 11], data[pos + 12]);
/* 419 */           sheet2 = IntegerHelper.getInt(data[pos + 13], data[pos + 14]);
/* 420 */           r1 = IntegerHelper.getInt(data[pos + 15], data[pos + 16]);
/* 421 */           r2 = IntegerHelper.getInt(data[pos + 17], data[pos + 18]);
/*     */           
/* 423 */           c1 = data[pos + 19];
/* 424 */           c2 = data[pos + 20];
/*     */           
/* 426 */           range = new NameRange(this, sheet1, c1, r1, c2, r2);
/* 427 */           this.ranges.add(range);
/*     */           
/* 429 */           pos += 21;
/*     */         }
/*     */       
/* 432 */       } else if (data[pos] == 41) {
/*     */         
/* 434 */         int sheet1 = 0;
/* 435 */         int sheet2 = 0;
/* 436 */         int r1 = 0;
/* 437 */         int c1 = 0;
/* 438 */         int r2 = 0;
/* 439 */         int c2 = 0;
/* 440 */         NameRange range = null;
/*     */ 
/*     */         
/* 443 */         if (pos < data.length && data[pos] != 58 && data[pos] != 59)
/*     */         {
/*     */ 
/*     */           
/* 447 */           if (data[pos] == 41) {
/*     */             
/* 449 */             pos += 3;
/*     */           }
/* 451 */           else if (data[pos] == 16) {
/*     */             
/* 453 */             pos++;
/*     */           } 
/*     */         }
/*     */         
/* 457 */         while (pos < data.length) {
/*     */           
/* 459 */           sheet1 = IntegerHelper.getInt(data[pos + 11], data[pos + 12]);
/* 460 */           sheet2 = IntegerHelper.getInt(data[pos + 13], data[pos + 14]);
/* 461 */           r1 = IntegerHelper.getInt(data[pos + 15], data[pos + 16]);
/* 462 */           r2 = IntegerHelper.getInt(data[pos + 17], data[pos + 18]);
/*     */           
/* 464 */           c1 = data[pos + 19];
/* 465 */           c2 = data[pos + 20];
/*     */           
/* 467 */           range = new NameRange(this, sheet1, c1, r1, c2, r2);
/* 468 */           this.ranges.add(range);
/*     */           
/* 470 */           pos += 21;
/*     */ 
/*     */           
/* 473 */           if (pos < data.length && data[pos] != 58 && data[pos] != 59)
/*     */           {
/*     */ 
/*     */             
/* 477 */             if (data[pos] == 41) {
/*     */               
/* 479 */               pos += 3; continue;
/*     */             } 
/* 481 */             if (data[pos] == 16)
/*     */             {
/* 483 */               pos++;
/*     */             }
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 489 */     } catch (Throwable t1) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 494 */       logger.warn("Cannot read name.");
/* 495 */       this.name = "ERROR";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 506 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameRange[] getRanges() {
/* 517 */     NameRange[] nr = new NameRange[this.ranges.size()];
/* 518 */     return (NameRange[])this.ranges.toArray((Object[])nr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getIndex() {
/* 528 */     return this.index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSheetRef() {
/* 539 */     return this.sheetRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSheetRef(int i) {
/* 549 */     this.sheetRef = i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 559 */     return getRecord().getData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBiff8() {
/* 569 */     return this.isbiff8;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\NameRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
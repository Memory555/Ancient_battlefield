/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.DoubleHelper;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.biff.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class MarginRecord
/*    */   extends RecordData
/*    */ {
/*    */   private double margin;
/*    */   
/*    */   protected MarginRecord(Type t, Record r) {
/* 45 */     super(t);
/*    */     
/* 47 */     byte[] data = r.getData();
/*    */     
/* 49 */     this.margin = DoubleHelper.getIEEEDouble(data, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   double getMargin() {
/* 59 */     return this.margin;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\MarginRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
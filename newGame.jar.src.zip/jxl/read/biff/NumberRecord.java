/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import jxl.CellType;
/*     */ import jxl.NumberCell;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.FormattingRecords;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NumberRecord
/*     */   extends CellValue
/*     */   implements NumberCell
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(NumberRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NumberFormat format;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private static DecimalFormat defaultFormat = new DecimalFormat("#.###");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberRecord(Record t, FormattingRecords fr, SheetImpl si) {
/*  67 */     super(t, fr, si);
/*  68 */     byte[] data = getRecord().getData();
/*     */     
/*  70 */     this.value = DoubleHelper.getIEEEDouble(data, 6);
/*     */ 
/*     */     
/*  73 */     this.format = fr.getNumberFormat(getXFIndex());
/*  74 */     if (this.format == null)
/*     */     {
/*  76 */       this.format = defaultFormat;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue() {
/*  87 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/*  97 */     return this.format.format(this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 107 */     return CellType.NUMBER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberFormat getNumberFormat() {
/* 118 */     return this.format;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\NumberRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
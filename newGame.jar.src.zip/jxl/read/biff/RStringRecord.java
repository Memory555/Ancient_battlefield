/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.CellType;
/*    */ import jxl.LabelCell;
/*    */ import jxl.WorkbookSettings;
/*    */ import jxl.biff.FormattingRecords;
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.StringHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RStringRecord
/*    */   extends CellValue
/*    */   implements LabelCell
/*    */ {
/*    */   private int length;
/*    */   private String string;
/*    */   
/*    */   private static class Biff7
/*    */   {
/*    */     private Biff7() {}
/*    */   }
/*    */   
/* 47 */   public static Biff7 biff7 = new Biff7();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RStringRecord(Record t, FormattingRecords fr, SheetImpl si, WorkbookSettings ws, Biff7 dummy) {
/* 61 */     super(t, fr, si);
/* 62 */     byte[] data = getRecord().getData();
/* 63 */     this.length = IntegerHelper.getInt(data[6], data[7]);
/*    */     
/* 65 */     this.string = StringHelper.getString(data, this.length, 8, ws);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getString() {
/* 75 */     return this.string;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getContents() {
/* 85 */     return this.string;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CellType getType() {
/* 95 */     return CellType.LABEL;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\RStringRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MulBlankRecord
/*     */   extends RecordData
/*     */ {
/*  34 */   private static Logger logger = Logger.getLogger(MulBlankRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int colFirst;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int colLast;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int numblanks;
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] xfIndices;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MulBlankRecord(Record t) {
/*  64 */     super(t);
/*  65 */     byte[] data = getRecord().getData();
/*  66 */     int length = getRecord().getLength();
/*  67 */     this.row = IntegerHelper.getInt(data[0], data[1]);
/*  68 */     this.colFirst = IntegerHelper.getInt(data[2], data[3]);
/*  69 */     this.colLast = IntegerHelper.getInt(data[length - 2], data[length - 1]);
/*  70 */     this.numblanks = this.colLast - this.colFirst + 1;
/*  71 */     this.xfIndices = new int[this.numblanks];
/*     */     
/*  73 */     readBlanks(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readBlanks(byte[] data) {
/*  83 */     int pos = 4;
/*  84 */     for (int i = 0; i < this.numblanks; i++) {
/*     */       
/*  86 */       this.xfIndices[i] = IntegerHelper.getInt(data[pos], data[pos + 1]);
/*  87 */       pos += 2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRow() {
/*  98 */     return this.row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstColumn() {
/* 108 */     return this.colFirst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfColumns() {
/* 118 */     return this.numblanks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getXFIndex(int index) {
/* 128 */     return this.xfIndices[index];
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\MulBlankRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
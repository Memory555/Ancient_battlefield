/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.util.Date;
/*     */ import jxl.CellType;
/*     */ import jxl.DateCell;
/*     */ import jxl.DateFormulaCell;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SharedDateFormulaRecord
/*     */   extends BaseSharedFormulaRecord
/*     */   implements DateCell, FormulaData, DateFormulaCell
/*     */ {
/*     */   private DateRecord dateRecord;
/*     */   private double value;
/*     */   
/*     */   public SharedDateFormulaRecord(SharedNumberFormulaRecord nfr, FormattingRecords fr, boolean nf, SheetImpl si, int pos) {
/*  68 */     super(nfr.getRecord(), fr, nfr.getExternalSheet(), nfr.getNameTable(), si, pos);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     this.dateRecord = new DateRecord(nfr, nfr.getXFIndex(), fr, nf, si);
/*  75 */     this.value = nfr.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue() {
/*  85 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/*  95 */     return this.dateRecord.getContents();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 105 */     return CellType.DATE_FORMULA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getFormulaData() throws FormulaException {
/* 117 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 119 */       throw new FormulaException(FormulaException.biff8Supported);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 124 */     FormulaParser fp = new FormulaParser(getTokens(), this, getExternalSheet(), getNameTable(), getSheet().getWorkbook().getSettings());
/*     */ 
/*     */ 
/*     */     
/* 128 */     fp.parse();
/* 129 */     byte[] rpnTokens = fp.getBytes();
/*     */     
/* 131 */     byte[] data = new byte[rpnTokens.length + 22];
/*     */ 
/*     */     
/* 134 */     IntegerHelper.getTwoBytes(getRow(), data, 0);
/* 135 */     IntegerHelper.getTwoBytes(getColumn(), data, 2);
/* 136 */     IntegerHelper.getTwoBytes(getXFIndex(), data, 4);
/* 137 */     DoubleHelper.getIEEEBytes(this.value, data, 6);
/*     */ 
/*     */     
/* 140 */     System.arraycopy(rpnTokens, 0, data, 22, rpnTokens.length);
/* 141 */     IntegerHelper.getTwoBytes(rpnTokens.length, data, 20);
/*     */ 
/*     */     
/* 144 */     byte[] d = new byte[data.length - 6];
/* 145 */     System.arraycopy(data, 6, d, 0, data.length - 6);
/*     */     
/* 147 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Date getDate() {
/* 157 */     return this.dateRecord.getDate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTime() {
/* 168 */     return this.dateRecord.isTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateFormat getDateFormat() {
/* 181 */     return this.dateRecord.getDateFormat();
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\SharedDateFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
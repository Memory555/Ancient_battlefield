/*    */ package jxl.read.biff;
/*    */ 
/*    */ import common.Logger;
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CountryRecord
/*    */   extends RecordData
/*    */ {
/* 35 */   private static Logger logger = Logger.getLogger(CountryRecord.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int language;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int regionalSettings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CountryRecord(Record t) {
/* 54 */     super(t);
/* 55 */     byte[] data = t.getData();
/*    */     
/* 57 */     this.language = IntegerHelper.getInt(data[0], data[1]);
/* 58 */     this.regionalSettings = IntegerHelper.getInt(data[2], data[3]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getLanguageCode() {
/* 68 */     return this.language;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getRegionalSettingsCode() {
/* 78 */     return this.regionalSettings;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\CountryRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
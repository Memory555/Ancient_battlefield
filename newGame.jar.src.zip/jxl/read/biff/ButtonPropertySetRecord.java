/*    */ package jxl.read.biff;
/*    */ 
/*    */ import common.Logger;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ButtonPropertySetRecord
/*    */   extends RecordData
/*    */ {
/* 34 */   private static Logger logger = Logger.getLogger(ButtonPropertySetRecord.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   ButtonPropertySetRecord(Record t) {
/* 45 */     super(t);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 55 */     return getRecord().getData();
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\ButtonPropertySetRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
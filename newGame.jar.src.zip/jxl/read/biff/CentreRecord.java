/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CentreRecord
/*    */   extends RecordData
/*    */ {
/*    */   private boolean centre;
/*    */   
/*    */   public CentreRecord(Record t) {
/* 42 */     super(t);
/* 43 */     byte[] data = getRecord().getData();
/* 44 */     this.centre = (IntegerHelper.getInt(data[0], data[1]) != 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCentre() {
/* 54 */     return this.centre;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\CentreRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
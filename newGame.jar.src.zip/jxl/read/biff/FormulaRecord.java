/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.CellType;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FormulaRecord
/*     */   extends CellValue
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(FormulaRecord.class);
/*     */ 
/*     */   
/*     */   private CellValue formula;
/*     */ 
/*     */   
/*     */   private boolean shared;
/*     */ 
/*     */ 
/*     */   
/*     */   private static class IgnoreSharedFormula
/*     */   {
/*     */     private IgnoreSharedFormula() {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static final IgnoreSharedFormula ignoreSharedFormula = new IgnoreSharedFormula();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormulaRecord(Record t, File excelFile, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si, WorkbookSettings ws) {
/*  82 */     super(t, fr, si);
/*     */     
/*  84 */     byte[] data = getRecord().getData();
/*     */     
/*  86 */     this.shared = false;
/*     */ 
/*     */     
/*  89 */     int grbit = IntegerHelper.getInt(data[14], data[15]);
/*  90 */     if ((grbit & 0x8) != 0) {
/*     */       
/*  92 */       this.shared = true;
/*     */       
/*  94 */       if (data[6] == 0 && data[12] == -1 && data[13] == -1) {
/*     */ 
/*     */         
/*  97 */         this.formula = new SharedStringFormulaRecord(t, excelFile, fr, es, nt, si, ws);
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 103 */         double value = DoubleHelper.getIEEEDouble(data, 6);
/* 104 */         SharedNumberFormulaRecord snfr = new SharedNumberFormulaRecord(t, excelFile, value, fr, es, nt, si);
/*     */         
/* 106 */         snfr.setNumberFormat(fr.getNumberFormat(getXFIndex()));
/* 107 */         this.formula = snfr;
/*     */       } 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 115 */     if (data[6] == 0 && data[12] == -1 && data[13] == -1) {
/*     */ 
/*     */       
/* 118 */       this.formula = new StringFormulaRecord(t, excelFile, fr, es, nt, si, ws);
/*     */     }
/* 120 */     else if (data[6] == 1 && data[12] == -1 && data[13] == -1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 126 */       this.formula = new BooleanFormulaRecord(t, fr, es, nt, si);
/*     */     }
/* 128 */     else if (data[6] == 2 && data[12] == -1 && data[13] == -1) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 133 */       this.formula = new ErrorFormulaRecord(t, fr, es, nt, si);
/*     */     }
/* 135 */     else if (data[6] == 3 && data[12] == -1 && data[13] == -1) {
/*     */ 
/*     */       
/* 138 */       this.formula = new StringFormulaRecord(t, fr, es, nt, si);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 143 */       this.formula = new NumberFormulaRecord(t, fr, es, nt, si);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormulaRecord(Record t, File excelFile, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, IgnoreSharedFormula i, SheetImpl si, WorkbookSettings ws) {
/* 171 */     super(t, fr, si);
/* 172 */     byte[] data = getRecord().getData();
/*     */     
/* 174 */     this.shared = false;
/*     */ 
/*     */ 
/*     */     
/* 178 */     if (data[6] == 0 && data[12] == -1 && data[13] == -1) {
/*     */ 
/*     */       
/* 181 */       this.formula = new StringFormulaRecord(t, excelFile, fr, es, nt, si, ws);
/*     */     }
/* 183 */     else if (data[6] == 1 && data[12] == -1 && data[13] == -1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 189 */       this.formula = new BooleanFormulaRecord(t, fr, es, nt, si);
/*     */     }
/* 191 */     else if (data[6] == 2 && data[12] == -1 && data[13] == -1) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 196 */       this.formula = new ErrorFormulaRecord(t, fr, es, nt, si);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 201 */       this.formula = new NumberFormulaRecord(t, fr, es, nt, si);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 212 */     Assert.verify(false);
/* 213 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 223 */     Assert.verify(false);
/* 224 */     return CellType.EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final CellValue getFormula() {
/* 234 */     return this.formula;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isShared() {
/* 245 */     return this.shared;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\FormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
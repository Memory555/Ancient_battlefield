/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BoundsheetRecord
/*     */   extends RecordData
/*     */ {
/*     */   private int offset;
/*     */   private byte typeFlag;
/*     */   private byte visibilityFlag;
/*     */   private int length;
/*     */   private String name;
/*     */   
/*     */   private static class Biff7
/*     */   {
/*     */     private Biff7() {}
/*     */   }
/*     */   
/*  57 */   public static Biff7 biff7 = new Biff7();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundsheetRecord(Record t) {
/*  66 */     super(t);
/*  67 */     byte[] data = getRecord().getData();
/*  68 */     this.offset = IntegerHelper.getInt(data[0], data[1], data[2], data[3]);
/*  69 */     this.typeFlag = data[5];
/*  70 */     this.visibilityFlag = data[4];
/*  71 */     this.length = data[6];
/*     */     
/*  73 */     if (data[7] == 0) {
/*     */ 
/*     */       
/*  76 */       byte[] bytes = new byte[this.length];
/*  77 */       System.arraycopy(data, 8, bytes, 0, this.length);
/*  78 */       this.name = new String(bytes);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  83 */       byte[] bytes = new byte[this.length * 2];
/*  84 */       System.arraycopy(data, 8, bytes, 0, this.length * 2);
/*     */       
/*     */       try {
/*  87 */         this.name = new String(bytes, "UnicodeLittle");
/*     */       }
/*  89 */       catch (UnsupportedEncodingException e) {
/*     */ 
/*     */         
/*  92 */         this.name = "Error";
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BoundsheetRecord(Record t, Biff7 biff7) {
/* 107 */     super(t);
/* 108 */     byte[] data = getRecord().getData();
/* 109 */     this.offset = IntegerHelper.getInt(data[0], data[1], data[2], data[3]);
/* 110 */     this.typeFlag = data[5];
/* 111 */     this.visibilityFlag = data[4];
/* 112 */     this.length = data[6];
/* 113 */     byte[] bytes = new byte[this.length];
/* 114 */     System.arraycopy(data, 7, bytes, 0, this.length);
/* 115 */     this.name = new String(bytes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 125 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHidden() {
/* 135 */     return (this.visibilityFlag != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSheet() {
/* 146 */     return (this.typeFlag == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isChart() {
/* 156 */     return (this.typeFlag == 2);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\BoundsheetRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
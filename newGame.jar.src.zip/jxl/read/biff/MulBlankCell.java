/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.Cell;
/*     */ import jxl.CellFeatures;
/*     */ import jxl.CellType;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MulBlankCell
/*     */   implements Cell, CellFeaturesAccessor
/*     */ {
/*  39 */   private static Logger logger = Logger.getLogger(MulBlankCell.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CellFormat cellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int xfIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FormattingRecords formattingRecords;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SheetImpl sheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CellFeatures features;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MulBlankCell(int r, int c, int xfi, FormattingRecords fr, SheetImpl si) {
/*  95 */     this.row = r;
/*  96 */     this.column = c;
/*  97 */     this.xfIndex = xfi;
/*  98 */     this.formattingRecords = fr;
/*  99 */     this.sheet = si;
/* 100 */     this.initialized = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRow() {
/* 110 */     return this.row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getColumn() {
/* 120 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 130 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 140 */     return CellType.EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellFormat getCellFormat() {
/* 150 */     if (!this.initialized) {
/*     */       
/* 152 */       this.cellFormat = (CellFormat)this.formattingRecords.getXFRecord(this.xfIndex);
/* 153 */       this.initialized = true;
/*     */     } 
/*     */     
/* 156 */     return this.cellFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHidden() {
/* 166 */     ColumnInfoRecord cir = this.sheet.getColumnInfo(this.column);
/*     */     
/* 168 */     if (cir != null && cir.getWidth() == 0)
/*     */     {
/* 170 */       return true;
/*     */     }
/*     */     
/* 173 */     RowRecord rr = this.sheet.getRowInfo(this.row);
/*     */     
/* 175 */     if (rr != null && (rr.getRowHeight() == 0 || rr.isCollapsed()))
/*     */     {
/* 177 */       return true;
/*     */     }
/*     */     
/* 180 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellFeatures getCellFeatures() {
/* 190 */     return this.features;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCellFeatures(CellFeatures cf) {
/* 200 */     if (this.features != null)
/*     */     {
/* 202 */       logger.warn("current cell features not null - overwriting");
/*     */     }
/*     */     
/* 205 */     this.features = cf;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\MulBlankCell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
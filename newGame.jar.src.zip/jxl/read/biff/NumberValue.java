/*     */ package jxl.read.biff;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import jxl.CellFeatures;
/*     */ import jxl.CellType;
/*     */ import jxl.NumberCell;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NumberValue
/*     */   implements NumberCell, CellFeaturesAccessor
/*     */ {
/*     */   private int row;
/*     */   private int column;
/*     */   private double value;
/*     */   private NumberFormat format;
/*     */   private CellFormat cellFormat;
/*     */   private CellFeatures features;
/*     */   private int xfIndex;
/*     */   private FormattingRecords formattingRecords;
/*     */   private boolean initialized;
/*     */   private SheetImpl sheet;
/*  89 */   private static DecimalFormat defaultFormat = new DecimalFormat("#.###");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberValue(int r, int c, double val, int xfi, FormattingRecords fr, SheetImpl si) {
/* 106 */     this.row = r;
/* 107 */     this.column = c;
/* 108 */     this.value = val;
/* 109 */     this.format = defaultFormat;
/* 110 */     this.xfIndex = xfi;
/* 111 */     this.formattingRecords = fr;
/* 112 */     this.sheet = si;
/* 113 */     this.initialized = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setNumberFormat(NumberFormat f) {
/* 125 */     if (f != null)
/*     */     {
/* 127 */       this.format = f;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRow() {
/* 138 */     return this.row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getColumn() {
/* 148 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue() {
/* 158 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 168 */     return this.format.format(this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 178 */     return CellType.NUMBER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellFormat getCellFormat() {
/* 188 */     if (!this.initialized) {
/*     */       
/* 190 */       this.cellFormat = (CellFormat)this.formattingRecords.getXFRecord(this.xfIndex);
/* 191 */       this.initialized = true;
/*     */     } 
/*     */     
/* 194 */     return this.cellFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHidden() {
/* 204 */     ColumnInfoRecord cir = this.sheet.getColumnInfo(this.column);
/*     */     
/* 206 */     if (cir != null && cir.getWidth() == 0)
/*     */     {
/* 208 */       return true;
/*     */     }
/*     */     
/* 211 */     RowRecord rr = this.sheet.getRowInfo(this.row);
/*     */     
/* 213 */     if (rr != null && (rr.getRowHeight() == 0 || rr.isCollapsed()))
/*     */     {
/* 215 */       return true;
/*     */     }
/*     */     
/* 218 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberFormat getNumberFormat() {
/* 229 */     return this.format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellFeatures getCellFeatures() {
/* 239 */     return this.features;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCellFeatures(CellFeatures cf) {
/* 249 */     this.features = cf;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\NumberValue.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
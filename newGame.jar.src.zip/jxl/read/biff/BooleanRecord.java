/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import jxl.BooleanCell;
/*     */ import jxl.CellType;
/*     */ import jxl.biff.FormattingRecords;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BooleanRecord
/*     */   extends CellValue
/*     */   implements BooleanCell
/*     */ {
/*     */   private boolean error;
/*     */   private boolean value;
/*     */   
/*     */   public BooleanRecord(Record t, FormattingRecords fr, SheetImpl si) {
/*  53 */     super(t, fr, si);
/*  54 */     this.error = false;
/*  55 */     this.value = false;
/*     */     
/*  57 */     byte[] data = getRecord().getData();
/*     */     
/*  59 */     this.error = (data[7] == 1);
/*     */     
/*  61 */     if (!this.error)
/*     */     {
/*  63 */       this.value = (data[6] == 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isError() {
/*  75 */     return this.error;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getValue() {
/*  88 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/*  98 */     Assert.verify(!isError());
/*     */ 
/*     */     
/* 101 */     return (new Boolean(this.value)).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 111 */     return CellType.BOOLEAN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Record getRecord() {
/* 122 */     return super.getRecord();
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\BooleanRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
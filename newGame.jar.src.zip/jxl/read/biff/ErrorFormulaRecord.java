/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import jxl.CellType;
/*     */ import jxl.ErrorCell;
/*     */ import jxl.ErrorFormulaCell;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ErrorFormulaRecord
/*     */   extends CellValue
/*     */   implements ErrorCell, FormulaData, ErrorFormulaCell
/*     */ {
/*     */   private int errorCode;
/*     */   private ExternalSheet externalSheet;
/*     */   private WorkbookMethods nameTable;
/*     */   private String formulaString;
/*     */   private byte[] data;
/*     */   
/*     */   public ErrorFormulaRecord(Record t, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si) {
/*  78 */     super(t, fr, si);
/*     */     
/*  80 */     this.externalSheet = es;
/*  81 */     this.nameTable = nt;
/*  82 */     this.data = getRecord().getData();
/*     */     
/*  84 */     Assert.verify((this.data[6] == 2));
/*     */     
/*  86 */     this.errorCode = this.data[8];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getErrorCode() {
/*  98 */     return this.errorCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 108 */     return "ERROR " + this.errorCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 118 */     return CellType.FORMULA_ERROR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getFormulaData() throws FormulaException {
/* 129 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 131 */       throw new FormulaException(FormulaException.biff8Supported);
/*     */     }
/*     */ 
/*     */     
/* 135 */     byte[] d = new byte[this.data.length - 6];
/* 136 */     System.arraycopy(this.data, 6, d, 0, this.data.length - 6);
/*     */     
/* 138 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormula() throws FormulaException {
/* 149 */     if (this.formulaString == null) {
/*     */       
/* 151 */       byte[] tokens = new byte[this.data.length - 22];
/* 152 */       System.arraycopy(this.data, 22, tokens, 0, tokens.length);
/* 153 */       FormulaParser fp = new FormulaParser(tokens, this, this.externalSheet, this.nameTable, getSheet().getWorkbook().getSettings());
/*     */ 
/*     */       
/* 156 */       fp.parse();
/* 157 */       this.formulaString = fp.getFormula();
/*     */     } 
/*     */     
/* 160 */     return this.formulaString;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\ErrorFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
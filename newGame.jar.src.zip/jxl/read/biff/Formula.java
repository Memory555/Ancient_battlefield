package jxl.read.biff;

import jxl.Cell;

public interface Formula extends Cell {
  byte[] getFormulaData();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\Formula.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
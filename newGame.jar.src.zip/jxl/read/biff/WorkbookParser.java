/*      */ package jxl.read.biff;
/*      */ 
/*      */ import common.Assert;
/*      */ import common.Logger;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import jxl.Cell;
/*      */ import jxl.Range;
/*      */ import jxl.Sheet;
/*      */ import jxl.Workbook;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.DisplayFormat;
/*      */ import jxl.biff.FontRecord;
/*      */ import jxl.biff.Fonts;
/*      */ import jxl.biff.FormatRecord;
/*      */ import jxl.biff.FormattingRecords;
/*      */ import jxl.biff.NumFormatRecordsException;
/*      */ import jxl.biff.PaletteRecord;
/*      */ import jxl.biff.RangeImpl;
/*      */ import jxl.biff.Type;
/*      */ import jxl.biff.WorkbookMethods;
/*      */ import jxl.biff.XFRecord;
/*      */ import jxl.biff.drawing.DrawingGroup;
/*      */ import jxl.biff.drawing.MsoDrawingGroupRecord;
/*      */ import jxl.biff.drawing.Origin;
/*      */ import jxl.biff.formula.ExternalSheet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WorkbookParser
/*      */   extends Workbook
/*      */   implements ExternalSheet, WorkbookMethods
/*      */ {
/*   59 */   private static Logger logger = Logger.getLogger(WorkbookParser.class);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private File excelFile;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int bofs;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean nineteenFour;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SSTRecord sharedStrings;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList boundsheets;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FormattingRecords formattingRecords;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Fonts fonts;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList sheets;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SheetImpl lastSheet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lastSheetIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HashMap namedRecords;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList nameTable;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ExternalSheetRecord externSheet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList supbooks;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BOFRecord workbookBof;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MsoDrawingGroupRecord msoDrawingGroup;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean wbProtected;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean containsMacros;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WorkbookSettings settings;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DrawingGroup drawingGroup;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CountryRecord countryRecord;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WorkbookParser(File f, WorkbookSettings s) {
/*  175 */     this.excelFile = f;
/*  176 */     this.boundsheets = new ArrayList(10);
/*  177 */     this.fonts = new Fonts();
/*  178 */     this.formattingRecords = new FormattingRecords(this.fonts);
/*  179 */     this.sheets = new ArrayList(10);
/*  180 */     this.supbooks = new ArrayList(10);
/*  181 */     this.namedRecords = new HashMap();
/*  182 */     this.lastSheetIndex = -1;
/*  183 */     this.wbProtected = false;
/*  184 */     this.containsMacros = false;
/*  185 */     this.settings = s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Sheet[] getSheets() {
/*  198 */     Sheet[] sheetArray = new Sheet[getNumberOfSheets()];
/*  199 */     return (Sheet[])this.sheets.toArray((Object[])sheetArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Sheet getReadSheet(int index) {
/*  211 */     return getSheet(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Sheet getSheet(int index) {
/*  225 */     if (this.lastSheet != null && this.lastSheetIndex == index)
/*      */     {
/*  227 */       return this.lastSheet;
/*      */     }
/*      */ 
/*      */     
/*  231 */     if (this.lastSheet != null) {
/*      */       
/*  233 */       this.lastSheet.clear();
/*      */       
/*  235 */       if (!this.settings.getGCDisabled())
/*      */       {
/*  237 */         System.gc();
/*      */       }
/*      */     } 
/*      */     
/*  241 */     this.lastSheet = this.sheets.get(index);
/*  242 */     this.lastSheetIndex = index;
/*  243 */     this.lastSheet.readSheet();
/*      */     
/*  245 */     return this.lastSheet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Sheet getSheet(String name) {
/*  257 */     int pos = 0;
/*  258 */     boolean found = false;
/*  259 */     Iterator i = this.boundsheets.iterator();
/*  260 */     BoundsheetRecord br = null;
/*      */     
/*  262 */     while (i.hasNext() && !found) {
/*      */       
/*  264 */       br = i.next();
/*      */       
/*  266 */       if (br.getName().equals(name)) {
/*      */         
/*  268 */         found = true;
/*      */         
/*      */         continue;
/*      */       } 
/*  272 */       pos++;
/*      */     } 
/*      */ 
/*      */     
/*  276 */     return found ? getSheet(pos) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getSheetNames() {
/*  286 */     String[] names = new String[this.boundsheets.size()];
/*      */     
/*  288 */     BoundsheetRecord br = null;
/*  289 */     for (int i = 0; i < names.length; i++) {
/*      */       
/*  291 */       br = this.boundsheets.get(i);
/*  292 */       names[i] = br.getName();
/*      */     } 
/*      */     
/*  295 */     return names;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getExternalSheetIndex(int index) {
/*  311 */     if (this.workbookBof.isBiff7())
/*      */     {
/*  313 */       return index;
/*      */     }
/*      */     
/*  316 */     Assert.verify((this.externSheet != null));
/*      */     
/*  318 */     int firstTab = this.externSheet.getFirstTabIndex(index);
/*      */     
/*  320 */     return firstTab;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastExternalSheetIndex(int index) {
/*  335 */     if (this.workbookBof.isBiff7())
/*      */     {
/*  337 */       return index;
/*      */     }
/*      */     
/*  340 */     Assert.verify((this.externSheet != null));
/*      */     
/*  342 */     int lastTab = this.externSheet.getLastTabIndex(index);
/*      */     
/*  344 */     return lastTab;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getExternalSheetName(int index) {
/*  357 */     if (this.workbookBof.isBiff7()) {
/*      */       
/*  359 */       BoundsheetRecord br = this.boundsheets.get(index);
/*      */       
/*  361 */       return br.getName();
/*      */     } 
/*      */     
/*  364 */     int supbookIndex = this.externSheet.getSupbookIndex(index);
/*  365 */     SupbookRecord sr = this.supbooks.get(supbookIndex);
/*      */     
/*  367 */     int firstTab = this.externSheet.getFirstTabIndex(index);
/*      */     
/*  369 */     if (sr.getType() == SupbookRecord.INTERNAL) {
/*      */ 
/*      */       
/*  372 */       BoundsheetRecord br = this.boundsheets.get(firstTab);
/*      */       
/*  374 */       return br.getName();
/*      */     } 
/*  376 */     if (sr.getType() == SupbookRecord.EXTERNAL) {
/*      */ 
/*      */       
/*  379 */       StringBuffer sb = new StringBuffer();
/*  380 */       sb.append('[');
/*  381 */       sb.append(sr.getFileName());
/*  382 */       sb.append(']');
/*  383 */       sb.append(sr.getSheetName(firstTab));
/*  384 */       return sb.toString();
/*      */     } 
/*      */ 
/*      */     
/*  388 */     return "[UNKNOWN]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLastExternalSheetName(int index) {
/*  401 */     if (this.workbookBof.isBiff7()) {
/*      */       
/*  403 */       BoundsheetRecord br = this.boundsheets.get(index);
/*      */       
/*  405 */       return br.getName();
/*      */     } 
/*      */     
/*  408 */     int supbookIndex = this.externSheet.getSupbookIndex(index);
/*  409 */     SupbookRecord sr = this.supbooks.get(supbookIndex);
/*      */     
/*  411 */     int lastTab = this.externSheet.getLastTabIndex(index);
/*      */     
/*  413 */     if (sr.getType() == SupbookRecord.INTERNAL) {
/*      */ 
/*      */       
/*  416 */       BoundsheetRecord br = this.boundsheets.get(lastTab);
/*      */       
/*  418 */       return br.getName();
/*      */     } 
/*  420 */     if (sr.getType() == SupbookRecord.EXTERNAL) {
/*      */ 
/*      */       
/*  423 */       StringBuffer sb = new StringBuffer();
/*  424 */       sb.append('[');
/*  425 */       sb.append(sr.getFileName());
/*  426 */       sb.append(']');
/*  427 */       sb.append(sr.getSheetName(lastTab));
/*  428 */       return sb.toString();
/*      */     } 
/*      */ 
/*      */     
/*  432 */     return "[UNKNOWN]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfSheets() {
/*  442 */     return this.sheets.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() {
/*  451 */     if (this.lastSheet != null)
/*      */     {
/*  453 */       this.lastSheet.clear();
/*      */     }
/*  455 */     this.excelFile.clear();
/*      */     
/*  457 */     if (!this.settings.getGCDisabled())
/*      */     {
/*  459 */       System.gc();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void addSheet(Sheet s) {
/*  470 */     this.sheets.add(s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void parse() throws BiffException, PasswordException {
/*  481 */     Record r = null;
/*      */     
/*  483 */     BOFRecord bof = new BOFRecord(this.excelFile.next());
/*  484 */     this.workbookBof = bof;
/*  485 */     this.bofs++;
/*      */     
/*  487 */     if (!bof.isBiff8() && !bof.isBiff7())
/*      */     {
/*  489 */       throw new BiffException(BiffException.unrecognizedBiffVersion);
/*      */     }
/*      */     
/*  492 */     if (!bof.isWorkbookGlobals())
/*      */     {
/*  494 */       throw new BiffException(BiffException.expectedGlobals);
/*      */     }
/*  496 */     ArrayList continueRecords = new ArrayList();
/*  497 */     this.nameTable = new ArrayList();
/*      */ 
/*      */     
/*  500 */     while (this.bofs == 1) {
/*      */       
/*  502 */       r = this.excelFile.next();
/*      */       
/*  504 */       if (r.getType() == Type.SST) {
/*      */         
/*  506 */         continueRecords.clear();
/*  507 */         Record nextrec = this.excelFile.peek();
/*  508 */         while (nextrec.getType() == Type.CONTINUE) {
/*      */           
/*  510 */           continueRecords.add(this.excelFile.next());
/*  511 */           nextrec = this.excelFile.peek();
/*      */         } 
/*      */ 
/*      */         
/*  515 */         Record[] records = new Record[continueRecords.size()];
/*  516 */         records = continueRecords.<Record>toArray(records);
/*      */         
/*  518 */         this.sharedStrings = new SSTRecord(r, records, this.settings); continue;
/*      */       } 
/*  520 */       if (r.getType() == Type.FILEPASS)
/*      */       {
/*  522 */         throw new PasswordException();
/*      */       }
/*  524 */       if (r.getType() == Type.NAME) {
/*      */         
/*  526 */         NameRecord nr = null;
/*      */         
/*  528 */         if (bof.isBiff8()) {
/*      */           
/*  530 */           nr = new NameRecord(r, this.settings, this.namedRecords.size());
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  535 */           nr = new NameRecord(r, this.settings, this.namedRecords.size(), NameRecord.biff7);
/*      */         } 
/*      */         
/*  538 */         this.namedRecords.put(nr.getName(), nr);
/*  539 */         this.nameTable.add(nr); continue;
/*      */       } 
/*  541 */       if (r.getType() == Type.FONT) {
/*      */         
/*  543 */         FontRecord fr = null;
/*      */         
/*  545 */         if (bof.isBiff8()) {
/*      */           
/*  547 */           fr = new FontRecord(r, this.settings);
/*      */         }
/*      */         else {
/*      */           
/*  551 */           fr = new FontRecord(r, this.settings, FontRecord.biff7);
/*      */         } 
/*  553 */         this.fonts.addFont(fr); continue;
/*      */       } 
/*  555 */       if (r.getType() == Type.PALETTE) {
/*      */         
/*  557 */         PaletteRecord palette = new PaletteRecord(r);
/*  558 */         this.formattingRecords.setPalette(palette); continue;
/*      */       } 
/*  560 */       if (r.getType() == Type.NINETEENFOUR) {
/*      */         
/*  562 */         NineteenFourRecord nr = new NineteenFourRecord(r);
/*  563 */         this.nineteenFour = nr.is1904(); continue;
/*      */       } 
/*  565 */       if (r.getType() == Type.FORMAT) {
/*      */         
/*  567 */         FormatRecord fr = null;
/*  568 */         if (bof.isBiff8()) {
/*      */           
/*  570 */           fr = new FormatRecord(r, this.settings, FormatRecord.biff8);
/*      */         }
/*      */         else {
/*      */           
/*  574 */           fr = new FormatRecord(r, this.settings, FormatRecord.biff7);
/*      */         } 
/*      */         
/*      */         try {
/*  578 */           this.formattingRecords.addFormat((DisplayFormat)fr);
/*      */         }
/*  580 */         catch (NumFormatRecordsException e) {
/*      */           
/*  582 */           e.printStackTrace();
/*      */           
/*  584 */           Assert.verify(false, e.getMessage());
/*      */         }  continue;
/*      */       } 
/*  587 */       if (r.getType() == Type.XF) {
/*      */         
/*  589 */         XFRecord xfr = null;
/*  590 */         if (bof.isBiff8()) {
/*      */           
/*  592 */           xfr = new XFRecord(r, this.settings, XFRecord.biff8);
/*      */         }
/*      */         else {
/*      */           
/*  596 */           xfr = new XFRecord(r, this.settings, XFRecord.biff7);
/*      */         } 
/*      */ 
/*      */         
/*      */         try {
/*  601 */           this.formattingRecords.addStyle(xfr);
/*      */         }
/*  603 */         catch (NumFormatRecordsException e) {
/*      */ 
/*      */           
/*  606 */           Assert.verify(false, e.getMessage());
/*      */         }  continue;
/*      */       } 
/*  609 */       if (r.getType() == Type.BOUNDSHEET) {
/*      */         
/*  611 */         BoundsheetRecord br = null;
/*      */         
/*  613 */         if (bof.isBiff8()) {
/*      */           
/*  615 */           br = new BoundsheetRecord(r);
/*      */         }
/*      */         else {
/*      */           
/*  619 */           br = new BoundsheetRecord(r, BoundsheetRecord.biff7);
/*      */         } 
/*      */         
/*  622 */         if (br.isSheet()) {
/*      */           
/*  624 */           this.boundsheets.add(br); continue;
/*      */         } 
/*  626 */         if (br.isChart() && !this.settings.getDrawingsDisabled())
/*      */         {
/*  628 */           this.boundsheets.add(br); } 
/*      */         continue;
/*      */       } 
/*  631 */       if (r.getType() == Type.EXTERNSHEET) {
/*      */         
/*  633 */         if (bof.isBiff8()) {
/*      */           
/*  635 */           this.externSheet = new ExternalSheetRecord(r, this.settings);
/*      */           
/*      */           continue;
/*      */         } 
/*  639 */         this.externSheet = new ExternalSheetRecord(r, this.settings, ExternalSheetRecord.biff7);
/*      */         
/*      */         continue;
/*      */       } 
/*  643 */       if (r.getType() == Type.CODEPAGE) {
/*      */         
/*  645 */         CodepageRecord cr = new CodepageRecord(r);
/*  646 */         this.settings.setCharacterSet(cr.getCharacterSet()); continue;
/*      */       } 
/*  648 */       if (r.getType() == Type.SUPBOOK) {
/*      */         
/*  650 */         Record nextrec = this.excelFile.peek();
/*  651 */         while (nextrec.getType() == Type.CONTINUE) {
/*      */           
/*  653 */           r.addContinueRecord(this.excelFile.next());
/*  654 */           nextrec = this.excelFile.peek();
/*      */         } 
/*      */         
/*  657 */         SupbookRecord sr = new SupbookRecord(r, this.settings);
/*  658 */         this.supbooks.add(sr); continue;
/*      */       } 
/*  660 */       if (r.getType() == Type.PROTECT) {
/*      */         
/*  662 */         ProtectRecord pr = new ProtectRecord(r);
/*  663 */         this.wbProtected = pr.isProtected(); continue;
/*      */       } 
/*  665 */       if (r.getType() == Type.OBJPROJ) {
/*      */         
/*  667 */         this.containsMacros = true; continue;
/*      */       } 
/*  669 */       if (r.getType() == Type.COUNTRY) {
/*      */         
/*  671 */         this.countryRecord = new CountryRecord(r); continue;
/*      */       } 
/*  673 */       if (r.getType() == Type.MSODRAWINGGROUP) {
/*      */         
/*  675 */         if (!this.settings.getDrawingsDisabled()) {
/*      */           
/*  677 */           this.msoDrawingGroup = new MsoDrawingGroupRecord(r);
/*      */           
/*  679 */           if (this.drawingGroup == null)
/*      */           {
/*  681 */             this.drawingGroup = new DrawingGroup(Origin.READ);
/*      */           }
/*      */           
/*  684 */           this.drawingGroup.add(this.msoDrawingGroup);
/*      */           
/*  686 */           Record nextrec = this.excelFile.peek();
/*  687 */           while (nextrec.getType() == Type.CONTINUE) {
/*      */             
/*  689 */             this.drawingGroup.add(this.excelFile.next());
/*  690 */             nextrec = this.excelFile.peek();
/*      */           } 
/*      */         }  continue;
/*      */       } 
/*  694 */       if (r.getType() == Type.BUTTONPROPERTYSET) {
/*      */         
/*  696 */         this.buttonPropertySet = new ButtonPropertySetRecord(r); continue;
/*      */       } 
/*  698 */       if (r.getType() == Type.EOF)
/*      */       {
/*  700 */         this.bofs--;
/*      */       }
/*      */     } 
/*      */     
/*  704 */     bof = null;
/*  705 */     if (this.excelFile.hasNext()) {
/*      */       
/*  707 */       r = this.excelFile.next();
/*      */       
/*  709 */       if (r.getType() == Type.BOF)
/*      */       {
/*  711 */         bof = new BOFRecord(r);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  716 */     while (bof != null && getNumberOfSheets() < this.boundsheets.size()) {
/*      */       
/*  718 */       if (!bof.isBiff8() && !bof.isBiff7())
/*      */       {
/*  720 */         throw new BiffException(BiffException.unrecognizedBiffVersion);
/*      */       }
/*      */       
/*  723 */       if (bof.isWorksheet()) {
/*      */ 
/*      */         
/*  726 */         SheetImpl s = new SheetImpl(this.excelFile, this.sharedStrings, this.formattingRecords, bof, this.workbookBof, this.nineteenFour, this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  734 */         BoundsheetRecord br = this.boundsheets.get(getNumberOfSheets());
/*      */         
/*  736 */         s.setName(br.getName());
/*  737 */         s.setHidden(br.isHidden());
/*  738 */         addSheet(s);
/*      */       }
/*  740 */       else if (bof.isChart()) {
/*      */ 
/*      */         
/*  743 */         SheetImpl s = new SheetImpl(this.excelFile, this.sharedStrings, this.formattingRecords, bof, this.workbookBof, this.nineteenFour, this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  751 */         BoundsheetRecord br = this.boundsheets.get(getNumberOfSheets());
/*      */         
/*  753 */         s.setName(br.getName());
/*  754 */         s.setHidden(br.isHidden());
/*  755 */         addSheet(s);
/*      */       }
/*      */       else {
/*      */         
/*  759 */         logger.warn("BOF is unrecognized");
/*      */ 
/*      */         
/*  762 */         while (this.excelFile.hasNext() && r.getType() != Type.EOF)
/*      */         {
/*  764 */           r = this.excelFile.next();
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  773 */       bof = null;
/*  774 */       if (this.excelFile.hasNext()) {
/*      */         
/*  776 */         r = this.excelFile.next();
/*      */         
/*  778 */         if (r.getType() == Type.BOF)
/*      */         {
/*  780 */           bof = new BOFRecord(r);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public FormattingRecords getFormattingRecords() {
/*  794 */     return this.formattingRecords;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ExternalSheetRecord getExternalSheetRecord() {
/*  805 */     return this.externSheet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MsoDrawingGroupRecord getMsoDrawingGroupRecord() {
/*  816 */     return this.msoDrawingGroup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SupbookRecord[] getSupbookRecords() {
/*  827 */     SupbookRecord[] sr = new SupbookRecord[this.supbooks.size()];
/*  828 */     return (SupbookRecord[])this.supbooks.toArray((Object[])sr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NameRecord[] getNameRecords() {
/*  839 */     NameRecord[] na = new NameRecord[this.nameTable.size()];
/*  840 */     return (NameRecord[])this.nameTable.toArray((Object[])na);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Fonts getFonts() {
/*  850 */     return this.fonts;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Cell findCellByName(String name) {
/*  864 */     NameRecord nr = (NameRecord)this.namedRecords.get(name);
/*      */     
/*  866 */     if (nr == null)
/*      */     {
/*  868 */       return null;
/*      */     }
/*      */     
/*  871 */     NameRecord.NameRange[] ranges = nr.getRanges();
/*      */ 
/*      */     
/*  874 */     Sheet s = getSheet(ranges[0].getExternalSheet());
/*  875 */     Cell cell = s.getCell(ranges[0].getFirstColumn(), ranges[0].getFirstRow());
/*      */     
/*  877 */     return cell;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Range[] findByName(String name) {
/*  896 */     NameRecord nr = (NameRecord)this.namedRecords.get(name);
/*      */     
/*  898 */     if (nr == null)
/*      */     {
/*  900 */       return null;
/*      */     }
/*      */     
/*  903 */     NameRecord.NameRange[] ranges = nr.getRanges();
/*      */     
/*  905 */     Range[] cellRanges = new Range[ranges.length];
/*      */     
/*  907 */     for (int i = 0; i < ranges.length; i++)
/*      */     {
/*  909 */       cellRanges[i] = (Range)new RangeImpl(this, getExternalSheetIndex(ranges[i].getExternalSheet()), ranges[i].getFirstColumn(), ranges[i].getFirstRow(), getLastExternalSheetIndex(ranges[i].getExternalSheet()), ranges[i].getLastColumn(), ranges[i].getLastRow());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  919 */     return cellRanges;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getRangeNames() {
/*  929 */     Object[] keys = this.namedRecords.keySet().toArray();
/*  930 */     String[] names = new String[keys.length];
/*  931 */     System.arraycopy(keys, 0, names, 0, keys.length);
/*      */     
/*  933 */     return names;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BOFRecord getWorkbookBof() {
/*  944 */     return this.workbookBof;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isProtected() {
/*  954 */     return this.wbProtected;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WorkbookSettings getSettings() {
/*  964 */     return this.settings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getExternalSheetIndex(String sheetName) {
/*  975 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastExternalSheetIndex(String sheetName) {
/*  986 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName(int index) {
/*  997 */     Assert.verify((index >= 0 && index < this.nameTable.size()));
/*  998 */     return ((NameRecord)this.nameTable.get(index)).getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNameIndex(String name) {
/* 1009 */     NameRecord nr = (NameRecord)this.namedRecords.get(name);
/*      */     
/* 1011 */     return (nr != null) ? nr.getIndex() : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DrawingGroup getDrawingGroup() {
/* 1021 */     return this.drawingGroup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CompoundFile getCompoundFile() {
/* 1035 */     return this.excelFile.getCompoundFile();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsMacros() {
/* 1045 */     return this.containsMacros;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ButtonPropertySetRecord getButtonPropertySet() {
/* 1055 */     return this.buttonPropertySet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CountryRecord getCountryRecord() {
/* 1065 */     return this.countryRecord;
/*      */   }
/*      */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\WorkbookParser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
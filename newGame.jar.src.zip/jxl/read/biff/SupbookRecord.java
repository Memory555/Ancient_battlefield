/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SupbookRecord
/*     */   extends RecordData
/*     */ {
/*  38 */   private static Logger logger = Logger.getLogger(SupbookRecord.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private Type type;
/*     */ 
/*     */ 
/*     */   
/*     */   private int numSheets;
/*     */ 
/*     */ 
/*     */   
/*     */   private String fileName;
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] sheetNames;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Type
/*     */   {
/*     */     private Type() {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  66 */   public static final Type INTERNAL = new Type();
/*  67 */   public static final Type EXTERNAL = new Type();
/*  68 */   public static final Type ADDIN = new Type();
/*  69 */   public static final Type LINK = new Type();
/*  70 */   public static final Type UNKNOWN = new Type();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SupbookRecord(Record t, WorkbookSettings ws) {
/*  80 */     super(t);
/*  81 */     byte[] data = getRecord().getData();
/*     */ 
/*     */     
/*  84 */     if (data.length == 4) {
/*     */       
/*  86 */       if (data[2] == 1 && data[3] == 4)
/*     */       {
/*  88 */         this.type = INTERNAL;
/*     */       }
/*  90 */       else if (data[2] == 1 && data[3] == 58)
/*     */       {
/*  92 */         this.type = ADDIN;
/*     */       }
/*     */       else
/*     */       {
/*  96 */         this.type = UNKNOWN;
/*     */       }
/*     */     
/*  99 */     } else if (data[0] == 0 && data[1] == 0) {
/*     */       
/* 101 */       this.type = LINK;
/*     */     }
/*     */     else {
/*     */       
/* 105 */       this.type = EXTERNAL;
/*     */     } 
/*     */     
/* 108 */     if (this.type == INTERNAL)
/*     */     {
/* 110 */       this.numSheets = IntegerHelper.getInt(data[0], data[1]);
/*     */     }
/*     */     
/* 113 */     if (this.type == EXTERNAL)
/*     */     {
/* 115 */       readExternal(data, ws);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readExternal(byte[] data, WorkbookSettings ws) {
/* 127 */     this.numSheets = IntegerHelper.getInt(data[0], data[1]);
/*     */ 
/*     */     
/* 130 */     int ln = IntegerHelper.getInt(data[2], data[3]) - 1;
/* 131 */     int pos = 0;
/*     */     
/* 133 */     if (data[4] == 0) {
/*     */ 
/*     */       
/* 136 */       int encoding = data[5];
/* 137 */       pos = 6;
/* 138 */       if (encoding == 0)
/*     */       {
/* 140 */         this.fileName = StringHelper.getString(data, ln, pos, ws);
/* 141 */         pos += ln;
/*     */       }
/*     */       else
/*     */       {
/* 145 */         this.fileName = getEncodedFilename(data, ln, pos);
/* 146 */         pos += ln;
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 152 */       int encoding = IntegerHelper.getInt(data[5], data[6]);
/* 153 */       pos = 7;
/* 154 */       if (encoding == 0) {
/*     */         
/* 156 */         this.fileName = StringHelper.getUnicodeString(data, ln, pos);
/* 157 */         pos += ln * 2;
/*     */       }
/*     */       else {
/*     */         
/* 161 */         this.fileName = getUnicodeEncodedFilename(data, ln, pos);
/* 162 */         pos += ln * 2;
/*     */       } 
/*     */     } 
/*     */     
/* 166 */     this.sheetNames = new String[this.numSheets];
/*     */     
/* 168 */     for (int i = 0; i < this.sheetNames.length; i++) {
/*     */       
/* 170 */       ln = IntegerHelper.getInt(data[pos], data[pos + 1]);
/*     */       
/* 172 */       if (data[pos + 2] == 0) {
/*     */         
/* 174 */         this.sheetNames[i] = StringHelper.getString(data, ln, pos + 3, ws);
/* 175 */         pos += ln + 3;
/*     */       }
/* 177 */       else if (data[pos + 2] == 1) {
/*     */         
/* 179 */         this.sheetNames[i] = StringHelper.getUnicodeString(data, ln, pos + 3);
/* 180 */         pos += ln * 2 + 3;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/* 192 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfSheets() {
/* 203 */     return this.numSheets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileName() {
/* 213 */     return this.fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSheetName(int i) {
/* 224 */     return this.sheetNames[i];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 234 */     return getRecord().getData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getEncodedFilename(byte[] data, int ln, int pos) {
/* 247 */     StringBuffer buf = new StringBuffer();
/* 248 */     int endpos = pos + ln;
/* 249 */     while (pos < endpos) {
/*     */       
/* 251 */       char c = (char)data[pos];
/*     */       
/* 253 */       if (c == '\001') {
/*     */ 
/*     */         
/* 256 */         pos++;
/* 257 */         c = (char)data[pos];
/* 258 */         buf.append(c);
/* 259 */         buf.append(":\\\\");
/*     */       }
/* 261 */       else if (c == '\002') {
/*     */ 
/*     */         
/* 264 */         buf.append('\\');
/*     */       }
/* 266 */       else if (c == '\003') {
/*     */ 
/*     */         
/* 269 */         buf.append('\\');
/*     */       }
/* 271 */       else if (c == '\004') {
/*     */ 
/*     */         
/* 274 */         buf.append("..\\");
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 279 */         buf.append(c);
/*     */       } 
/*     */       
/* 282 */       pos++;
/*     */     } 
/*     */     
/* 285 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getUnicodeEncodedFilename(byte[] data, int ln, int pos) {
/* 298 */     StringBuffer buf = new StringBuffer();
/* 299 */     int endpos = pos + ln * 2;
/* 300 */     while (pos < endpos) {
/*     */       
/* 302 */       char c = (char)IntegerHelper.getInt(data[pos], data[pos + 1]);
/*     */       
/* 304 */       if (c == '\001') {
/*     */ 
/*     */         
/* 307 */         pos += 2;
/* 308 */         c = (char)IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 309 */         buf.append(c);
/* 310 */         buf.append(":\\\\");
/*     */       }
/* 312 */       else if (c == '\002') {
/*     */ 
/*     */         
/* 315 */         buf.append('\\');
/*     */       }
/* 317 */       else if (c == '\003') {
/*     */ 
/*     */         
/* 320 */         buf.append('\\');
/*     */       }
/* 322 */       else if (c == '\004') {
/*     */ 
/*     */         
/* 325 */         buf.append("..\\");
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 330 */         buf.append(c);
/*     */       } 
/*     */       
/* 333 */       pos += 2;
/*     */     } 
/*     */     
/* 336 */     return buf.toString();
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\SupbookRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
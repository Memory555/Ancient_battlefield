/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.BaseCompoundFile;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class File
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(File.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int filePos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int oldPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int initialFileSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int arrayGrowSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CompoundFile compoundFile;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings workbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File(InputStream is, WorkbookSettings ws) throws IOException, BiffException {
/*  86 */     this.workbookSettings = ws;
/*  87 */     this.initialFileSize = this.workbookSettings.getInitialFileSize();
/*  88 */     this.arrayGrowSize = this.workbookSettings.getArrayGrowSize();
/*     */     
/*  90 */     byte[] d = new byte[this.initialFileSize];
/*  91 */     int bytesRead = is.read(d);
/*  92 */     int pos = bytesRead;
/*     */ 
/*     */ 
/*     */     
/*  96 */     if (Thread.currentThread().isInterrupted())
/*     */     {
/*  98 */       throw new InterruptedIOException();
/*     */     }
/*     */     
/* 101 */     while (bytesRead != -1) {
/*     */       
/* 103 */       if (pos >= d.length) {
/*     */ 
/*     */         
/* 106 */         byte[] newArray = new byte[d.length + this.arrayGrowSize];
/* 107 */         System.arraycopy(d, 0, newArray, 0, d.length);
/* 108 */         d = newArray;
/*     */       } 
/* 110 */       bytesRead = is.read(d, pos, d.length - pos);
/* 111 */       pos += bytesRead;
/*     */       
/* 113 */       if (Thread.currentThread().isInterrupted())
/*     */       {
/* 115 */         throw new InterruptedIOException();
/*     */       }
/*     */     } 
/*     */     
/* 119 */     bytesRead = pos + 1;
/*     */ 
/*     */     
/* 122 */     if (bytesRead == 0)
/*     */     {
/* 124 */       throw new BiffException(BiffException.excelFileNotFound);
/*     */     }
/*     */     
/* 127 */     CompoundFile cf = new CompoundFile(d, ws);
/*     */     
/*     */     try {
/* 130 */       this.data = cf.getStream("workbook");
/*     */     }
/* 132 */     catch (BiffException e) {
/*     */ 
/*     */       
/* 135 */       this.data = cf.getStream("book");
/*     */     } 
/*     */     
/* 138 */     if (!this.workbookSettings.getPropertySetsDisabled() && (cf.getPropertySetNames()).length > BaseCompoundFile.STANDARD_PROPERTY_SETS.length)
/*     */     {
/*     */ 
/*     */       
/* 142 */       this.compoundFile = cf;
/*     */     }
/*     */     
/* 145 */     cf = null;
/*     */     
/* 147 */     if (!this.workbookSettings.getGCDisabled())
/*     */     {
/* 149 */       System.gc();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File(byte[] d) {
/* 171 */     this.data = d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Record next() {
/* 181 */     Record r = new Record(this.data, this.filePos, this);
/* 182 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Record peek() {
/* 192 */     int tempPos = this.filePos;
/* 193 */     Record r = new Record(this.data, this.filePos, this);
/* 194 */     this.filePos = tempPos;
/* 195 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void skip(int bytes) {
/* 205 */     this.filePos += bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] read(int pos, int length) {
/* 217 */     byte[] ret = new byte[length];
/*     */     
/*     */     try {
/* 220 */       System.arraycopy(this.data, pos, ret, 0, length);
/*     */     }
/* 222 */     catch (ArrayIndexOutOfBoundsException e) {
/*     */       
/* 224 */       logger.error("Array index out of bounds at position " + pos + " record length " + length);
/*     */       
/* 226 */       throw e;
/*     */     } 
/* 228 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPos() {
/* 238 */     return this.filePos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPos(int p) {
/* 254 */     this.oldPos = this.filePos;
/* 255 */     this.filePos = p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void restorePos() {
/* 266 */     this.filePos = this.oldPos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void moveToFirstBof() {
/* 274 */     boolean bofFound = false;
/* 275 */     while (!bofFound) {
/*     */       
/* 277 */       int code = IntegerHelper.getInt(this.data[this.filePos], this.data[this.filePos + 1]);
/* 278 */       if (code == Type.BOF.value) {
/*     */         
/* 280 */         bofFound = true;
/*     */         
/*     */         continue;
/*     */       } 
/* 284 */       skip(128);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 303 */     this.data = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 314 */     return (this.filePos < this.data.length - 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CompoundFile getCompoundFile() {
/* 326 */     return this.compoundFile;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\File.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
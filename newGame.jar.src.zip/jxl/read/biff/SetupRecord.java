/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SetupRecord
/*     */   extends RecordData
/*     */ {
/*     */   private byte[] data;
/*     */   private boolean portraitOrientation;
/*     */   private double headerMargin;
/*     */   private double footerMargin;
/*     */   private int paperSize;
/*     */   private int scaleFactor;
/*     */   private int pageStart;
/*     */   private int fitWidth;
/*     */   private int fitHeight;
/*     */   private int horizontalPrintResolution;
/*     */   private int verticalPrintResolution;
/*     */   private int copies;
/*     */   
/*     */   SetupRecord(Record t) {
/*  99 */     super(Type.SETUP);
/*     */     
/* 101 */     this.data = t.getData();
/*     */     
/* 103 */     this.paperSize = IntegerHelper.getInt(this.data[0], this.data[1]);
/* 104 */     this.scaleFactor = IntegerHelper.getInt(this.data[2], this.data[3]);
/* 105 */     this.pageStart = IntegerHelper.getInt(this.data[4], this.data[5]);
/* 106 */     this.fitWidth = IntegerHelper.getInt(this.data[6], this.data[7]);
/* 107 */     this.fitHeight = IntegerHelper.getInt(this.data[8], this.data[9]);
/* 108 */     this.horizontalPrintResolution = IntegerHelper.getInt(this.data[12], this.data[13]);
/* 109 */     this.verticalPrintResolution = IntegerHelper.getInt(this.data[14], this.data[15]);
/* 110 */     this.copies = IntegerHelper.getInt(this.data[32], this.data[33]);
/*     */     
/* 112 */     this.headerMargin = DoubleHelper.getIEEEDouble(this.data, 16);
/* 113 */     this.footerMargin = DoubleHelper.getIEEEDouble(this.data, 24);
/*     */ 
/*     */ 
/*     */     
/* 117 */     int grbit = IntegerHelper.getInt(this.data[10], this.data[11]);
/* 118 */     this.portraitOrientation = ((grbit & 0x2) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isPortrait() {
/* 128 */     return this.portraitOrientation;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getHeaderMargin() {
/* 138 */     return this.headerMargin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getFooterMargin() {
/* 148 */     return this.footerMargin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPaperSize() {
/* 158 */     return this.paperSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getScaleFactor() {
/* 168 */     return this.scaleFactor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPageStart() {
/* 178 */     return this.pageStart;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFitWidth() {
/* 188 */     return this.fitWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFitHeight() {
/* 198 */     return this.fitHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHorizontalPrintResolution() {
/* 208 */     return this.horizontalPrintResolution;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getVerticalPrintResolution() {
/* 218 */     return this.verticalPrintResolution;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCopies() {
/* 228 */     return this.copies;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\SetupRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import jxl.CellType;
/*     */ import jxl.NumberCell;
/*     */ import jxl.NumberFormulaCell;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SharedNumberFormulaRecord
/*     */   extends BaseSharedFormulaRecord
/*     */   implements NumberCell, FormulaData, NumberFormulaCell
/*     */ {
/*  50 */   private static Logger logger = Logger.getLogger(SharedNumberFormulaRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NumberFormat format;
/*     */ 
/*     */ 
/*     */   
/*     */   private FormattingRecords formattingRecords;
/*     */ 
/*     */ 
/*     */   
/*  68 */   private static DecimalFormat defaultFormat = new DecimalFormat("#.###");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SharedNumberFormulaRecord(Record t, File excelFile, double v, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si) {
/*  89 */     super(t, fr, es, nt, si, excelFile.getPos());
/*  90 */     this.value = v;
/*  91 */     this.format = defaultFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setNumberFormat(NumberFormat f) {
/* 104 */     if (f != null)
/*     */     {
/* 106 */       this.format = f;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue() {
/* 117 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 127 */     return this.format.format(this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 137 */     return CellType.NUMBER_FORMULA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getFormulaData() throws FormulaException {
/* 149 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 151 */       throw new FormulaException(FormulaException.biff8Supported);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 156 */     FormulaParser fp = new FormulaParser(getTokens(), this, getExternalSheet(), getNameTable(), getSheet().getWorkbook().getSettings());
/*     */ 
/*     */ 
/*     */     
/* 160 */     fp.parse();
/* 161 */     byte[] rpnTokens = fp.getBytes();
/*     */     
/* 163 */     byte[] data = new byte[rpnTokens.length + 22];
/*     */ 
/*     */     
/* 166 */     IntegerHelper.getTwoBytes(getRow(), data, 0);
/* 167 */     IntegerHelper.getTwoBytes(getColumn(), data, 2);
/* 168 */     IntegerHelper.getTwoBytes(getXFIndex(), data, 4);
/* 169 */     DoubleHelper.getIEEEBytes(this.value, data, 6);
/*     */ 
/*     */     
/* 172 */     System.arraycopy(rpnTokens, 0, data, 22, rpnTokens.length);
/* 173 */     IntegerHelper.getTwoBytes(rpnTokens.length, data, 20);
/*     */ 
/*     */     
/* 176 */     byte[] d = new byte[data.length - 6];
/* 177 */     System.arraycopy(data, 6, d, 0, data.length - 6);
/*     */     
/* 179 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberFormat getNumberFormat() {
/* 190 */     return this.format;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\SharedNumberFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
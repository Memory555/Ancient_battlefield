/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataValidityListRecord
/*    */   extends RecordData
/*    */ {
/*    */   private int numSettings;
/*    */   
/*    */   DataValidityListRecord(Record t) {
/* 38 */     super(t);
/*    */     
/* 40 */     byte[] data = getRecord().getData();
/* 41 */     this.numSettings = IntegerHelper.getInt(data[14], data[15], data[16], data[17]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   int getNumberOfSettings() {
/* 49 */     return this.numSettings;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 57 */     return getRecord().getData();
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\DataValidityListRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
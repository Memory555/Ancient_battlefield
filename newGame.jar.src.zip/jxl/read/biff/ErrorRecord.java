/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.CellType;
/*    */ import jxl.ErrorCell;
/*    */ import jxl.biff.FormattingRecords;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ErrorRecord
/*    */   extends CellValue
/*    */   implements ErrorCell
/*    */ {
/*    */   private int errorCode;
/*    */   
/*    */   public ErrorRecord(Record t, FormattingRecords fr, SheetImpl si) {
/* 46 */     super(t, fr, si);
/*    */     
/* 48 */     byte[] data = getRecord().getData();
/*    */     
/* 50 */     this.errorCode = data[6];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getErrorCode() {
/* 62 */     return this.errorCode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getContents() {
/* 72 */     return "ERROR " + this.errorCode;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CellType getType() {
/* 82 */     return CellType.ERROR;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\ErrorRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
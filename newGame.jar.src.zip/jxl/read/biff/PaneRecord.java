/*    */ package jxl.read.biff;
/*    */ 
/*    */ import common.Logger;
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PaneRecord
/*    */   extends RecordData
/*    */ {
/* 35 */   private static Logger logger = Logger.getLogger(PaneRecord.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int rowsVisible;
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int columnsVisible;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PaneRecord(Record t) {
/* 53 */     super(t);
/* 54 */     byte[] data = t.getData();
/*    */     
/* 56 */     this.columnsVisible = IntegerHelper.getInt(data[0], data[1]);
/* 57 */     this.rowsVisible = IntegerHelper.getInt(data[2], data[3]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int getRowsVisible() {
/* 67 */     return this.rowsVisible;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final int getColumnsVisible() {
/* 77 */     return this.columnsVisible;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\PaneRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColumnInfoRecord
/*     */   extends RecordData
/*     */ {
/*     */   private byte[] data;
/*     */   private int startColumn;
/*     */   private int endColumn;
/*     */   private int xfIndex;
/*     */   private int width;
/*     */   private boolean hidden;
/*     */   
/*     */   ColumnInfoRecord(Record t) {
/*  68 */     super(Type.COLINFO);
/*     */     
/*  70 */     this.data = t.getData();
/*     */     
/*  72 */     this.startColumn = IntegerHelper.getInt(this.data[0], this.data[1]);
/*  73 */     this.endColumn = IntegerHelper.getInt(this.data[2], this.data[3]);
/*  74 */     this.width = IntegerHelper.getInt(this.data[4], this.data[5]);
/*  75 */     this.xfIndex = IntegerHelper.getInt(this.data[6], this.data[7]);
/*     */     
/*  77 */     int options = IntegerHelper.getInt(this.data[8], this.data[9]);
/*  78 */     this.hidden = ((options & 0x1) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getStartColumn() {
/*  88 */     return this.startColumn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getEndColumn() {
/*  98 */     return this.endColumn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getXFIndex() {
/* 108 */     return this.xfIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 118 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getHidden() {
/* 128 */     return this.hidden;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\ColumnInfoRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
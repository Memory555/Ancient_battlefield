/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.CellType;
/*     */ import jxl.LabelCell;
/*     */ import jxl.StringFormulaCell;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SharedStringFormulaRecord
/*     */   extends BaseSharedFormulaRecord
/*     */   implements LabelCell, FormulaData, StringFormulaCell
/*     */ {
/*  49 */   private static Logger logger = Logger.getLogger(SharedStringFormulaRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SharedStringFormulaRecord(Record t, File excelFile, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si, WorkbookSettings ws) {
/*  76 */     super(t, fr, es, nt, si, excelFile.getPos());
/*  77 */     int pos = excelFile.getPos();
/*     */ 
/*     */     
/*  80 */     int filepos = excelFile.getPos();
/*     */ 
/*     */ 
/*     */     
/*  84 */     Record nextRecord = excelFile.next();
/*  85 */     int count = 0;
/*  86 */     while (nextRecord.getType() != Type.STRING && count < 4) {
/*     */       
/*  88 */       nextRecord = excelFile.next();
/*  89 */       count++;
/*     */     } 
/*  91 */     Assert.verify((count < 4), " @ " + pos);
/*     */     
/*  93 */     byte[] stringData = nextRecord.getData();
/*  94 */     int chars = IntegerHelper.getInt(stringData[0], stringData[1]);
/*     */     
/*  96 */     boolean unicode = false;
/*  97 */     int startpos = 3;
/*  98 */     if (stringData.length == chars + 2) {
/*     */ 
/*     */ 
/*     */       
/* 102 */       startpos = 2;
/* 103 */       unicode = false;
/*     */     }
/* 105 */     else if (stringData[2] == 1) {
/*     */ 
/*     */       
/* 108 */       startpos = 3;
/* 109 */       unicode = true;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 114 */       startpos = 3;
/* 115 */       unicode = false;
/*     */     } 
/*     */     
/* 118 */     if (!unicode) {
/*     */       
/* 120 */       this.value = StringHelper.getString(stringData, chars, startpos, ws);
/*     */     }
/*     */     else {
/*     */       
/* 124 */       this.value = StringHelper.getUnicodeString(stringData, chars, startpos);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 129 */     excelFile.setPos(filepos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString() {
/* 139 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 149 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 159 */     return CellType.STRING_FORMULA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getFormulaData() throws FormulaException {
/* 171 */     if (!getSheet().getWorkbookBof().isBiff8())
/*     */     {
/* 173 */       throw new FormulaException(FormulaException.biff8Supported);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 178 */     FormulaParser fp = new FormulaParser(getTokens(), this, getExternalSheet(), getNameTable(), getSheet().getWorkbook().getSettings());
/*     */ 
/*     */ 
/*     */     
/* 182 */     fp.parse();
/* 183 */     byte[] rpnTokens = fp.getBytes();
/*     */     
/* 185 */     byte[] data = new byte[rpnTokens.length + 22];
/*     */ 
/*     */     
/* 188 */     IntegerHelper.getTwoBytes(getRow(), data, 0);
/* 189 */     IntegerHelper.getTwoBytes(getColumn(), data, 2);
/* 190 */     IntegerHelper.getTwoBytes(getXFIndex(), data, 4);
/*     */ 
/*     */ 
/*     */     
/* 194 */     data[6] = 0;
/* 195 */     data[12] = -1;
/* 196 */     data[13] = -1;
/*     */ 
/*     */     
/* 199 */     System.arraycopy(rpnTokens, 0, data, 22, rpnTokens.length);
/* 200 */     IntegerHelper.getTwoBytes(rpnTokens.length, data, 20);
/*     */ 
/*     */     
/* 203 */     byte[] d = new byte[data.length - 6];
/* 204 */     System.arraycopy(data, 6, d, 0, data.length - 6);
/*     */     
/* 206 */     return d;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\SharedStringFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*      */ package jxl.read.biff;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import jxl.Cell;
/*      */ import jxl.CellType;
/*      */ import jxl.CellView;
/*      */ import jxl.Hyperlink;
/*      */ import jxl.Image;
/*      */ import jxl.LabelCell;
/*      */ import jxl.Range;
/*      */ import jxl.Sheet;
/*      */ import jxl.SheetSettings;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.EmptyCell;
/*      */ import jxl.biff.FormattingRecords;
/*      */ import jxl.biff.Type;
/*      */ import jxl.biff.WorkspaceInformationRecord;
/*      */ import jxl.biff.drawing.Chart;
/*      */ import jxl.biff.drawing.DrawingGroupObject;
/*      */ import jxl.format.CellFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SheetImpl
/*      */   implements Sheet
/*      */ {
/*      */   private File excelFile;
/*      */   private SSTRecord sharedStrings;
/*      */   private BOFRecord sheetBof;
/*      */   private BOFRecord workbookBof;
/*      */   private FormattingRecords formattingRecords;
/*      */   private String name;
/*      */   private int numRows;
/*      */   private int numCols;
/*      */   private Cell[][] cells;
/*      */   private int startPosition;
/*      */   private ColumnInfoRecord[] columnInfos;
/*      */   private RowRecord[] rowRecords;
/*      */   private ArrayList rowProperties;
/*      */   private ArrayList columnInfosArray;
/*      */   private ArrayList sharedFormulas;
/*      */   private ArrayList hyperlinks;
/*      */   private ArrayList charts;
/*      */   private ArrayList drawings;
/*      */   private ArrayList images;
/*      */   private DataValidation dataValidation;
/*      */   private Range[] mergedCells;
/*      */   private boolean columnInfosInitialized;
/*      */   private boolean rowRecordsInitialized;
/*      */   private boolean nineteenFour;
/*      */   private WorkspaceInformationRecord workspaceOptions;
/*      */   private boolean hidden;
/*      */   private PLSRecord plsRecord;
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */   private SheetSettings settings;
/*      */   private int[] rowBreaks;
/*      */   private WorkbookParser workbook;
/*      */   private WorkbookSettings workbookSettings;
/*      */   
/*      */   SheetImpl(File f, SSTRecord sst, FormattingRecords fr, BOFRecord sb, BOFRecord wb, boolean nf, WorkbookParser wp) throws BiffException {
/*  237 */     this.excelFile = f;
/*  238 */     this.sharedStrings = sst;
/*  239 */     this.formattingRecords = fr;
/*  240 */     this.sheetBof = sb;
/*  241 */     this.workbookBof = wb;
/*  242 */     this.columnInfosArray = new ArrayList();
/*  243 */     this.sharedFormulas = new ArrayList();
/*  244 */     this.hyperlinks = new ArrayList();
/*  245 */     this.rowProperties = new ArrayList(10);
/*  246 */     this.columnInfosInitialized = false;
/*  247 */     this.rowRecordsInitialized = false;
/*  248 */     this.nineteenFour = nf;
/*  249 */     this.workbook = wp;
/*  250 */     this.workbookSettings = this.workbook.getSettings();
/*      */ 
/*      */     
/*  253 */     this.startPosition = f.getPos();
/*      */     
/*  255 */     if (this.sheetBof.isChart())
/*      */     {
/*      */       
/*  258 */       this.startPosition -= this.sheetBof.getLength() + 4;
/*      */     }
/*      */     
/*  261 */     Record r = null;
/*  262 */     int bofs = 1;
/*      */     
/*  264 */     while (bofs >= 1) {
/*      */       
/*  266 */       r = f.next();
/*      */ 
/*      */       
/*  269 */       if (r.getCode() == Type.EOF.value)
/*      */       {
/*  271 */         bofs--;
/*      */       }
/*      */       
/*  274 */       if (r.getCode() == Type.BOF.value)
/*      */       {
/*  276 */         bofs++;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Cell getCell(int column, int row) {
/*      */     EmptyCell emptyCell;
/*  292 */     if (this.cells == null)
/*      */     {
/*  294 */       readSheet();
/*      */     }
/*      */     
/*  297 */     Cell c = this.cells[row][column];
/*      */     
/*  299 */     if (c == null) {
/*      */       
/*  301 */       emptyCell = new EmptyCell(column, row);
/*  302 */       this.cells[row][column] = (Cell)emptyCell;
/*      */     } 
/*      */     
/*  305 */     return (Cell)emptyCell;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Cell findCell(String contents) {
/*  319 */     Cell cell = null;
/*  320 */     boolean found = false;
/*      */     
/*  322 */     for (int i = 0; i < getRows() && !found; i++) {
/*      */       
/*  324 */       Cell[] row = getRow(i);
/*  325 */       for (int j = 0; j < row.length && !found; j++) {
/*      */         
/*  327 */         if (row[j].getContents().equals(contents)) {
/*      */           
/*  329 */           cell = row[j];
/*  330 */           found = true;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  335 */     return cell;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LabelCell findLabelCell(String contents) {
/*  352 */     LabelCell cell = null;
/*  353 */     boolean found = false;
/*      */     
/*  355 */     for (int i = 0; i < getRows() && !found; i++) {
/*      */       
/*  357 */       Cell[] row = getRow(i);
/*  358 */       for (int j = 0; j < row.length && !found; j++) {
/*      */         
/*  360 */         if ((row[j].getType() == CellType.LABEL || row[j].getType() == CellType.STRING_FORMULA) && row[j].getContents().equals(contents)) {
/*      */ 
/*      */ 
/*      */           
/*  364 */           cell = (LabelCell)row[j];
/*  365 */           found = true;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  370 */     return cell;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRows() {
/*  382 */     if (this.cells == null)
/*      */     {
/*  384 */       readSheet();
/*      */     }
/*      */     
/*  387 */     return this.numRows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getColumns() {
/*  399 */     if (this.cells == null)
/*      */     {
/*  401 */       readSheet();
/*      */     }
/*      */     
/*  404 */     return this.numCols;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Cell[] getRow(int row) {
/*  418 */     if (this.cells == null)
/*      */     {
/*  420 */       readSheet();
/*      */     }
/*      */ 
/*      */     
/*  424 */     boolean found = false;
/*  425 */     int col = this.numCols - 1;
/*  426 */     while (col >= 0 && !found) {
/*      */       
/*  428 */       if (this.cells[row][col] != null) {
/*      */         
/*  430 */         found = true;
/*      */         
/*      */         continue;
/*      */       } 
/*  434 */       col--;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  439 */     Cell[] c = new Cell[col + 1];
/*      */     
/*  441 */     for (int i = 0; i <= col; i++)
/*      */     {
/*  443 */       c[i] = getCell(i, row);
/*      */     }
/*  445 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Cell[] getColumn(int col) {
/*  459 */     if (this.cells == null)
/*      */     {
/*  461 */       readSheet();
/*      */     }
/*      */ 
/*      */     
/*  465 */     boolean found = false;
/*  466 */     int row = this.numRows - 1;
/*  467 */     while (row >= 0 && !found) {
/*      */       
/*  469 */       if (this.cells[row][col] != null) {
/*      */         
/*  471 */         found = true;
/*      */         
/*      */         continue;
/*      */       } 
/*  475 */       row--;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  480 */     Cell[] c = new Cell[row + 1];
/*      */     
/*  482 */     for (int i = 0; i <= row; i++)
/*      */     {
/*  484 */       c[i] = getCell(col, i);
/*      */     }
/*  486 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  496 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setName(String s) {
/*  506 */     this.name = s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isHidden() {
/*  517 */     return this.hidden;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ColumnInfoRecord getColumnInfo(int col) {
/*  529 */     if (!this.columnInfosInitialized) {
/*      */ 
/*      */       
/*  532 */       Iterator i = this.columnInfosArray.iterator();
/*  533 */       ColumnInfoRecord cir = null;
/*  534 */       while (i.hasNext()) {
/*      */         
/*  536 */         cir = i.next();
/*      */         
/*  538 */         int startcol = Math.max(0, cir.getStartColumn());
/*  539 */         int endcol = Math.min(this.columnInfos.length - 1, cir.getEndColumn());
/*      */         
/*  541 */         for (int c = startcol; c <= endcol; c++)
/*      */         {
/*  543 */           this.columnInfos[c] = cir;
/*      */         }
/*      */         
/*  546 */         if (endcol < startcol)
/*      */         {
/*  548 */           this.columnInfos[startcol] = cir;
/*      */         }
/*      */       } 
/*      */       
/*  552 */       this.columnInfosInitialized = true;
/*      */     } 
/*      */     
/*  555 */     return (col < this.columnInfos.length) ? this.columnInfos[col] : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ColumnInfoRecord[] getColumnInfos() {
/*  566 */     ColumnInfoRecord[] infos = new ColumnInfoRecord[this.columnInfosArray.size()];
/*  567 */     for (int i = 0; i < this.columnInfosArray.size(); i++)
/*      */     {
/*  569 */       infos[i] = this.columnInfosArray.get(i);
/*      */     }
/*      */     
/*  572 */     return infos;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setHidden(boolean h) {
/*  582 */     this.hidden = h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void clear() {
/*  591 */     this.cells = (Cell[][])null;
/*  592 */     this.mergedCells = null;
/*  593 */     this.columnInfosArray.clear();
/*  594 */     this.sharedFormulas.clear();
/*  595 */     this.hyperlinks.clear();
/*  596 */     this.columnInfosInitialized = false;
/*      */     
/*  598 */     if (!this.workbookSettings.getGCDisabled())
/*      */     {
/*  600 */       System.gc();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void readSheet() {
/*  612 */     if (!this.sheetBof.isWorksheet()) {
/*      */       
/*  614 */       this.numRows = 0;
/*  615 */       this.numCols = 0;
/*  616 */       this.cells = new Cell[0][0];
/*      */     } 
/*      */ 
/*      */     
/*  620 */     SheetReader reader = new SheetReader(this.excelFile, this.sharedStrings, this.formattingRecords, this.sheetBof, this.workbookBof, this.nineteenFour, this.workbook, this.startPosition, this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  629 */     reader.read();
/*      */ 
/*      */     
/*  632 */     this.numRows = reader.getNumRows();
/*  633 */     this.numCols = reader.getNumCols();
/*  634 */     this.cells = reader.getCells();
/*  635 */     this.rowProperties = reader.getRowProperties();
/*  636 */     this.columnInfosArray = reader.getColumnInfosArray();
/*  637 */     this.hyperlinks = reader.getHyperlinks();
/*  638 */     this.charts = reader.getCharts();
/*  639 */     this.drawings = reader.getDrawings();
/*  640 */     this.dataValidation = reader.getDataValidation();
/*  641 */     this.mergedCells = reader.getMergedCells();
/*  642 */     this.settings = reader.getSettings();
/*  643 */     this.settings.setHidden(this.hidden);
/*  644 */     this.rowBreaks = reader.getRowBreaks();
/*  645 */     this.workspaceOptions = reader.getWorkspaceOptions();
/*  646 */     this.plsRecord = reader.getPLS();
/*  647 */     this.buttonPropertySet = reader.getButtonPropertySet();
/*      */     
/*  649 */     reader = null;
/*      */     
/*  651 */     if (!this.workbookSettings.getGCDisabled())
/*      */     {
/*  653 */       System.gc();
/*      */     }
/*      */     
/*  656 */     if (this.columnInfosArray.size() > 0) {
/*      */       
/*  658 */       ColumnInfoRecord cir = this.columnInfosArray.get(this.columnInfosArray.size() - 1);
/*      */       
/*  660 */       this.columnInfos = new ColumnInfoRecord[cir.getEndColumn() + 1];
/*      */     }
/*      */     else {
/*      */       
/*  664 */       this.columnInfos = new ColumnInfoRecord[0];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Hyperlink[] getHyperlinks() {
/*  675 */     Hyperlink[] hl = new Hyperlink[this.hyperlinks.size()];
/*      */     
/*  677 */     for (int i = 0; i < this.hyperlinks.size(); i++)
/*      */     {
/*  679 */       hl[i] = this.hyperlinks.get(i);
/*      */     }
/*      */     
/*  682 */     return hl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Range[] getMergedCells() {
/*  692 */     if (this.mergedCells == null)
/*      */     {
/*  694 */       return new Range[0];
/*      */     }
/*      */     
/*  697 */     return this.mergedCells;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowRecord[] getRowProperties() {
/*  707 */     RowRecord[] rp = new RowRecord[this.rowProperties.size()];
/*  708 */     for (int i = 0; i < rp.length; i++)
/*      */     {
/*  710 */       rp[i] = this.rowProperties.get(i);
/*      */     }
/*      */     
/*  713 */     return rp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DataValidation getDataValidation() {
/*  723 */     return this.dataValidation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   RowRecord getRowInfo(int r) {
/*  735 */     if (!this.rowRecordsInitialized) {
/*      */       
/*  737 */       this.rowRecords = new RowRecord[getRows()];
/*  738 */       Iterator i = this.rowProperties.iterator();
/*      */       
/*  740 */       int rownum = 0;
/*  741 */       RowRecord rr = null;
/*  742 */       while (i.hasNext()) {
/*      */         
/*  744 */         rr = i.next();
/*  745 */         rownum = rr.getRowNumber();
/*  746 */         if (rownum < this.rowRecords.length)
/*      */         {
/*  748 */           this.rowRecords[rownum] = rr;
/*      */         }
/*      */       } 
/*      */       
/*  752 */       this.rowRecordsInitialized = true;
/*      */     } 
/*      */     
/*  755 */     return this.rowRecords[r];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int[] getRowPageBreaks() {
/*  765 */     return this.rowBreaks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Chart[] getCharts() {
/*  775 */     Chart[] ch = new Chart[this.charts.size()];
/*      */     
/*  777 */     for (int i = 0; i < ch.length; i++)
/*      */     {
/*  779 */       ch[i] = this.charts.get(i);
/*      */     }
/*  781 */     return ch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final DrawingGroupObject[] getDrawings() {
/*  791 */     DrawingGroupObject[] dr = new DrawingGroupObject[this.drawings.size()];
/*  792 */     dr = (DrawingGroupObject[])this.drawings.toArray((Object[])dr);
/*  793 */     return dr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isProtected() {
/*  804 */     return this.settings.isProtected();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WorkspaceInformationRecord getWorkspaceOptions() {
/*  815 */     return this.workspaceOptions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SheetSettings getSettings() {
/*  825 */     return this.settings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   WorkbookParser getWorkbook() {
/*  834 */     return this.workbook;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CellFormat getColumnFormat(int col) {
/*  846 */     CellView cv = getColumnView(col);
/*  847 */     return cv.getFormat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getColumnWidth(int col) {
/*  859 */     return getColumnView(col).getSize() / 256;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CellView getColumnView(int col) {
/*  871 */     ColumnInfoRecord cir = getColumnInfo(col);
/*  872 */     CellView cv = new CellView();
/*      */     
/*  874 */     if (cir != null) {
/*      */       
/*  876 */       cv.setDimension(cir.getWidth() / 256);
/*  877 */       cv.setSize(cir.getWidth());
/*  878 */       cv.setHidden(cir.getHidden());
/*  879 */       cv.setFormat((CellFormat)this.formattingRecords.getXFRecord(cir.getXFIndex()));
/*      */     }
/*      */     else {
/*      */       
/*  883 */       cv.setDimension(this.settings.getDefaultColumnWidth() / 256);
/*  884 */       cv.setSize(this.settings.getDefaultColumnWidth());
/*      */     } 
/*      */     
/*  887 */     return cv;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRowHeight(int row) {
/*  900 */     return getRowView(row).getDimension();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CellView getRowView(int row) {
/*  912 */     RowRecord rr = getRowInfo(row);
/*      */     
/*  914 */     CellView cv = new CellView();
/*      */     
/*  916 */     if (rr != null) {
/*      */       
/*  918 */       cv.setDimension(rr.getRowHeight());
/*  919 */       cv.setSize(rr.getRowHeight());
/*  920 */       cv.setHidden(rr.isCollapsed());
/*      */     }
/*      */     else {
/*      */       
/*  924 */       cv.setDimension(this.settings.getDefaultRowHeight());
/*  925 */       cv.setSize(this.settings.getDefaultRowHeight());
/*      */     } 
/*      */     
/*  928 */     return cv;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BOFRecord getSheetBof() {
/*  939 */     return this.sheetBof;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BOFRecord getWorkbookBof() {
/*  950 */     return this.workbookBof;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PLSRecord getPLS() {
/*  961 */     return this.plsRecord;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ButtonPropertySetRecord getButtonPropertySet() {
/*  971 */     return this.buttonPropertySet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfImages() {
/*  981 */     if (this.images == null)
/*      */     {
/*  983 */       initializeImages();
/*      */     }
/*      */     
/*  986 */     return this.images.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Image getDrawing(int i) {
/*  997 */     if (this.images == null)
/*      */     {
/*  999 */       initializeImages();
/*      */     }
/*      */     
/* 1002 */     return this.images.get(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeImages() {
/* 1010 */     if (this.images != null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1015 */     this.images = new ArrayList();
/* 1016 */     DrawingGroupObject[] dgos = getDrawings();
/*      */     
/* 1018 */     for (int i = 0; i < dgos.length; i++) {
/*      */       
/* 1020 */       if (dgos[i] instanceof jxl.biff.drawing.Drawing)
/*      */       {
/* 1022 */         this.images.add(dgos[i]);
/*      */       }
/*      */     } 
/*      */   }
/*      */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\SheetImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
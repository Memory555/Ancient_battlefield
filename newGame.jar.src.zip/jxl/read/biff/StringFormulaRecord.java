/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.CellType;
/*     */ import jxl.LabelCell;
/*     */ import jxl.StringFormulaCell;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StringFormulaRecord
/*     */   extends CellValue
/*     */   implements LabelCell, FormulaData, StringFormulaCell
/*     */ {
/*  48 */   private static Logger logger = Logger.getLogger(StringFormulaRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExternalSheet externalSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookMethods nameTable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String formulaString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringFormulaRecord(Record t, File excelFile, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si, WorkbookSettings ws) {
/*  94 */     super(t, fr, si);
/*     */     
/*  96 */     this.externalSheet = es;
/*  97 */     this.nameTable = nt;
/*     */     
/*  99 */     this.data = getRecord().getData();
/*     */     
/* 101 */     int pos = excelFile.getPos();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     Record nextRecord = excelFile.next();
/* 107 */     int count = 0;
/* 108 */     while (nextRecord.getType() != Type.STRING && count < 4) {
/*     */       
/* 110 */       nextRecord = excelFile.next();
/* 111 */       count++;
/*     */     } 
/* 113 */     Assert.verify((count < 4), " @ " + pos);
/* 114 */     readString(nextRecord.getData(), ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringFormulaRecord(Record t, FormattingRecords fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si) {
/* 134 */     super(t, fr, si);
/*     */     
/* 136 */     this.externalSheet = es;
/* 137 */     this.nameTable = nt;
/*     */     
/* 139 */     this.data = getRecord().getData();
/* 140 */     this.value = "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readString(byte[] d, WorkbookSettings ws) {
/* 152 */     int pos = 0;
/* 153 */     int chars = IntegerHelper.getInt(d[0], d[1]);
/*     */     
/* 155 */     if (chars == 0) {
/*     */       
/* 157 */       this.value = "";
/*     */       return;
/*     */     } 
/* 160 */     pos += 2;
/* 161 */     int optionFlags = d[pos];
/* 162 */     pos++;
/*     */     
/* 164 */     if ((optionFlags & 0xF) != optionFlags) {
/*     */ 
/*     */ 
/*     */       
/* 168 */       pos = 0;
/* 169 */       chars = IntegerHelper.getInt(d[0], (byte)0);
/* 170 */       optionFlags = d[1];
/* 171 */       pos = 2;
/*     */     } 
/*     */ 
/*     */     
/* 175 */     boolean extendedString = ((optionFlags & 0x4) != 0);
/*     */ 
/*     */     
/* 178 */     boolean richString = ((optionFlags & 0x8) != 0);
/*     */     
/* 180 */     if (richString)
/*     */     {
/* 182 */       pos += 2;
/*     */     }
/*     */     
/* 185 */     if (extendedString)
/*     */     {
/* 187 */       pos += 4;
/*     */     }
/*     */ 
/*     */     
/* 191 */     boolean asciiEncoding = ((optionFlags & 0x1) == 0);
/*     */     
/* 193 */     if (asciiEncoding) {
/*     */       
/* 195 */       this.value = StringHelper.getString(d, chars, pos, ws);
/*     */     }
/*     */     else {
/*     */       
/* 199 */       this.value = StringHelper.getUnicodeString(d, chars, pos);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 210 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString() {
/* 220 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 230 */     return CellType.STRING_FORMULA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getFormulaData() throws FormulaException {
/* 241 */     if (!getSheet().getWorkbook().getWorkbookBof().isBiff8())
/*     */     {
/* 243 */       throw new FormulaException(FormulaException.biff8Supported);
/*     */     }
/*     */ 
/*     */     
/* 247 */     byte[] d = new byte[this.data.length - 6];
/* 248 */     System.arraycopy(this.data, 6, d, 0, this.data.length - 6);
/*     */     
/* 250 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormula() throws FormulaException {
/* 261 */     if (this.formulaString == null) {
/*     */       
/* 263 */       byte[] tokens = new byte[this.data.length - 22];
/* 264 */       System.arraycopy(this.data, 22, tokens, 0, tokens.length);
/* 265 */       FormulaParser fp = new FormulaParser(tokens, this, this.externalSheet, this.nameTable, getSheet().getWorkbook().getSettings());
/*     */ 
/*     */       
/* 268 */       fp.parse();
/* 269 */       this.formulaString = fp.getFormula();
/*     */     } 
/*     */     
/* 272 */     return this.formulaString;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\StringFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.util.ArrayList;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Record
/*     */ {
/*  37 */   private static final Logger logger = Logger.getLogger(Record.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int code;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Type type;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int length;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int dataPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File file;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList continueRecords;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Record(byte[] d, int offset, File f) {
/*  78 */     this.code = IntegerHelper.getInt(d[offset], d[offset + 1]);
/*  79 */     this.length = IntegerHelper.getInt(d[offset + 2], d[offset + 3]);
/*  80 */     this.file = f;
/*  81 */     this.file.skip(4);
/*  82 */     this.dataPos = f.getPos();
/*  83 */     this.file.skip(this.length);
/*  84 */     this.type = Type.getType(this.code);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Type getType() {
/*  94 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 104 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 114 */     if (this.data == null)
/*     */     {
/* 116 */       this.data = this.file.read(this.dataPos, this.length);
/*     */     }
/*     */ 
/*     */     
/* 120 */     if (this.continueRecords != null) {
/*     */       
/* 122 */       int size = 0;
/* 123 */       byte[][] contData = new byte[this.continueRecords.size()][];
/* 124 */       for (int i = 0; i < this.continueRecords.size(); i++) {
/*     */         
/* 126 */         Record r = this.continueRecords.get(i);
/* 127 */         contData[i] = r.getData();
/* 128 */         byte[] d2 = contData[i];
/* 129 */         size += d2.length;
/*     */       } 
/*     */       
/* 132 */       byte[] d3 = new byte[this.data.length + size];
/* 133 */       System.arraycopy(this.data, 0, d3, 0, this.data.length);
/* 134 */       int pos = this.data.length;
/* 135 */       for (int j = 0; j < contData.length; j++) {
/*     */         
/* 137 */         byte[] d2 = contData[j];
/* 138 */         System.arraycopy(d2, 0, d3, pos, d2.length);
/* 139 */         pos += d2.length;
/*     */       } 
/*     */       
/* 142 */       this.data = d3;
/*     */     } 
/*     */     
/* 145 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCode() {
/* 155 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setType(Type t) {
/* 166 */     this.type = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addContinueRecord(Record d) {
/* 176 */     if (this.continueRecords == null)
/*     */     {
/* 178 */       this.continueRecords = new ArrayList();
/*     */     }
/*     */     
/* 181 */     this.continueRecords.add(d);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\Record.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SharedFormulaRecord
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(SharedFormulaRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int firstRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int lastRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int firstCol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int lastCol;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BaseSharedFormulaRecord templateFormula;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList formulas;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] tokens;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExternalSheet externalSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SheetImpl sheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SharedFormulaRecord(Record t, BaseSharedFormulaRecord fr, ExternalSheet es, WorkbookMethods nt, SheetImpl si) {
/* 105 */     this.sheet = si;
/* 106 */     byte[] data = t.getData();
/*     */     
/* 108 */     this.firstRow = IntegerHelper.getInt(data[0], data[1]);
/* 109 */     this.lastRow = IntegerHelper.getInt(data[2], data[3]);
/* 110 */     this.firstCol = data[4] & 0xFF;
/* 111 */     this.lastCol = data[5] & 0xFF;
/*     */     
/* 113 */     this.formulas = new ArrayList();
/*     */     
/* 115 */     this.templateFormula = fr;
/*     */     
/* 117 */     this.tokens = new byte[data.length - 10];
/* 118 */     System.arraycopy(data, 10, this.tokens, 0, this.tokens.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(BaseSharedFormulaRecord fr) {
/* 130 */     if (fr.getRow() >= this.firstRow && fr.getRow() <= this.lastRow && fr.getColumn() >= this.firstCol && fr.getColumn() <= this.lastCol) {
/*     */ 
/*     */       
/* 133 */       this.formulas.add(fr);
/* 134 */       return true;
/*     */     } 
/*     */     
/* 137 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Cell[] getFormulas(FormattingRecords fr, boolean nf) {
/* 150 */     Cell[] sfs = new Cell[this.formulas.size() + 1];
/*     */ 
/*     */ 
/*     */     
/* 154 */     if (this.templateFormula == null) {
/*     */       
/* 156 */       logger.warn("Shared formula template formula is null");
/* 157 */       return new Cell[0];
/*     */     } 
/*     */     
/* 160 */     this.templateFormula.setTokens(this.tokens);
/* 161 */     NumberFormat templateNumberFormat = null;
/*     */ 
/*     */     
/* 164 */     if (this.templateFormula.getType() == CellType.NUMBER_FORMULA) {
/*     */       
/* 166 */       SharedNumberFormulaRecord snfr = (SharedNumberFormulaRecord)this.templateFormula;
/*     */       
/* 168 */       templateNumberFormat = snfr.getNumberFormat();
/*     */       
/* 170 */       if (fr.isDate(this.templateFormula.getXFIndex())) {
/*     */         
/* 172 */         this.templateFormula = new SharedDateFormulaRecord(snfr, fr, nf, this.sheet, snfr.getFilePos());
/*     */         
/* 174 */         this.templateFormula.setTokens(snfr.getTokens());
/*     */       } 
/*     */     } 
/*     */     
/* 178 */     sfs[0] = this.templateFormula;
/*     */     
/* 180 */     BaseSharedFormulaRecord f = null;
/*     */     
/* 182 */     for (int i = 0; i < this.formulas.size(); i++) {
/*     */       
/* 184 */       f = this.formulas.get(i);
/*     */ 
/*     */       
/* 187 */       if (f.getType() == CellType.NUMBER_FORMULA) {
/*     */         
/* 189 */         SharedNumberFormulaRecord snfr = (SharedNumberFormulaRecord)f;
/*     */         
/* 191 */         if (fr.isDate(f.getXFIndex())) {
/*     */           
/* 193 */           f = new SharedDateFormulaRecord(snfr, fr, nf, this.sheet, snfr.getFilePos());
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 198 */           snfr.setNumberFormat(templateNumberFormat);
/*     */         } 
/*     */       } 
/*     */       
/* 202 */       f.setTokens(this.tokens);
/* 203 */       sfs[i + 1] = f;
/*     */     } 
/*     */     
/* 206 */     return sfs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BaseSharedFormulaRecord getTemplateFormula() {
/* 216 */     return this.templateFormula;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\SharedFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
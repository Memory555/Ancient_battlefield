/*    */ package jxl.read.biff;
/*    */ 
/*    */ import common.Logger;
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CodepageRecord
/*    */   extends RecordData
/*    */ {
/* 35 */   private static Logger logger = Logger.getLogger(CodepageRecord.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int characterSet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CodepageRecord(Record t) {
/* 49 */     super(t);
/* 50 */     byte[] data = t.getData();
/* 51 */     this.characterSet = IntegerHelper.getInt(data[0], data[1]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getCharacterSet() {
/* 61 */     return this.characterSet;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\CodepageRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
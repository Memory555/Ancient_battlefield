/*    */ package jxl.read.biff;
/*    */ 
/*    */ import common.Assert;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DataValidation
/*    */ {
/*    */   private DataValidityListRecord validityList;
/*    */   private DataValiditySettingsRecord[] validitySettings;
/*    */   private int pos;
/*    */   
/*    */   DataValidation(DataValidityListRecord dvlr) {
/* 50 */     this.validityList = dvlr;
/* 51 */     this.validitySettings = new DataValiditySettingsRecord[this.validityList.getNumberOfSettings()];
/*    */     
/* 53 */     this.pos = 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void add(DataValiditySettingsRecord dvsr) {
/* 61 */     Assert.verify((this.pos < this.validitySettings.length));
/*    */     
/* 63 */     this.validitySettings[this.pos] = dvsr;
/* 64 */     this.pos++;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataValidityListRecord getDataValidityList() {
/* 72 */     return this.validityList;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DataValiditySettingsRecord[] getDataValiditySettings() {
/* 80 */     return this.validitySettings;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\DataValidation.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
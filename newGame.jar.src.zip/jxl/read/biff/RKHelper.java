/*    */ package jxl.read.biff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class RKHelper
/*    */ {
/*    */   public static double getDouble(int rk) {
/* 42 */     if ((rk & 0x2) != 0) {
/*    */       
/* 44 */       int intval = rk >> 2;
/*    */       
/* 46 */       double d = intval;
/* 47 */       if ((rk & 0x1) != 0)
/*    */       {
/* 49 */         d /= 100.0D;
/*    */       }
/*    */       
/* 52 */       return d;
/*    */     } 
/*    */ 
/*    */     
/* 56 */     long valbits = (rk & 0xFFFFFFFC);
/* 57 */     valbits <<= 32L;
/* 58 */     double value = Double.longBitsToDouble(valbits);
/*    */     
/* 60 */     if ((rk & 0x1) != 0)
/*    */     {
/* 62 */       value /= 100.0D;
/*    */     }
/*    */     
/* 65 */     return value;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\RKHelper.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
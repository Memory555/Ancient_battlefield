/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Window2Record
/*     */   extends RecordData
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(Window2Record.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean selected;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean showGridLines;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean displayZeroValues;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean frozenPanes;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean frozenNotSplit;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Window2Record(Record t) {
/*  65 */     super(t);
/*  66 */     byte[] data = t.getData();
/*     */     
/*  68 */     int options = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/*  70 */     this.selected = ((options & 0x200) != 0);
/*  71 */     this.showGridLines = ((options & 0x2) != 0);
/*  72 */     this.frozenPanes = ((options & 0x8) != 0);
/*  73 */     this.displayZeroValues = ((options & 0x10) != 0);
/*  74 */     this.frozenNotSplit = ((options & 0x100) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSelected() {
/*  84 */     return this.selected;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getShowGridLines() {
/*  94 */     return this.showGridLines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getDisplayZeroValues() {
/* 104 */     return this.displayZeroValues;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFrozen() {
/* 114 */     return this.frozenPanes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getFrozenNotSplit() {
/* 124 */     return this.frozenNotSplit;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\Window2Record.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.RecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PrintGridLinesRecord
/*    */   extends RecordData
/*    */ {
/*    */   private boolean printGridLines;
/*    */   
/*    */   public PrintGridLinesRecord(Record pgl) {
/* 41 */     super(pgl);
/* 42 */     byte[] data = pgl.getData();
/*    */     
/* 44 */     this.printGridLines = (data[0] == 1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getPrintGridLines() {
/* 54 */     return this.printGridLines;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\PrintGridLinesRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.read.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.RecordData;
/*    */ import jxl.biff.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SCLRecord
/*    */   extends RecordData
/*    */ {
/*    */   private int numerator;
/*    */   private int denominator;
/*    */   
/*    */   protected SCLRecord(Record r) {
/* 47 */     super(Type.SCL);
/*    */     
/* 49 */     byte[] data = r.getData();
/*    */     
/* 51 */     this.numerator = IntegerHelper.getInt(data[0], data[1]);
/* 52 */     this.denominator = IntegerHelper.getInt(data[2], data[3]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getZoomFactor() {
/* 62 */     return this.numerator * 100 / this.denominator;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\SCLRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
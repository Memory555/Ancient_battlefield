/*     */ package jxl.read.biff;
/*     */ 
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SortRecord
/*     */   extends RecordData
/*     */ {
/*     */   private int col1Size;
/*     */   private int col2Size;
/*     */   private int col3Size;
/*     */   private String col1Name;
/*     */   private String col2Name;
/*     */   private String col3Name;
/*     */   private byte optionFlags;
/*     */   private boolean sortColumns = false;
/*     */   private boolean sortKey1Desc = false;
/*     */   private boolean sortKey2Desc = false;
/*     */   private boolean sortKey3Desc = false;
/*     */   private boolean sortCaseSensitive = false;
/*     */   
/*     */   public SortRecord(Record r) {
/*  50 */     super(Type.SORT);
/*     */     
/*  52 */     byte[] data = r.getData();
/*     */     
/*  54 */     this.optionFlags = data[0];
/*     */     
/*  56 */     this.sortColumns = ((this.optionFlags & 0x1) != 0);
/*  57 */     this.sortKey1Desc = ((this.optionFlags & 0x2) != 0);
/*  58 */     this.sortKey2Desc = ((this.optionFlags & 0x4) != 0);
/*  59 */     this.sortKey3Desc = ((this.optionFlags & 0x8) != 0);
/*  60 */     this.sortCaseSensitive = ((this.optionFlags & 0x10) != 0);
/*     */ 
/*     */ 
/*     */     
/*  64 */     this.col1Size = data[2];
/*  65 */     this.col2Size = data[3];
/*  66 */     this.col3Size = data[4];
/*  67 */     int curPos = 5;
/*  68 */     if (data[curPos++] == 0) {
/*     */       
/*  70 */       this.col1Name = new String(data, curPos, this.col1Size);
/*  71 */       curPos += this.col1Size;
/*     */     }
/*     */     else {
/*     */       
/*  75 */       this.col1Name = StringHelper.getUnicodeString(data, this.col1Size, curPos);
/*  76 */       curPos += this.col1Size * 2;
/*     */     } 
/*     */     
/*  79 */     if (this.col2Size > 0) {
/*     */       
/*  81 */       if (data[curPos++] == 0)
/*     */       {
/*  83 */         this.col2Name = new String(data, curPos, this.col2Size);
/*  84 */         curPos += this.col2Size;
/*     */       }
/*     */       else
/*     */       {
/*  88 */         this.col2Name = StringHelper.getUnicodeString(data, this.col2Size, curPos);
/*  89 */         curPos += this.col2Size * 2;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/*  94 */       this.col2Name = "";
/*     */     } 
/*  96 */     if (this.col3Size > 0) {
/*     */       
/*  98 */       if (data[curPos++] == 0)
/*     */       {
/* 100 */         this.col3Name = new String(data, curPos, this.col3Size);
/* 101 */         curPos += this.col3Size;
/*     */       }
/*     */       else
/*     */       {
/* 105 */         this.col3Name = StringHelper.getUnicodeString(data, this.col3Size, curPos);
/* 106 */         curPos += this.col3Size * 2;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 111 */       this.col3Name = "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSortCol1Name() {
/* 121 */     return this.col1Name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSortCol2Name() {
/* 129 */     return this.col2Name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSortCol3Name() {
/* 137 */     return this.col3Name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSortColumns() {
/* 145 */     return this.sortColumns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSortKey1Desc() {
/* 153 */     return this.sortKey1Desc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSortKey2Desc() {
/* 161 */     return this.sortKey2Desc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSortKey3Desc() {
/* 169 */     return this.sortKey3Desc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSortCaseSensitive() {
/* 177 */     return this.sortCaseSensitive;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\SortRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
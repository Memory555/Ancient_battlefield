/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HeaderRecord
/*     */   extends RecordData
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(HeaderRecord.class);
/*     */   
/*     */   private String header;
/*     */ 
/*     */   
/*     */   private static class Biff7
/*     */   {
/*     */     private Biff7() {}
/*     */   }
/*     */ 
/*     */   
/*  48 */   public static Biff7 biff7 = new Biff7();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HeaderRecord(Record t, WorkbookSettings ws) {
/*  58 */     super(t);
/*  59 */     byte[] data = getRecord().getData();
/*     */     
/*  61 */     if (data.length == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  66 */     int chars = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/*  68 */     boolean unicode = (data[2] == 1);
/*     */     
/*  70 */     if (unicode) {
/*     */       
/*  72 */       this.header = StringHelper.getUnicodeString(data, chars, 3);
/*     */     }
/*     */     else {
/*     */       
/*  76 */       this.header = StringHelper.getString(data, chars, 3, ws);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HeaderRecord(Record t, WorkbookSettings ws, Biff7 dummy) {
/*  89 */     super(t);
/*  90 */     byte[] data = getRecord().getData();
/*     */     
/*  92 */     if (data.length == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  97 */     int chars = data[0];
/*  98 */     this.header = StringHelper.getString(data, chars, 1, ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getHeader() {
/* 108 */     return this.header;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\HeaderRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
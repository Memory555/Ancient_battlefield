/*     */ package jxl.read.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.File;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import jxl.CellReferenceHelper;
/*     */ import jxl.Hyperlink;
/*     */ import jxl.Range;
/*     */ import jxl.Sheet;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.RecordData;
/*     */ import jxl.biff.SheetRangeImpl;
/*     */ import jxl.biff.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HyperlinkRecord
/*     */   extends RecordData
/*     */   implements Hyperlink
/*     */ {
/*  47 */   private static Logger logger = Logger.getLogger(HyperlinkRecord.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private int firstRow;
/*     */ 
/*     */ 
/*     */   
/*     */   private int lastRow;
/*     */ 
/*     */ 
/*     */   
/*     */   private int firstColumn;
/*     */ 
/*     */ 
/*     */   
/*     */   private int lastColumn;
/*     */ 
/*     */ 
/*     */   
/*     */   private URL url;
/*     */ 
/*     */ 
/*     */   
/*     */   private File file;
/*     */ 
/*     */ 
/*     */   
/*     */   private String location;
/*     */ 
/*     */ 
/*     */   
/*     */   private SheetRangeImpl range;
/*     */ 
/*     */ 
/*     */   
/*     */   private LinkType linkType;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class LinkType
/*     */   {
/*     */     private LinkType() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   private static final LinkType urlLink = new LinkType();
/*  97 */   private static final LinkType fileLink = new LinkType();
/*  98 */   private static final LinkType workbookLink = new LinkType();
/*  99 */   private static final LinkType unknown = new LinkType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   HyperlinkRecord(Record t, Sheet s, WorkbookSettings ws) {
/* 110 */     super(t);
/*     */     
/* 112 */     this.linkType = unknown;
/*     */     
/* 114 */     byte[] data = getRecord().getData();
/*     */ 
/*     */     
/* 117 */     this.firstRow = IntegerHelper.getInt(data[0], data[1]);
/* 118 */     this.lastRow = IntegerHelper.getInt(data[2], data[3]);
/* 119 */     this.firstColumn = IntegerHelper.getInt(data[4], data[5]);
/* 120 */     this.lastColumn = IntegerHelper.getInt(data[6], data[7]);
/* 121 */     this.range = new SheetRangeImpl(s, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*     */ 
/*     */ 
/*     */     
/* 125 */     int options = IntegerHelper.getInt(data[28], data[29], data[30], data[31]);
/*     */     
/* 127 */     boolean description = ((options & 0x14) != 0);
/* 128 */     int startpos = 32;
/* 129 */     int descbytes = 0;
/* 130 */     if (description) {
/*     */       
/* 132 */       int descchars = IntegerHelper.getInt(data[startpos], data[startpos + 1], data[startpos + 2], data[startpos + 3]);
/*     */ 
/*     */       
/* 135 */       descbytes = descchars * 2 + 4;
/*     */     } 
/*     */     
/* 138 */     startpos += descbytes;
/*     */     
/* 140 */     boolean targetFrame = ((options & 0x80) != 0);
/* 141 */     int targetbytes = 0;
/* 142 */     if (targetFrame) {
/*     */       
/* 144 */       int targetchars = IntegerHelper.getInt(data[startpos], data[startpos + 1], data[startpos + 2], data[startpos + 3]);
/*     */ 
/*     */       
/* 147 */       targetbytes = targetchars * 2 + 4;
/*     */     } 
/*     */     
/* 150 */     startpos += targetbytes;
/*     */ 
/*     */     
/* 153 */     if ((options & 0x3) == 3) {
/*     */       
/* 155 */       this.linkType = urlLink;
/*     */ 
/*     */       
/* 158 */       if (data[startpos] == 3)
/*     */       {
/* 160 */         this.linkType = fileLink;
/*     */       }
/*     */     }
/* 163 */     else if ((options & 0x1) != 0) {
/*     */       
/* 165 */       this.linkType = fileLink;
/*     */       
/* 167 */       if (data[startpos] == -32)
/*     */       {
/* 169 */         this.linkType = urlLink;
/*     */       }
/*     */     }
/* 172 */     else if ((options & 0x8) != 0) {
/*     */       
/* 174 */       this.linkType = workbookLink;
/*     */     } 
/*     */ 
/*     */     
/* 178 */     if (this.linkType == urlLink) {
/*     */       
/* 180 */       String urlString = null;
/*     */       
/*     */       try {
/* 183 */         startpos += 16;
/*     */ 
/*     */         
/* 186 */         int bytes = IntegerHelper.getInt(data[startpos], data[startpos + 1], data[startpos + 2], data[startpos + 3]);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 191 */         urlString = StringHelper.getUnicodeString(data, bytes / 2 - 1, startpos + 4);
/*     */         
/* 193 */         this.url = new URL(urlString);
/*     */       }
/* 195 */       catch (MalformedURLException e) {
/*     */         
/* 197 */         logger.warn("URL " + urlString + " is malformed.  Trying a file");
/*     */         
/*     */         try {
/* 200 */           this.linkType = fileLink;
/* 201 */           this.file = new File(urlString);
/*     */         }
/* 203 */         catch (Exception e3) {
/*     */           
/* 205 */           logger.warn("Cannot set to file.  Setting a default URL");
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/* 210 */             this.linkType = urlLink;
/* 211 */             this.url = new URL("http://www.andykhan.com/jexcelapi/index.html");
/*     */           }
/* 213 */           catch (MalformedURLException e2) {}
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/* 219 */       catch (Throwable e) {
/*     */         
/* 221 */         StringBuffer sb1 = new StringBuffer();
/* 222 */         StringBuffer sb2 = new StringBuffer();
/* 223 */         CellReferenceHelper.getCellReference(this.firstColumn, this.firstRow, sb1);
/* 224 */         CellReferenceHelper.getCellReference(this.lastColumn, this.lastRow, sb2);
/* 225 */         sb1.insert(0, "Exception when parsing URL ");
/* 226 */         sb1.append('"').append(sb2.toString()).append("\".  Using default.");
/* 227 */         logger.warn(sb1, e);
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 232 */           this.url = new URL("http://www.andykhan.com/jexcelapi/index.html");
/*     */         }
/* 234 */         catch (MalformedURLException e2) {}
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 240 */     else if (this.linkType == fileLink) {
/*     */       
/*     */       try
/*     */       {
/* 244 */         startpos += 16;
/*     */ 
/*     */ 
/*     */         
/* 248 */         int upLevelCount = IntegerHelper.getInt(data[startpos], data[startpos + 1]);
/*     */         
/* 250 */         int chars = IntegerHelper.getInt(data[startpos + 2], data[startpos + 3], data[startpos + 4], data[startpos + 5]);
/*     */ 
/*     */ 
/*     */         
/* 254 */         String fileName = StringHelper.getString(data, chars - 1, startpos + 6, ws);
/*     */ 
/*     */         
/* 257 */         StringBuffer sb = new StringBuffer();
/*     */         
/* 259 */         for (int i = 0; i < upLevelCount; i++)
/*     */         {
/* 261 */           sb.append("..\\");
/*     */         }
/*     */         
/* 264 */         sb.append(fileName);
/*     */         
/* 266 */         this.file = new File(sb.toString());
/*     */       }
/* 268 */       catch (Throwable e)
/*     */       {
/* 270 */         e.printStackTrace();
/* 271 */         logger.warn("Exception when parsing file " + e.getClass().getName() + ".");
/*     */         
/* 273 */         this.file = new File(".");
/*     */       }
/*     */     
/* 276 */     } else if (this.linkType == workbookLink) {
/*     */       
/* 278 */       int chars = IntegerHelper.getInt(data[32], data[33], data[34], data[35]);
/* 279 */       this.location = StringHelper.getUnicodeString(data, chars - 1, 36);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 284 */       logger.warn("Cannot determine link type");
/*     */       return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFile() {
/* 296 */     return (this.linkType == fileLink);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isURL() {
/* 306 */     return (this.linkType == urlLink);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocation() {
/* 316 */     return (this.linkType == workbookLink);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRow() {
/* 326 */     return this.firstRow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 336 */     return this.firstColumn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastRow() {
/* 346 */     return this.lastRow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastColumn() {
/* 356 */     return this.lastColumn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public URL getURL() {
/* 366 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getFile() {
/* 376 */     return this.file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Record getRecord() {
/* 386 */     return super.getRecord();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Range getRange() {
/* 398 */     return (Range)this.range;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocation() {
/* 408 */     return this.location;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\read\biff\HyperlinkRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
package jxl;

import jxl.format.CellFormat;

public interface CellFormat extends CellFormat {}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\CellFormat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
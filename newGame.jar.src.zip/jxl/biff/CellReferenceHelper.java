/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CellReferenceHelper
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(CellReferenceHelper.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final char fixedInd = '$';
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getCellReference(int column, int row, StringBuffer buf) {
/*  64 */     getColumnReference(column, buf);
/*     */ 
/*     */     
/*  67 */     buf.append(Integer.toString(row + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getCellReference(int column, boolean colabs, int row, boolean rowabs, StringBuffer buf) {
/*  83 */     if (colabs)
/*     */     {
/*  85 */       buf.append('$');
/*     */     }
/*     */ 
/*     */     
/*  89 */     getColumnReference(column, buf);
/*     */     
/*  91 */     if (rowabs)
/*     */     {
/*  93 */       buf.append('$');
/*     */     }
/*     */ 
/*     */     
/*  97 */     buf.append(Integer.toString(row + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getColumnReference(int column) {
/* 108 */     StringBuffer buf = new StringBuffer();
/* 109 */     getColumnReference(column, buf);
/* 110 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getColumnReference(int column, StringBuffer buf) {
/* 121 */     int v = column / 26;
/* 122 */     int r = column % 26;
/*     */     
/* 124 */     StringBuffer tmp = new StringBuffer();
/* 125 */     while (v != 0) {
/*     */       
/* 127 */       char c = (char)(65 + r);
/*     */       
/* 129 */       tmp.append(c);
/*     */       
/* 131 */       r = v % 26 - 1;
/* 132 */       v /= 26;
/*     */     } 
/*     */     
/* 135 */     char col = (char)(65 + r);
/* 136 */     tmp.append(col);
/*     */ 
/*     */     
/* 139 */     for (int i = tmp.length() - 1; i >= 0; i--)
/*     */     {
/* 141 */       buf.append(tmp.charAt(i));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getCellReference(int sheet, int column, int row, ExternalSheet workbook, StringBuffer buf) {
/* 159 */     buf.append('\'');
/* 160 */     buf.append(workbook.getExternalSheetName(sheet));
/* 161 */     buf.append('\'');
/* 162 */     buf.append('!');
/* 163 */     getCellReference(column, row, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getCellReference(int sheet, int column, boolean colabs, int row, boolean rowabs, ExternalSheet workbook, StringBuffer buf) {
/* 183 */     buf.append('\'');
/* 184 */     buf.append(workbook.getExternalSheetName(sheet));
/* 185 */     buf.append('\'');
/* 186 */     buf.append('!');
/* 187 */     getCellReference(column, colabs, row, rowabs, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCellReference(int sheet, int column, int row, ExternalSheet workbook) {
/* 204 */     StringBuffer sb = new StringBuffer();
/* 205 */     getCellReference(sheet, column, row, workbook, sb);
/* 206 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCellReference(int column, int row) {
/* 219 */     StringBuffer buf = new StringBuffer();
/* 220 */     getCellReference(column, row, buf);
/* 221 */     return buf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getColumn(String s) {
/* 232 */     int colnum = 0;
/* 233 */     int numindex = getNumberIndex(s);
/*     */     
/* 235 */     String s2 = s.toUpperCase();
/*     */     
/* 237 */     int startPos = 0;
/* 238 */     if (s.charAt(0) == '$')
/*     */     {
/* 240 */       startPos = 1;
/*     */     }
/*     */     
/* 243 */     int endPos = numindex;
/* 244 */     if (s.charAt(numindex - 1) == '$')
/*     */     {
/* 246 */       endPos--;
/*     */     }
/*     */     
/* 249 */     for (int i = startPos; i < endPos; i++) {
/*     */ 
/*     */       
/* 252 */       if (i != startPos)
/*     */       {
/* 254 */         colnum = (colnum + 1) * 26;
/*     */       }
/* 256 */       colnum += s2.charAt(i) - 65;
/*     */     } 
/*     */     
/* 259 */     return colnum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getRow(String s) {
/*     */     try {
/* 269 */       return Integer.parseInt(s.substring(getNumberIndex(s))) - 1;
/*     */     }
/* 271 */     catch (NumberFormatException e) {
/*     */       
/* 273 */       logger.warn(e, e);
/* 274 */       return 65535;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getNumberIndex(String s) {
/* 284 */     boolean numberFound = false;
/* 285 */     int pos = 0;
/* 286 */     char c = Character.MIN_VALUE;
/*     */     
/* 288 */     while (!numberFound && pos < s.length()) {
/*     */       
/* 290 */       c = s.charAt(pos);
/*     */       
/* 292 */       if (c >= '0' && c <= '9') {
/*     */         
/* 294 */         numberFound = true;
/*     */         
/*     */         continue;
/*     */       } 
/* 298 */       pos++;
/*     */     } 
/*     */ 
/*     */     
/* 302 */     return pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isColumnRelative(String s) {
/* 313 */     return (s.charAt(0) != '$');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRowRelative(String s) {
/* 324 */     return (s.charAt(getNumberIndex(s) - 1) != '$');
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\CellReferenceHelper.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
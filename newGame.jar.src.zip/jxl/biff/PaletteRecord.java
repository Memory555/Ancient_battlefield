/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.RGB;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PaletteRecord
/*     */   extends WritableRecordData
/*     */ {
/*  34 */   private RGB[] rgbColours = new RGB[56];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean dirty;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean read;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int numColours = 56;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PaletteRecord(Record t) {
/*  64 */     super(t);
/*     */     
/*  66 */     this.initialized = false;
/*  67 */     this.dirty = false;
/*  68 */     this.read = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PaletteRecord() {
/*  76 */     super(Type.PALETTE);
/*     */     
/*  78 */     this.initialized = true;
/*  79 */     this.dirty = false;
/*  80 */     this.read = false;
/*     */ 
/*     */     
/*  83 */     Colour[] colours = Colour.getAllColours();
/*     */     
/*  85 */     for (int i = 0; i < colours.length; i++) {
/*     */       
/*  87 */       Colour c = colours[i];
/*  88 */       setColourRGB(c, c.getDefaultRGB().getRed(), c.getDefaultRGB().getGreen(), c.getDefaultRGB().getBlue());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 103 */     if (this.read && !this.dirty)
/*     */     {
/* 105 */       return getRecord().getData();
/*     */     }
/*     */     
/* 108 */     byte[] data = new byte[226];
/* 109 */     int pos = 0;
/*     */ 
/*     */     
/* 112 */     IntegerHelper.getTwoBytes(56, data, pos);
/*     */ 
/*     */     
/* 115 */     for (int i = 0; i < 56; i++) {
/*     */       
/* 117 */       pos = i * 4 + 2;
/* 118 */       data[pos] = (byte)this.rgbColours[i].getRed();
/* 119 */       data[pos + 1] = (byte)this.rgbColours[i].getGreen();
/* 120 */       data[pos + 2] = (byte)this.rgbColours[i].getBlue();
/*     */     } 
/*     */     
/* 123 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 131 */     byte[] data = getRecord().getData();
/*     */     
/* 133 */     int numrecords = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/* 135 */     for (int i = 0; i < numrecords; i++) {
/*     */       
/* 137 */       int pos = i * 4 + 2;
/* 138 */       int red = IntegerHelper.getInt(data[pos], (byte)0);
/* 139 */       int green = IntegerHelper.getInt(data[pos + 1], (byte)0);
/* 140 */       int blue = IntegerHelper.getInt(data[pos + 2], (byte)0);
/* 141 */       this.rgbColours[i] = new RGB(red, green, blue);
/*     */     } 
/*     */     
/* 144 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDirty() {
/* 155 */     return this.dirty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColourRGB(Colour c, int r, int g, int b) {
/* 169 */     int pos = c.getValue() - 8;
/* 170 */     if (pos < 0 || pos >= 56) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 175 */     if (!this.initialized)
/*     */     {
/* 177 */       initialize();
/*     */     }
/*     */ 
/*     */     
/* 181 */     r = setValueRange(r, 0, 255);
/* 182 */     g = setValueRange(g, 0, 255);
/* 183 */     b = setValueRange(b, 0, 255);
/*     */     
/* 185 */     this.rgbColours[pos] = new RGB(r, g, b);
/*     */ 
/*     */     
/* 188 */     this.dirty = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RGB getColourRGB(Colour c) {
/* 200 */     int pos = c.getValue() - 8;
/* 201 */     if (pos < 0 || pos >= 56)
/*     */     {
/* 203 */       return c.getDefaultRGB();
/*     */     }
/*     */     
/* 206 */     if (!this.initialized)
/*     */     {
/* 208 */       initialize();
/*     */     }
/*     */     
/* 211 */     return this.rgbColours[pos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int setValueRange(int val, int min, int max) {
/* 224 */     val = Math.max(val, min);
/* 225 */     val = Math.min(val, max);
/* 226 */     return val;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\PaletteRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
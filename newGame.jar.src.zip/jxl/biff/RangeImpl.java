/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.Cell;
/*     */ import jxl.Range;
/*     */ import jxl.Sheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RangeImpl
/*     */   implements Range
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(RangeImpl.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookMethods workbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int sheet1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int sheet2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RangeImpl(WorkbookMethods w, int s1, int c1, int r1, int s2, int c2, int r2) {
/*  93 */     this.workbook = w;
/*  94 */     this.sheet1 = s1;
/*  95 */     this.sheet2 = s2;
/*  96 */     this.row1 = r1;
/*  97 */     this.row2 = r2;
/*  98 */     this.column1 = c1;
/*  99 */     this.column2 = c2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cell getTopLeft() {
/* 109 */     Sheet s = this.workbook.getReadSheet(this.sheet1);
/*     */     
/* 111 */     if (this.column1 < s.getColumns() && this.row1 < s.getRows())
/*     */     {
/*     */       
/* 114 */       return s.getCell(this.column1, this.row1);
/*     */     }
/*     */ 
/*     */     
/* 118 */     return (Cell)new EmptyCell(this.column1, this.row1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cell getBottomRight() {
/* 129 */     Sheet s = this.workbook.getReadSheet(this.sheet2);
/*     */     
/* 131 */     if (this.column2 < s.getColumns() && this.row2 < s.getRows())
/*     */     {
/*     */       
/* 134 */       return s.getCell(this.column2, this.row2);
/*     */     }
/*     */ 
/*     */     
/* 138 */     return (Cell)new EmptyCell(this.column2, this.row2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstSheetIndex() {
/* 149 */     return this.sheet1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastSheetIndex() {
/* 159 */     return this.sheet2;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\RangeImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.WorkbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EncodedURLHelper
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(EncodedURLHelper.class);
/*     */ 
/*     */   
/*  40 */   private static byte msDosDriveLetter = 1;
/*  41 */   private static byte sameDrive = 2;
/*  42 */   private static byte endOfSubdirectory = 3;
/*  43 */   private static byte parentDirectory = 4;
/*  44 */   private static byte unencodedUrl = 5;
/*     */ 
/*     */   
/*     */   public static byte[] getEncodedURL(String s, WorkbookSettings ws) {
/*  48 */     if (s.startsWith("http:"))
/*     */     {
/*  50 */       return getURL(s, ws);
/*     */     }
/*     */ 
/*     */     
/*  54 */     return getFile(s, ws);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] getFile(String s, WorkbookSettings ws) {
/*  60 */     ByteArray byteArray = new ByteArray();
/*     */     
/*  62 */     int pos = 0;
/*  63 */     if (s.charAt(1) == ':') {
/*     */ 
/*     */       
/*  66 */       byteArray.add(msDosDriveLetter);
/*  67 */       byteArray.add((byte)s.charAt(0));
/*  68 */       pos = 2;
/*     */     }
/*  70 */     else if (s.charAt(pos) == '\\' || s.charAt(pos) == '/') {
/*     */ 
/*     */       
/*  73 */       byteArray.add(sameDrive);
/*     */     } 
/*     */ 
/*     */     
/*  77 */     while (s.charAt(pos) == '\\' || s.charAt(pos) == '/')
/*     */     {
/*  79 */       pos++;
/*     */     }
/*     */     
/*  82 */     while (pos < s.length()) {
/*     */       
/*  84 */       int nextSepIndex1 = s.indexOf('/', pos);
/*  85 */       int nextSepIndex2 = s.indexOf('\\', pos);
/*  86 */       int nextSepIndex = 0;
/*  87 */       String nextFileNameComponent = null;
/*     */       
/*  89 */       if (nextSepIndex1 != -1 && nextSepIndex2 != -1) {
/*     */ 
/*     */         
/*  92 */         nextSepIndex = Math.min(nextSepIndex1, nextSepIndex2);
/*     */       }
/*  94 */       else if (nextSepIndex1 == -1 || nextSepIndex2 == -1) {
/*     */ 
/*     */         
/*  97 */         nextSepIndex = Math.max(nextSepIndex1, nextSepIndex2);
/*     */       } 
/*     */       
/* 100 */       if (nextSepIndex == -1) {
/*     */ 
/*     */         
/* 103 */         nextFileNameComponent = s.substring(pos);
/* 104 */         pos = s.length();
/*     */       }
/*     */       else {
/*     */         
/* 108 */         nextFileNameComponent = s.substring(pos, nextSepIndex);
/* 109 */         pos = nextSepIndex + 1;
/*     */       } 
/*     */       
/* 112 */       if (!nextFileNameComponent.equals("."))
/*     */       {
/*     */ 
/*     */         
/* 116 */         if (nextFileNameComponent.equals("..")) {
/*     */ 
/*     */           
/* 119 */           byteArray.add(parentDirectory);
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 124 */           byteArray.add(StringHelper.getBytes(nextFileNameComponent, ws));
/*     */         } 
/*     */       }
/*     */       
/* 128 */       if (pos < s.length())
/*     */       {
/* 130 */         byteArray.add(endOfSubdirectory);
/*     */       }
/*     */     } 
/*     */     
/* 134 */     return byteArray.getBytes();
/*     */   }
/*     */ 
/*     */   
/*     */   private static byte[] getURL(String s, WorkbookSettings ws) {
/* 139 */     ByteArray byteArray = new ByteArray();
/* 140 */     byteArray.add(unencodedUrl);
/* 141 */     byteArray.add((byte)s.length());
/* 142 */     byteArray.add(StringHelper.getBytes(s, ws));
/* 143 */     return byteArray.getBytes();
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\EncodedURLHelper.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
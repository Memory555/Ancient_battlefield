/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.Range;
/*     */ import jxl.Sheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SheetRangeImpl
/*     */   implements Range
/*     */ {
/*     */   private Sheet sheet;
/*     */   private int column1;
/*     */   private int row1;
/*     */   private int column2;
/*     */   private int row2;
/*     */   
/*     */   public SheetRangeImpl(Sheet s, int c1, int r1, int c2, int r2) {
/*  70 */     this.sheet = s;
/*  71 */     this.row1 = r1;
/*  72 */     this.row2 = r2;
/*  73 */     this.column1 = c1;
/*  74 */     this.column2 = c2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SheetRangeImpl(SheetRangeImpl c, Sheet s) {
/*  85 */     this.sheet = s;
/*  86 */     this.row1 = c.row1;
/*  87 */     this.row2 = c.row2;
/*  88 */     this.column1 = c.column1;
/*  89 */     this.column2 = c.column2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cell getTopLeft() {
/*  99 */     return this.sheet.getCell(this.column1, this.row1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cell getBottomRight() {
/* 109 */     return this.sheet.getCell(this.column2, this.row2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstSheetIndex() {
/* 120 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastSheetIndex() {
/* 131 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean intersects(SheetRangeImpl range) {
/* 145 */     if (range == this)
/*     */     {
/* 147 */       return true;
/*     */     }
/*     */     
/* 150 */     if (this.row2 < range.row1 || this.row1 > range.row2 || this.column2 < range.column1 || this.column1 > range.column2)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 155 */       return false;
/*     */     }
/*     */     
/* 158 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 168 */     StringBuffer sb = new StringBuffer();
/* 169 */     CellReferenceHelper.getCellReference(this.column1, this.row1, sb);
/* 170 */     sb.append('-');
/* 171 */     CellReferenceHelper.getCellReference(this.column2, this.row2, sb);
/* 172 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertRow(int r) {
/* 182 */     if (r > this.row2) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 187 */     if (r <= this.row1)
/*     */     {
/* 189 */       this.row1++;
/*     */     }
/*     */     
/* 192 */     if (r <= this.row2)
/*     */     {
/* 194 */       this.row2++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertColumn(int c) {
/* 205 */     if (c > this.column2) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 210 */     if (c <= this.column1)
/*     */     {
/* 212 */       this.column1++;
/*     */     }
/*     */     
/* 215 */     if (c <= this.column2)
/*     */     {
/* 217 */       this.column2++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRow(int r) {
/* 228 */     if (r > this.row2) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 233 */     if (r < this.row1)
/*     */     {
/* 235 */       this.row1--;
/*     */     }
/*     */     
/* 238 */     if (r < this.row2)
/*     */     {
/* 240 */       this.row2--;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeColumn(int c) {
/* 251 */     if (c > this.column2) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 256 */     if (c < this.column1)
/*     */     {
/* 258 */       this.column1--;
/*     */     }
/*     */     
/* 261 */     if (c < this.column2)
/*     */     {
/* 263 */       this.column2--;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 274 */     return 0xFFFF ^ this.row1 ^ this.row2 ^ this.column1 ^ this.column2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 285 */     if (o == this)
/*     */     {
/* 287 */       return true;
/*     */     }
/*     */     
/* 290 */     if (!(o instanceof SheetRangeImpl))
/*     */     {
/* 292 */       return false;
/*     */     }
/*     */     
/* 295 */     SheetRangeImpl compare = (SheetRangeImpl)o;
/*     */     
/* 297 */     return (this.column1 == compare.column1 && this.column2 == compare.column2 && this.row1 == compare.row1 && this.row2 == compare.row2);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\SheetRangeImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
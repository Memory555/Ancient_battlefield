/*     */ package jxl.biff;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ByteArray
/*     */ {
/*     */   private int growSize;
/*     */   private byte[] bytes;
/*     */   private int pos;
/*     */   private static final int defaultGrowSize = 1024;
/*     */   
/*     */   public ByteArray() {
/*  50 */     this(1024);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArray(int gs) {
/*  60 */     this.growSize = gs;
/*  61 */     this.bytes = new byte[1024];
/*  62 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(byte b) {
/*  72 */     checkSize(1);
/*  73 */     this.bytes[this.pos] = b;
/*  74 */     this.pos++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(byte[] b) {
/*  84 */     checkSize(b.length);
/*  85 */     System.arraycopy(b, 0, this.bytes, this.pos, b.length);
/*  86 */     this.pos += b.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/*  96 */     byte[] returnArray = new byte[this.pos];
/*  97 */     System.arraycopy(this.bytes, 0, returnArray, 0, this.pos);
/*  98 */     return returnArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkSize(int sz) {
/* 109 */     while (this.pos + sz >= this.bytes.length) {
/*     */ 
/*     */       
/* 112 */       byte[] newArray = new byte[this.bytes.length + this.growSize];
/* 113 */       System.arraycopy(this.bytes, 0, newArray, 0, this.pos);
/* 114 */       this.bytes = newArray;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\ByteArray.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
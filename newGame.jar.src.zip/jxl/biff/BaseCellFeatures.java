/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.drawing.Comment;
/*     */ import jxl.write.biff.CellValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BaseCellFeatures
/*     */ {
/*  34 */   public static Logger logger = Logger.getLogger(BaseCellFeatures.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String comment;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double commentWidth;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double commentHeight;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Comment commentDrawing;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CellValue writableCell;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double defaultCommentWidth = 3.0D;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final double defaultCommentHeight = 4.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BaseCellFeatures() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BaseCellFeatures(BaseCellFeatures cf) {
/*  79 */     this.comment = cf.comment;
/*  80 */     this.commentWidth = cf.commentWidth;
/*  81 */     this.commentHeight = cf.commentHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getComment() {
/*  89 */     return this.comment;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getCommentWidth() {
/*  97 */     return this.commentWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getCommentHeight() {
/* 105 */     return this.commentHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setWritableCell(CellValue wc) {
/* 115 */     this.writableCell = wc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReadComment(String s, double w, double h) {
/* 123 */     this.comment = s;
/* 124 */     this.commentWidth = w;
/* 125 */     this.commentHeight = h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComment(String s) {
/* 135 */     setComment(s, 3.0D, 4.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setComment(String s, double width, double height) {
/* 147 */     this.comment = s;
/* 148 */     this.commentWidth = width;
/* 149 */     this.commentHeight = height;
/*     */     
/* 151 */     if (this.commentDrawing != null) {
/*     */       
/* 153 */       this.commentDrawing.setCommentText(s);
/* 154 */       this.commentDrawing.setWidth(width);
/* 155 */       this.commentDrawing.setWidth(height);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeComment() {
/* 166 */     this.comment = null;
/*     */ 
/*     */     
/* 169 */     if (this.commentDrawing != null) {
/*     */ 
/*     */ 
/*     */       
/* 173 */       this.writableCell.removeComment(this.commentDrawing);
/* 174 */       this.commentDrawing = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCommentDrawing(Comment c) {
/* 183 */     this.commentDrawing = c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Comment getCommentDrawing() {
/* 191 */     return this.commentDrawing;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\BaseCellFeatures.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
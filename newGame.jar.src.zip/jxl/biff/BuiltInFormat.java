/*     */ package jxl.biff;
/*     */ 
/*     */ import jxl.format.Format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class BuiltInFormat
/*     */   implements Format, DisplayFormat
/*     */ {
/*     */   private String formatString;
/*     */   private int formatIndex;
/*     */   
/*     */   private BuiltInFormat(String s, int i) {
/*  52 */     this.formatIndex = i;
/*  53 */     this.formatString = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormatString() {
/*  65 */     return this.formatString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFormatIndex() {
/*  75 */     return this.formatIndex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInitialized() {
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(int pos) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBuiltIn() {
/* 102 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 112 */     if (o == this)
/*     */     {
/* 114 */       return true;
/*     */     }
/*     */     
/* 117 */     if (!(o instanceof BuiltInFormat))
/*     */     {
/* 119 */       return false;
/*     */     }
/*     */     
/* 122 */     BuiltInFormat bif = (BuiltInFormat)o;
/* 123 */     return (this.formatIndex == bif.formatIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   public static BuiltInFormat[] builtIns = new BuiltInFormat[50];
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 134 */     builtIns[0] = new BuiltInFormat("", 0);
/* 135 */     builtIns[1] = new BuiltInFormat("0", 1);
/* 136 */     builtIns[2] = new BuiltInFormat("0.00", 2);
/* 137 */     builtIns[3] = new BuiltInFormat("#,##0", 3);
/* 138 */     builtIns[4] = new BuiltInFormat("#,##0.00", 4);
/* 139 */     builtIns[5] = new BuiltInFormat("($#,##0_);($#,##0)", 5);
/* 140 */     builtIns[6] = new BuiltInFormat("($#,##0_);[Red]($#,##0)", 6);
/* 141 */     builtIns[7] = new BuiltInFormat("($#,##0_);[Red]($#,##0)", 7);
/* 142 */     builtIns[8] = new BuiltInFormat("($#,##0.00_);[Red]($#,##0.00)", 8);
/* 143 */     builtIns[9] = new BuiltInFormat("0%", 9);
/* 144 */     builtIns[10] = new BuiltInFormat("0.00%", 10);
/* 145 */     builtIns[11] = new BuiltInFormat("0.00E+00", 11);
/* 146 */     builtIns[12] = new BuiltInFormat("# ?/?", 12);
/* 147 */     builtIns[13] = new BuiltInFormat("# ??/??", 13);
/* 148 */     builtIns[14] = new BuiltInFormat("dd/mm/yyyy", 14);
/* 149 */     builtIns[15] = new BuiltInFormat("d-mmm-yy", 15);
/* 150 */     builtIns[16] = new BuiltInFormat("d-mmm", 16);
/* 151 */     builtIns[17] = new BuiltInFormat("mmm-yy", 17);
/* 152 */     builtIns[18] = new BuiltInFormat("h:mm AM/PM", 18);
/* 153 */     builtIns[19] = new BuiltInFormat("h:mm:ss AM/PM", 19);
/* 154 */     builtIns[20] = new BuiltInFormat("h:mm", 20);
/* 155 */     builtIns[21] = new BuiltInFormat("h:mm:ss", 21);
/* 156 */     builtIns[22] = new BuiltInFormat("m/d/yy h:mm", 22);
/* 157 */     builtIns[37] = new BuiltInFormat("(#,##0_);(#,##0)", 37);
/* 158 */     builtIns[38] = new BuiltInFormat("(#,##0_);[Red](#,##0)", 38);
/* 159 */     builtIns[39] = new BuiltInFormat("(#,##0.00_);(#,##0.00)", 39);
/* 160 */     builtIns[40] = new BuiltInFormat("(#,##0.00_);[Red](#,##0.00)", 40);
/* 161 */     builtIns[41] = new BuiltInFormat("_(*#,##0_);_(*(#,##0);_(*\"-\"_);(@_)", 41);
/*     */     
/* 163 */     builtIns[42] = new BuiltInFormat("_($*#,##0_);_($*(#,##0);_($*\"-\"_);(@_)", 42);
/*     */     
/* 165 */     builtIns[43] = new BuiltInFormat("_(* #,##0.00_);_(* (#,##0.00);_(* \"-\"??_);(@_)", 43);
/*     */     
/* 167 */     builtIns[44] = new BuiltInFormat("_($* #,##0.00_);_($* (#,##0.00);_($* \"-\"??_);(@_)", 44);
/*     */     
/* 169 */     builtIns[45] = new BuiltInFormat("mm:ss", 45);
/* 170 */     builtIns[46] = new BuiltInFormat("[h]mm:ss", 46);
/* 171 */     builtIns[47] = new BuiltInFormat("mm:ss.0", 47);
/* 172 */     builtIns[48] = new BuiltInFormat("##0.0E+0", 48);
/* 173 */     builtIns[49] = new BuiltInFormat("@", 49);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\BuiltInFormat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
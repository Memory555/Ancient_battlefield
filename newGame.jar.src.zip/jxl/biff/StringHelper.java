/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import jxl.WorkbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StringHelper
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(StringHelper.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getBytes(String s) {
/*  56 */     return s.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getBytes(String s, WorkbookSettings ws) {
/*     */     try {
/*  70 */       return s.getBytes(ws.getEncoding());
/*     */     }
/*  72 */     catch (UnsupportedEncodingException e) {
/*     */ 
/*     */       
/*  75 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getUnicodeBytes(String s) {
/*     */     try {
/*  89 */       byte[] b = s.getBytes("UnicodeLittle");
/*     */ 
/*     */ 
/*     */       
/*  93 */       if (b.length == s.length() * 2 + 2) {
/*     */         
/*  95 */         byte[] b2 = new byte[b.length - 2];
/*  96 */         System.arraycopy(b, 2, b2, 0, b2.length);
/*  97 */         b = b2;
/*     */       } 
/*  99 */       return b;
/*     */     }
/* 101 */     catch (UnsupportedEncodingException e) {
/*     */ 
/*     */       
/* 104 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getBytes(String s, byte[] d, int pos) {
/* 118 */     byte[] b = getBytes(s);
/* 119 */     System.arraycopy(b, 0, d, pos, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getUnicodeBytes(String s, byte[] d, int pos) {
/* 132 */     byte[] b = getUnicodeBytes(s);
/* 133 */     System.arraycopy(b, 0, d, pos, b.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getString(byte[] d, int length, int pos, WorkbookSettings ws) {
/*     */     try {
/* 151 */       byte[] b = new byte[length];
/* 152 */       System.arraycopy(d, pos, b, 0, length);
/* 153 */       return new String(b, ws.getEncoding());
/*     */     }
/* 155 */     catch (UnsupportedEncodingException e) {
/*     */       
/* 157 */       logger.warn(e.toString());
/* 158 */       return "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getUnicodeString(byte[] d, int length, int pos) {
/*     */     try {
/* 174 */       byte[] b = new byte[length * 2];
/* 175 */       System.arraycopy(d, pos, b, 0, length * 2);
/* 176 */       return new String(b, "UnicodeLittle");
/*     */     }
/* 178 */     catch (UnsupportedEncodingException e) {
/*     */ 
/*     */       
/* 181 */       return "";
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\StringHelper.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.text.DateFormat;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.Format;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.format.Format;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormatRecord
/*     */   extends WritableRecordData
/*     */   implements DisplayFormat, Format
/*     */ {
/*  43 */   public static Logger logger = Logger.getLogger(FormatRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int indexCode;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String formatString;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean date;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean number;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Format format;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings settings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private static String[] dateStrings = new String[] { "dd", "mm", "yy", "hh", "ss", "m/", "/d" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BiffType
/*     */   {
/*     */     private BiffType() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   public static final BiffType biff8 = new BiffType();
/* 105 */   public static final BiffType biff7 = new BiffType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FormatRecord(String fmt, int refno) {
/* 115 */     super(Type.FORMAT);
/* 116 */     this.formatString = fmt;
/* 117 */     this.indexCode = refno;
/* 118 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FormatRecord() {
/* 126 */     super(Type.FORMAT);
/* 127 */     this.initialized = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FormatRecord(FormatRecord fr) {
/* 137 */     super(Type.FORMAT);
/* 138 */     this.initialized = false;
/*     */     
/* 140 */     this.formatString = fr.formatString;
/* 141 */     this.date = fr.date;
/* 142 */     this.number = fr.number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormatRecord(Record t, WorkbookSettings ws, BiffType biffType) {
/* 156 */     super(t);
/*     */     
/* 158 */     byte[] data = getRecord().getData();
/* 159 */     this.indexCode = IntegerHelper.getInt(data[0], data[1]);
/* 160 */     this.initialized = true;
/*     */     
/* 162 */     if (biffType == biff8) {
/*     */       
/* 164 */       int numchars = IntegerHelper.getInt(data[2], data[3]);
/* 165 */       if (data[4] == 0)
/*     */       {
/* 167 */         this.formatString = StringHelper.getString(data, numchars, 5, ws);
/*     */       }
/*     */       else
/*     */       {
/* 171 */         this.formatString = StringHelper.getUnicodeString(data, numchars, 5);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 176 */       int numchars = data[2];
/* 177 */       byte[] chars = new byte[numchars];
/* 178 */       System.arraycopy(data, 3, chars, 0, chars.length);
/* 179 */       this.formatString = new String(chars);
/*     */     } 
/*     */     
/* 182 */     this.date = false;
/* 183 */     this.number = false;
/*     */ 
/*     */     
/* 186 */     for (int i = 0; i < dateStrings.length; i++) {
/*     */       
/* 188 */       String dateString = dateStrings[i];
/* 189 */       if (this.formatString.indexOf(dateString) != -1 || this.formatString.indexOf(dateString.toUpperCase()) != -1) {
/*     */ 
/*     */         
/* 192 */         this.date = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 198 */     if (!this.date)
/*     */     {
/* 200 */       if (this.formatString.indexOf('#') != -1 || this.formatString.indexOf('0') != -1)
/*     */       {
/*     */         
/* 203 */         this.number = true;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 215 */     this.data = new byte[this.formatString.length() * 2 + 3 + 2];
/*     */     
/* 217 */     IntegerHelper.getTwoBytes(this.indexCode, this.data, 0);
/* 218 */     IntegerHelper.getTwoBytes(this.formatString.length(), this.data, 2);
/* 219 */     this.data[4] = 1;
/* 220 */     StringHelper.getUnicodeBytes(this.formatString, this.data, 5);
/*     */     
/* 222 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFormatIndex() {
/* 232 */     return this.indexCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInitialized() {
/* 242 */     return this.initialized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initialize(int pos) {
/* 254 */     this.indexCode = pos;
/* 255 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String replace(String input, String search, String replace) {
/* 269 */     String fmtstr = input;
/* 270 */     int pos = fmtstr.indexOf(search);
/* 271 */     while (pos != -1) {
/*     */       
/* 273 */       StringBuffer tmp = new StringBuffer(fmtstr.substring(0, pos));
/* 274 */       tmp.append(replace);
/* 275 */       tmp.append(fmtstr.substring(pos + search.length()));
/* 276 */       fmtstr = tmp.toString();
/* 277 */       pos = fmtstr.indexOf(search);
/*     */     } 
/* 279 */     return fmtstr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setFormatString(String s) {
/* 290 */     this.formatString = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isDate() {
/* 300 */     return this.date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isNumber() {
/* 310 */     return this.number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final NumberFormat getNumberFormat() {
/* 320 */     if (this.format != null && this.format instanceof NumberFormat)
/*     */     {
/* 322 */       return (NumberFormat)this.format;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 327 */       String fs = this.formatString;
/*     */ 
/*     */       
/* 330 */       fs = replace(fs, "E+", "E");
/* 331 */       fs = replace(fs, "_)", "");
/* 332 */       fs = replace(fs, "_", "");
/* 333 */       fs = replace(fs, "[Red]", "");
/* 334 */       fs = replace(fs, "\\", "");
/*     */       
/* 336 */       this.format = new DecimalFormat(fs);
/*     */     }
/* 338 */     catch (IllegalArgumentException e) {
/*     */ 
/*     */ 
/*     */       
/* 342 */       this.format = new DecimalFormat("#.###");
/*     */     } 
/*     */     
/* 345 */     return (NumberFormat)this.format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DateFormat getDateFormat() {
/* 355 */     if (this.format != null && this.format instanceof DateFormat)
/*     */     {
/* 357 */       return (DateFormat)this.format;
/*     */     }
/*     */     
/* 360 */     String fmt = this.formatString;
/*     */ 
/*     */     
/* 363 */     int pos = fmt.indexOf("AM/PM");
/* 364 */     while (pos != -1) {
/*     */       
/* 366 */       StringBuffer stringBuffer = new StringBuffer(fmt.substring(0, pos));
/* 367 */       stringBuffer.append('a');
/* 368 */       stringBuffer.append(fmt.substring(pos + 5));
/* 369 */       fmt = stringBuffer.toString();
/* 370 */       pos = fmt.indexOf("AM/PM");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 375 */     pos = fmt.indexOf("ss.0");
/* 376 */     while (pos != -1) {
/*     */       
/* 378 */       StringBuffer stringBuffer = new StringBuffer(fmt.substring(0, pos));
/* 379 */       stringBuffer.append("ss.SSS");
/*     */ 
/*     */       
/* 382 */       pos += 4;
/* 383 */       while (pos < fmt.length() && fmt.charAt(pos) == '0')
/*     */       {
/* 385 */         pos++;
/*     */       }
/*     */       
/* 388 */       stringBuffer.append(fmt.substring(pos));
/* 389 */       fmt = stringBuffer.toString();
/* 390 */       pos = fmt.indexOf("ss.0");
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 395 */     StringBuffer sb = new StringBuffer();
/* 396 */     for (int i = 0; i < fmt.length(); i++) {
/*     */       
/* 398 */       if (fmt.charAt(i) != '\\')
/*     */       {
/* 400 */         sb.append(fmt.charAt(i));
/*     */       }
/*     */     } 
/*     */     
/* 404 */     fmt = sb.toString();
/*     */ 
/*     */ 
/*     */     
/* 408 */     if (fmt.charAt(0) == '[') {
/*     */       
/* 410 */       int end = fmt.indexOf(']');
/* 411 */       if (end != -1)
/*     */       {
/* 413 */         fmt = fmt.substring(end + 1);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 418 */     fmt = replace(fmt, ";@", "");
/*     */ 
/*     */ 
/*     */     
/* 422 */     char[] formatBytes = fmt.toCharArray();
/*     */     
/* 424 */     for (int j = 0; j < formatBytes.length; j++) {
/*     */       
/* 426 */       if (formatBytes[j] == 'm')
/*     */       {
/*     */ 
/*     */         
/* 430 */         if (j > 0 && (formatBytes[j - 1] == 'm' || formatBytes[j - 1] == 'M')) {
/*     */           
/* 432 */           formatBytes[j] = formatBytes[j - 1];
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/* 440 */           int minuteDist = Integer.MAX_VALUE; int k;
/* 441 */           for (k = j - 1; k > 0; k--) {
/*     */             
/* 443 */             if (formatBytes[k] == 'h') {
/*     */               
/* 445 */               minuteDist = j - k;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 450 */           for (k = j + 1; k < formatBytes.length; k++) {
/*     */             
/* 452 */             if (formatBytes[k] == 'h') {
/*     */               
/* 454 */               minuteDist = Math.min(minuteDist, k - j);
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 459 */           for (k = j - 1; k > 0; k--) {
/*     */             
/* 461 */             if (formatBytes[k] == 'H') {
/*     */               
/* 463 */               minuteDist = j - k;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 468 */           for (k = j + 1; k < formatBytes.length; k++) {
/*     */             
/* 470 */             if (formatBytes[k] == 'H') {
/*     */               
/* 472 */               minuteDist = Math.min(minuteDist, k - j);
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */           
/* 478 */           for (k = j - 1; k > 0; k--) {
/*     */             
/* 480 */             if (formatBytes[k] == 's') {
/*     */               
/* 482 */               minuteDist = Math.min(minuteDist, j - k);
/*     */               break;
/*     */             } 
/*     */           } 
/* 486 */           for (k = j + 1; k < formatBytes.length; k++) {
/*     */             
/* 488 */             if (formatBytes[k] == 's') {
/*     */               
/* 490 */               minuteDist = Math.min(minuteDist, k - j);
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */           
/* 497 */           int monthDist = Integer.MAX_VALUE; int m;
/* 498 */           for (m = j - 1; m > 0; m--) {
/*     */             
/* 500 */             if (formatBytes[m] == 'd') {
/*     */               
/* 502 */               monthDist = j - m;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 507 */           for (m = j + 1; m < formatBytes.length; m++) {
/*     */             
/* 509 */             if (formatBytes[m] == 'd') {
/*     */               
/* 511 */               monthDist = Math.min(monthDist, m - j);
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 516 */           for (m = j - 1; m > 0; m--) {
/*     */             
/* 518 */             if (formatBytes[m] == 'y') {
/*     */               
/* 520 */               monthDist = Math.min(monthDist, j - m);
/*     */               break;
/*     */             } 
/*     */           } 
/* 524 */           for (m = j + 1; m < formatBytes.length; m++) {
/*     */             
/* 526 */             if (formatBytes[m] == 'y') {
/*     */               
/* 528 */               monthDist = Math.min(monthDist, m - j);
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 533 */           if (monthDist < minuteDist) {
/*     */ 
/*     */             
/* 536 */             formatBytes[j] = Character.toUpperCase(formatBytes[j]);
/*     */           }
/* 538 */           else if (monthDist == minuteDist && monthDist != Integer.MAX_VALUE) {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 543 */             char ind = formatBytes[j - monthDist];
/* 544 */             if (ind == 'y' || ind == 'd')
/*     */             {
/*     */               
/* 547 */               formatBytes[j] = Character.toUpperCase(formatBytes[j]);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 556 */       this.format = new SimpleDateFormat(new String(formatBytes));
/*     */     }
/* 558 */     catch (IllegalArgumentException e) {
/*     */ 
/*     */       
/* 561 */       this.format = new SimpleDateFormat("dd MM yyyy hh:mm:ss");
/*     */     } 
/* 563 */     return (DateFormat)this.format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndexCode() {
/* 573 */     return this.indexCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormatString() {
/* 583 */     return this.formatString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isBuiltIn() {
/* 593 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 602 */     return this.formatString.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 614 */     if (o == this)
/*     */     {
/* 616 */       return true;
/*     */     }
/*     */     
/* 619 */     if (!(o instanceof FormatRecord))
/*     */     {
/* 621 */       return false;
/*     */     }
/*     */     
/* 624 */     FormatRecord fr = (FormatRecord)o;
/*     */ 
/*     */     
/* 627 */     if (this.initialized && fr.initialized) {
/*     */ 
/*     */       
/* 630 */       if (this.date != fr.date || this.number != fr.number)
/*     */       {
/*     */         
/* 633 */         return false;
/*     */       }
/*     */       
/* 636 */       return this.formatString.equals(fr.formatString);
/*     */     } 
/*     */ 
/*     */     
/* 640 */     return this.formatString.equals(fr.formatString);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\FormatRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
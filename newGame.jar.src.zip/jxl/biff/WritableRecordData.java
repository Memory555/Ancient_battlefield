/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class WritableRecordData
/*     */   extends RecordData
/*     */   implements ByteData
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(WritableRecordData.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final int maxRecordLength = 8228;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WritableRecordData(Type t) {
/*  50 */     super(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WritableRecordData(Record t) {
/*  60 */     super(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final byte[] getBytes() {
/*  72 */     byte[] data = getData();
/*     */     
/*  74 */     int dataLength = data.length;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     if (data.length > 8224) {
/*     */       
/*  82 */       dataLength = 8224;
/*  83 */       data = handleContinueRecords(data);
/*     */     } 
/*     */     
/*  86 */     byte[] bytes = new byte[data.length + 4];
/*     */     
/*  88 */     System.arraycopy(data, 0, bytes, 4, data.length);
/*     */     
/*  90 */     IntegerHelper.getTwoBytes(getCode(), bytes, 0);
/*  91 */     IntegerHelper.getTwoBytes(dataLength, bytes, 2);
/*     */     
/*  93 */     return bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] handleContinueRecords(byte[] data) {
/* 105 */     int continuedData = data.length - 8224;
/* 106 */     int numContinueRecords = continuedData / 8224 + 1;
/*     */ 
/*     */ 
/*     */     
/* 110 */     byte[] newdata = new byte[data.length + numContinueRecords * 4];
/*     */ 
/*     */ 
/*     */     
/* 114 */     System.arraycopy(data, 0, newdata, 0, 8224);
/* 115 */     int oldarraypos = 8224;
/* 116 */     int newarraypos = 8224;
/*     */ 
/*     */     
/* 119 */     for (int i = 0; i < numContinueRecords; i++) {
/*     */ 
/*     */       
/* 122 */       int length = Math.min(data.length - oldarraypos, 8224);
/*     */ 
/*     */       
/* 125 */       IntegerHelper.getTwoBytes(Type.CONTINUE.value, newdata, newarraypos);
/* 126 */       IntegerHelper.getTwoBytes(length, newdata, newarraypos + 2);
/*     */ 
/*     */       
/* 129 */       System.arraycopy(data, oldarraypos, newdata, newarraypos + 4, length);
/*     */ 
/*     */       
/* 132 */       oldarraypos += length;
/* 133 */       newarraypos += length + 4;
/*     */     } 
/*     */     
/* 136 */     return newdata;
/*     */   }
/*     */   
/*     */   protected abstract byte[] getData();
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\WritableRecordData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Type
/*     */ {
/*     */   public final int value;
/*  34 */   private static Type[] types = new Type[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Type(int v) {
/*  44 */     this.value = v;
/*     */ 
/*     */     
/*  47 */     Type[] newTypes = new Type[types.length + 1];
/*  48 */     System.arraycopy(types, 0, newTypes, 0, types.length);
/*  49 */     newTypes[types.length] = this;
/*  50 */     types = newTypes;
/*     */   }
/*     */ 
/*     */   
/*  54 */   private static ArbitraryType arbitrary = new ArbitraryType();
/*     */   
/*     */   private static class ArbitraryType {
/*     */     private ArbitraryType() {}
/*     */   }
/*     */   
/*     */   private Type(int v, ArbitraryType arb) {
/*  61 */     this.value = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  70 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  80 */     if (o == this)
/*     */     {
/*  82 */       return true;
/*     */     }
/*     */     
/*  85 */     if (!(o instanceof Type))
/*     */     {
/*  87 */       return false;
/*     */     }
/*     */     
/*  90 */     Type t = (Type)o;
/*     */     
/*  92 */     return (this.value == t.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type getType(int v) {
/* 102 */     for (int i = 0; i < types.length; i++) {
/*     */       
/* 104 */       if ((types[i]).value == v)
/*     */       {
/* 106 */         return types[i];
/*     */       }
/*     */     } 
/*     */     
/* 110 */     return UNKNOWN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Type createType(int v) {
/* 120 */     return new Type(v, arbitrary);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 125 */   public static final Type BOF = new Type(2057);
/*     */ 
/*     */   
/* 128 */   public static final Type EOF = new Type(10);
/*     */ 
/*     */   
/* 131 */   public static final Type BOUNDSHEET = new Type(133);
/*     */ 
/*     */   
/* 134 */   public static final Type SUPBOOK = new Type(430);
/*     */ 
/*     */   
/* 137 */   public static final Type EXTERNSHEET = new Type(23);
/*     */ 
/*     */   
/* 140 */   public static final Type DIMENSION = new Type(512);
/*     */ 
/*     */   
/* 143 */   public static final Type BLANK = new Type(513);
/*     */ 
/*     */   
/* 146 */   public static final Type MULBLANK = new Type(190);
/*     */ 
/*     */   
/* 149 */   public static final Type ROW = new Type(520);
/*     */ 
/*     */   
/* 152 */   public static final Type NOTE = new Type(28);
/*     */ 
/*     */   
/* 155 */   public static final Type TXO = new Type(438);
/*     */ 
/*     */   
/* 158 */   public static final Type RK = new Type(126);
/*     */ 
/*     */   
/* 161 */   public static final Type RK2 = new Type(638);
/*     */ 
/*     */   
/* 164 */   public static final Type MULRK = new Type(189);
/*     */ 
/*     */   
/* 167 */   public static final Type INDEX = new Type(523);
/*     */ 
/*     */   
/* 170 */   public static final Type DBCELL = new Type(215);
/*     */ 
/*     */   
/* 173 */   public static final Type SST = new Type(252);
/*     */ 
/*     */   
/* 176 */   public static final Type COLINFO = new Type(125);
/*     */ 
/*     */   
/* 179 */   public static final Type EXTSST = new Type(255);
/*     */ 
/*     */   
/* 182 */   public static final Type CONTINUE = new Type(60);
/*     */ 
/*     */   
/* 185 */   public static final Type LABEL = new Type(516);
/*     */ 
/*     */   
/* 188 */   public static final Type RSTRING = new Type(214);
/*     */ 
/*     */   
/* 191 */   public static final Type LABELSST = new Type(253);
/*     */ 
/*     */   
/* 194 */   public static final Type NUMBER = new Type(515);
/*     */ 
/*     */   
/* 197 */   public static final Type NAME = new Type(24);
/*     */ 
/*     */   
/* 200 */   public static final Type TABID = new Type(317);
/*     */ 
/*     */   
/* 203 */   public static final Type ARRAY = new Type(545);
/*     */ 
/*     */   
/* 206 */   public static final Type STRING = new Type(519);
/*     */ 
/*     */   
/* 209 */   public static final Type FORMULA = new Type(1030);
/*     */ 
/*     */   
/* 212 */   public static final Type FORMULA2 = new Type(6);
/*     */ 
/*     */   
/* 215 */   public static final Type SHAREDFORMULA = new Type(1212);
/*     */ 
/*     */   
/* 218 */   public static final Type FORMAT = new Type(1054);
/*     */ 
/*     */   
/* 221 */   public static final Type XF = new Type(224);
/*     */ 
/*     */   
/* 224 */   public static final Type BOOLERR = new Type(517);
/*     */ 
/*     */   
/* 227 */   public static final Type INTERFACEHDR = new Type(225);
/*     */ 
/*     */   
/* 230 */   public static final Type SAVERECALC = new Type(95);
/*     */ 
/*     */   
/* 233 */   public static final Type INTERFACEEND = new Type(226);
/*     */ 
/*     */   
/* 236 */   public static final Type XCT = new Type(89);
/*     */ 
/*     */   
/* 239 */   public static final Type CRN = new Type(90);
/*     */ 
/*     */   
/* 242 */   public static final Type DEFCOLWIDTH = new Type(85);
/*     */ 
/*     */   
/* 245 */   public static final Type DEFAULTROWHEIGHT = new Type(549);
/*     */ 
/*     */   
/* 248 */   public static final Type WRITEACCESS = new Type(92);
/*     */ 
/*     */   
/* 251 */   public static final Type WSBOOL = new Type(129);
/*     */ 
/*     */   
/* 254 */   public static final Type CODEPAGE = new Type(66);
/*     */ 
/*     */   
/* 257 */   public static final Type DSF = new Type(353);
/*     */ 
/*     */   
/* 260 */   public static final Type FNGROUPCOUNT = new Type(156);
/*     */ 
/*     */   
/* 263 */   public static final Type COUNTRY = new Type(140);
/*     */ 
/*     */   
/* 266 */   public static final Type PROTECT = new Type(18);
/*     */ 
/*     */   
/* 269 */   public static final Type SCENPROTECT = new Type(221);
/*     */ 
/*     */   
/* 272 */   public static final Type OBJPROTECT = new Type(99);
/*     */ 
/*     */   
/* 275 */   public static final Type PRINTHEADERS = new Type(42);
/*     */ 
/*     */   
/* 278 */   public static final Type HEADER = new Type(20);
/*     */ 
/*     */   
/* 281 */   public static final Type FOOTER = new Type(21);
/*     */ 
/*     */   
/* 284 */   public static final Type HCENTER = new Type(131);
/*     */ 
/*     */   
/* 287 */   public static final Type VCENTER = new Type(132);
/*     */ 
/*     */   
/* 290 */   public static final Type FILEPASS = new Type(47);
/*     */ 
/*     */   
/* 293 */   public static final Type SETUP = new Type(161);
/*     */ 
/*     */   
/* 296 */   public static final Type PRINTGRIDLINES = new Type(43);
/*     */ 
/*     */   
/* 299 */   public static final Type GRIDSET = new Type(130);
/*     */ 
/*     */   
/* 302 */   public static final Type GUTS = new Type(128);
/*     */ 
/*     */   
/* 305 */   public static final Type WINDOWPROTECT = new Type(25);
/*     */ 
/*     */   
/* 308 */   public static final Type PROT4REV = new Type(431);
/*     */ 
/*     */   
/* 311 */   public static final Type PROT4REVPASS = new Type(444);
/*     */ 
/*     */   
/* 314 */   public static final Type PASSWORD = new Type(19);
/*     */ 
/*     */   
/* 317 */   public static final Type REFRESHALL = new Type(439);
/*     */ 
/*     */   
/* 320 */   public static final Type WINDOW1 = new Type(61);
/*     */ 
/*     */   
/* 323 */   public static final Type WINDOW2 = new Type(574);
/*     */ 
/*     */   
/* 326 */   public static final Type BACKUP = new Type(64);
/*     */ 
/*     */   
/* 329 */   public static final Type HIDEOBJ = new Type(141);
/*     */ 
/*     */   
/* 332 */   public static final Type NINETEENFOUR = new Type(34);
/*     */ 
/*     */   
/* 335 */   public static final Type PRECISION = new Type(14);
/*     */ 
/*     */   
/* 338 */   public static final Type BOOKBOOL = new Type(218);
/*     */ 
/*     */   
/* 341 */   public static final Type FONT = new Type(49);
/*     */ 
/*     */   
/* 344 */   public static final Type MMS = new Type(193);
/*     */ 
/*     */   
/* 347 */   public static final Type CALCMODE = new Type(13);
/*     */ 
/*     */   
/* 350 */   public static final Type CALCCOUNT = new Type(12);
/*     */ 
/*     */   
/* 353 */   public static final Type REFMODE = new Type(15);
/*     */ 
/*     */   
/* 356 */   public static final Type TEMPLATE = new Type(96);
/*     */ 
/*     */   
/* 359 */   public static final Type OBJPROJ = new Type(211);
/*     */ 
/*     */   
/* 362 */   public static final Type DELTA = new Type(16);
/*     */ 
/*     */   
/* 365 */   public static final Type MERGEDCELLS = new Type(229);
/*     */ 
/*     */   
/* 368 */   public static final Type ITERATION = new Type(17);
/*     */ 
/*     */   
/* 371 */   public static final Type STYLE = new Type(659);
/*     */ 
/*     */   
/* 374 */   public static final Type USESELFS = new Type(352);
/*     */ 
/*     */   
/* 377 */   public static final Type HORIZONTALPAGEBREAKS = new Type(27);
/*     */ 
/*     */   
/* 380 */   public static final Type SELECTION = new Type(29);
/*     */ 
/*     */   
/* 383 */   public static final Type HLINK = new Type(440);
/*     */ 
/*     */   
/* 386 */   public static final Type OBJ = new Type(93);
/*     */ 
/*     */   
/* 389 */   public static final Type MSODRAWING = new Type(236);
/*     */ 
/*     */   
/* 392 */   public static final Type MSODRAWINGGROUP = new Type(235);
/*     */ 
/*     */   
/* 395 */   public static final Type LEFTMARGIN = new Type(38);
/*     */ 
/*     */   
/* 398 */   public static final Type RIGHTMARGIN = new Type(39);
/*     */ 
/*     */   
/* 401 */   public static final Type TOPMARGIN = new Type(40);
/*     */ 
/*     */   
/* 404 */   public static final Type BOTTOMMARGIN = new Type(41);
/*     */ 
/*     */   
/* 407 */   public static final Type EXTERNNAME = new Type(35);
/*     */ 
/*     */   
/* 410 */   public static final Type PALETTE = new Type(146);
/*     */ 
/*     */   
/* 413 */   public static final Type PLS = new Type(77);
/*     */ 
/*     */   
/* 416 */   public static final Type SCL = new Type(160);
/*     */ 
/*     */   
/* 419 */   public static final Type PANE = new Type(65);
/*     */ 
/*     */   
/* 422 */   public static final Type WEIRD1 = new Type(239);
/*     */ 
/*     */   
/* 425 */   public static final Type SORT = new Type(144);
/*     */ 
/*     */   
/* 428 */   public static final Type DV = new Type(446);
/*     */ 
/*     */   
/* 431 */   public static final Type DVAL = new Type(434);
/*     */ 
/*     */   
/* 434 */   public static final Type BUTTONPROPERTYSET = new Type(442);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 439 */   public static final Type FONTX = new Type(4134);
/*     */ 
/*     */   
/* 442 */   public static final Type IFMT = new Type(4174);
/*     */ 
/*     */   
/* 445 */   public static final Type FBI = new Type(4192);
/*     */ 
/*     */   
/* 448 */   public static final Type ALRUNS = new Type(4176);
/*     */ 
/*     */   
/* 451 */   public static final Type UNKNOWN = new Type(65535);
/*     */ 
/*     */   
/* 454 */   public static final Type U1C0 = new Type(448);
/* 455 */   public static final Type U1C1 = new Type(449);
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\Type.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
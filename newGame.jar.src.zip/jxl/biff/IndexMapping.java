/*    */ package jxl.biff;
/*    */ 
/*    */ import common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class IndexMapping
/*    */ {
/* 34 */   private static Logger logger = Logger.getLogger(IndexMapping.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int[] newIndices;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   IndexMapping(int size) {
/* 48 */     this.newIndices = new int[size];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void setMapping(int oldIndex, int newIndex) {
/* 58 */     this.newIndices[oldIndex] = newIndex;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getNewIndex(int oldIndex) {
/* 68 */     return this.newIndices[oldIndex];
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\IndexMapping.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
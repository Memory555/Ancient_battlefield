/*     */ package jxl.biff;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class IntegerHelper
/*     */ {
/*     */   public static int getInt(byte b1, byte b2) {
/*  43 */     int i1 = b1 & 0xFF;
/*  44 */     int i2 = b2 & 0xFF;
/*  45 */     int val = i2 << 8 | i1;
/*  46 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static short getShort(byte b1, byte b2) {
/*  58 */     short i1 = (short)(b1 & 0xFF);
/*  59 */     short i2 = (short)(b2 & 0xFF);
/*  60 */     short val = (short)(i2 << 8 | i1);
/*  61 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getInt(byte b1, byte b2, byte b3, byte b4) {
/*  76 */     int i1 = getInt(b1, b2);
/*  77 */     int i2 = getInt(b3, b4);
/*     */     
/*  79 */     int val = i2 << 16 | i1;
/*  80 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getTwoBytes(int i) {
/*  91 */     byte[] bytes = new byte[2];
/*     */     
/*  93 */     bytes[0] = (byte)(i & 0xFF);
/*  94 */     bytes[1] = (byte)((i & 0xFF00) >> 8);
/*     */     
/*  96 */     return bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] getFourBytes(int i) {
/* 107 */     byte[] bytes = new byte[4];
/*     */     
/* 109 */     int i1 = i & 0xFFFF;
/* 110 */     int i2 = (i & 0xFFFF0000) >> 16;
/*     */     
/* 112 */     getTwoBytes(i1, bytes, 0);
/* 113 */     getTwoBytes(i2, bytes, 2);
/*     */     
/* 115 */     return bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getTwoBytes(int i, byte[] target, int pos) {
/* 129 */     byte[] bytes = getTwoBytes(i);
/* 130 */     target[pos] = bytes[0];
/* 131 */     target[pos + 1] = bytes[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getFourBytes(int i, byte[] target, int pos) {
/* 144 */     byte[] bytes = getFourBytes(i);
/* 145 */     target[pos] = bytes[0];
/* 146 */     target[pos + 1] = bytes[1];
/* 147 */     target[pos + 2] = bytes[2];
/* 148 */     target[pos + 3] = bytes[3];
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\IntegerHelper.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
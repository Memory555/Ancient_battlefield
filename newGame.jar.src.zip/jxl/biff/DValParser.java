/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DValParser
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(DValParser.class);
/*     */ 
/*     */   
/*  40 */   private static int PROMPT_BOX_VISIBLE_MASK = 1;
/*  41 */   private static int PROMPT_BOX_AT_CELL_MASK = 2;
/*  42 */   private static int VALIDITY_DATA_CACHED_MASK = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean promptBoxVisible;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean promptBoxAtCell;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validityDataCached;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int numDVRecords;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DValParser(byte[] data) {
/*  69 */     int options = IntegerHelper.getInt(data[0], data[1]);
/*     */     
/*  71 */     this.promptBoxVisible = ((options & PROMPT_BOX_VISIBLE_MASK) != 0);
/*  72 */     this.promptBoxAtCell = ((options & PROMPT_BOX_AT_CELL_MASK) != 0);
/*  73 */     this.validityDataCached = ((options & VALIDITY_DATA_CACHED_MASK) != 0);
/*     */     
/*  75 */     this.numDVRecords = IntegerHelper.getInt(data[14], data[15], data[16], data[17]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/*  84 */     byte[] data = new byte[18];
/*     */     
/*  86 */     int options = 0;
/*     */     
/*  88 */     if (this.promptBoxVisible)
/*     */     {
/*  90 */       options |= PROMPT_BOX_VISIBLE_MASK;
/*     */     }
/*     */     
/*  93 */     if (this.promptBoxAtCell)
/*     */     {
/*  95 */       options |= PROMPT_BOX_AT_CELL_MASK;
/*     */     }
/*     */     
/*  98 */     if (this.validityDataCached)
/*     */     {
/* 100 */       options |= VALIDITY_DATA_CACHED_MASK;
/*     */     }
/*     */     
/* 103 */     IntegerHelper.getFourBytes(-1, data, 10);
/*     */     
/* 105 */     IntegerHelper.getFourBytes(this.numDVRecords, data, 14);
/*     */     
/* 107 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dvRemoved() {
/* 116 */     this.numDVRecords--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfDVRecords() {
/* 126 */     return this.numDVRecords;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\DValParser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
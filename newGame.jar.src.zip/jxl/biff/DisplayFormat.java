package jxl.biff;

public interface DisplayFormat {
  int getFormatIndex();
  
  boolean isInitialized();
  
  void initialize(int paramInt);
  
  boolean isBuiltIn();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\DisplayFormat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
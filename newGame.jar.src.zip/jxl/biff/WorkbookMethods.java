package jxl.biff;

import jxl.Sheet;

public interface WorkbookMethods {
  Sheet getReadSheet(int paramInt);
  
  String getName(int paramInt);
  
  int getNameIndex(String paramString);
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\WorkbookMethods.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
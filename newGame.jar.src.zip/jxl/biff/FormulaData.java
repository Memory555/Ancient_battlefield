package jxl.biff;

import jxl.Cell;
import jxl.biff.formula.FormulaException;

public interface FormulaData extends Cell {
  byte[] getFormulaData() throws FormulaException;
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\FormulaData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
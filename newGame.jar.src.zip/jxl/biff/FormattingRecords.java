/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.RGB;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormattingRecords
/*     */ {
/*  44 */   private static Logger logger = Logger.getLogger(FormattingRecords.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap formats;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList formatsList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList xfRecords;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int nextCustomIndexNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Fonts fonts;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PaletteRecord palette;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int customFormatStartIndex = 164;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int maxFormatRecordsIndex = 441;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int minXFRecords = 21;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormattingRecords(Fonts f) {
/* 101 */     this.xfRecords = new ArrayList(10);
/* 102 */     this.formats = new HashMap(10);
/* 103 */     this.formatsList = new ArrayList(10);
/* 104 */     this.fonts = f;
/* 105 */     this.nextCustomIndexNumber = 164;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addStyle(XFRecord xf) throws NumFormatRecordsException {
/* 120 */     if (!xf.isInitialized()) {
/*     */       
/* 122 */       int pos = this.xfRecords.size();
/* 123 */       xf.initialize(pos, this, this.fonts);
/* 124 */       this.xfRecords.add(xf);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 131 */     else if (xf.getXFIndex() >= this.xfRecords.size()) {
/*     */       
/* 133 */       this.xfRecords.add(xf);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addFormat(DisplayFormat fr) throws NumFormatRecordsException {
/* 151 */     if (fr.isInitialized() && fr.getFormatIndex() >= 441) {
/*     */ 
/*     */       
/* 154 */       logger.warn("Format index exceeds Excel maximum - assigning custom number");
/*     */       
/* 156 */       fr.initialize(this.nextCustomIndexNumber);
/* 157 */       this.nextCustomIndexNumber++;
/*     */     } 
/*     */ 
/*     */     
/* 161 */     if (!fr.isInitialized()) {
/*     */       
/* 163 */       fr.initialize(this.nextCustomIndexNumber);
/* 164 */       this.nextCustomIndexNumber++;
/*     */     } 
/*     */     
/* 167 */     if (this.nextCustomIndexNumber > 441) {
/*     */       
/* 169 */       this.nextCustomIndexNumber = 441;
/* 170 */       throw new NumFormatRecordsException();
/*     */     } 
/*     */     
/* 173 */     if (fr.getFormatIndex() >= this.nextCustomIndexNumber)
/*     */     {
/* 175 */       this.nextCustomIndexNumber = fr.getFormatIndex() + 1;
/*     */     }
/*     */     
/* 178 */     if (!fr.isBuiltIn()) {
/*     */       
/* 180 */       this.formatsList.add(fr);
/* 181 */       this.formats.put(new Integer(fr.getFormatIndex()), fr);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isDate(int pos) {
/* 195 */     XFRecord xfr = this.xfRecords.get(pos);
/*     */     
/* 197 */     if (xfr.isDate())
/*     */     {
/* 199 */       return true;
/*     */     }
/*     */     
/* 202 */     FormatRecord fr = (FormatRecord)this.formats.get(new Integer(xfr.getFormatRecord()));
/*     */ 
/*     */     
/* 205 */     return (fr == null) ? false : fr.isDate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final DateFormat getDateFormat(int pos) {
/* 217 */     XFRecord xfr = this.xfRecords.get(pos);
/*     */     
/* 219 */     if (xfr.isDate())
/*     */     {
/* 221 */       return xfr.getDateFormat();
/*     */     }
/*     */     
/* 224 */     FormatRecord fr = (FormatRecord)this.formats.get(new Integer(xfr.getFormatRecord()));
/*     */ 
/*     */     
/* 227 */     if (fr == null)
/*     */     {
/* 229 */       return null;
/*     */     }
/*     */     
/* 232 */     return fr.isDate() ? fr.getDateFormat() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final NumberFormat getNumberFormat(int pos) {
/* 244 */     XFRecord xfr = this.xfRecords.get(pos);
/*     */     
/* 246 */     if (xfr.isNumber())
/*     */     {
/* 248 */       return xfr.getNumberFormat();
/*     */     }
/*     */     
/* 251 */     FormatRecord fr = (FormatRecord)this.formats.get(new Integer(xfr.getFormatRecord()));
/*     */ 
/*     */     
/* 254 */     if (fr == null)
/*     */     {
/* 256 */       return null;
/*     */     }
/*     */     
/* 259 */     return fr.isNumber() ? fr.getNumberFormat() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FormatRecord getFormatRecord(int index) {
/* 270 */     return (FormatRecord)this.formats.get(new Integer(index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(File outputFile) throws IOException {
/* 282 */     Iterator i = this.formatsList.iterator();
/* 283 */     FormatRecord fr = null;
/* 284 */     while (i.hasNext()) {
/*     */       
/* 286 */       fr = i.next();
/* 287 */       outputFile.write(fr);
/*     */     } 
/*     */ 
/*     */     
/* 291 */     i = this.xfRecords.iterator();
/* 292 */     XFRecord xfr = null;
/* 293 */     while (i.hasNext()) {
/*     */       
/* 295 */       xfr = (XFRecord)i.next();
/* 296 */       outputFile.write(xfr);
/*     */     } 
/*     */ 
/*     */     
/* 300 */     BuiltInStyle style = new BuiltInStyle(16, 3);
/* 301 */     outputFile.write(style);
/*     */     
/* 303 */     style = new BuiltInStyle(17, 6);
/* 304 */     outputFile.write(style);
/*     */     
/* 306 */     style = new BuiltInStyle(18, 4);
/* 307 */     outputFile.write(style);
/*     */     
/* 309 */     style = new BuiltInStyle(19, 7);
/* 310 */     outputFile.write(style);
/*     */     
/* 312 */     style = new BuiltInStyle(0, 0);
/* 313 */     outputFile.write(style);
/*     */     
/* 315 */     style = new BuiltInStyle(20, 5);
/* 316 */     outputFile.write(style);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final Fonts getFonts() {
/* 326 */     return this.fonts;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final XFRecord getXFRecord(int index) {
/* 338 */     return this.xfRecords.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int getNumberOfFormatRecords() {
/* 350 */     return this.formatsList.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndexMapping rationalizeFonts() {
/* 360 */     return this.fonts.rationalize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndexMapping rationalize(IndexMapping fontMapping, IndexMapping formatMapping) {
/* 378 */     XFRecord xfr = null;
/* 379 */     for (Iterator it = this.xfRecords.iterator(); it.hasNext(); ) {
/*     */       
/* 381 */       xfr = it.next();
/*     */       
/* 383 */       if (xfr.getFormatRecord() >= 164)
/*     */       {
/* 385 */         xfr.setFormatIndex(formatMapping.getNewIndex(xfr.getFormatRecord()));
/*     */       }
/*     */       
/* 388 */       xfr.setFontIndex(fontMapping.getNewIndex(xfr.getFontIndex()));
/*     */     } 
/*     */     
/* 391 */     ArrayList newrecords = new ArrayList(21);
/* 392 */     IndexMapping mapping = new IndexMapping(this.xfRecords.size());
/* 393 */     int numremoved = 0;
/*     */     
/*     */     int j;
/* 396 */     for (j = 0; j < 21; j++) {
/*     */       
/* 398 */       newrecords.add(this.xfRecords.get(j));
/* 399 */       mapping.setMapping(j, j);
/*     */     } 
/*     */ 
/*     */     
/* 403 */     for (j = 21; j < this.xfRecords.size(); j++) {
/*     */       
/* 405 */       XFRecord xf = this.xfRecords.get(j);
/*     */ 
/*     */       
/* 408 */       boolean duplicate = false;
/* 409 */       Iterator iterator = newrecords.iterator();
/* 410 */       while (iterator.hasNext() && !duplicate) {
/*     */         
/* 412 */         XFRecord xf2 = iterator.next();
/* 413 */         if (xf2.equals(xf)) {
/*     */           
/* 415 */           duplicate = true;
/* 416 */           mapping.setMapping(j, mapping.getNewIndex(xf2.getXFIndex()));
/* 417 */           numremoved++;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 422 */       if (!duplicate) {
/*     */         
/* 424 */         newrecords.add(xf);
/* 425 */         mapping.setMapping(j, j - numremoved);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 432 */     for (Iterator i = this.xfRecords.iterator(); i.hasNext(); ) {
/*     */       
/* 434 */       XFRecord xf = i.next();
/* 435 */       xf.rationalize(mapping);
/*     */     } 
/*     */ 
/*     */     
/* 439 */     this.xfRecords = newrecords;
/*     */     
/* 441 */     return mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IndexMapping rationalizeDisplayFormats() {
/* 454 */     ArrayList newformats = new ArrayList();
/* 455 */     int numremoved = 0;
/* 456 */     IndexMapping mapping = new IndexMapping(this.nextCustomIndexNumber);
/*     */ 
/*     */     
/* 459 */     Iterator i = this.formatsList.iterator();
/* 460 */     DisplayFormat df = null;
/* 461 */     DisplayFormat df2 = null;
/* 462 */     boolean duplicate = false;
/* 463 */     while (i.hasNext()) {
/*     */       
/* 465 */       df = i.next();
/*     */       
/* 467 */       Assert.verify(!df.isBuiltIn());
/*     */ 
/*     */       
/* 470 */       Iterator i2 = newformats.iterator();
/* 471 */       duplicate = false;
/* 472 */       while (i2.hasNext() && !duplicate) {
/*     */         
/* 474 */         df2 = i2.next();
/* 475 */         if (df2.equals(df)) {
/*     */           
/* 477 */           duplicate = true;
/* 478 */           mapping.setMapping(df.getFormatIndex(), mapping.getNewIndex(df2.getFormatIndex()));
/*     */           
/* 480 */           numremoved++;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 485 */       if (!duplicate) {
/*     */         
/* 487 */         newformats.add(df);
/* 488 */         int indexnum = df.getFormatIndex() - numremoved;
/* 489 */         if (indexnum > 441) {
/*     */           
/* 491 */           logger.warn("Too many number formats - using default format.");
/* 492 */           indexnum = 0;
/*     */         } 
/* 494 */         mapping.setMapping(df.getFormatIndex(), df.getFormatIndex() - numremoved);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 500 */     this.formatsList = newformats;
/*     */ 
/*     */     
/* 503 */     i = this.formatsList.iterator();
/*     */     
/* 505 */     while (i.hasNext()) {
/*     */       
/* 507 */       df = i.next();
/* 508 */       df.initialize(mapping.getNewIndex(df.getFormatIndex()));
/*     */     } 
/*     */     
/* 511 */     return mapping;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PaletteRecord getPalette() {
/* 521 */     return this.palette;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPalette(PaletteRecord pr) {
/* 531 */     this.palette = pr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColourRGB(Colour c, int r, int g, int b) {
/* 544 */     if (this.palette == null)
/*     */     {
/* 546 */       this.palette = new PaletteRecord();
/*     */     }
/* 548 */     this.palette.setColourRGB(c, r, g, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RGB getColourRGB(Colour c) {
/* 558 */     if (this.palette == null)
/*     */     {
/* 560 */       return c.getDefaultRGB();
/*     */     }
/*     */     
/* 563 */     return this.palette.getColourRGB(c);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\FormattingRecords.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
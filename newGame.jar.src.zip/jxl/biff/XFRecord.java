/*      */ package jxl.biff;
/*      */ 
/*      */ import common.Assert;
/*      */ import common.Logger;
/*      */ import java.text.DateFormat;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.DecimalFormatSymbols;
/*      */ import java.text.NumberFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.format.Alignment;
/*      */ import jxl.format.Border;
/*      */ import jxl.format.BorderLineStyle;
/*      */ import jxl.format.CellFormat;
/*      */ import jxl.format.Colour;
/*      */ import jxl.format.Font;
/*      */ import jxl.format.Format;
/*      */ import jxl.format.Orientation;
/*      */ import jxl.format.Pattern;
/*      */ import jxl.format.VerticalAlignment;
/*      */ import jxl.read.biff.Record;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class XFRecord
/*      */   extends WritableRecordData
/*      */   implements CellFormat
/*      */ {
/*   53 */   private static Logger logger = Logger.getLogger(XFRecord.class);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int formatIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int parentFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private XFType xfFormatType;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean date;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean number;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DateFormat dateFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private NumberFormat numberFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte usedAttributes;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int fontIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean locked;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean hidden;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Alignment align;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private VerticalAlignment valign;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Orientation orientation;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean wrap;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int indentation;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean shrinkToFit;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BorderLineStyle leftBorder;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BorderLineStyle rightBorder;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BorderLineStyle topBorder;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BorderLineStyle bottomBorder;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Colour leftBorderColour;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Colour rightBorderColour;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Colour topBorderColour;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Colour bottomBorderColour;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Colour backgroundColour;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Pattern pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int options;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int xfIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FontRecord font;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DisplayFormat format;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean initialized;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean read;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Format excelFormat;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean formatInfoInitialized;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean copied;
/*      */ 
/*      */ 
/*      */   
/*      */   private FormattingRecords formattingRecords;
/*      */ 
/*      */ 
/*      */   
/*  239 */   private static final int[] dateFormats = new int[] { 14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 46, 47 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  256 */   private static final DateFormat[] javaDateFormats = new DateFormat[] { new SimpleDateFormat("dd/MM/yyyy"), new SimpleDateFormat("d-MMM-yy"), new SimpleDateFormat("d-MMM"), new SimpleDateFormat("MMM-yy"), new SimpleDateFormat("h:mm a"), new SimpleDateFormat("h:mm:ss a"), new SimpleDateFormat("H:mm"), new SimpleDateFormat("H:mm:ss"), new SimpleDateFormat("M/d/yy H:mm"), new SimpleDateFormat("mm:ss"), new SimpleDateFormat("H:mm:ss"), new SimpleDateFormat("mm:ss.S") };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  273 */   private static int[] numberFormats = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 37, 38, 39, 40, 41, 42, 43, 44, 48 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  298 */   private static NumberFormat[] javaNumberFormats = new NumberFormat[] { new DecimalFormat("0"), new DecimalFormat("0.00"), new DecimalFormat("#,##0"), new DecimalFormat("#,##0.00"), new DecimalFormat("$#,##0;($#,##0)"), new DecimalFormat("$#,##0;($#,##0)"), new DecimalFormat("$#,##0.00;($#,##0.00)"), new DecimalFormat("$#,##0.00;($#,##0.00)"), new DecimalFormat("0%"), new DecimalFormat("0.00%"), new DecimalFormat("0.00E00"), new DecimalFormat("#,##0;(#,##0)"), new DecimalFormat("#,##0;(#,##0)"), new DecimalFormat("#,##0.00;(#,##0.00)"), new DecimalFormat("#,##0.00;(#,##0.00)"), new DecimalFormat("#,##0;(#,##0)"), new DecimalFormat("$#,##0;($#,##0)"), new DecimalFormat("#,##0.00;(#,##0.00)"), new DecimalFormat("$#,##0.00;($#,##0.00)"), new DecimalFormat("##0.0E0") };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class BiffType
/*      */   {
/*      */     private BiffType() {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  323 */   public static final BiffType biff8 = new BiffType();
/*  324 */   public static final BiffType biff7 = new BiffType();
/*      */   
/*      */   private BiffType biffType;
/*      */ 
/*      */   
/*      */   private static class XFType
/*      */   {
/*      */     private XFType() {}
/*      */   }
/*      */ 
/*      */   
/*  335 */   protected static final XFType cell = new XFType();
/*  336 */   protected static final XFType style = new XFType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XFRecord(Record t, WorkbookSettings ws, BiffType bt) {
/*  346 */     super(t);
/*      */     
/*  348 */     this.biffType = bt;
/*      */     
/*  350 */     byte[] data = getRecord().getData();
/*      */     
/*  352 */     this.fontIndex = IntegerHelper.getInt(data[0], data[1]);
/*  353 */     this.formatIndex = IntegerHelper.getInt(data[2], data[3]);
/*  354 */     this.date = false;
/*  355 */     this.number = false;
/*      */     
/*      */     int i;
/*      */     
/*  359 */     for (i = 0; i < dateFormats.length && !this.date; i++) {
/*      */       
/*  361 */       if (this.formatIndex == dateFormats[i]) {
/*      */         
/*  363 */         this.date = true;
/*  364 */         this.dateFormat = javaDateFormats[i];
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  369 */     for (i = 0; i < numberFormats.length && !this.number; i++) {
/*      */       
/*  371 */       if (this.formatIndex == numberFormats[i]) {
/*      */         
/*  373 */         this.number = true;
/*  374 */         DecimalFormat df = (DecimalFormat)javaNumberFormats[i].clone();
/*  375 */         DecimalFormatSymbols symbols = new DecimalFormatSymbols(ws.getLocale());
/*      */         
/*  377 */         df.setDecimalFormatSymbols(symbols);
/*  378 */         this.numberFormat = df;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  384 */     int cellAttributes = IntegerHelper.getInt(data[4], data[5]);
/*  385 */     this.parentFormat = (cellAttributes & 0xFFF0) >> 4;
/*      */     
/*  387 */     int formatType = cellAttributes & 0x4;
/*  388 */     this.xfFormatType = (formatType == 0) ? cell : style;
/*  389 */     this.locked = ((cellAttributes & 0x1) != 0);
/*  390 */     this.hidden = ((cellAttributes & 0x2) != 0);
/*      */     
/*  392 */     if (this.xfFormatType == cell && (this.parentFormat & 0xFFF) == 4095) {
/*      */ 
/*      */ 
/*      */       
/*  396 */       this.parentFormat = 0;
/*  397 */       logger.warn("Invalid parent format found - ignoring");
/*      */     } 
/*      */     
/*  400 */     this.initialized = false;
/*  401 */     this.read = true;
/*  402 */     this.formatInfoInitialized = false;
/*  403 */     this.copied = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XFRecord(FontRecord fnt, DisplayFormat form) {
/*  414 */     super(Type.XF);
/*      */     
/*  416 */     this.initialized = false;
/*  417 */     this.locked = true;
/*  418 */     this.hidden = false;
/*  419 */     this.align = Alignment.GENERAL;
/*  420 */     this.valign = VerticalAlignment.BOTTOM;
/*  421 */     this.orientation = Orientation.HORIZONTAL;
/*  422 */     this.wrap = false;
/*  423 */     this.leftBorder = BorderLineStyle.NONE;
/*  424 */     this.rightBorder = BorderLineStyle.NONE;
/*  425 */     this.topBorder = BorderLineStyle.NONE;
/*  426 */     this.bottomBorder = BorderLineStyle.NONE;
/*  427 */     this.leftBorderColour = Colour.AUTOMATIC;
/*  428 */     this.rightBorderColour = Colour.AUTOMATIC;
/*  429 */     this.topBorderColour = Colour.AUTOMATIC;
/*  430 */     this.bottomBorderColour = Colour.AUTOMATIC;
/*  431 */     this.pattern = Pattern.NONE;
/*  432 */     this.backgroundColour = Colour.DEFAULT_BACKGROUND;
/*  433 */     this.indentation = 0;
/*  434 */     this.shrinkToFit = false;
/*      */ 
/*      */     
/*  437 */     this.parentFormat = 0;
/*  438 */     this.xfFormatType = null;
/*      */     
/*  440 */     this.font = fnt;
/*  441 */     this.format = form;
/*  442 */     this.biffType = biff8;
/*  443 */     this.read = false;
/*  444 */     this.copied = false;
/*  445 */     this.formatInfoInitialized = true;
/*      */     
/*  447 */     Assert.verify((this.font != null));
/*  448 */     Assert.verify((this.format != null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected XFRecord(XFRecord fmt) {
/*  459 */     super(Type.XF);
/*      */     
/*  461 */     this.initialized = false;
/*  462 */     this.locked = fmt.locked;
/*  463 */     this.hidden = fmt.hidden;
/*  464 */     this.align = fmt.align;
/*  465 */     this.valign = fmt.valign;
/*  466 */     this.orientation = fmt.orientation;
/*  467 */     this.wrap = fmt.wrap;
/*  468 */     this.leftBorder = fmt.leftBorder;
/*  469 */     this.rightBorder = fmt.rightBorder;
/*  470 */     this.topBorder = fmt.topBorder;
/*  471 */     this.bottomBorder = fmt.bottomBorder;
/*  472 */     this.leftBorderColour = fmt.leftBorderColour;
/*  473 */     this.rightBorderColour = fmt.rightBorderColour;
/*  474 */     this.topBorderColour = fmt.topBorderColour;
/*  475 */     this.bottomBorderColour = fmt.bottomBorderColour;
/*  476 */     this.pattern = fmt.pattern;
/*  477 */     this.xfFormatType = fmt.xfFormatType;
/*  478 */     this.indentation = fmt.indentation;
/*  479 */     this.shrinkToFit = fmt.shrinkToFit;
/*  480 */     this.parentFormat = fmt.parentFormat;
/*  481 */     this.backgroundColour = fmt.backgroundColour;
/*      */ 
/*      */     
/*  484 */     this.font = fmt.font;
/*  485 */     this.format = fmt.format;
/*      */     
/*  487 */     this.fontIndex = fmt.fontIndex;
/*  488 */     this.formatIndex = fmt.formatIndex;
/*      */     
/*  490 */     this.formatInfoInitialized = fmt.formatInfoInitialized;
/*      */     
/*  492 */     this.biffType = biff8;
/*  493 */     this.read = false;
/*  494 */     this.copied = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected XFRecord(CellFormat cellFormat) {
/*  506 */     super(Type.XF);
/*      */     
/*  508 */     Assert.verify((cellFormat != null));
/*  509 */     Assert.verify(cellFormat instanceof XFRecord);
/*  510 */     XFRecord fmt = (XFRecord)cellFormat;
/*      */     
/*  512 */     if (!fmt.formatInfoInitialized)
/*      */     {
/*  514 */       fmt.initializeFormatInformation();
/*      */     }
/*      */     
/*  517 */     this.locked = fmt.locked;
/*  518 */     this.hidden = fmt.hidden;
/*  519 */     this.align = fmt.align;
/*  520 */     this.valign = fmt.valign;
/*  521 */     this.orientation = fmt.orientation;
/*  522 */     this.wrap = fmt.wrap;
/*  523 */     this.leftBorder = fmt.leftBorder;
/*  524 */     this.rightBorder = fmt.rightBorder;
/*  525 */     this.topBorder = fmt.topBorder;
/*  526 */     this.bottomBorder = fmt.bottomBorder;
/*  527 */     this.leftBorderColour = fmt.leftBorderColour;
/*  528 */     this.rightBorderColour = fmt.rightBorderColour;
/*  529 */     this.topBorderColour = fmt.topBorderColour;
/*  530 */     this.bottomBorderColour = fmt.bottomBorderColour;
/*  531 */     this.pattern = fmt.pattern;
/*  532 */     this.xfFormatType = fmt.xfFormatType;
/*  533 */     this.parentFormat = fmt.parentFormat;
/*  534 */     this.indentation = fmt.indentation;
/*  535 */     this.shrinkToFit = fmt.shrinkToFit;
/*  536 */     this.backgroundColour = fmt.backgroundColour;
/*      */ 
/*      */     
/*  539 */     this.font = new FontRecord(fmt.getFont());
/*      */ 
/*      */     
/*  542 */     if (fmt.getFormat() == null) {
/*      */ 
/*      */       
/*  545 */       if (fmt.format.isBuiltIn())
/*      */       {
/*  547 */         this.format = fmt.format;
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*  552 */         this.format = new FormatRecord((FormatRecord)fmt.format);
/*      */       }
/*      */     
/*  555 */     } else if (fmt.getFormat() instanceof BuiltInFormat) {
/*      */ 
/*      */       
/*  558 */       this.excelFormat = fmt.excelFormat;
/*  559 */       this.format = (BuiltInFormat)fmt.excelFormat;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  564 */       Assert.verify(fmt.formatInfoInitialized);
/*      */ 
/*      */ 
/*      */       
/*  568 */       Assert.verify(fmt.excelFormat instanceof FormatRecord);
/*      */ 
/*      */       
/*  571 */       FormatRecord fr = new FormatRecord((FormatRecord)fmt.excelFormat);
/*      */ 
/*      */ 
/*      */       
/*  575 */       this.excelFormat = fr;
/*  576 */       this.format = fr;
/*      */     } 
/*      */     
/*  579 */     this.biffType = biff8;
/*      */ 
/*      */     
/*  582 */     this.formatInfoInitialized = true;
/*      */ 
/*      */ 
/*      */     
/*  586 */     this.read = false;
/*      */ 
/*      */     
/*  589 */     this.copied = false;
/*      */ 
/*      */     
/*  592 */     this.initialized = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DateFormat getDateFormat() {
/*  602 */     return this.dateFormat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NumberFormat getNumberFormat() {
/*  612 */     return this.numberFormat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFormatRecord() {
/*  622 */     return this.formatIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDate() {
/*  632 */     return this.date;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNumber() {
/*  642 */     return this.number;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getData() {
/*  658 */     if (!this.formatInfoInitialized)
/*      */     {
/*  660 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  663 */     byte[] data = new byte[20];
/*      */     
/*  665 */     IntegerHelper.getTwoBytes(this.fontIndex, data, 0);
/*  666 */     IntegerHelper.getTwoBytes(this.formatIndex, data, 2);
/*      */ 
/*      */     
/*  669 */     int cellAttributes = 0;
/*      */     
/*  671 */     if (getLocked())
/*      */     {
/*  673 */       cellAttributes |= 0x1;
/*      */     }
/*      */     
/*  676 */     if (getHidden())
/*      */     {
/*  678 */       cellAttributes |= 0x2;
/*      */     }
/*      */     
/*  681 */     if (this.xfFormatType == style) {
/*      */       
/*  683 */       cellAttributes |= 0x4;
/*  684 */       this.parentFormat = 65535;
/*      */     } 
/*      */     
/*  687 */     cellAttributes |= this.parentFormat << 4;
/*      */     
/*  689 */     IntegerHelper.getTwoBytes(cellAttributes, data, 4);
/*      */     
/*  691 */     int alignMask = this.align.getValue();
/*      */     
/*  693 */     if (this.wrap)
/*      */     {
/*  695 */       alignMask |= 0x8;
/*      */     }
/*      */     
/*  698 */     alignMask |= this.valign.getValue() << 4;
/*      */     
/*  700 */     alignMask |= this.orientation.getValue() << 8;
/*      */     
/*  702 */     IntegerHelper.getTwoBytes(alignMask, data, 6);
/*      */     
/*  704 */     data[9] = 16;
/*      */ 
/*      */     
/*  707 */     int borderMask = this.leftBorder.getValue();
/*  708 */     borderMask |= this.rightBorder.getValue() << 4;
/*  709 */     borderMask |= this.topBorder.getValue() << 8;
/*  710 */     borderMask |= this.bottomBorder.getValue() << 12;
/*      */     
/*  712 */     IntegerHelper.getTwoBytes(borderMask, data, 10);
/*      */ 
/*      */ 
/*      */     
/*  716 */     if (borderMask != 0) {
/*      */       
/*  718 */       byte lc = (byte)this.leftBorderColour.getValue();
/*  719 */       byte rc = (byte)this.rightBorderColour.getValue();
/*  720 */       byte tc = (byte)this.topBorderColour.getValue();
/*  721 */       byte bc = (byte)this.bottomBorderColour.getValue();
/*      */       
/*  723 */       int sideColourMask = lc & Byte.MAX_VALUE | (rc & Byte.MAX_VALUE) << 7;
/*  724 */       int topColourMask = tc & Byte.MAX_VALUE | (bc & Byte.MAX_VALUE) << 7;
/*      */       
/*  726 */       IntegerHelper.getTwoBytes(sideColourMask, data, 12);
/*  727 */       IntegerHelper.getTwoBytes(topColourMask, data, 14);
/*      */     } 
/*      */ 
/*      */     
/*  731 */     int patternVal = this.pattern.getValue() << 10;
/*  732 */     IntegerHelper.getTwoBytes(patternVal, data, 16);
/*      */ 
/*      */     
/*  735 */     int colourPaletteMask = this.backgroundColour.getValue();
/*  736 */     colourPaletteMask |= 0x2000;
/*  737 */     IntegerHelper.getTwoBytes(colourPaletteMask, data, 18);
/*      */ 
/*      */     
/*  740 */     this.options |= this.indentation & 0xF;
/*      */     
/*  742 */     if (this.shrinkToFit) {
/*      */       
/*  744 */       this.options |= 0x10;
/*      */     }
/*      */     else {
/*      */       
/*  748 */       this.options &= 0xEF;
/*      */     } 
/*      */     
/*  751 */     data[8] = (byte)this.options;
/*      */     
/*  753 */     if (this.biffType == biff8)
/*      */     {
/*      */       
/*  756 */       data[9] = this.usedAttributes;
/*      */     }
/*      */     
/*  759 */     return data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean getLocked() {
/*  769 */     return this.locked;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean getHidden() {
/*  779 */     return this.hidden;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setXFLocked(boolean l) {
/*  789 */     this.locked = l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setXFCellOptions(int opt) {
/*  799 */     this.options |= opt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setXFAlignment(Alignment a) {
/*  811 */     Assert.verify(!this.initialized);
/*  812 */     this.align = a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setXFIndentation(int i) {
/*  822 */     Assert.verify(!this.initialized);
/*  823 */     this.indentation = i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setXFShrinkToFit(boolean s) {
/*  833 */     Assert.verify(!this.initialized);
/*  834 */     this.shrinkToFit = s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Alignment getAlignment() {
/*  844 */     if (!this.formatInfoInitialized)
/*      */     {
/*  846 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  849 */     return this.align;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getIndentation() {
/*  859 */     if (!this.formatInfoInitialized)
/*      */     {
/*  861 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  864 */     return this.indentation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isShrinkToFit() {
/*  874 */     if (!this.formatInfoInitialized)
/*      */     {
/*  876 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  879 */     return this.shrinkToFit;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLocked() {
/*  889 */     if (!this.formatInfoInitialized)
/*      */     {
/*  891 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  894 */     return this.locked;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VerticalAlignment getVerticalAlignment() {
/*  905 */     if (!this.formatInfoInitialized)
/*      */     {
/*  907 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  910 */     return this.valign;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Orientation getOrientation() {
/*  920 */     if (!this.formatInfoInitialized)
/*      */     {
/*  922 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  925 */     return this.orientation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setXFBackground(Colour c, Pattern p) {
/*  938 */     Assert.verify(!this.initialized);
/*  939 */     this.backgroundColour = c;
/*  940 */     this.pattern = p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Colour getBackgroundColour() {
/*  950 */     if (!this.formatInfoInitialized)
/*      */     {
/*  952 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  955 */     return this.backgroundColour;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pattern getPattern() {
/*  965 */     if (!this.formatInfoInitialized)
/*      */     {
/*  967 */       initializeFormatInformation();
/*      */     }
/*      */     
/*  970 */     return this.pattern;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setXFVerticalAlignment(VerticalAlignment va) {
/*  983 */     Assert.verify(!this.initialized);
/*  984 */     this.valign = va;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setXFOrientation(Orientation o) {
/*  997 */     Assert.verify(!this.initialized);
/*  998 */     this.orientation = o;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setXFWrap(boolean w) {
/* 1010 */     Assert.verify(!this.initialized);
/* 1011 */     this.wrap = w;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getWrap() {
/* 1021 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1023 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1026 */     return this.wrap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setXFBorder(Border b, BorderLineStyle ls, Colour c) {
/* 1039 */     Assert.verify(!this.initialized);
/*      */     
/* 1041 */     if (c == Colour.BLACK)
/*      */     {
/* 1043 */       c = Colour.PALETTE_BLACK;
/*      */     }
/*      */     
/* 1046 */     if (b == Border.LEFT) {
/*      */       
/* 1048 */       this.leftBorder = ls;
/* 1049 */       this.leftBorderColour = c;
/*      */     }
/* 1051 */     else if (b == Border.RIGHT) {
/*      */       
/* 1053 */       this.rightBorder = ls;
/* 1054 */       this.rightBorderColour = c;
/*      */     }
/* 1056 */     else if (b == Border.TOP) {
/*      */       
/* 1058 */       this.topBorder = ls;
/* 1059 */       this.topBorderColour = c;
/*      */     }
/* 1061 */     else if (b == Border.BOTTOM) {
/*      */       
/* 1063 */       this.bottomBorder = ls;
/* 1064 */       this.bottomBorderColour = c;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BorderLineStyle getBorder(Border border) {
/* 1080 */     return getBorderLine(border);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BorderLineStyle getBorderLine(Border border) {
/* 1094 */     if (border == Border.NONE || border == Border.ALL)
/*      */     {
/*      */       
/* 1097 */       return BorderLineStyle.NONE;
/*      */     }
/*      */     
/* 1100 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1102 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1105 */     if (border == Border.LEFT)
/*      */     {
/* 1107 */       return this.leftBorder;
/*      */     }
/* 1109 */     if (border == Border.RIGHT)
/*      */     {
/* 1111 */       return this.rightBorder;
/*      */     }
/* 1113 */     if (border == Border.TOP)
/*      */     {
/* 1115 */       return this.topBorder;
/*      */     }
/* 1117 */     if (border == Border.BOTTOM)
/*      */     {
/* 1119 */       return this.bottomBorder;
/*      */     }
/*      */     
/* 1122 */     return BorderLineStyle.NONE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Colour getBorderColour(Border border) {
/* 1136 */     if (border == Border.NONE || border == Border.ALL)
/*      */     {
/*      */       
/* 1139 */       return Colour.PALETTE_BLACK;
/*      */     }
/*      */     
/* 1142 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1144 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1147 */     if (border == Border.LEFT)
/*      */     {
/* 1149 */       return this.leftBorderColour;
/*      */     }
/* 1151 */     if (border == Border.RIGHT)
/*      */     {
/* 1153 */       return this.rightBorderColour;
/*      */     }
/* 1155 */     if (border == Border.TOP)
/*      */     {
/* 1157 */       return this.topBorderColour;
/*      */     }
/* 1159 */     if (border == Border.BOTTOM)
/*      */     {
/* 1161 */       return this.bottomBorderColour;
/*      */     }
/*      */     
/* 1164 */     return Colour.BLACK;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean hasBorders() {
/* 1176 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1178 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1181 */     if (this.leftBorder == BorderLineStyle.NONE && this.rightBorder == BorderLineStyle.NONE && this.topBorder == BorderLineStyle.NONE && this.bottomBorder == BorderLineStyle.NONE)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 1186 */       return false;
/*      */     }
/*      */     
/* 1189 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void initialize(int pos, FormattingRecords fr, Fonts fonts) throws NumFormatRecordsException {
/* 1205 */     this.xfIndex = pos;
/* 1206 */     this.formattingRecords = fr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1212 */     if (this.read || this.copied) {
/*      */       
/* 1214 */       this.initialized = true;
/*      */       
/*      */       return;
/*      */     } 
/* 1218 */     if (!this.font.isInitialized())
/*      */     {
/* 1220 */       fonts.addFont(this.font);
/*      */     }
/*      */     
/* 1223 */     if (!this.format.isInitialized())
/*      */     {
/* 1225 */       fr.addFormat(this.format);
/*      */     }
/*      */     
/* 1228 */     this.fontIndex = this.font.getFontIndex();
/* 1229 */     this.formatIndex = this.format.getFormatIndex();
/*      */     
/* 1231 */     this.initialized = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void uninitialize() {
/* 1242 */     if (this.initialized == true)
/*      */     {
/* 1244 */       logger.warn("A default format has been initialized");
/*      */     }
/* 1246 */     this.initialized = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setXFIndex(int xfi) {
/* 1257 */     this.xfIndex = xfi;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getXFIndex() {
/* 1267 */     return this.xfIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isInitialized() {
/* 1277 */     return this.initialized;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isRead() {
/* 1289 */     return this.read;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Format getFormat() {
/* 1299 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1301 */       initializeFormatInformation();
/*      */     }
/* 1303 */     return this.excelFormat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Font getFont() {
/* 1313 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1315 */       initializeFormatInformation();
/*      */     }
/* 1317 */     return this.font;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeFormatInformation() {
/* 1326 */     if (this.formatIndex < BuiltInFormat.builtIns.length && BuiltInFormat.builtIns[this.formatIndex] != null) {
/*      */ 
/*      */       
/* 1329 */       this.excelFormat = BuiltInFormat.builtIns[this.formatIndex];
/*      */     }
/*      */     else {
/*      */       
/* 1333 */       this.excelFormat = this.formattingRecords.getFormatRecord(this.formatIndex);
/*      */     } 
/*      */ 
/*      */     
/* 1337 */     this.font = this.formattingRecords.getFonts().getFont(this.fontIndex);
/*      */ 
/*      */     
/* 1340 */     byte[] data = getRecord().getData();
/*      */ 
/*      */     
/* 1343 */     int cellAttributes = IntegerHelper.getInt(data[4], data[5]);
/* 1344 */     this.parentFormat = (cellAttributes & 0xFFF0) >> 4;
/* 1345 */     int formatType = cellAttributes & 0x4;
/* 1346 */     this.xfFormatType = (formatType == 0) ? cell : style;
/* 1347 */     this.locked = ((cellAttributes & 0x1) != 0);
/* 1348 */     this.hidden = ((cellAttributes & 0x2) != 0);
/*      */     
/* 1350 */     if (this.xfFormatType == cell && (this.parentFormat & 0xFFF) == 4095) {
/*      */ 
/*      */ 
/*      */       
/* 1354 */       this.parentFormat = 0;
/* 1355 */       logger.warn("Invalid parent format found - ignoring");
/*      */     } 
/*      */ 
/*      */     
/* 1359 */     int alignMask = IntegerHelper.getInt(data[6], data[7]);
/*      */ 
/*      */     
/* 1362 */     if ((alignMask & 0x8) != 0)
/*      */     {
/* 1364 */       this.wrap = true;
/*      */     }
/*      */ 
/*      */     
/* 1368 */     this.align = Alignment.getAlignment(alignMask & 0x7);
/*      */ 
/*      */     
/* 1371 */     this.valign = VerticalAlignment.getAlignment(alignMask >> 4 & 0x7);
/*      */ 
/*      */     
/* 1374 */     this.orientation = Orientation.getOrientation(alignMask >> 8 & 0xFF);
/*      */     
/* 1376 */     int attr = IntegerHelper.getInt(data[8], data[9]);
/*      */ 
/*      */     
/* 1379 */     this.indentation = attr & 0xF;
/*      */ 
/*      */     
/* 1382 */     this.shrinkToFit = ((attr & 0x10) != 0);
/*      */ 
/*      */     
/* 1385 */     if (this.biffType == biff8)
/*      */     {
/* 1387 */       this.usedAttributes = data[9];
/*      */     }
/*      */ 
/*      */     
/* 1391 */     int borderMask = IntegerHelper.getInt(data[10], data[11]);
/*      */     
/* 1393 */     this.leftBorder = BorderLineStyle.getStyle(borderMask & 0x7);
/* 1394 */     this.rightBorder = BorderLineStyle.getStyle(borderMask >> 4 & 0x7);
/* 1395 */     this.topBorder = BorderLineStyle.getStyle(borderMask >> 8 & 0x7);
/* 1396 */     this.bottomBorder = BorderLineStyle.getStyle(borderMask >> 12 & 0x7);
/*      */     
/* 1398 */     int borderColourMask = IntegerHelper.getInt(data[12], data[13]);
/*      */     
/* 1400 */     this.leftBorderColour = Colour.getInternalColour(borderColourMask & 0x7F);
/* 1401 */     this.rightBorderColour = Colour.getInternalColour((borderColourMask & 0x3F80) >> 7);
/*      */ 
/*      */     
/* 1404 */     borderColourMask = IntegerHelper.getInt(data[14], data[15]);
/* 1405 */     this.topBorderColour = Colour.getInternalColour(borderColourMask & 0x7F);
/* 1406 */     this.bottomBorderColour = Colour.getInternalColour((borderColourMask & 0x3F80) >> 7);
/*      */ 
/*      */     
/* 1409 */     if (this.biffType == biff8) {
/*      */ 
/*      */       
/* 1412 */       int patternVal = IntegerHelper.getInt(data[16], data[17]);
/* 1413 */       patternVal &= 0xFC00;
/* 1414 */       patternVal >>= 10;
/* 1415 */       this.pattern = Pattern.getPattern(patternVal);
/*      */ 
/*      */       
/* 1418 */       int colourPaletteMask = IntegerHelper.getInt(data[18], data[19]);
/* 1419 */       this.backgroundColour = Colour.getInternalColour(colourPaletteMask & 0x3F);
/*      */       
/* 1421 */       if (this.backgroundColour == Colour.UNKNOWN || this.backgroundColour == Colour.DEFAULT_BACKGROUND1)
/*      */       {
/*      */         
/* 1424 */         this.backgroundColour = Colour.DEFAULT_BACKGROUND;
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 1429 */       this.pattern = Pattern.NONE;
/* 1430 */       this.backgroundColour = Colour.DEFAULT_BACKGROUND;
/*      */     } 
/*      */ 
/*      */     
/* 1434 */     this.formatInfoInitialized = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1444 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1446 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1449 */     int hashValue = 17;
/* 1450 */     int oddPrimeNumber = 37;
/*      */ 
/*      */     
/* 1453 */     hashValue = oddPrimeNumber * hashValue + (this.hidden ? 1 : 0);
/* 1454 */     hashValue = oddPrimeNumber * hashValue + (this.locked ? 1 : 0);
/* 1455 */     hashValue = oddPrimeNumber * hashValue + (this.wrap ? 1 : 0);
/* 1456 */     hashValue = oddPrimeNumber * hashValue + (this.shrinkToFit ? 1 : 0);
/*      */ 
/*      */     
/* 1459 */     if (this.xfFormatType == cell) {
/*      */       
/* 1461 */       hashValue = oddPrimeNumber * hashValue + 1;
/*      */     }
/* 1463 */     else if (this.xfFormatType == style) {
/*      */       
/* 1465 */       hashValue = oddPrimeNumber * hashValue + 2;
/*      */     } 
/*      */     
/* 1468 */     hashValue = oddPrimeNumber * hashValue + this.align.getValue() + 1;
/* 1469 */     hashValue = oddPrimeNumber * hashValue + this.valign.getValue() + 1;
/* 1470 */     hashValue = oddPrimeNumber * hashValue + this.orientation.getValue();
/*      */     
/* 1472 */     hashValue ^= this.leftBorder.getDescription().hashCode();
/* 1473 */     hashValue ^= this.rightBorder.getDescription().hashCode();
/* 1474 */     hashValue ^= this.topBorder.getDescription().hashCode();
/* 1475 */     hashValue ^= this.bottomBorder.getDescription().hashCode();
/*      */     
/* 1477 */     hashValue = oddPrimeNumber * hashValue + this.leftBorderColour.getValue();
/* 1478 */     hashValue = oddPrimeNumber * hashValue + this.rightBorderColour.getValue();
/* 1479 */     hashValue = oddPrimeNumber * hashValue + this.topBorderColour.getValue();
/* 1480 */     hashValue = oddPrimeNumber * hashValue + this.bottomBorderColour.getValue();
/* 1481 */     hashValue = oddPrimeNumber * hashValue + this.backgroundColour.getValue();
/* 1482 */     hashValue = oddPrimeNumber * hashValue + this.pattern.getValue() + 1;
/*      */ 
/*      */     
/* 1485 */     hashValue = oddPrimeNumber * hashValue + this.usedAttributes;
/* 1486 */     hashValue = oddPrimeNumber * hashValue + this.parentFormat;
/* 1487 */     hashValue = oddPrimeNumber * hashValue + this.fontIndex;
/* 1488 */     hashValue = oddPrimeNumber * hashValue + this.formatIndex;
/* 1489 */     hashValue = oddPrimeNumber * hashValue + this.indentation;
/*      */     
/* 1491 */     return hashValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/* 1503 */     if (o == this)
/*      */     {
/* 1505 */       return true;
/*      */     }
/*      */     
/* 1508 */     if (!(o instanceof XFRecord))
/*      */     {
/* 1510 */       return false;
/*      */     }
/*      */     
/* 1513 */     XFRecord xfr = (XFRecord)o;
/*      */ 
/*      */     
/* 1516 */     if (!this.formatInfoInitialized)
/*      */     {
/* 1518 */       initializeFormatInformation();
/*      */     }
/*      */     
/* 1521 */     if (!xfr.formatInfoInitialized)
/*      */     {
/* 1523 */       xfr.initializeFormatInformation();
/*      */     }
/*      */     
/* 1526 */     if (this.xfFormatType != xfr.xfFormatType || this.parentFormat != xfr.parentFormat || this.locked != xfr.locked || this.hidden != xfr.hidden || this.usedAttributes != xfr.usedAttributes)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1532 */       return false;
/*      */     }
/*      */     
/* 1535 */     if (this.align != xfr.align || this.valign != xfr.valign || this.orientation != xfr.orientation || this.wrap != xfr.wrap || this.shrinkToFit != xfr.shrinkToFit || this.indentation != xfr.indentation)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1542 */       return false;
/*      */     }
/*      */     
/* 1545 */     if (this.leftBorder != xfr.leftBorder || this.rightBorder != xfr.rightBorder || this.topBorder != xfr.topBorder || this.bottomBorder != xfr.bottomBorder)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 1550 */       return false;
/*      */     }
/*      */     
/* 1553 */     if (this.leftBorderColour != xfr.leftBorderColour || this.rightBorderColour != xfr.rightBorderColour || this.topBorderColour != xfr.topBorderColour || this.bottomBorderColour != xfr.bottomBorderColour)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 1558 */       return false;
/*      */     }
/*      */     
/* 1561 */     if (this.backgroundColour != xfr.backgroundColour || this.pattern != xfr.pattern)
/*      */     {
/*      */       
/* 1564 */       return false;
/*      */     }
/*      */     
/* 1567 */     if (this.initialized && xfr.initialized) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1574 */       if (this.fontIndex != xfr.fontIndex || this.formatIndex != xfr.formatIndex)
/*      */       {
/*      */         
/* 1577 */         return false;
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1583 */     else if (!this.font.equals(xfr.font) || !this.format.equals(xfr.format)) {
/*      */ 
/*      */       
/* 1586 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1590 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setFormatIndex(int newindex) {
/* 1600 */     this.formatIndex = newindex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getFontIndex() {
/* 1610 */     return this.fontIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setFontIndex(int newindex) {
/* 1621 */     this.fontIndex = newindex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setXFDetails(XFType t, int pf) {
/* 1631 */     this.xfFormatType = t;
/* 1632 */     this.parentFormat = pf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void rationalize(IndexMapping xfMapping) {
/* 1641 */     this.xfIndex = xfMapping.getNewIndex(this.xfIndex);
/*      */     
/* 1643 */     if (this.xfFormatType == cell)
/*      */     {
/* 1645 */       this.parentFormat = xfMapping.getNewIndex(this.parentFormat);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFont(FontRecord f) {
/* 1661 */     this.font = f;
/*      */   }
/*      */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\XFRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
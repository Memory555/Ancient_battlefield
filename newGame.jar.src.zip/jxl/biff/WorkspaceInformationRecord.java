/*    */ package jxl.biff;
/*    */ 
/*    */ import jxl.read.biff.Record;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WorkspaceInformationRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private int wsoptions;
/*    */   private static final int fitToPages = 256;
/*    */   private static final int defaultOptions = 1217;
/*    */   
/*    */   public WorkspaceInformationRecord(Record t) {
/* 45 */     super(t);
/* 46 */     byte[] data = getRecord().getData();
/*    */     
/* 48 */     this.wsoptions = IntegerHelper.getInt(data[0], data[1]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WorkspaceInformationRecord() {
/* 56 */     super(Type.WSBOOL);
/* 57 */     this.wsoptions = 1217;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getFitToPages() {
/* 67 */     return ((this.wsoptions & 0x100) != 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setFitToPages(boolean b) {
/* 77 */     this.wsoptions = b ? (this.wsoptions | 0x100) : (this.wsoptions & 0xFFFFFEFF);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 88 */     byte[] data = new byte[2];
/*    */ 
/*    */     
/* 91 */     IntegerHelper.getTwoBytes(this.wsoptions, data, 0);
/*    */     
/* 93 */     return data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\WorkspaceInformationRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
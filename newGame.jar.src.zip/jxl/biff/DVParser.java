/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DVParser
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(DVParser.class);
/*     */ 
/*     */   
/*     */   public static class DVType
/*     */   {
/*     */     private int value;
/*     */     
/*  44 */     private static DVType[] types = new DVType[0];
/*     */ 
/*     */     
/*     */     DVType(int v) {
/*  48 */       this.value = v;
/*  49 */       DVType[] oldtypes = types;
/*  50 */       types = new DVType[oldtypes.length + 1];
/*  51 */       System.arraycopy(oldtypes, 0, types, 0, oldtypes.length);
/*  52 */       types[oldtypes.length] = this;
/*     */     }
/*     */ 
/*     */     
/*     */     static DVType getType(int v) {
/*  57 */       DVType found = null;
/*  58 */       for (int i = 0; i < types.length && found == null; i++) {
/*     */         
/*  60 */         if ((types[i]).value == v)
/*     */         {
/*  62 */           found = types[i];
/*     */         }
/*     */       } 
/*  65 */       return found;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getValue() {
/*  70 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ErrorStyle
/*     */   {
/*     */     private int value;
/*     */     
/*  79 */     private static ErrorStyle[] types = new ErrorStyle[0];
/*     */ 
/*     */     
/*     */     ErrorStyle(int v) {
/*  83 */       this.value = v;
/*  84 */       ErrorStyle[] oldtypes = types;
/*  85 */       types = new ErrorStyle[oldtypes.length + 1];
/*  86 */       System.arraycopy(oldtypes, 0, types, 0, oldtypes.length);
/*  87 */       types[oldtypes.length] = this;
/*     */     }
/*     */ 
/*     */     
/*     */     static ErrorStyle getErrorStyle(int v) {
/*  92 */       ErrorStyle found = null;
/*  93 */       for (int i = 0; i < types.length && found == null; i++) {
/*     */         
/*  95 */         if ((types[i]).value == v)
/*     */         {
/*  97 */           found = types[i];
/*     */         }
/*     */       } 
/* 100 */       return found;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 105 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class Condition
/*     */   {
/*     */     private int value;
/*     */     
/* 114 */     private static Condition[] types = new Condition[0];
/*     */ 
/*     */     
/*     */     Condition(int v) {
/* 118 */       this.value = v;
/* 119 */       Condition[] oldtypes = types;
/* 120 */       types = new Condition[oldtypes.length + 1];
/* 121 */       System.arraycopy(oldtypes, 0, types, 0, oldtypes.length);
/* 122 */       types[oldtypes.length] = this;
/*     */     }
/*     */ 
/*     */     
/*     */     static Condition getCondition(int v) {
/* 127 */       Condition found = null;
/* 128 */       for (int i = 0; i < types.length && found == null; i++) {
/*     */         
/* 130 */         if ((types[i]).value == v)
/*     */         {
/* 132 */           found = types[i];
/*     */         }
/*     */       } 
/* 135 */       return found;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getValue() {
/* 140 */       return this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 146 */   public static final DVType ANY = new DVType(0);
/* 147 */   public static final DVType INTEGER = new DVType(1);
/* 148 */   public static final DVType DECIMAL = new DVType(2);
/* 149 */   public static final DVType LIST = new DVType(3);
/* 150 */   public static final DVType DATE = new DVType(4);
/* 151 */   public static final DVType TIME = new DVType(5);
/* 152 */   public static final DVType TEXT_LENGTH = new DVType(6);
/* 153 */   public static final DVType FORMULA = new DVType(7);
/*     */ 
/*     */   
/* 156 */   public static final ErrorStyle STOP = new ErrorStyle(0);
/* 157 */   public static final ErrorStyle WARNING = new ErrorStyle(1);
/* 158 */   public static final ErrorStyle INFO = new ErrorStyle(2);
/*     */ 
/*     */   
/* 161 */   public static final Condition BETWEEN = new Condition(0);
/* 162 */   public static final Condition NOT_BETWEEN = new Condition(1);
/* 163 */   public static final Condition EQUAL = new Condition(2);
/* 164 */   public static final Condition NOT_EQUAL = new Condition(3);
/* 165 */   public static final Condition GREATER_THAN = new Condition(4);
/* 166 */   public static final Condition LESS_THAN = new Condition(5);
/* 167 */   public static final Condition GREATER_EQUAL = new Condition(6);
/* 168 */   public static final Condition LESS_EQUAL = new Condition(7);
/*     */ 
/*     */   
/* 171 */   private static int STRING_LIST_GIVEN_MASK = 128;
/* 172 */   private static int EMPTY_CELLS_ALLOWED_MASK = 256;
/* 173 */   private static int SUPPRESS_ARROW_MASK = 512;
/* 174 */   private static int SHOW_PROMPT_MASK = 262144;
/* 175 */   private static int SHOW_ERROR_MASK = 524288;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DVType type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ErrorStyle errorStyle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Condition condition;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean stringListGiven;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean emptyCellsAllowed;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean suppressArrow;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean showPrompt;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean showError;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String promptTitle;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String errorTitle;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String promptText;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String errorText;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FormulaParser formula1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FormulaParser formula2;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column2;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DVParser(byte[] data, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws) throws FormulaException {
/* 275 */     int options = IntegerHelper.getInt(data[0], data[1], data[2], data[3]);
/*     */     
/* 277 */     int typeVal = options & 0xF;
/* 278 */     this.type = DVType.getType(typeVal);
/*     */     
/* 280 */     int errorStyleVal = (options & 0x70) >> 4;
/* 281 */     this.errorStyle = ErrorStyle.getErrorStyle(errorStyleVal);
/*     */     
/* 283 */     int conditionVal = (options & 0xF00000) >> 20;
/* 284 */     this.condition = Condition.getCondition(conditionVal);
/*     */     
/* 286 */     this.stringListGiven = ((options & STRING_LIST_GIVEN_MASK) != 0);
/* 287 */     this.emptyCellsAllowed = ((options & EMPTY_CELLS_ALLOWED_MASK) != 0);
/* 288 */     this.suppressArrow = ((options & SUPPRESS_ARROW_MASK) != 0);
/* 289 */     this.showPrompt = ((options & SHOW_PROMPT_MASK) != 0);
/* 290 */     this.showError = ((options & SHOW_ERROR_MASK) != 0);
/*     */     
/* 292 */     int pos = 4;
/* 293 */     int length = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 294 */     this.promptTitle = StringHelper.getUnicodeString(data, length, pos + 2);
/* 295 */     pos += length * 2 + 2;
/*     */     
/* 297 */     length = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 298 */     this.errorTitle = StringHelper.getUnicodeString(data, length, pos + 2);
/* 299 */     pos += length * 2 + 2;
/*     */     
/* 301 */     length = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 302 */     this.promptText = StringHelper.getUnicodeString(data, length, pos + 2);
/* 303 */     pos += length * 2 + 2;
/*     */     
/* 305 */     length = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 306 */     this.errorText = StringHelper.getUnicodeString(data, length, pos + 2);
/* 307 */     pos += length * 2 + 2;
/*     */     
/* 309 */     int formulaLength = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 310 */     pos += 4;
/* 311 */     if (formulaLength != 0) {
/*     */       
/* 313 */       byte[] tokens = new byte[formulaLength];
/* 314 */       System.arraycopy(data, pos, tokens, 0, formulaLength);
/* 315 */       this.formula1 = new FormulaParser(tokens, null, es, nt, ws);
/* 316 */       this.formula1.parse();
/* 317 */       pos += formulaLength;
/*     */     } 
/*     */     
/* 320 */     formulaLength = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 321 */     pos += 4;
/* 322 */     if (formulaLength != 0) {
/*     */       
/* 324 */       byte[] tokens = new byte[formulaLength];
/* 325 */       System.arraycopy(data, pos, tokens, 0, formulaLength);
/* 326 */       this.formula2 = new FormulaParser(tokens, null, es, nt, ws);
/* 327 */       this.formula2.parse();
/* 328 */       pos += formulaLength;
/*     */     } 
/*     */     
/* 331 */     pos += 2;
/*     */     
/* 333 */     this.row1 = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 334 */     pos += 2;
/*     */     
/* 336 */     this.row2 = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 337 */     pos += 2;
/*     */     
/* 339 */     this.column1 = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 340 */     pos += 2;
/*     */     
/* 342 */     this.column2 = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 343 */     pos += 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 352 */     byte[] f1Bytes = (this.formula1 != null) ? this.formula1.getBytes() : new byte[0];
/* 353 */     byte[] f2Bytes = (this.formula2 != null) ? this.formula2.getBytes() : new byte[0];
/* 354 */     int dataLength = 4 + this.promptTitle.length() * 2 + 2 + this.errorTitle.length() * 2 + 2 + this.promptText.length() * 2 + 2 + this.errorText.length() * 2 + 2 + f1Bytes.length + 2 + f2Bytes.length + 2 + 4 + 10;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 365 */     byte[] data = new byte[dataLength];
/*     */ 
/*     */     
/* 368 */     int pos = 0;
/*     */ 
/*     */     
/* 371 */     int options = 0;
/* 372 */     options |= this.type.getValue();
/* 373 */     options |= this.errorStyle.getValue() << 4;
/* 374 */     options |= this.condition.getValue() << 20;
/*     */     
/* 376 */     if (this.stringListGiven)
/*     */     {
/* 378 */       options |= STRING_LIST_GIVEN_MASK;
/*     */     }
/*     */     
/* 381 */     if (this.emptyCellsAllowed)
/*     */     {
/* 383 */       options |= EMPTY_CELLS_ALLOWED_MASK;
/*     */     }
/*     */     
/* 386 */     if (this.suppressArrow)
/*     */     {
/* 388 */       options |= SUPPRESS_ARROW_MASK;
/*     */     }
/*     */     
/* 391 */     if (this.showPrompt)
/*     */     {
/* 393 */       options |= SHOW_PROMPT_MASK;
/*     */     }
/*     */     
/* 396 */     if (this.showError)
/*     */     {
/* 398 */       options |= SHOW_ERROR_MASK;
/*     */     }
/*     */ 
/*     */     
/* 402 */     IntegerHelper.getFourBytes(options, data, pos);
/* 403 */     pos += 4;
/*     */     
/* 405 */     IntegerHelper.getTwoBytes(this.promptTitle.length(), data, pos);
/* 406 */     pos += 2;
/*     */     
/* 408 */     StringHelper.getUnicodeBytes(this.promptTitle, data, pos);
/* 409 */     pos += this.promptTitle.length() * 2;
/*     */     
/* 411 */     IntegerHelper.getTwoBytes(this.errorTitle.length(), data, pos);
/* 412 */     pos += 2;
/*     */     
/* 414 */     StringHelper.getUnicodeBytes(this.errorTitle, data, pos);
/* 415 */     pos += this.errorTitle.length() * 2;
/*     */     
/* 417 */     IntegerHelper.getTwoBytes(this.promptText.length(), data, pos);
/* 418 */     pos += 2;
/*     */     
/* 420 */     StringHelper.getUnicodeBytes(this.promptText, data, pos);
/* 421 */     pos += this.promptText.length() * 2;
/*     */     
/* 423 */     IntegerHelper.getTwoBytes(this.errorText.length(), data, pos);
/* 424 */     pos += 2;
/*     */     
/* 426 */     StringHelper.getUnicodeBytes(this.errorText, data, pos);
/* 427 */     pos += this.errorText.length() * 2;
/*     */ 
/*     */     
/* 430 */     IntegerHelper.getTwoBytes(f1Bytes.length, data, pos);
/* 431 */     pos += 4;
/*     */     
/* 433 */     System.arraycopy(f1Bytes, 0, data, pos, f1Bytes.length);
/* 434 */     pos += f1Bytes.length;
/*     */ 
/*     */     
/* 437 */     IntegerHelper.getTwoBytes(f2Bytes.length, data, pos);
/* 438 */     pos += 2;
/*     */     
/* 440 */     System.arraycopy(f2Bytes, 0, data, pos, f2Bytes.length);
/* 441 */     pos += f2Bytes.length;
/*     */ 
/*     */     
/* 444 */     pos += 2;
/*     */ 
/*     */     
/* 447 */     IntegerHelper.getTwoBytes(1, data, pos);
/* 448 */     pos += 2;
/*     */     
/* 450 */     IntegerHelper.getTwoBytes(this.row1, data, pos);
/* 451 */     pos += 2;
/*     */     
/* 453 */     IntegerHelper.getTwoBytes(this.row2, data, pos);
/* 454 */     pos += 2;
/*     */     
/* 456 */     IntegerHelper.getTwoBytes(this.column1, data, pos);
/* 457 */     pos += 2;
/*     */     
/* 459 */     IntegerHelper.getTwoBytes(this.column2, data, pos);
/* 460 */     pos += 2;
/*     */     
/* 462 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertRow(int row) {
/* 472 */     if (this.formula1 != null)
/*     */     {
/* 474 */       this.formula1.rowInserted(0, row, true);
/*     */     }
/*     */     
/* 477 */     if (this.formula2 != null)
/*     */     {
/* 479 */       this.formula2.rowInserted(0, row, true);
/*     */     }
/*     */     
/* 482 */     if (this.row1 >= row)
/*     */     {
/* 484 */       this.row1++;
/*     */     }
/*     */     
/* 487 */     if (this.row2 >= row)
/*     */     {
/* 489 */       this.row2++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertColumn(int col) {
/* 500 */     if (this.formula1 != null)
/*     */     {
/* 502 */       this.formula1.columnInserted(0, col, true);
/*     */     }
/*     */     
/* 505 */     if (this.formula2 != null)
/*     */     {
/* 507 */       this.formula2.columnInserted(0, col, true);
/*     */     }
/*     */     
/* 510 */     if (this.column1 >= col)
/*     */     {
/* 512 */       this.column1++;
/*     */     }
/*     */     
/* 515 */     if (this.column2 >= col)
/*     */     {
/* 517 */       this.column2++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRow(int row) {
/* 528 */     if (this.formula1 != null)
/*     */     {
/* 530 */       this.formula1.rowRemoved(0, row, true);
/*     */     }
/*     */     
/* 533 */     if (this.formula2 != null)
/*     */     {
/* 535 */       this.formula2.rowRemoved(0, row, true);
/*     */     }
/*     */     
/* 538 */     if (this.row1 > row)
/*     */     {
/* 540 */       this.row1--;
/*     */     }
/*     */     
/* 543 */     if (this.row2 >= row)
/*     */     {
/* 545 */       this.row2--;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeColumn(int col) {
/* 556 */     if (this.formula1 != null)
/*     */     {
/* 558 */       this.formula1.columnRemoved(0, col, true);
/*     */     }
/*     */     
/* 561 */     if (this.formula2 != null)
/*     */     {
/* 563 */       this.formula2.columnRemoved(0, col, true);
/*     */     }
/*     */     
/* 566 */     if (this.column1 > col)
/*     */     {
/* 568 */       this.column1--;
/*     */     }
/*     */     
/* 571 */     if (this.column2 >= col)
/*     */     {
/* 573 */       this.column2--;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstColumn() {
/* 584 */     return this.column1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastColumn() {
/* 594 */     return this.column2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstRow() {
/* 604 */     return this.row1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastRow() {
/* 614 */     return this.row2;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\DVParser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
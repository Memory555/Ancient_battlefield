/*    */ package jxl.biff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BuiltInStyle
/*    */   extends WritableRecordData
/*    */ {
/*    */   private int xfIndex;
/*    */   private int styleNumber;
/*    */   
/*    */   public BuiltInStyle(int xfind, int sn) {
/* 46 */     super(Type.STYLE);
/*    */     
/* 48 */     this.xfIndex = xfind;
/* 49 */     this.styleNumber = sn;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 59 */     byte[] data = new byte[4];
/*    */     
/* 61 */     IntegerHelper.getTwoBytes(this.xfIndex, data, 0);
/*    */ 
/*    */     
/* 64 */     data[1] = (byte)(data[1] | 0x80);
/*    */     
/* 66 */     data[2] = (byte)this.styleNumber;
/*    */ 
/*    */     
/* 69 */     data[3] = -1;
/*    */     
/* 71 */     return data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\BuiltInStyle.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class HeaderFooter
/*     */ {
/*  39 */   private static Logger logger = Logger.getLogger(HeaderFooter.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String BOLD_TOGGLE = "&B";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String UNDERLINE_TOGGLE = "&U";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ITALICS_TOGGLE = "&I";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String STRIKETHROUGH_TOGGLE = "&S";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DOUBLE_UNDERLINE_TOGGLE = "&E";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String SUPERSCRIPT_TOGGLE = "&X";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String SUBSCRIPT_TOGGLE = "&Y";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String OUTLINE_TOGGLE = "&O";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String SHADOW_TOGGLE = "&H";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String LEFT_ALIGN = "&L";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String CENTRE = "&C";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String RIGHT_ALIGN = "&R";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String PAGENUM = "&P";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String TOTAL_PAGENUM = "&N";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DATE = "&D";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String TIME = "&T";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String WORKBOOK_NAME = "&F";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String WORKSHEET_NAME = "&A";
/*     */ 
/*     */ 
/*     */   
/*     */   private Contents left;
/*     */ 
/*     */ 
/*     */   
/*     */   private Contents right;
/*     */ 
/*     */ 
/*     */   
/*     */   private Contents centre;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class Contents
/*     */   {
/*     */     private StringBuffer contents;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Contents() {
/* 150 */       this.contents = new StringBuffer();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Contents(String s) {
/* 161 */       this.contents = new StringBuffer(s);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Contents(Contents copy) {
/* 171 */       this.contents = new StringBuffer(copy.getContents());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String getContents() {
/* 182 */       return (this.contents != null) ? this.contents.toString() : "";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void appendInternal(String txt) {
/* 192 */       if (this.contents == null)
/*     */       {
/* 194 */         this.contents = new StringBuffer();
/*     */       }
/*     */       
/* 197 */       this.contents.append(txt);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void appendInternal(char ch) {
/* 207 */       if (this.contents == null)
/*     */       {
/* 209 */         this.contents = new StringBuffer();
/*     */       }
/*     */       
/* 212 */       this.contents.append(ch);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void append(String txt) {
/* 222 */       appendInternal(txt);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void toggleBold() {
/* 233 */       appendInternal("&B");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void toggleUnderline() {
/* 244 */       appendInternal("&U");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void toggleItalics() {
/* 255 */       appendInternal("&I");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void toggleStrikethrough() {
/* 266 */       appendInternal("&S");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void toggleDoubleUnderline() {
/* 277 */       appendInternal("&E");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void toggleSuperScript() {
/* 288 */       appendInternal("&X");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void toggleSubScript() {
/* 299 */       appendInternal("&Y");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void toggleOutline() {
/* 310 */       appendInternal("&O");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void toggleShadow() {
/* 321 */       appendInternal("&H");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void setFontName(String fontName) {
/* 336 */       appendInternal("&\"");
/* 337 */       appendInternal(fontName);
/* 338 */       appendInternal('"');
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean setFontSize(int size) {
/*     */       String fontSize;
/* 357 */       if (size < 1 || size > 99)
/*     */       {
/* 359 */         return false;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 365 */       if (size < 10) {
/*     */ 
/*     */         
/* 368 */         fontSize = "0" + size;
/*     */       }
/*     */       else {
/*     */         
/* 372 */         fontSize = Integer.toString(size);
/*     */       } 
/*     */       
/* 375 */       appendInternal('&');
/* 376 */       appendInternal(fontSize);
/* 377 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void appendPageNumber() {
/* 385 */       appendInternal("&P");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void appendTotalPages() {
/* 393 */       appendInternal("&N");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void appendDate() {
/* 401 */       appendInternal("&D");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void appendTime() {
/* 409 */       appendInternal("&T");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void appendWorkbookName() {
/* 417 */       appendInternal("&F");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void appendWorkSheetName() {
/* 425 */       appendInternal("&A");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void clear() {
/* 433 */       this.contents = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected boolean empty() {
/* 443 */       if (this.contents == null || this.contents.length() == 0)
/*     */       {
/* 445 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 449 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HeaderFooter() {
/* 474 */     this.left = createContents();
/* 475 */     this.right = createContents();
/* 476 */     this.centre = createContents();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HeaderFooter(HeaderFooter hf) {
/* 486 */     this.left = createContents(hf.left);
/* 487 */     this.right = createContents(hf.right);
/* 488 */     this.centre = createContents(hf.centre);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected HeaderFooter(String s) {
/* 497 */     if (s == null || s.length() == 0) {
/*     */       
/* 499 */       this.left = createContents();
/* 500 */       this.right = createContents();
/* 501 */       this.centre = createContents();
/*     */       
/*     */       return;
/*     */     } 
/* 505 */     int pos = 0;
/* 506 */     int leftPos = s.indexOf("&L");
/* 507 */     int rightPos = s.indexOf("&R");
/* 508 */     int centrePos = s.indexOf("&C");
/*     */ 
/*     */     
/* 511 */     if (pos == leftPos)
/*     */     {
/* 513 */       if (centrePos != -1) {
/*     */         
/* 515 */         this.left = createContents(s.substring(pos + 2, centrePos));
/* 516 */         pos = centrePos;
/*     */       }
/* 518 */       else if (rightPos != -1) {
/*     */         
/* 520 */         this.left = createContents(s.substring(pos + 2, rightPos));
/* 521 */         pos = rightPos;
/*     */       }
/*     */       else {
/*     */         
/* 525 */         this.left = createContents(s.substring(pos + 2));
/* 526 */         pos = s.length();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 532 */     if (pos == centrePos || (leftPos == -1 && rightPos == -1 && centrePos == -1))
/*     */     {
/*     */       
/* 535 */       if (rightPos != -1) {
/*     */         
/* 537 */         this.centre = createContents(s.substring(pos + 2, rightPos));
/* 538 */         pos = rightPos;
/*     */       }
/*     */       else {
/*     */         
/* 542 */         this.centre = createContents(s.substring(pos + 2));
/* 543 */         pos = s.length();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 548 */     if (pos == rightPos) {
/*     */       
/* 550 */       this.right = createContents(s.substring(pos + 2));
/* 551 */       pos = s.length();
/*     */     } 
/*     */     
/* 554 */     if (this.left == null)
/*     */     {
/* 556 */       this.left = createContents();
/*     */     }
/*     */     
/* 559 */     if (this.centre == null)
/*     */     {
/* 561 */       this.centre = createContents();
/*     */     }
/*     */     
/* 564 */     if (this.right == null)
/*     */     {
/* 566 */       this.right = createContents();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 578 */     StringBuffer hf = new StringBuffer();
/* 579 */     if (!this.left.empty()) {
/*     */       
/* 581 */       hf.append("&L");
/* 582 */       hf.append(this.left.getContents());
/*     */     } 
/*     */     
/* 585 */     if (!this.centre.empty()) {
/*     */       
/* 587 */       hf.append("&C");
/* 588 */       hf.append(this.centre.getContents());
/*     */     } 
/*     */     
/* 591 */     if (!this.right.empty()) {
/*     */       
/* 593 */       hf.append("&R");
/* 594 */       hf.append(this.right.getContents());
/*     */     } 
/*     */     
/* 597 */     return hf.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Contents getRightText() {
/* 607 */     return this.right;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Contents getCentreText() {
/* 617 */     return this.centre;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Contents getLeftText() {
/* 627 */     return this.left;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void clear() {
/* 635 */     this.left.clear();
/* 636 */     this.right.clear();
/* 637 */     this.centre.clear();
/*     */   }
/*     */   
/*     */   protected abstract Contents createContents();
/*     */   
/*     */   protected abstract Contents createContents(String paramString);
/*     */   
/*     */   protected abstract Contents createContents(Contents paramContents);
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\HeaderFooter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Fonts
/*     */ {
/*  50 */   private ArrayList fonts = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int numDefaultFonts = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFont(FontRecord f) {
/*  63 */     if (!f.isInitialized()) {
/*     */       
/*  65 */       int pos = this.fonts.size();
/*     */ 
/*     */       
/*  68 */       if (pos >= 4)
/*     */       {
/*  70 */         pos++;
/*     */       }
/*     */       
/*  73 */       f.initialize(pos);
/*  74 */       this.fonts.add(f);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FontRecord getFont(int index) {
/*  88 */     if (index > 4)
/*     */     {
/*  90 */       index--;
/*     */     }
/*     */     
/*  93 */     return this.fonts.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(File outputFile) throws IOException {
/* 104 */     Iterator i = this.fonts.iterator();
/*     */     
/* 106 */     FontRecord font = null;
/* 107 */     while (i.hasNext()) {
/*     */       
/* 109 */       font = i.next();
/* 110 */       outputFile.write(font);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   IndexMapping rationalize() {
/* 121 */     IndexMapping mapping = new IndexMapping(this.fonts.size() + 1);
/*     */ 
/*     */     
/* 124 */     ArrayList newfonts = new ArrayList();
/* 125 */     FontRecord fr = null;
/* 126 */     int numremoved = 0;
/*     */ 
/*     */     
/* 129 */     for (int i = 0; i < 4; i++) {
/*     */       
/* 131 */       fr = this.fonts.get(i);
/* 132 */       newfonts.add(fr);
/* 133 */       mapping.setMapping(fr.getFontIndex(), fr.getFontIndex());
/*     */     } 
/*     */ 
/*     */     
/* 137 */     Iterator it = null;
/* 138 */     FontRecord fr2 = null;
/* 139 */     boolean duplicate = false;
/* 140 */     for (int j = 4; j < this.fonts.size(); j++) {
/*     */       
/* 142 */       fr = this.fonts.get(j);
/*     */ 
/*     */       
/* 145 */       duplicate = false;
/* 146 */       it = newfonts.iterator();
/* 147 */       while (it.hasNext() && !duplicate) {
/*     */         
/* 149 */         fr2 = it.next();
/* 150 */         if (fr.equals(fr2)) {
/*     */           
/* 152 */           duplicate = true;
/* 153 */           mapping.setMapping(fr.getFontIndex(), mapping.getNewIndex(fr2.getFontIndex()));
/*     */           
/* 155 */           numremoved++;
/*     */         } 
/*     */       } 
/*     */       
/* 159 */       if (!duplicate) {
/*     */ 
/*     */         
/* 162 */         newfonts.add(fr);
/* 163 */         int newindex = fr.getFontIndex() - numremoved;
/* 164 */         Assert.verify((newindex > 4));
/* 165 */         mapping.setMapping(fr.getFontIndex(), newindex);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 170 */     it = newfonts.iterator();
/* 171 */     while (it.hasNext()) {
/*     */       
/* 173 */       fr = it.next();
/* 174 */       fr.initialize(mapping.getNewIndex(fr.getFontIndex()));
/*     */     } 
/*     */     
/* 177 */     this.fonts = newfonts;
/*     */     
/* 179 */     return mapping;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\Fonts.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
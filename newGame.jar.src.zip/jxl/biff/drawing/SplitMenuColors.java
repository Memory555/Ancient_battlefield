/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SplitMenuColors
/*    */   extends EscherAtom
/*    */ {
/*    */   private byte[] data;
/*    */   
/*    */   public SplitMenuColors(EscherRecordData erd) {
/* 28 */     super(erd);
/*    */   }
/*    */ 
/*    */   
/*    */   public SplitMenuColors() {
/* 33 */     super(EscherRecordType.SPLIT_MENU_COLORS);
/* 34 */     setVersion(0);
/* 35 */     setInstance(4);
/*    */     
/* 37 */     this.data = new byte[] { 13, 0, 0, 8, 12, 0, 0, 8, 23, 0, 0, 8, -9, 0, 0, 16 };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getData() {
/* 46 */     return setHeaderData(this.data);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\SplitMenuColors.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
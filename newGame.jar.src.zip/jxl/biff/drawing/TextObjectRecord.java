/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TextObjectRecord
/*     */   extends WritableRecordData
/*     */ {
/*  36 */   private static Logger logger = Logger.getLogger(TextObjectRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int textLength;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TextObjectRecord(String t) {
/*  53 */     super(Type.TXO);
/*     */     
/*  55 */     this.textLength = t.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextObjectRecord(Record t) {
/*  65 */     super(t);
/*  66 */     this.data = getRecord().getData();
/*  67 */     this.textLength = IntegerHelper.getInt(this.data[10], this.data[11]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TextObjectRecord(byte[] d) {
/*  77 */     super(Type.TXO);
/*  78 */     this.data = d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/*  88 */     if (this.data != null)
/*     */     {
/*  90 */       return this.data;
/*     */     }
/*     */     
/*  93 */     this.data = new byte[18];
/*     */ 
/*     */     
/*  96 */     int options = 0;
/*  97 */     options |= 0x2;
/*  98 */     options |= 0x10;
/*  99 */     options |= 0x200;
/* 100 */     IntegerHelper.getTwoBytes(options, this.data, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     IntegerHelper.getTwoBytes(this.textLength, this.data, 10);
/*     */ 
/*     */     
/* 109 */     IntegerHelper.getTwoBytes(16, this.data, 12);
/*     */     
/* 111 */     return this.data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\TextObjectRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
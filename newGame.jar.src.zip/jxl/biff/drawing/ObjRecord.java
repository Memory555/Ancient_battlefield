/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ObjRecord
/*     */   extends WritableRecordData
/*     */ {
/*  38 */   private static final Logger logger = Logger.getLogger(ObjRecord.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjType type;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean read;
/*     */ 
/*     */ 
/*     */   
/*     */   private int objectId;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class ObjType
/*     */   {
/*     */     public int value;
/*     */ 
/*     */     
/*     */     public String desc;
/*     */ 
/*     */     
/*  63 */     private static ObjType[] types = new ObjType[0];
/*     */ 
/*     */     
/*     */     ObjType(int v, String d) {
/*  67 */       this.value = v;
/*  68 */       this.desc = d;
/*     */       
/*  70 */       ObjType[] oldtypes = types;
/*  71 */       types = new ObjType[types.length + 1];
/*  72 */       System.arraycopy(oldtypes, 0, types, 0, oldtypes.length);
/*  73 */       types[oldtypes.length] = this;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  78 */       return this.desc;
/*     */     }
/*     */ 
/*     */     
/*     */     public static ObjType getType(int val) {
/*  83 */       ObjType retval = ObjRecord.UNKNOWN;
/*  84 */       for (int i = 0; i < types.length && retval == ObjRecord.UNKNOWN; i++) {
/*     */         
/*  86 */         if ((types[i]).value == val)
/*     */         {
/*  88 */           retval = types[i];
/*     */         }
/*     */       } 
/*  91 */       return retval;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*  96 */   public static final ObjType TBD2 = new ObjType(1, "TBD2");
/*  97 */   public static final ObjType TBD = new ObjType(2, "TBD");
/*  98 */   public static final ObjType CHART = new ObjType(5, "Chart");
/*  99 */   public static final ObjType TEXT = new ObjType(6, "Text");
/* 100 */   public static final ObjType BUTTON = new ObjType(7, "Button");
/* 101 */   public static final ObjType PICTURE = new ObjType(8, "Picture");
/* 102 */   public static final ObjType CHECKBOX = new ObjType(14, "Checkbox");
/* 103 */   public static final ObjType OPTION = new ObjType(12, "Option");
/* 104 */   public static final ObjType EDITBOX = new ObjType(13, "Edit Box");
/* 105 */   public static final ObjType LABEL = new ObjType(14, "Label");
/* 106 */   public static final ObjType DIALOGUEBOX = new ObjType(15, "Dialogue Box");
/* 107 */   public static final ObjType LISTBOX = new ObjType(18, "List Box");
/* 108 */   public static final ObjType GROUPBOX = new ObjType(19, "Group Box");
/* 109 */   public static final ObjType COMBOBOX = new ObjType(20, "Combo Box");
/* 110 */   public static final ObjType MSOFFICEDRAWING = new ObjType(30, "MS Office Drawing");
/*     */   
/* 112 */   public static final ObjType FORMCONTROL = new ObjType(20, "Form Combo Box");
/*     */   
/* 114 */   public static final ObjType EXCELNOTE = new ObjType(25, "Excel Note");
/*     */ 
/*     */   
/* 117 */   public static final ObjType UNKNOWN = new ObjType(255, "Unknown");
/*     */ 
/*     */   
/*     */   private static final int COMMON_DATA_LENGTH = 22;
/*     */ 
/*     */   
/*     */   private static final int CLIPBOARD_FORMAT_LENGTH = 6;
/*     */   
/*     */   private static final int PICTURE_OPTION_LENGTH = 6;
/*     */   
/*     */   private static final int NOTE_STRUCTURE_LENGTH = 26;
/*     */   
/*     */   private static final int END_LENGTH = 4;
/*     */ 
/*     */   
/*     */   public ObjRecord(Record t) {
/* 133 */     super(t);
/* 134 */     byte[] data = t.getData();
/* 135 */     int objtype = IntegerHelper.getInt(data[4], data[5]);
/* 136 */     this.read = true;
/* 137 */     this.type = ObjType.getType(objtype);
/*     */     
/* 139 */     if (this.type == UNKNOWN);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 144 */     this.objectId = IntegerHelper.getInt(data[6], data[7]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ObjRecord(int objId, ObjType t) {
/* 155 */     super(Type.OBJ);
/* 156 */     this.objectId = objId;
/* 157 */     this.type = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 167 */     if (this.read)
/*     */     {
/* 169 */       return getRecord().getData();
/*     */     }
/*     */     
/* 172 */     if (this.type == PICTURE || this.type == CHART)
/*     */     {
/* 174 */       return getPictureData();
/*     */     }
/* 176 */     if (this.type == EXCELNOTE)
/*     */     {
/* 178 */       return getNoteData();
/*     */     }
/*     */ 
/*     */     
/* 182 */     Assert.verify(false);
/*     */     
/* 184 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getPictureData() {
/* 193 */     int dataLength = 38;
/*     */ 
/*     */ 
/*     */     
/* 197 */     int pos = 0;
/* 198 */     byte[] data = new byte[dataLength];
/*     */ 
/*     */ 
/*     */     
/* 202 */     IntegerHelper.getTwoBytes(21, data, pos);
/*     */ 
/*     */     
/* 205 */     IntegerHelper.getTwoBytes(18, data, pos + 2);
/*     */ 
/*     */     
/* 208 */     IntegerHelper.getTwoBytes(this.type.value, data, pos + 4);
/*     */ 
/*     */     
/* 211 */     IntegerHelper.getTwoBytes(this.objectId, data, pos + 6);
/*     */ 
/*     */     
/* 214 */     IntegerHelper.getTwoBytes(24593, data, pos + 8);
/* 215 */     pos += 22;
/*     */ 
/*     */ 
/*     */     
/* 219 */     IntegerHelper.getTwoBytes(7, data, pos);
/*     */ 
/*     */     
/* 222 */     IntegerHelper.getTwoBytes(2, data, pos + 2);
/*     */ 
/*     */     
/* 225 */     IntegerHelper.getTwoBytes(65535, data, pos + 4);
/* 226 */     pos += 6;
/*     */ 
/*     */ 
/*     */     
/* 230 */     IntegerHelper.getTwoBytes(8, data, pos);
/*     */ 
/*     */     
/* 233 */     IntegerHelper.getTwoBytes(2, data, pos + 2);
/*     */ 
/*     */     
/* 236 */     IntegerHelper.getTwoBytes(1, data, pos + 4);
/* 237 */     pos += 6;
/*     */ 
/*     */     
/* 240 */     IntegerHelper.getTwoBytes(0, data, pos);
/*     */ 
/*     */     
/* 243 */     IntegerHelper.getTwoBytes(0, data, pos + 2);
/*     */ 
/*     */     
/* 246 */     pos += 4;
/*     */     
/* 248 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getNoteData() {
/* 257 */     int dataLength = 52;
/*     */ 
/*     */     
/* 260 */     int pos = 0;
/* 261 */     byte[] data = new byte[dataLength];
/*     */ 
/*     */ 
/*     */     
/* 265 */     IntegerHelper.getTwoBytes(21, data, pos);
/*     */ 
/*     */     
/* 268 */     IntegerHelper.getTwoBytes(18, data, pos + 2);
/*     */ 
/*     */     
/* 271 */     IntegerHelper.getTwoBytes(this.type.value, data, pos + 4);
/*     */ 
/*     */     
/* 274 */     IntegerHelper.getTwoBytes(this.objectId, data, pos + 6);
/*     */ 
/*     */     
/* 277 */     IntegerHelper.getTwoBytes(16401, data, pos + 8);
/* 278 */     pos += 22;
/*     */ 
/*     */ 
/*     */     
/* 282 */     IntegerHelper.getTwoBytes(13, data, pos);
/*     */ 
/*     */     
/* 285 */     IntegerHelper.getTwoBytes(22, data, pos + 2);
/*     */ 
/*     */     
/* 288 */     pos += 26;
/*     */ 
/*     */ 
/*     */     
/* 292 */     IntegerHelper.getTwoBytes(0, data, pos);
/*     */ 
/*     */     
/* 295 */     IntegerHelper.getTwoBytes(0, data, pos + 2);
/*     */ 
/*     */     
/* 298 */     pos += 4;
/*     */     
/* 300 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Record getRecord() {
/* 310 */     return super.getRecord();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ObjType getType() {
/* 320 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getObjectId() {
/* 328 */     return this.objectId;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\ObjRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
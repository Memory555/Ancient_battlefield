/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Dg
/*    */   extends EscherAtom
/*    */ {
/*    */   private byte[] data;
/*    */   private int drawingId;
/*    */   private int shapeCount;
/*    */   private int seed;
/*    */   
/*    */   public Dg(EscherRecordData erd) {
/* 56 */     super(erd);
/* 57 */     this.drawingId = getInstance();
/*    */     
/* 59 */     byte[] bytes = getBytes();
/* 60 */     this.shapeCount = IntegerHelper.getInt(bytes[0], bytes[1], bytes[2], bytes[3]);
/* 61 */     this.seed = IntegerHelper.getInt(bytes[4], bytes[5], bytes[6], bytes[7]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Dg(int numDrawings) {
/* 71 */     super(EscherRecordType.DG);
/* 72 */     this.drawingId = 1;
/* 73 */     this.shapeCount = numDrawings + 1;
/* 74 */     this.seed = 1024 + this.shapeCount + 1;
/* 75 */     setInstance(this.drawingId);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getDrawingId() {
/* 85 */     return this.drawingId;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getData() {
/* 95 */     this.data = new byte[8];
/* 96 */     IntegerHelper.getFourBytes(this.shapeCount, this.data, 0);
/* 97 */     IntegerHelper.getFourBytes(this.seed, this.data, 4);
/*    */     
/* 99 */     return setHeaderData(this.data);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\Dg.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
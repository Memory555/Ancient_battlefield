/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ import jxl.read.biff.Record;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MsoDrawingGroupRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   
/*    */   public MsoDrawingGroupRecord(Record t) {
/* 41 */     super(t);
/* 42 */     this.data = t.getData();
/*    */   }
/*    */ 
/*    */   
/*    */   MsoDrawingGroupRecord(byte[] d) {
/* 47 */     super(Type.MSODRAWINGGROUP);
/* 48 */     this.data = d;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 58 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\MsoDrawingGroupRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ import common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EscherAtom
/*    */   extends EscherRecord
/*    */ {
/* 34 */   private static Logger logger = Logger.getLogger(EscherAtom.class);
/*    */ 
/*    */   
/*    */   public EscherAtom(EscherRecordData erd) {
/* 38 */     super(erd);
/*    */   }
/*    */ 
/*    */   
/*    */   protected EscherAtom(EscherRecordType type) {
/* 43 */     super(type);
/*    */   }
/*    */ 
/*    */   
/*    */   byte[] getData() {
/* 48 */     logger.warn("escher atom getData called on object of type " + getClass().getName() + " code " + Integer.toString(getType().getValue(), 16));
/*    */ 
/*    */     
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\EscherAtom.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
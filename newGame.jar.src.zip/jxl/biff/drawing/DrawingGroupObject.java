package jxl.biff.drawing;

import java.io.IOException;
import jxl.write.biff.File;

public interface DrawingGroupObject {
  void setObjectId(int paramInt1, int paramInt2, int paramInt3);
  
  int getObjectId();
  
  int getBlipId();
  
  int getShapeId();
  
  MsoDrawingRecord getMsoDrawingRecord();
  
  EscherContainer getSpContainer();
  
  void setDrawingGroup(DrawingGroup paramDrawingGroup);
  
  DrawingGroup getDrawingGroup();
  
  Origin getOrigin();
  
  int getReferenceCount();
  
  void setReferenceCount(int paramInt);
  
  double getX();
  
  void setX(double paramDouble);
  
  double getY();
  
  void setY(double paramDouble);
  
  double getWidth();
  
  void setWidth(double paramDouble);
  
  double getHeight();
  
  void setHeight(double paramDouble);
  
  ShapeType getType();
  
  byte[] getImageData();
  
  byte[] getImageBytes() throws IOException;
  
  String getImageFilePath();
  
  void writeAdditionalRecords(File paramFile) throws IOException;
  
  void writeTailRecords(File paramFile) throws IOException;
  
  boolean isFirst();
  
  boolean isFormObject();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\DrawingGroupObject.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
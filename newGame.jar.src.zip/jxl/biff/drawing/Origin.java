/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Origin
/*    */ {
/* 31 */   public static final Origin READ = new Origin();
/* 32 */   public static final Origin WRITE = new Origin();
/* 33 */   public static final Origin READ_WRITE = new Origin();
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\Origin.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
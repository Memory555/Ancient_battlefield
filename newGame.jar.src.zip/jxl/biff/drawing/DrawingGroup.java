/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.read.biff.Record;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DrawingGroup
/*     */   implements EscherStream
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(DrawingGroup.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] drawingData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer escherData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BStoreContainer bstoreContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList drawings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int numBlips;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int numCharts;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int drawingGroupId;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean drawingsOmitted;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Origin origin;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HashMap imageFiles;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int maxObjectId;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int maxShapeId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DrawingGroup(Origin o) {
/* 118 */     this.origin = o;
/* 119 */     this.initialized = (o == Origin.WRITE);
/* 120 */     this.drawings = new ArrayList();
/* 121 */     this.imageFiles = new HashMap();
/* 122 */     this.drawingsOmitted = false;
/* 123 */     this.maxObjectId = 1;
/* 124 */     this.maxShapeId = 1024;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DrawingGroup(DrawingGroup dg) {
/* 137 */     this.drawingData = dg.drawingData;
/* 138 */     this.escherData = dg.escherData;
/* 139 */     this.bstoreContainer = dg.bstoreContainer;
/* 140 */     this.initialized = dg.initialized;
/* 141 */     this.drawingData = dg.drawingData;
/* 142 */     this.escherData = dg.escherData;
/* 143 */     this.bstoreContainer = dg.bstoreContainer;
/* 144 */     this.numBlips = dg.numBlips;
/* 145 */     this.numCharts = dg.numCharts;
/* 146 */     this.drawingGroupId = dg.drawingGroupId;
/* 147 */     this.drawingsOmitted = dg.drawingsOmitted;
/* 148 */     this.origin = dg.origin;
/* 149 */     this.imageFiles = (HashMap)dg.imageFiles.clone();
/* 150 */     this.maxObjectId = dg.maxObjectId;
/* 151 */     this.maxShapeId = dg.maxShapeId;
/*     */ 
/*     */ 
/*     */     
/* 155 */     this.drawings = new ArrayList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(MsoDrawingGroupRecord mso) {
/* 169 */     addData(mso.getData());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Record cont) {
/* 180 */     addData(cont.getData());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addData(byte[] msodata) {
/* 188 */     if (this.drawingData == null) {
/*     */       
/* 190 */       this.drawingData = new byte[msodata.length];
/* 191 */       System.arraycopy(msodata, 0, this.drawingData, 0, msodata.length);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 196 */     byte[] newdata = new byte[this.drawingData.length + msodata.length];
/* 197 */     System.arraycopy(this.drawingData, 0, newdata, 0, this.drawingData.length);
/* 198 */     System.arraycopy(msodata, 0, newdata, this.drawingData.length, msodata.length);
/* 199 */     this.drawingData = newdata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void addDrawing(DrawingGroupObject d) {
/* 209 */     this.drawings.add(d);
/* 210 */     this.maxObjectId = Math.max(this.maxObjectId, d.getObjectId());
/* 211 */     this.maxShapeId = Math.max(this.maxShapeId, d.getShapeId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(Chart c) {
/* 221 */     this.numCharts++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(DrawingGroupObject d) {
/* 231 */     if (this.origin == Origin.READ) {
/*     */       
/* 233 */       this.origin = Origin.READ_WRITE;
/* 234 */       BStoreContainer bsc = getBStoreContainer();
/* 235 */       Dgg dgg = (Dgg)this.escherData.getChildren()[0];
/* 236 */       this.drawingGroupId = (dgg.getCluster(1)).drawingGroupId - this.numBlips - 1;
/* 237 */       this.numBlips = dgg.getDrawingsSaved();
/*     */       
/* 239 */       if (bsc != null)
/*     */       {
/* 241 */         Assert.verify((this.numBlips == bsc.getNumBlips()));
/*     */       }
/*     */     } 
/*     */     
/* 245 */     if (!(d instanceof Drawing)) {
/*     */ 
/*     */ 
/*     */       
/* 249 */       this.maxObjectId++;
/* 250 */       this.maxShapeId++;
/* 251 */       d.setDrawingGroup(this);
/* 252 */       d.setObjectId(this.maxObjectId, this.numBlips + 1, this.maxShapeId);
/* 253 */       if (this.drawings.size() > this.maxObjectId)
/*     */       {
/* 255 */         logger.warn("drawings length " + this.drawings.size() + " exceeds the max object id " + this.maxObjectId);
/*     */       }
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 262 */     Drawing drawing = (Drawing)d;
/*     */ 
/*     */     
/* 265 */     Drawing refImage = (Drawing)this.imageFiles.get(d.getImageFilePath());
/*     */ 
/*     */     
/* 268 */     if (refImage == null) {
/*     */ 
/*     */ 
/*     */       
/* 272 */       this.maxObjectId++;
/* 273 */       this.maxShapeId++;
/* 274 */       this.drawings.add(drawing);
/* 275 */       drawing.setDrawingGroup(this);
/* 276 */       drawing.setObjectId(this.maxObjectId, this.numBlips + 1, this.maxShapeId);
/* 277 */       this.numBlips++;
/* 278 */       this.imageFiles.put(drawing.getImageFilePath(), drawing);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 285 */       refImage.setReferenceCount(refImage.getReferenceCount() + 1);
/* 286 */       drawing.setDrawingGroup(this);
/* 287 */       drawing.setObjectId(refImage.getObjectId(), refImage.getBlipId(), refImage.getShapeId());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(DrawingGroupObject d) {
/* 302 */     if (getBStoreContainer() == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 307 */     if (this.origin == Origin.READ) {
/*     */       
/* 309 */       this.origin = Origin.READ_WRITE;
/* 310 */       this.numBlips = getBStoreContainer().getNumBlips();
/* 311 */       Dgg dgg = (Dgg)this.escherData.getChildren()[0];
/* 312 */       this.drawingGroupId = (dgg.getCluster(1)).drawingGroupId - this.numBlips - 1;
/*     */     } 
/*     */ 
/*     */     
/* 316 */     EscherRecord[] children = getBStoreContainer().getChildren();
/* 317 */     BlipStoreEntry bse = (BlipStoreEntry)children[d.getBlipId() - 1];
/*     */     
/* 319 */     bse.dereference();
/*     */     
/* 321 */     if (bse.getReferenceCount() == 0) {
/*     */ 
/*     */       
/* 324 */       getBStoreContainer().remove(bse);
/*     */ 
/*     */       
/* 327 */       for (Iterator i = this.drawings.iterator(); i.hasNext(); ) {
/*     */         
/* 329 */         DrawingGroupObject drawing = i.next();
/*     */         
/* 331 */         if (drawing.getBlipId() > d.getBlipId())
/*     */         {
/* 333 */           drawing.setObjectId(drawing.getObjectId(), drawing.getBlipId() - 1, drawing.getShapeId());
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 339 */       this.numBlips--;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 349 */     EscherRecordData er = new EscherRecordData(this, 0);
/*     */     
/* 351 */     Assert.verify(er.isContainer());
/*     */     
/* 353 */     this.escherData = new EscherContainer(er);
/*     */     
/* 355 */     Assert.verify((this.escherData.getLength() == this.drawingData.length));
/* 356 */     Assert.verify((this.escherData.getType() == EscherRecordType.DGG_CONTAINER));
/*     */     
/* 358 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BStoreContainer getBStoreContainer() {
/* 368 */     if (this.bstoreContainer == null) {
/*     */       
/* 370 */       if (!this.initialized)
/*     */       {
/* 372 */         initialize();
/*     */       }
/*     */       
/* 375 */       EscherRecord[] children = this.escherData.getChildren();
/* 376 */       if (children.length > 1 && children[1].getType() == EscherRecordType.BSTORE_CONTAINER)
/*     */       {
/*     */         
/* 379 */         this.bstoreContainer = (BStoreContainer)children[1];
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 387 */     return this.bstoreContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 397 */     return this.drawingData;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(File outputFile) throws IOException {
/* 408 */     if (this.origin == Origin.WRITE) {
/*     */       
/* 410 */       DggContainer dggContainer = new DggContainer();
/*     */       
/* 412 */       Dgg dgg = new Dgg(this.numBlips + this.numCharts + 1, this.numBlips);
/*     */       
/* 414 */       dgg.addCluster(1, 0);
/* 415 */       dgg.addCluster(this.numBlips + 1, 0);
/*     */       
/* 417 */       dggContainer.add(dgg);
/*     */       
/* 419 */       int drawingsAdded = 0;
/* 420 */       BStoreContainer bstoreCont = new BStoreContainer();
/*     */ 
/*     */       
/* 423 */       for (Iterator i = this.drawings.iterator(); i.hasNext(); ) {
/*     */         
/* 425 */         Object o = i.next();
/* 426 */         if (o instanceof Drawing) {
/*     */           
/* 428 */           Drawing d = (Drawing)o;
/* 429 */           BlipStoreEntry bse = new BlipStoreEntry(d);
/*     */           
/* 431 */           bstoreCont.add(bse);
/* 432 */           drawingsAdded++;
/*     */         } 
/*     */       } 
/* 435 */       if (drawingsAdded > 0) {
/*     */         
/* 437 */         bstoreCont.setNumBlips(drawingsAdded);
/* 438 */         dggContainer.add(bstoreCont);
/*     */       } 
/*     */       
/* 441 */       Opt opt = new Opt();
/*     */       
/* 443 */       dggContainer.add(opt);
/*     */       
/* 445 */       SplitMenuColors splitMenuColors = new SplitMenuColors();
/* 446 */       dggContainer.add(splitMenuColors);
/*     */       
/* 448 */       this.drawingData = dggContainer.getData();
/*     */     }
/* 450 */     else if (this.origin == Origin.READ_WRITE) {
/*     */       
/* 452 */       DggContainer dggContainer = new DggContainer();
/*     */       
/* 454 */       Dgg dgg = new Dgg(this.numBlips + this.numCharts + 1, this.numBlips);
/*     */       
/* 456 */       dgg.addCluster(1, 0);
/* 457 */       dgg.addCluster(this.drawingGroupId + this.numBlips + 1, 0);
/*     */       
/* 459 */       dggContainer.add(dgg);
/*     */       
/* 461 */       BStoreContainer bstoreCont = new BStoreContainer();
/* 462 */       bstoreCont.setNumBlips(this.numBlips);
/*     */ 
/*     */       
/* 465 */       BStoreContainer readBStoreContainer = getBStoreContainer();
/*     */       
/* 467 */       if (readBStoreContainer != null) {
/*     */         
/* 469 */         EscherRecord[] children = readBStoreContainer.getChildren();
/* 470 */         for (int j = 0; j < children.length; j++) {
/*     */           
/* 472 */           BlipStoreEntry bse = (BlipStoreEntry)children[j];
/* 473 */           bstoreCont.add(bse);
/*     */         } 
/*     */ 
/*     */         
/* 477 */         for (Iterator i = this.drawings.iterator(); i.hasNext(); ) {
/*     */           
/* 479 */           DrawingGroupObject dgo = i.next();
/* 480 */           if (dgo instanceof Drawing) {
/*     */             
/* 482 */             Drawing d = (Drawing)dgo;
/* 483 */             if (d.getOrigin() != Origin.READ) {
/*     */               
/* 485 */               BlipStoreEntry bse = new BlipStoreEntry(d);
/* 486 */               bstoreCont.add(bse);
/*     */             } 
/*     */           } 
/*     */         } 
/* 490 */         dggContainer.add(bstoreCont);
/*     */       } 
/*     */       
/* 493 */       Opt opt = new Opt();
/*     */       
/* 495 */       opt.addProperty(191, false, false, 524296);
/* 496 */       opt.addProperty(385, false, false, 134217737);
/* 497 */       opt.addProperty(448, false, false, 134217792);
/*     */       
/* 499 */       dggContainer.add(opt);
/*     */       
/* 501 */       SplitMenuColors splitMenuColors = new SplitMenuColors();
/* 502 */       dggContainer.add(splitMenuColors);
/*     */       
/* 504 */       this.drawingData = dggContainer.getData();
/*     */     } 
/*     */     
/* 507 */     MsoDrawingGroupRecord msodg = new MsoDrawingGroupRecord(this.drawingData);
/* 508 */     outputFile.write((ByteData)msodg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int getNumberOfBlips() {
/* 518 */     return this.numBlips;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getImageData(int blipId) {
/* 530 */     this.numBlips = getBStoreContainer().getNumBlips();
/*     */     
/* 532 */     Assert.verify((blipId <= this.numBlips));
/* 533 */     Assert.verify((this.origin == Origin.READ || this.origin == Origin.READ_WRITE));
/*     */ 
/*     */     
/* 536 */     EscherRecord[] children = getBStoreContainer().getChildren();
/* 537 */     BlipStoreEntry bse = (BlipStoreEntry)children[blipId - 1];
/*     */     
/* 539 */     return bse.getImageData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDrawingsOmitted(MsoDrawingRecord mso, ObjRecord obj) {
/* 548 */     this.drawingsOmitted = true;
/*     */     
/* 550 */     if (obj != null)
/*     */     {
/* 552 */       this.maxObjectId = Math.max(this.maxObjectId, obj.getObjectId());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDrawingsOmitted() {
/* 563 */     return this.drawingsOmitted;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateData(DrawingGroup dg) {
/* 578 */     this.drawingsOmitted = dg.drawingsOmitted;
/* 579 */     this.maxObjectId = dg.maxObjectId;
/* 580 */     this.maxShapeId = dg.maxShapeId;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\DrawingGroup.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
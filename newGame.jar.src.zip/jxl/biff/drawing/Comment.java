/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.biff.ContinueRecord;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Comment
/*     */   implements DrawingGroupObject
/*     */ {
/*  46 */   private static Logger logger = Logger.getLogger(Comment.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer readSpContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer spContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MsoDrawingRecord msoDrawingRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjRecord objRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int objectId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int blipId;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int shapeId;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double width;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double height;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int referenceCount;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer escherData;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Origin origin;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DrawingGroup drawingGroup;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DrawingData drawingData;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ShapeType type;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int drawingNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MsoDrawingRecord mso;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TextObjectRecord txo;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private NoteRecord note;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ContinueRecord text;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ContinueRecord formatting;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String commentText;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings workbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comment(MsoDrawingRecord mso, ObjRecord obj, DrawingData dd, DrawingGroup dg, WorkbookSettings ws) {
/* 190 */     this.drawingGroup = dg;
/* 191 */     this.msoDrawingRecord = mso;
/* 192 */     this.drawingData = dd;
/* 193 */     this.objRecord = obj;
/* 194 */     this.initialized = false;
/* 195 */     this.workbookSettings = ws;
/* 196 */     this.origin = Origin.READ;
/* 197 */     this.drawingData.addData(this.msoDrawingRecord.getData());
/* 198 */     this.drawingNumber = this.drawingData.getNumDrawings() - 1;
/* 199 */     this.drawingGroup.addDrawing(this);
/*     */     
/* 201 */     Assert.verify((mso != null && obj != null));
/*     */     
/* 203 */     if (!this.initialized)
/*     */     {
/* 205 */       initialize();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comment(DrawingGroupObject dgo, DrawingGroup dg, WorkbookSettings ws) {
/* 218 */     Comment d = (Comment)dgo;
/* 219 */     Assert.verify((d.origin == Origin.READ));
/* 220 */     this.msoDrawingRecord = d.msoDrawingRecord;
/* 221 */     this.objRecord = d.objRecord;
/* 222 */     this.initialized = false;
/* 223 */     this.origin = Origin.READ;
/* 224 */     this.drawingData = d.drawingData;
/* 225 */     this.drawingGroup = dg;
/* 226 */     this.drawingNumber = d.drawingNumber;
/* 227 */     this.drawingGroup.addDrawing(this);
/* 228 */     this.mso = d.mso;
/* 229 */     this.txo = d.txo;
/* 230 */     this.text = d.text;
/* 231 */     this.formatting = d.formatting;
/* 232 */     this.note = d.note;
/* 233 */     this.width = d.width;
/* 234 */     this.height = d.height;
/* 235 */     this.workbookSettings = ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comment(String text, int c, int r) {
/* 249 */     this.initialized = true;
/* 250 */     this.origin = Origin.WRITE;
/* 251 */     this.column = c;
/* 252 */     this.row = r;
/* 253 */     this.referenceCount = 1;
/* 254 */     this.type = ShapeType.TEXT_BOX;
/* 255 */     this.commentText = text;
/* 256 */     this.width = 3.0D;
/* 257 */     this.height = 4.0D;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 265 */     this.readSpContainer = this.drawingData.getSpContainer(this.drawingNumber);
/* 266 */     Assert.verify((this.readSpContainer != null));
/*     */     
/* 268 */     EscherRecord[] children = this.readSpContainer.getChildren();
/*     */     
/* 270 */     Sp sp = (Sp)this.readSpContainer.getChildren()[0];
/* 271 */     this.objectId = this.objRecord.getObjectId();
/* 272 */     this.shapeId = sp.getShapeId();
/* 273 */     this.type = ShapeType.getType(sp.getShapeType());
/*     */     
/* 275 */     if (this.type == ShapeType.UNKNOWN)
/*     */     {
/* 277 */       logger.warn("Unknown shape type");
/*     */     }
/*     */     
/* 280 */     Opt opt = (Opt)this.readSpContainer.getChildren()[1];
/*     */     
/* 282 */     ClientAnchor clientAnchor = null;
/* 283 */     for (int i = 0; i < children.length && clientAnchor == null; i++) {
/*     */       
/* 285 */       if (children[i].getType() == EscherRecordType.CLIENT_ANCHOR)
/*     */       {
/* 287 */         clientAnchor = (ClientAnchor)children[i];
/*     */       }
/*     */     } 
/*     */     
/* 291 */     if (clientAnchor == null) {
/*     */       
/* 293 */       logger.warn("client anchor not found");
/*     */     }
/*     */     else {
/*     */       
/* 297 */       this.column = (int)clientAnchor.getX1() - 1;
/* 298 */       this.row = (int)clientAnchor.getY1() + 1;
/* 299 */       this.width = clientAnchor.getX2() - clientAnchor.getX1();
/* 300 */       this.height = clientAnchor.getY2() - clientAnchor.getY1();
/*     */     } 
/*     */     
/* 303 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setObjectId(int objid, int bip, int sid) {
/* 317 */     this.objectId = objid;
/* 318 */     this.blipId = bip;
/* 319 */     this.shapeId = sid;
/*     */     
/* 321 */     if (this.origin == Origin.READ)
/*     */     {
/* 323 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getObjectId() {
/* 334 */     if (!this.initialized)
/*     */     {
/* 336 */       initialize();
/*     */     }
/*     */     
/* 339 */     return this.objectId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getShapeId() {
/* 349 */     if (!this.initialized)
/*     */     {
/* 351 */       initialize();
/*     */     }
/*     */     
/* 354 */     return this.shapeId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getBlipId() {
/* 364 */     if (!this.initialized)
/*     */     {
/* 366 */       initialize();
/*     */     }
/*     */     
/* 369 */     return this.blipId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MsoDrawingRecord getMsoDrawingRecord() {
/* 379 */     return this.msoDrawingRecord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EscherContainer getSpContainer() {
/* 389 */     if (!this.initialized)
/*     */     {
/* 391 */       initialize();
/*     */     }
/*     */     
/* 394 */     if (this.origin == Origin.READ)
/*     */     {
/* 396 */       return getReadSpContainer();
/*     */     }
/*     */     
/* 399 */     if (this.spContainer == null) {
/*     */       
/* 401 */       this.spContainer = new SpContainer();
/* 402 */       Sp sp = new Sp(this.type, this.shapeId, 2560);
/* 403 */       this.spContainer.add(sp);
/* 404 */       Opt opt = new Opt();
/* 405 */       opt.addProperty(344, false, false, 0);
/* 406 */       opt.addProperty(385, false, false, 134217808);
/* 407 */       opt.addProperty(387, false, false, 134217808);
/* 408 */       opt.addProperty(959, false, false, 131074);
/* 409 */       this.spContainer.add(opt);
/*     */       
/* 411 */       ClientAnchor clientAnchor = new ClientAnchor(this.column + 1.3D, Math.max(0.0D, this.row - 0.6D), this.column + 1.3D + this.width, this.row + this.height);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 416 */       this.spContainer.add(clientAnchor);
/*     */       
/* 418 */       ClientData clientData = new ClientData();
/* 419 */       this.spContainer.add(clientData);
/*     */       
/* 421 */       ClientTextBox clientTextBox = new ClientTextBox();
/* 422 */       this.spContainer.add(clientTextBox);
/*     */     } 
/*     */     
/* 425 */     return this.spContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDrawingGroup(DrawingGroup dg) {
/* 436 */     this.drawingGroup = dg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DrawingGroup getDrawingGroup() {
/* 446 */     return this.drawingGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Origin getOrigin() {
/* 456 */     return this.origin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getReferenceCount() {
/* 466 */     return this.referenceCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReferenceCount(int r) {
/* 476 */     this.referenceCount = r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getX() {
/* 486 */     if (!this.initialized)
/*     */     {
/* 488 */       initialize();
/*     */     }
/* 490 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setX(double x) {
/* 501 */     if (this.origin == Origin.READ) {
/*     */       
/* 503 */       if (!this.initialized)
/*     */       {
/* 505 */         initialize();
/*     */       }
/* 507 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 510 */     this.column = (int)x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getY() {
/* 520 */     if (!this.initialized)
/*     */     {
/* 522 */       initialize();
/*     */     }
/*     */     
/* 525 */     return this.row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setY(double y) {
/* 535 */     if (this.origin == Origin.READ) {
/*     */       
/* 537 */       if (!this.initialized)
/*     */       {
/* 539 */         initialize();
/*     */       }
/* 541 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 544 */     this.row = (int)y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getWidth() {
/* 555 */     if (!this.initialized)
/*     */     {
/* 557 */       initialize();
/*     */     }
/*     */     
/* 560 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidth(double w) {
/* 570 */     if (this.origin == Origin.READ) {
/*     */       
/* 572 */       if (!this.initialized)
/*     */       {
/* 574 */         initialize();
/*     */       }
/* 576 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 579 */     this.width = w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getHeight() {
/* 589 */     if (!this.initialized)
/*     */     {
/* 591 */       initialize();
/*     */     }
/*     */     
/* 594 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeight(double h) {
/* 604 */     if (this.origin == Origin.READ) {
/*     */       
/* 606 */       if (!this.initialized)
/*     */       {
/* 608 */         initialize();
/*     */       }
/* 610 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 613 */     this.height = h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer getReadSpContainer() {
/* 624 */     if (!this.initialized)
/*     */     {
/* 626 */       initialize();
/*     */     }
/*     */     
/* 629 */     return this.readSpContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getImageData() {
/* 639 */     Assert.verify((this.origin == Origin.READ || this.origin == Origin.READ_WRITE));
/*     */     
/* 641 */     if (!this.initialized)
/*     */     {
/* 643 */       initialize();
/*     */     }
/*     */     
/* 646 */     return this.drawingGroup.getImageData(this.blipId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShapeType getType() {
/* 656 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTextObject(TextObjectRecord t) {
/* 664 */     this.txo = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNote(NoteRecord t) {
/* 672 */     this.note = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(ContinueRecord t) {
/* 680 */     this.text = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormatting(ContinueRecord t) {
/* 688 */     this.formatting = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getImageBytes() {
/* 698 */     Assert.verify(false);
/* 699 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImageFilePath() {
/* 711 */     Assert.verify(false);
/* 712 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addMso(MsoDrawingRecord d) {
/* 717 */     this.mso = d;
/* 718 */     this.drawingData.addRawData(this.mso.getData());
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeAdditionalRecords(File outputFile) throws IOException {
/* 723 */     if (this.origin == Origin.READ) {
/*     */       
/* 725 */       outputFile.write((ByteData)this.objRecord);
/*     */       
/* 727 */       if (this.mso != null)
/*     */       {
/* 729 */         outputFile.write((ByteData)this.mso);
/*     */       }
/* 731 */       outputFile.write((ByteData)this.txo);
/* 732 */       outputFile.write((ByteData)this.text);
/* 733 */       if (this.formatting != null)
/*     */       {
/* 735 */         outputFile.write((ByteData)this.formatting);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 741 */     ObjRecord objRecord = new ObjRecord(this.objectId, ObjRecord.EXCELNOTE);
/*     */ 
/*     */     
/* 744 */     outputFile.write((ByteData)objRecord);
/*     */ 
/*     */ 
/*     */     
/* 748 */     ClientTextBox textBox = new ClientTextBox();
/* 749 */     MsoDrawingRecord msod = new MsoDrawingRecord(textBox.getData());
/* 750 */     outputFile.write((ByteData)msod);
/*     */     
/* 752 */     TextObjectRecord txo = new TextObjectRecord(getText());
/* 753 */     outputFile.write((ByteData)txo);
/*     */ 
/*     */     
/* 756 */     byte[] textData = new byte[this.commentText.length() * 2 + 1];
/* 757 */     textData[0] = 1;
/* 758 */     StringHelper.getUnicodeBytes(this.commentText, textData, 1);
/*     */     
/* 760 */     ContinueRecord textContinue = new ContinueRecord(textData);
/* 761 */     outputFile.write((ByteData)textContinue);
/*     */ 
/*     */ 
/*     */     
/* 765 */     byte[] frData = new byte[16];
/*     */ 
/*     */     
/* 768 */     IntegerHelper.getTwoBytes(0, frData, 0);
/* 769 */     IntegerHelper.getTwoBytes(0, frData, 2);
/*     */     
/* 771 */     IntegerHelper.getTwoBytes(this.commentText.length(), frData, 8);
/* 772 */     IntegerHelper.getTwoBytes(0, frData, 10);
/*     */     
/* 774 */     ContinueRecord frContinue = new ContinueRecord(frData);
/* 775 */     outputFile.write((ByteData)frContinue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTailRecords(File outputFile) throws IOException {
/* 785 */     if (this.origin == Origin.READ) {
/*     */       
/* 787 */       outputFile.write((ByteData)this.note);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 792 */     NoteRecord noteRecord = new NoteRecord(this.column, this.row, this.objectId);
/* 793 */     outputFile.write((ByteData)noteRecord);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRow() {
/* 801 */     return this.note.getRow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 809 */     return this.note.getColumn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 817 */     if (this.commentText == null) {
/*     */       
/* 819 */       Assert.verify((this.text != null));
/*     */       
/* 821 */       byte[] td = this.text.getData();
/* 822 */       if (td[0] == 0) {
/*     */         
/* 824 */         this.commentText = StringHelper.getString(td, td.length - 1, 1, this.workbookSettings);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 829 */         this.commentText = StringHelper.getUnicodeString(td, (td.length - 1) / 2, 1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 834 */     return this.commentText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 842 */     return this.commentText.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommentText(String t) {
/* 852 */     this.commentText = t;
/*     */     
/* 854 */     if (this.origin == Origin.READ)
/*     */     {
/* 856 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFirst() {
/* 869 */     return this.msoDrawingRecord.isFirst();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFormObject() {
/* 880 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\Comment.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ShapeType
/*    */ {
/*    */   int value;
/* 32 */   private static ShapeType[] types = new ShapeType[0];
/*    */   
/*    */   ShapeType(int v) {
/* 35 */     this.value = v;
/*    */     
/* 37 */     ShapeType[] old = types;
/* 38 */     types = new ShapeType[types.length + 1];
/* 39 */     System.arraycopy(old, 0, types, 0, old.length);
/* 40 */     types[old.length] = this;
/*    */   }
/*    */ 
/*    */   
/*    */   static ShapeType getType(int v) {
/* 45 */     ShapeType st = UNKNOWN;
/* 46 */     boolean found = false;
/* 47 */     for (int i = 0; i < types.length && !found; i++) {
/*    */       
/* 49 */       if ((types[i]).value == v) {
/*    */         
/* 51 */         found = true;
/* 52 */         st = types[i];
/*    */       } 
/*    */     } 
/* 55 */     return st;
/*    */   }
/*    */   
/* 58 */   public static final ShapeType MIN = new ShapeType(0);
/* 59 */   public static final ShapeType PICTURE_FRAME = new ShapeType(75);
/* 60 */   public static final ShapeType HOST_CONTROL = new ShapeType(201);
/* 61 */   public static final ShapeType TEXT_BOX = new ShapeType(202);
/* 62 */   public static final ShapeType UNKNOWN = new ShapeType(-1);
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\ShapeType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
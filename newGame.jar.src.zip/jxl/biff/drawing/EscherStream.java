package jxl.biff.drawing;

interface EscherStream {
  byte[] getData();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\EscherStream.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
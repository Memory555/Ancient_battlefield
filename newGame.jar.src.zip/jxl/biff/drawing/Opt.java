/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Opt
/*     */   extends EscherAtom
/*     */ {
/*  38 */   private static Logger logger = Logger.getLogger(Opt.class);
/*     */   
/*     */   private byte[] data;
/*     */   
/*     */   private int numProperties;
/*     */   
/*     */   private ArrayList properties;
/*     */ 
/*     */   
/*     */   static final class Property
/*     */   {
/*     */     int id;
/*     */     
/*     */     boolean blipId;
/*     */     
/*     */     boolean complex;
/*     */     int value;
/*     */     String stringValue;
/*     */     
/*     */     public Property(int i, boolean bl, boolean co, int v) {
/*  58 */       this.id = i;
/*  59 */       this.blipId = bl;
/*  60 */       this.complex = co;
/*  61 */       this.value = v;
/*     */     }
/*     */ 
/*     */     
/*     */     public Property(int i, boolean bl, boolean co, int v, String s) {
/*  66 */       this.id = i;
/*  67 */       this.blipId = bl;
/*  68 */       this.complex = co;
/*  69 */       this.value = v;
/*  70 */       this.stringValue = s;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Opt(EscherRecordData erd) {
/*  76 */     super(erd);
/*  77 */     this.numProperties = getInstance();
/*  78 */     readProperties();
/*     */   }
/*     */ 
/*     */   
/*     */   private void readProperties() {
/*  83 */     this.properties = new ArrayList();
/*  84 */     int pos = 0;
/*  85 */     byte[] bytes = getBytes();
/*     */     
/*  87 */     for (int j = 0; j < this.numProperties; j++) {
/*     */       
/*  89 */       int val = IntegerHelper.getInt(bytes[pos], bytes[pos + 1]);
/*  90 */       int id = val & 0x3FFF;
/*  91 */       int value = IntegerHelper.getInt(bytes[pos + 2], bytes[pos + 3], bytes[pos + 4], bytes[pos + 5]);
/*     */       
/*  93 */       Property p = new Property(id, ((val & 0x4000) != 0), ((val & 0x8000) != 0), value);
/*     */ 
/*     */ 
/*     */       
/*  97 */       pos += 6;
/*  98 */       this.properties.add(p);
/*     */     } 
/*     */     
/* 101 */     for (Iterator i = this.properties.iterator(); i.hasNext(); ) {
/*     */       
/* 103 */       Property p = i.next();
/* 104 */       if (p.complex) {
/*     */         
/* 106 */         p.stringValue = StringHelper.getUnicodeString(bytes, p.value / 2, pos);
/*     */         
/* 108 */         pos += p.value;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Opt() {
/* 115 */     super(EscherRecordType.OPT);
/* 116 */     this.properties = new ArrayList();
/* 117 */     setVersion(3);
/*     */   }
/*     */ 
/*     */   
/*     */   byte[] getData() {
/* 122 */     this.numProperties = this.properties.size();
/* 123 */     setInstance(this.numProperties);
/*     */     
/* 125 */     this.data = new byte[this.numProperties * 6];
/* 126 */     int pos = 0;
/*     */ 
/*     */     
/* 129 */     for (Iterator iterator1 = this.properties.iterator(); iterator1.hasNext(); ) {
/*     */       
/* 131 */       Property p = iterator1.next();
/* 132 */       int val = p.id & 0x3FFF;
/*     */       
/* 134 */       if (p.blipId)
/*     */       {
/* 136 */         val |= 0x4000;
/*     */       }
/*     */       
/* 139 */       if (p.complex)
/*     */       {
/* 141 */         val |= 0x8000;
/*     */       }
/*     */       
/* 144 */       IntegerHelper.getTwoBytes(val, this.data, pos);
/* 145 */       IntegerHelper.getFourBytes(p.value, this.data, pos + 2);
/* 146 */       pos += 6;
/*     */     } 
/*     */ 
/*     */     
/* 150 */     for (Iterator i = this.properties.iterator(); i.hasNext(); ) {
/*     */       
/* 152 */       Property p = i.next();
/*     */       
/* 154 */       if (p.complex && p.stringValue != null) {
/*     */         
/* 156 */         byte[] newData = new byte[this.data.length + p.stringValue.length() * 2];
/*     */         
/* 158 */         System.arraycopy(this.data, 0, newData, 0, this.data.length);
/* 159 */         StringHelper.getUnicodeBytes(p.stringValue, newData, this.data.length);
/* 160 */         this.data = newData;
/*     */       } 
/*     */     } 
/*     */     
/* 164 */     return setHeaderData(this.data);
/*     */   }
/*     */ 
/*     */   
/*     */   void addProperty(int id, boolean blip, boolean complex, int val) {
/* 169 */     Property p = new Property(id, blip, complex, val);
/* 170 */     this.properties.add(p);
/*     */   }
/*     */ 
/*     */   
/*     */   void addProperty(int id, boolean blip, boolean complex, int val, String s) {
/* 175 */     Property p = new Property(id, blip, complex, val, s);
/* 176 */     this.properties.add(p);
/*     */   }
/*     */ 
/*     */   
/*     */   Property getProperty(int id) {
/* 181 */     boolean found = false;
/* 182 */     Property p = null;
/* 183 */     for (Iterator i = this.properties.iterator(); i.hasNext() && !found; ) {
/*     */       
/* 185 */       p = i.next();
/* 186 */       if (p.id == id)
/*     */       {
/* 188 */         found = true;
/*     */       }
/*     */     } 
/* 191 */     return found ? p : null;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\Opt.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
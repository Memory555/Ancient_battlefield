/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClientAnchor
/*     */   extends EscherAtom
/*     */ {
/*  30 */   private static final Logger logger = Logger.getLogger(ClientAnchor.class);
/*     */   
/*     */   private byte[] data;
/*     */   
/*     */   private double x1;
/*     */   
/*     */   private double y1;
/*     */   private double x2;
/*     */   private double y2;
/*     */   
/*     */   public ClientAnchor(EscherRecordData erd) {
/*  41 */     super(erd);
/*  42 */     byte[] bytes = getBytes();
/*     */ 
/*     */     
/*  45 */     int x1Cell = IntegerHelper.getInt(bytes[2], bytes[3]);
/*  46 */     int x1Fraction = IntegerHelper.getInt(bytes[4], bytes[5]);
/*     */     
/*  48 */     this.x1 = x1Cell + x1Fraction / 1024.0D;
/*     */ 
/*     */     
/*  51 */     int y1Cell = IntegerHelper.getInt(bytes[6], bytes[7]);
/*  52 */     int y1Fraction = IntegerHelper.getInt(bytes[8], bytes[9]);
/*     */     
/*  54 */     this.y1 = y1Cell + y1Fraction / 256.0D;
/*     */ 
/*     */     
/*  57 */     int x2Cell = IntegerHelper.getInt(bytes[10], bytes[11]);
/*  58 */     int x2Fraction = IntegerHelper.getInt(bytes[12], bytes[13]);
/*     */     
/*  60 */     this.x2 = x2Cell + x2Fraction / 1024.0D;
/*     */ 
/*     */     
/*  63 */     int y2Cell = IntegerHelper.getInt(bytes[14], bytes[15]);
/*  64 */     int y2Fraction = IntegerHelper.getInt(bytes[16], bytes[17]);
/*     */     
/*  66 */     this.y2 = y2Cell + y2Fraction / 256.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public ClientAnchor(double x1, double y1, double x2, double y2) {
/*  71 */     super(EscherRecordType.CLIENT_ANCHOR);
/*  72 */     this.x1 = x1;
/*  73 */     this.y1 = y1;
/*  74 */     this.x2 = x2;
/*  75 */     this.y2 = y2;
/*     */   }
/*     */ 
/*     */   
/*     */   byte[] getData() {
/*  80 */     this.data = new byte[18];
/*  81 */     IntegerHelper.getTwoBytes(2, this.data, 0);
/*     */ 
/*     */     
/*  84 */     IntegerHelper.getTwoBytes((int)this.x1, this.data, 2);
/*     */ 
/*     */     
/*  87 */     int x1fraction = (int)((this.x1 - (int)this.x1) * 1024.0D);
/*  88 */     IntegerHelper.getTwoBytes(x1fraction, this.data, 4);
/*     */ 
/*     */     
/*  91 */     IntegerHelper.getTwoBytes((int)this.y1, this.data, 6);
/*     */ 
/*     */     
/*  94 */     int y1fraction = (int)((this.y1 - (int)this.y1) * 256.0D);
/*  95 */     IntegerHelper.getTwoBytes(y1fraction, this.data, 8);
/*     */ 
/*     */     
/*  98 */     IntegerHelper.getTwoBytes((int)this.x2, this.data, 10);
/*     */ 
/*     */     
/* 101 */     int x2fraction = (int)((this.x2 - (int)this.x2) * 1024.0D);
/* 102 */     IntegerHelper.getTwoBytes(x2fraction, this.data, 12);
/*     */ 
/*     */     
/* 105 */     IntegerHelper.getTwoBytes((int)this.y2, this.data, 14);
/*     */ 
/*     */     
/* 108 */     int y2fraction = (int)((this.y2 - (int)this.y2) * 256.0D);
/* 109 */     IntegerHelper.getTwoBytes(y2fraction, this.data, 16);
/*     */     
/* 111 */     return setHeaderData(this.data);
/*     */   }
/*     */ 
/*     */   
/*     */   double getX1() {
/* 116 */     return this.x1;
/*     */   }
/*     */ 
/*     */   
/*     */   double getY1() {
/* 121 */     return this.y1;
/*     */   }
/*     */ 
/*     */   
/*     */   double getX2() {
/* 126 */     return this.x2;
/*     */   }
/*     */ 
/*     */   
/*     */   double getY2() {
/* 131 */     return this.y2;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\ClientAnchor.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
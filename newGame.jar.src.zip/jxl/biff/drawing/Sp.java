/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ import common.Logger;
/*    */ import jxl.biff.IntegerHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Sp
/*    */   extends EscherAtom
/*    */ {
/* 30 */   private static Logger logger = Logger.getLogger(Sp.class);
/*    */ 
/*    */   
/*    */   private byte[] data;
/*    */ 
/*    */   
/*    */   private int shapeType;
/*    */   
/*    */   private int shapeId;
/*    */   
/*    */   private int persistenceFlags;
/*    */ 
/*    */   
/*    */   public Sp(EscherRecordData erd) {
/* 44 */     super(erd);
/* 45 */     this.shapeType = getInstance();
/* 46 */     byte[] bytes = getBytes();
/* 47 */     this.shapeId = IntegerHelper.getInt(bytes[0], bytes[1], bytes[2], bytes[3]);
/* 48 */     this.persistenceFlags = IntegerHelper.getInt(bytes[4], bytes[5], bytes[6], bytes[7]);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Sp(ShapeType st, int sid, int p) {
/* 61 */     super(EscherRecordType.SP);
/* 62 */     setVersion(2);
/* 63 */     this.shapeType = st.value;
/* 64 */     this.shapeId = sid;
/* 65 */     this.persistenceFlags = p;
/* 66 */     setInstance(this.shapeType);
/*    */   }
/*    */ 
/*    */   
/*    */   int getShapeId() {
/* 71 */     return this.shapeId;
/*    */   }
/*    */ 
/*    */   
/*    */   int getShapeType() {
/* 76 */     return this.shapeType;
/*    */   }
/*    */ 
/*    */   
/*    */   byte[] getData() {
/* 81 */     this.data = new byte[8];
/* 82 */     IntegerHelper.getFourBytes(this.shapeId, this.data, 0);
/* 83 */     IntegerHelper.getFourBytes(this.persistenceFlags, this.data, 4);
/* 84 */     return setHeaderData(this.data);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\Sp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
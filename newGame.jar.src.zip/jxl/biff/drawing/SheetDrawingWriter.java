/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SheetDrawingWriter
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(SheetDrawingWriter.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList drawings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean drawingsModified;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private Chart[] charts = new Chart[0];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings workbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDrawings(ArrayList dr, boolean mod) {
/*  81 */     this.drawings = dr;
/*  82 */     this.drawingsModified = mod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(File outputFile) throws IOException {
/*  95 */     if (this.drawings.size() == 0 && this.charts.length == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 101 */     boolean modified = this.drawingsModified;
/* 102 */     int numImages = this.drawings.size();
/*     */ 
/*     */     
/* 105 */     for (Iterator i = this.drawings.iterator(); i.hasNext() && !modified; ) {
/*     */       
/* 107 */       DrawingGroupObject d = i.next();
/* 108 */       if (d.getOrigin() != Origin.READ)
/*     */       {
/* 110 */         modified = true;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 116 */     if (numImages > 0 && !modified) {
/*     */       
/* 118 */       DrawingGroupObject d2 = this.drawings.get(0);
/* 119 */       if (!d2.isFirst())
/*     */       {
/* 121 */         modified = true;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 127 */     if (numImages == 0 && this.charts.length == 1 && this.charts[0].getMsoDrawingRecord() == null)
/*     */     {
/*     */ 
/*     */       
/* 131 */       modified = false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 136 */     if (!modified) {
/*     */       
/* 138 */       writeUnmodified(outputFile);
/*     */       
/*     */       return;
/*     */     } 
/* 142 */     Object[] spContainerData = new Object[numImages + this.charts.length];
/* 143 */     int length = 0;
/* 144 */     EscherContainer firstSpContainer = null;
/*     */     
/*     */     int j;
/*     */     
/* 148 */     for (j = 0; j < numImages; j++) {
/*     */       
/* 150 */       DrawingGroupObject drawing = this.drawings.get(j);
/*     */       
/* 152 */       EscherContainer spc = drawing.getSpContainer();
/* 153 */       byte[] data = spc.getData();
/* 154 */       spContainerData[j] = data;
/*     */       
/* 156 */       if (j == 0) {
/*     */         
/* 158 */         firstSpContainer = spc;
/*     */       }
/*     */       else {
/*     */         
/* 162 */         length += data.length;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 167 */     for (j = 0; j < this.charts.length; j++) {
/*     */       
/* 169 */       EscherContainer escherContainer = this.charts[j].getSpContainer();
/* 170 */       byte[] data = escherContainer.getBytes();
/* 171 */       data = escherContainer.setHeaderData(data);
/* 172 */       spContainerData[j + numImages] = data;
/*     */       
/* 174 */       if (j == 0 && numImages == 0) {
/*     */         
/* 176 */         firstSpContainer = escherContainer;
/*     */       }
/*     */       else {
/*     */         
/* 180 */         length += data.length;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 185 */     DgContainer dgContainer = new DgContainer();
/* 186 */     Dg dg = new Dg(numImages + this.charts.length);
/* 187 */     dgContainer.add(dg);
/*     */     
/* 189 */     SpgrContainer spgrContainer = new SpgrContainer();
/*     */     
/* 191 */     SpContainer spContainer = new SpContainer();
/* 192 */     Spgr spgr = new Spgr();
/* 193 */     spContainer.add(spgr);
/* 194 */     Sp sp = new Sp(ShapeType.MIN, 1024, 5);
/* 195 */     spContainer.add(sp);
/* 196 */     spgrContainer.add(spContainer);
/*     */     
/* 198 */     spgrContainer.add(firstSpContainer);
/*     */     
/* 200 */     dgContainer.add(spgrContainer);
/*     */     
/* 202 */     byte[] firstMsoData = dgContainer.getData();
/*     */ 
/*     */     
/* 205 */     int len = IntegerHelper.getInt(firstMsoData[4], firstMsoData[5], firstMsoData[6], firstMsoData[7]);
/*     */ 
/*     */ 
/*     */     
/* 209 */     IntegerHelper.getFourBytes(len + length, firstMsoData, 4);
/*     */ 
/*     */     
/* 212 */     len = IntegerHelper.getInt(firstMsoData[28], firstMsoData[29], firstMsoData[30], firstMsoData[31]);
/*     */ 
/*     */ 
/*     */     
/* 216 */     IntegerHelper.getFourBytes(len + length, firstMsoData, 28);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     if (numImages > 0 && ((DrawingGroupObject)this.drawings.get(0)).isFormObject()) {
/*     */ 
/*     */       
/* 226 */       byte[] msodata2 = new byte[firstMsoData.length - 8];
/* 227 */       System.arraycopy(firstMsoData, 0, msodata2, 0, msodata2.length);
/* 228 */       firstMsoData = msodata2;
/*     */     } 
/*     */     
/* 231 */     MsoDrawingRecord msoDrawingRecord = new MsoDrawingRecord(firstMsoData);
/* 232 */     outputFile.write((ByteData)msoDrawingRecord);
/*     */     
/* 234 */     if (numImages > 0) {
/*     */       
/* 236 */       DrawingGroupObject firstDrawing = this.drawings.get(0);
/* 237 */       firstDrawing.writeAdditionalRecords(outputFile);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 242 */       Chart chart = this.charts[0];
/* 243 */       ObjRecord objRecord = chart.getObjRecord();
/* 244 */       outputFile.write((ByteData)objRecord);
/* 245 */       outputFile.write(chart);
/*     */     } 
/*     */ 
/*     */     
/* 249 */     for (int k = 1; k < spContainerData.length; k++) {
/*     */       
/* 251 */       byte[] bytes = (byte[])spContainerData[k];
/*     */ 
/*     */ 
/*     */       
/* 255 */       if (k < numImages && ((DrawingGroupObject)this.drawings.get(k)).isFormObject()) {
/*     */ 
/*     */         
/* 258 */         byte[] bytes2 = new byte[bytes.length - 8];
/* 259 */         System.arraycopy(bytes, 0, bytes2, 0, bytes2.length);
/* 260 */         bytes = bytes2;
/*     */       } 
/*     */       
/* 263 */       msoDrawingRecord = new MsoDrawingRecord(bytes);
/* 264 */       outputFile.write((ByteData)msoDrawingRecord);
/*     */       
/* 266 */       if (k < numImages) {
/*     */ 
/*     */         
/* 269 */         DrawingGroupObject d = this.drawings.get(k);
/* 270 */         d.writeAdditionalRecords(outputFile);
/*     */       }
/*     */       else {
/*     */         
/* 274 */         Chart chart = this.charts[k - numImages];
/* 275 */         ObjRecord objRecord = chart.getObjRecord();
/* 276 */         outputFile.write((ByteData)objRecord);
/* 277 */         outputFile.write(chart);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 282 */     for (Iterator iterator1 = this.drawings.iterator(); iterator1.hasNext(); ) {
/*     */       
/* 284 */       DrawingGroupObject dgo2 = iterator1.next();
/* 285 */       dgo2.writeTailRecords(outputFile);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeUnmodified(File outputFile) throws IOException {
/* 297 */     if (this.charts.length == 0 && this.drawings.size() == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 302 */     if (this.charts.length == 0 && this.drawings.size() != 0) {
/*     */ 
/*     */       
/* 305 */       for (Iterator iterator2 = this.drawings.iterator(); iterator2.hasNext(); ) {
/*     */         
/* 307 */         DrawingGroupObject d = iterator2.next();
/* 308 */         outputFile.write((ByteData)d.getMsoDrawingRecord());
/* 309 */         d.writeAdditionalRecords(outputFile);
/*     */       } 
/*     */       
/* 312 */       for (Iterator iterator1 = this.drawings.iterator(); iterator1.hasNext(); ) {
/*     */         
/* 314 */         DrawingGroupObject d = iterator1.next();
/* 315 */         d.writeTailRecords(outputFile);
/*     */       } 
/*     */       return;
/*     */     } 
/* 319 */     if (this.drawings.size() == 0 && this.charts.length != 0) {
/*     */ 
/*     */       
/* 322 */       Chart curChart = null;
/* 323 */       for (int k = 0; k < this.charts.length; k++) {
/*     */         
/* 325 */         curChart = this.charts[k];
/* 326 */         if (curChart.getMsoDrawingRecord() != null)
/*     */         {
/* 328 */           outputFile.write((ByteData)curChart.getMsoDrawingRecord());
/*     */         }
/*     */         
/* 331 */         if (curChart.getObjRecord() != null)
/*     */         {
/* 333 */           outputFile.write((ByteData)curChart.getObjRecord());
/*     */         }
/*     */         
/* 336 */         outputFile.write(curChart);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 346 */     int numDrawings = this.drawings.size();
/* 347 */     int length = 0;
/* 348 */     EscherContainer[] spContainers = new EscherContainer[numDrawings + this.charts.length];
/*     */     
/* 350 */     boolean[] isFormObject = new boolean[numDrawings + this.charts.length];
/*     */     int i;
/* 352 */     for (i = 0; i < numDrawings; i++) {
/*     */       
/* 354 */       DrawingGroupObject d = this.drawings.get(i);
/* 355 */       spContainers[i] = d.getSpContainer();
/*     */       
/* 357 */       if (i > 0)
/*     */       {
/* 359 */         length += spContainers[i].getLength();
/*     */       }
/*     */       
/* 362 */       if (d.isFormObject())
/*     */       {
/* 364 */         isFormObject[i] = true;
/*     */       }
/*     */     } 
/*     */     
/* 368 */     for (i = 0; i < this.charts.length; i++) {
/*     */       
/* 370 */       spContainers[i + numDrawings] = this.charts[i].getSpContainer();
/* 371 */       length += spContainers[i + numDrawings].getLength();
/*     */     } 
/*     */ 
/*     */     
/* 375 */     DgContainer dgContainer = new DgContainer();
/* 376 */     Dg dg = new Dg(numDrawings + this.charts.length);
/* 377 */     dgContainer.add(dg);
/*     */     
/* 379 */     SpgrContainer spgrContainer = new SpgrContainer();
/*     */     
/* 381 */     SpContainer spContainer = new SpContainer();
/* 382 */     Spgr spgr = new Spgr();
/* 383 */     spContainer.add(spgr);
/* 384 */     Sp sp = new Sp(ShapeType.MIN, 1024, 5);
/* 385 */     spContainer.add(sp);
/* 386 */     spgrContainer.add(spContainer);
/*     */     
/* 388 */     spgrContainer.add(spContainers[0]);
/*     */     
/* 390 */     dgContainer.add(spgrContainer);
/*     */     
/* 392 */     byte[] firstMsoData = dgContainer.getData();
/*     */ 
/*     */     
/* 395 */     int len = IntegerHelper.getInt(firstMsoData[4], firstMsoData[5], firstMsoData[6], firstMsoData[7]);
/*     */ 
/*     */ 
/*     */     
/* 399 */     IntegerHelper.getFourBytes(len + length, firstMsoData, 4);
/*     */ 
/*     */     
/* 402 */     len = IntegerHelper.getInt(firstMsoData[28], firstMsoData[29], firstMsoData[30], firstMsoData[31]);
/*     */ 
/*     */ 
/*     */     
/* 406 */     IntegerHelper.getFourBytes(len + length, firstMsoData, 28);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 412 */     if (isFormObject[0] == true) {
/*     */       
/* 414 */       byte[] cbytes = new byte[firstMsoData.length - 8];
/* 415 */       System.arraycopy(firstMsoData, 0, cbytes, 0, cbytes.length);
/* 416 */       firstMsoData = cbytes;
/*     */     } 
/*     */ 
/*     */     
/* 420 */     MsoDrawingRecord msoDrawingRecord = new MsoDrawingRecord(firstMsoData);
/* 421 */     outputFile.write((ByteData)msoDrawingRecord);
/*     */     
/* 423 */     DrawingGroupObject dgo = this.drawings.get(0);
/* 424 */     dgo.writeAdditionalRecords(outputFile);
/*     */ 
/*     */     
/* 427 */     for (int j = 1; j < spContainers.length; j++) {
/*     */       
/* 429 */       byte[] bytes = spContainers[j].getBytes();
/*     */ 
/*     */       
/* 432 */       byte[] bytes2 = spContainers[j].setHeaderData(bytes);
/*     */ 
/*     */ 
/*     */       
/* 436 */       if (isFormObject[j] == true) {
/*     */         
/* 438 */         byte[] cbytes = new byte[bytes2.length - 8];
/* 439 */         System.arraycopy(bytes2, 0, cbytes, 0, cbytes.length);
/* 440 */         bytes2 = cbytes;
/*     */       } 
/*     */       
/* 443 */       msoDrawingRecord = new MsoDrawingRecord(bytes2);
/* 444 */       outputFile.write((ByteData)msoDrawingRecord);
/*     */       
/* 446 */       if (j < numDrawings) {
/*     */         
/* 448 */         dgo = this.drawings.get(j);
/* 449 */         dgo.writeAdditionalRecords(outputFile);
/*     */       }
/*     */       else {
/*     */         
/* 453 */         Chart chart = this.charts[j - numDrawings];
/* 454 */         ObjRecord objRecord = chart.getObjRecord();
/* 455 */         outputFile.write((ByteData)objRecord);
/* 456 */         outputFile.write(chart);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 461 */     for (Iterator iterator = this.drawings.iterator(); iterator.hasNext(); ) {
/*     */       
/* 463 */       DrawingGroupObject dgo2 = iterator.next();
/* 464 */       dgo2.writeTailRecords(outputFile);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCharts(Chart[] ch) {
/* 475 */     this.charts = ch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Chart[] getCharts() {
/* 485 */     return this.charts;
/*     */   }
/*     */   
/*     */   public SheetDrawingWriter(WorkbookSettings ws) {}
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\SheetDrawingWriter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
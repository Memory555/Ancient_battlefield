/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DrawingData
/*     */   implements EscherStream
/*     */ {
/*  34 */   private static Logger logger = Logger.getLogger(DrawingData.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private int numDrawings = 0;
/*  62 */   private byte[] drawingData = null;
/*     */ 
/*     */   
/*     */   private boolean initialized = false;
/*     */   
/*     */   private EscherRecord[] spgrChildren;
/*     */ 
/*     */   
/*     */   private void initialize() {
/*  71 */     EscherRecordData er = new EscherRecordData(this, 0);
/*  72 */     Assert.verify(er.isContainer());
/*     */     
/*  74 */     EscherContainer dgContainer = new EscherContainer(er);
/*  75 */     EscherRecord[] children = dgContainer.getChildren();
/*     */     
/*  77 */     children = dgContainer.getChildren();
/*     */ 
/*     */     
/*  80 */     EscherContainer spgrContainer = null;
/*     */     
/*  82 */     for (int i = 0; i < children.length && spgrContainer == null; i++) {
/*     */       
/*  84 */       EscherRecord child = children[i];
/*  85 */       if (child.getType() == EscherRecordType.SPGR_CONTAINER)
/*     */       {
/*  87 */         spgrContainer = (EscherContainer)child;
/*     */       }
/*     */     } 
/*  90 */     Assert.verify((spgrContainer != null));
/*     */     
/*  92 */     this.spgrChildren = spgrContainer.getChildren();
/*  93 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addData(byte[] data) {
/* 103 */     addRawData(data);
/* 104 */     this.numDrawings++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addRawData(byte[] data) {
/* 114 */     if (this.drawingData == null) {
/*     */       
/* 116 */       this.drawingData = data;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 121 */     byte[] newArray = new byte[this.drawingData.length + data.length];
/* 122 */     System.arraycopy(this.drawingData, 0, newArray, 0, this.drawingData.length);
/* 123 */     System.arraycopy(data, 0, newArray, this.drawingData.length, data.length);
/* 124 */     this.drawingData = newArray;
/*     */ 
/*     */     
/* 127 */     this.initialized = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int getNumDrawings() {
/* 137 */     return this.numDrawings;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EscherContainer getSpContainer(int drawingNum) {
/* 148 */     if (!this.initialized)
/*     */     {
/* 150 */       initialize();
/*     */     }
/*     */     
/* 153 */     EscherContainer spContainer = (EscherContainer)this.spgrChildren[drawingNum + 1];
/*     */     
/* 155 */     Assert.verify((spContainer != null));
/*     */     
/* 157 */     return spContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 167 */     return this.drawingData;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\DrawingData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
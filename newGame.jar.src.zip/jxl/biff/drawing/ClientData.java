/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ import common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ClientData
/*    */   extends EscherAtom
/*    */ {
/* 34 */   private static Logger logger = Logger.getLogger(ClientData.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private byte[] data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClientData(EscherRecordData erd) {
/* 48 */     super(erd);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClientData() {
/* 56 */     super(EscherRecordType.CLIENT_DATA);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getData() {
/* 66 */     this.data = new byte[0];
/* 67 */     return setHeaderData(this.data);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\ClientData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
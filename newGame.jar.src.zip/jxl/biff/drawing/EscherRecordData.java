/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class EscherRecordData
/*     */ {
/*     */   private int pos;
/*     */   private int instance;
/*     */   private int version;
/*     */   private int recordId;
/*     */   private int length;
/*     */   private int streamLength;
/*     */   private boolean container;
/*     */   private EscherRecordType type;
/*     */   private EscherStream escherStream;
/*     */   
/*     */   public EscherRecordData(EscherStream dg, int p) {
/*  81 */     this.escherStream = dg;
/*  82 */     this.pos = p;
/*  83 */     byte[] data = this.escherStream.getData();
/*     */     
/*  85 */     this.streamLength = data.length;
/*     */ 
/*     */     
/*  88 */     int value = IntegerHelper.getInt(data[this.pos], data[this.pos + 1]);
/*     */ 
/*     */     
/*  91 */     this.instance = (value & 0xFFF0) >> 4;
/*     */ 
/*     */     
/*  94 */     this.version = value & 0xF;
/*     */ 
/*     */     
/*  97 */     this.recordId = IntegerHelper.getInt(data[this.pos + 2], data[this.pos + 3]);
/*     */ 
/*     */     
/* 100 */     this.length = IntegerHelper.getInt(data[this.pos + 4], data[this.pos + 5], data[this.pos + 6], data[this.pos + 7]);
/*     */ 
/*     */     
/* 103 */     if (this.version == 15) {
/*     */       
/* 105 */       this.container = true;
/*     */     }
/*     */     else {
/*     */       
/* 109 */       this.container = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EscherRecordData(EscherRecordType t) {
/* 120 */     this.type = t;
/* 121 */     this.recordId = this.type.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isContainer() {
/* 131 */     return this.container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 141 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRecordId() {
/* 151 */     return this.recordId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EscherStream getDrawingGroup() {
/* 161 */     return this.escherStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getPos() {
/* 171 */     return this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EscherRecordType getType() {
/* 179 */     if (this.type == null)
/*     */     {
/* 181 */       this.type = EscherRecordType.getType(this.recordId);
/*     */     }
/*     */     
/* 184 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getInstance() {
/* 194 */     return this.instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setContainer(boolean c) {
/* 205 */     this.container = c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setInstance(int inst) {
/* 215 */     this.instance = inst;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setLength(int l) {
/* 225 */     this.length = l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setVersion(int v) {
/* 235 */     this.version = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] setHeaderData(byte[] d) {
/* 247 */     byte[] data = new byte[d.length + 8];
/* 248 */     System.arraycopy(d, 0, data, 8, d.length);
/*     */     
/* 250 */     if (this.container)
/*     */     {
/* 252 */       this.version = 15;
/*     */     }
/*     */ 
/*     */     
/* 256 */     int value = this.instance << 4;
/* 257 */     value |= this.version;
/* 258 */     IntegerHelper.getTwoBytes(value, data, 0);
/*     */ 
/*     */     
/* 261 */     IntegerHelper.getTwoBytes(this.recordId, data, 2);
/*     */ 
/*     */     
/* 264 */     IntegerHelper.getFourBytes(d.length, data, 4);
/*     */     
/* 266 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EscherStream getEscherStream() {
/* 276 */     return this.escherStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 286 */     byte[] d = new byte[this.length];
/* 287 */     System.arraycopy(this.escherStream.getData(), this.pos + 8, d, 0, this.length);
/* 288 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getStreamLength() {
/* 298 */     return this.streamLength;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\EscherRecordData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
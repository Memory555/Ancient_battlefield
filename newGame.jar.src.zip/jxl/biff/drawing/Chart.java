/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.biff.IndexMapping;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.read.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Chart
/*     */   implements ByteData, EscherStream
/*     */ {
/*  41 */   private static final Logger logger = Logger.getLogger(Chart.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MsoDrawingRecord msoDrawingRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjRecord objRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int startpos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int endpos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File file;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DrawingData drawingData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int drawingNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings workbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Chart(MsoDrawingRecord mso, ObjRecord obj, DrawingData dd, int sp, int ep, File f, WorkbookSettings ws) {
/* 107 */     this.msoDrawingRecord = mso;
/* 108 */     this.objRecord = obj;
/* 109 */     this.startpos = sp;
/* 110 */     this.endpos = ep;
/* 111 */     this.file = f;
/* 112 */     this.workbookSettings = ws;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     if (this.msoDrawingRecord != null) {
/*     */       
/* 119 */       this.drawingData = dd;
/* 120 */       this.drawingData.addData(this.msoDrawingRecord.getRecord().getData());
/* 121 */       this.drawingNumber = this.drawingData.getNumDrawings() - 1;
/*     */     } 
/*     */     
/* 124 */     this.initialized = false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 129 */     Assert.verify(((mso != null && obj != null) || (mso == null && obj == null)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/* 140 */     if (!this.initialized)
/*     */     {
/* 142 */       initialize();
/*     */     }
/*     */     
/* 145 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 155 */     return this.msoDrawingRecord.getRecord().getData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 163 */     this.data = this.file.read(this.startpos, this.endpos - this.startpos);
/* 164 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rationalize(IndexMapping xfMapping, IndexMapping fontMapping, IndexMapping formatMapping) {
/* 177 */     if (!this.initialized)
/*     */     {
/* 179 */       initialize();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     int pos = 0;
/* 186 */     int code = 0;
/* 187 */     int length = 0;
/* 188 */     Type type = null;
/* 189 */     while (pos < this.data.length) {
/*     */       
/* 191 */       code = IntegerHelper.getInt(this.data[pos], this.data[pos + 1]);
/* 192 */       length = IntegerHelper.getInt(this.data[pos + 2], this.data[pos + 3]);
/*     */       
/* 194 */       type = Type.getType(code);
/*     */       
/* 196 */       if (type == Type.FONTX) {
/*     */         
/* 198 */         int fontind = IntegerHelper.getInt(this.data[pos + 4], this.data[pos + 5]);
/* 199 */         IntegerHelper.getTwoBytes(fontMapping.getNewIndex(fontind), this.data, pos + 4);
/*     */       
/*     */       }
/* 202 */       else if (type == Type.FBI) {
/*     */         
/* 204 */         int fontind = IntegerHelper.getInt(this.data[pos + 12], this.data[pos + 13]);
/* 205 */         IntegerHelper.getTwoBytes(fontMapping.getNewIndex(fontind), this.data, pos + 12);
/*     */       
/*     */       }
/* 208 */       else if (type == Type.IFMT) {
/*     */         
/* 210 */         int formind = IntegerHelper.getInt(this.data[pos + 4], this.data[pos + 5]);
/* 211 */         IntegerHelper.getTwoBytes(formatMapping.getNewIndex(formind), this.data, pos + 4);
/*     */       
/*     */       }
/* 214 */       else if (type == Type.ALRUNS) {
/*     */         
/* 216 */         int numRuns = IntegerHelper.getInt(this.data[pos + 4], this.data[pos + 5]);
/* 217 */         int fontPos = pos + 6;
/* 218 */         for (int i = 0; i < numRuns; i++) {
/*     */           
/* 220 */           int fontind = IntegerHelper.getInt(this.data[fontPos + 2], this.data[fontPos + 3]);
/* 221 */           IntegerHelper.getTwoBytes(fontMapping.getNewIndex(fontind), this.data, fontPos + 2);
/*     */           
/* 223 */           fontPos += 4;
/*     */         } 
/*     */       } 
/*     */       
/* 227 */       pos += length + 4;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   EscherContainer getSpContainer() {
/* 238 */     EscherContainer spContainer = this.drawingData.getSpContainer(this.drawingNumber);
/*     */     
/* 240 */     return spContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MsoDrawingRecord getMsoDrawingRecord() {
/* 250 */     return this.msoDrawingRecord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ObjRecord getObjRecord() {
/* 260 */     return this.objRecord;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\Chart.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Spgr
/*    */   extends EscherAtom
/*    */ {
/*    */   private byte[] data;
/*    */   
/*    */   public Spgr(EscherRecordData erd) {
/* 30 */     super(erd);
/*    */   }
/*    */ 
/*    */   
/*    */   public Spgr() {
/* 35 */     super(EscherRecordType.SPGR);
/* 36 */     setVersion(1);
/* 37 */     this.data = new byte[16];
/*    */   }
/*    */ 
/*    */   
/*    */   byte[] getData() {
/* 42 */     return setHeaderData(this.data);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\Spgr.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
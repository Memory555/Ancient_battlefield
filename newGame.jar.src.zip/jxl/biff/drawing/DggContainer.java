/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DggContainer
/*    */   extends EscherContainer
/*    */ {
/*    */   public DggContainer() {
/* 26 */     super(EscherRecordType.DGG_CONTAINER);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\DggContainer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
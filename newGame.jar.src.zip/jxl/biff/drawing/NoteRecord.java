/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.read.biff.Record;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NoteRecord
/*     */   extends WritableRecordData
/*     */ {
/*  37 */   private static Logger logger = Logger.getLogger(NoteRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int objectId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoteRecord(Record t) {
/*  66 */     super(t);
/*  67 */     this.data = getRecord().getData();
/*  68 */     this.row = IntegerHelper.getInt(this.data[0], this.data[1]);
/*  69 */     this.column = IntegerHelper.getInt(this.data[2], this.data[3]);
/*  70 */     this.objectId = IntegerHelper.getInt(this.data[6], this.data[7]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoteRecord(byte[] d) {
/*  80 */     super(Type.NOTE);
/*  81 */     this.data = d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoteRecord(int c, int r, int id) {
/*  89 */     super(Type.NOTE);
/*  90 */     this.row = r;
/*  91 */     this.column = c;
/*  92 */     this.objectId = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 102 */     if (this.data != null)
/*     */     {
/* 104 */       return this.data;
/*     */     }
/*     */     
/* 107 */     String author = "";
/* 108 */     this.data = new byte[8 + author.length() + 4];
/*     */ 
/*     */     
/* 111 */     IntegerHelper.getTwoBytes(this.row, this.data, 0);
/*     */ 
/*     */     
/* 114 */     IntegerHelper.getTwoBytes(this.column, this.data, 2);
/*     */ 
/*     */     
/* 117 */     IntegerHelper.getTwoBytes(this.objectId, this.data, 6);
/*     */ 
/*     */     
/* 120 */     IntegerHelper.getTwoBytes(author.length(), this.data, 8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getRow() {
/* 135 */     return this.row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getColumn() {
/* 143 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getObjectId() {
/* 151 */     return this.objectId;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\NoteRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Assert;
/*     */ import java.io.IOException;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BlipStoreEntry
/*     */   extends EscherAtom
/*     */ {
/*     */   private BlipType type;
/*     */   private byte[] data;
/*     */   private int imageDataLength;
/*     */   private int referenceCount;
/*     */   private boolean write;
/*     */   private static final int IMAGE_DATA_OFFSET = 61;
/*     */   
/*     */   public BlipStoreEntry(EscherRecordData erd) {
/*  71 */     super(erd);
/*  72 */     this.type = BlipType.getType(getInstance());
/*  73 */     this.write = false;
/*  74 */     byte[] bytes = getBytes();
/*  75 */     this.referenceCount = IntegerHelper.getInt(bytes[24], bytes[25], bytes[26], bytes[27]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlipStoreEntry(Drawing d) throws IOException {
/*  88 */     super(EscherRecordType.BSE);
/*  89 */     this.type = BlipType.PNG;
/*  90 */     setVersion(2);
/*  91 */     setInstance(this.type.getValue());
/*     */     
/*  93 */     byte[] imageData = d.getImageBytes();
/*  94 */     this.imageDataLength = imageData.length;
/*  95 */     this.data = new byte[this.imageDataLength + 61];
/*  96 */     System.arraycopy(imageData, 0, this.data, 61, this.imageDataLength);
/*  97 */     this.referenceCount = d.getReferenceCount();
/*  98 */     this.write = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BlipType getBlipType() {
/* 108 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 118 */     if (this.write) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 123 */       this.data[0] = (byte)this.type.getValue();
/*     */ 
/*     */       
/* 126 */       this.data[1] = (byte)this.type.getValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 135 */       IntegerHelper.getFourBytes(this.imageDataLength + 8 + 17, this.data, 20);
/*     */ 
/*     */       
/* 138 */       IntegerHelper.getFourBytes(this.referenceCount, this.data, 24);
/*     */ 
/*     */       
/* 141 */       IntegerHelper.getFourBytes(0, this.data, 28);
/*     */ 
/*     */       
/* 144 */       this.data[32] = 0;
/*     */ 
/*     */       
/* 147 */       this.data[33] = 0;
/*     */ 
/*     */       
/* 150 */       this.data[34] = 126;
/* 151 */       this.data[35] = 1;
/*     */ 
/*     */       
/* 154 */       this.data[36] = 0;
/* 155 */       this.data[37] = 110;
/*     */ 
/*     */       
/* 158 */       IntegerHelper.getTwoBytes(61470, this.data, 38);
/*     */ 
/*     */ 
/*     */       
/* 162 */       IntegerHelper.getFourBytes(this.imageDataLength + 17, this.data, 40);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 170 */       this.data = getBytes();
/*     */     } 
/*     */     
/* 173 */     return setHeaderData(this.data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dereference() {
/* 182 */     this.referenceCount--;
/* 183 */     Assert.verify((this.referenceCount >= 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getReferenceCount() {
/* 193 */     return this.referenceCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getImageData() {
/* 203 */     byte[] allData = getBytes();
/* 204 */     byte[] imageData = new byte[allData.length - 61];
/* 205 */     System.arraycopy(allData, 61, imageData, 0, imageData.length);
/*     */     
/* 207 */     return imageData;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\BlipStoreEntry.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
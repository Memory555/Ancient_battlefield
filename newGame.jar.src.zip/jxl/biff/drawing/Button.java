/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.biff.ContinueRecord;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Button
/*     */   implements DrawingGroupObject
/*     */ {
/*  46 */   private static Logger logger = Logger.getLogger(Button.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer readSpContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer spContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MsoDrawingRecord msoDrawingRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjRecord objRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int objectId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int blipId;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int shapeId;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double width;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double height;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int referenceCount;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer escherData;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Origin origin;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DrawingGroup drawingGroup;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DrawingData drawingData;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ShapeType type;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int drawingNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MsoDrawingRecord mso;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TextObjectRecord txo;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ContinueRecord text;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ContinueRecord formatting;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String commentText;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings workbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Button(MsoDrawingRecord mso, ObjRecord obj, DrawingData dd, DrawingGroup dg, WorkbookSettings ws) {
/* 185 */     this.drawingGroup = dg;
/* 186 */     this.msoDrawingRecord = mso;
/* 187 */     this.drawingData = dd;
/* 188 */     this.objRecord = obj;
/* 189 */     this.initialized = false;
/* 190 */     this.workbookSettings = ws;
/* 191 */     this.origin = Origin.READ;
/* 192 */     this.drawingData.addData(this.msoDrawingRecord.getData());
/* 193 */     this.drawingNumber = this.drawingData.getNumDrawings() - 1;
/* 194 */     this.drawingGroup.addDrawing(this);
/*     */     
/* 196 */     Assert.verify((mso != null && obj != null));
/*     */     
/* 198 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Button(DrawingGroupObject dgo, DrawingGroup dg, WorkbookSettings ws) {
/* 210 */     Button d = (Button)dgo;
/* 211 */     Assert.verify((d.origin == Origin.READ));
/* 212 */     this.msoDrawingRecord = d.msoDrawingRecord;
/* 213 */     this.objRecord = d.objRecord;
/* 214 */     this.initialized = false;
/* 215 */     this.origin = Origin.READ;
/* 216 */     this.drawingData = d.drawingData;
/* 217 */     this.drawingGroup = dg;
/* 218 */     this.drawingNumber = d.drawingNumber;
/* 219 */     this.drawingGroup.addDrawing(this);
/* 220 */     this.mso = d.mso;
/* 221 */     this.txo = d.txo;
/* 222 */     this.text = d.text;
/* 223 */     this.formatting = d.formatting;
/* 224 */     this.workbookSettings = ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 254 */     this.readSpContainer = this.drawingData.getSpContainer(this.drawingNumber);
/* 255 */     Assert.verify((this.readSpContainer != null));
/*     */     
/* 257 */     EscherRecord[] children = this.readSpContainer.getChildren();
/*     */     
/* 259 */     Sp sp = (Sp)this.readSpContainer.getChildren()[0];
/* 260 */     this.objectId = this.objRecord.getObjectId();
/* 261 */     this.shapeId = sp.getShapeId();
/* 262 */     this.type = ShapeType.getType(sp.getShapeType());
/*     */     
/* 264 */     if (this.type == ShapeType.UNKNOWN)
/*     */     {
/* 266 */       logger.warn("Unknown shape type");
/*     */     }
/*     */     
/* 269 */     Opt opt = (Opt)this.readSpContainer.getChildren()[1];
/*     */     
/* 271 */     ClientAnchor clientAnchor = null;
/* 272 */     for (int i = 0; i < children.length && clientAnchor == null; i++) {
/*     */       
/* 274 */       if (children[i].getType() == EscherRecordType.CLIENT_ANCHOR)
/*     */       {
/* 276 */         clientAnchor = (ClientAnchor)children[i];
/*     */       }
/*     */     } 
/*     */     
/* 280 */     if (clientAnchor == null) {
/*     */       
/* 282 */       logger.warn("Client anchor not found");
/*     */     }
/*     */     else {
/*     */       
/* 286 */       this.column = (int)clientAnchor.getX1() - 1;
/* 287 */       this.row = (int)clientAnchor.getY1() + 1;
/*     */     } 
/*     */     
/* 290 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setObjectId(int objid, int bip, int sid) {
/* 304 */     this.objectId = objid;
/* 305 */     this.blipId = bip;
/* 306 */     this.shapeId = sid;
/*     */     
/* 308 */     if (this.origin == Origin.READ)
/*     */     {
/* 310 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getObjectId() {
/* 321 */     if (!this.initialized)
/*     */     {
/* 323 */       initialize();
/*     */     }
/*     */     
/* 326 */     return this.objectId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getShapeId() {
/* 336 */     if (!this.initialized)
/*     */     {
/* 338 */       initialize();
/*     */     }
/*     */     
/* 341 */     return this.shapeId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getBlipId() {
/* 351 */     if (!this.initialized)
/*     */     {
/* 353 */       initialize();
/*     */     }
/*     */     
/* 356 */     return this.blipId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MsoDrawingRecord getMsoDrawingRecord() {
/* 366 */     return this.msoDrawingRecord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EscherContainer getSpContainer() {
/* 376 */     if (!this.initialized)
/*     */     {
/* 378 */       initialize();
/*     */     }
/*     */     
/* 381 */     if (this.origin == Origin.READ)
/*     */     {
/* 383 */       return getReadSpContainer();
/*     */     }
/*     */     
/* 386 */     Assert.verify(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 415 */     return this.spContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDrawingGroup(DrawingGroup dg) {
/* 426 */     this.drawingGroup = dg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DrawingGroup getDrawingGroup() {
/* 436 */     return this.drawingGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Origin getOrigin() {
/* 446 */     return this.origin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getReferenceCount() {
/* 456 */     return this.referenceCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReferenceCount(int r) {
/* 466 */     this.referenceCount = r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getX() {
/* 476 */     if (!this.initialized)
/*     */     {
/* 478 */       initialize();
/*     */     }
/* 480 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setX(double x) {
/* 491 */     if (this.origin == Origin.READ) {
/*     */       
/* 493 */       if (!this.initialized)
/*     */       {
/* 495 */         initialize();
/*     */       }
/* 497 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 500 */     this.column = (int)x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getY() {
/* 510 */     if (!this.initialized)
/*     */     {
/* 512 */       initialize();
/*     */     }
/*     */     
/* 515 */     return this.row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setY(double y) {
/* 525 */     if (this.origin == Origin.READ) {
/*     */       
/* 527 */       if (!this.initialized)
/*     */       {
/* 529 */         initialize();
/*     */       }
/* 531 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 534 */     this.row = (int)y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getWidth() {
/* 545 */     if (!this.initialized)
/*     */     {
/* 547 */       initialize();
/*     */     }
/*     */     
/* 550 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidth(double w) {
/* 560 */     if (this.origin == Origin.READ) {
/*     */       
/* 562 */       if (!this.initialized)
/*     */       {
/* 564 */         initialize();
/*     */       }
/* 566 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 569 */     this.width = w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getHeight() {
/* 579 */     if (!this.initialized)
/*     */     {
/* 581 */       initialize();
/*     */     }
/*     */     
/* 584 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeight(double h) {
/* 594 */     if (this.origin == Origin.READ) {
/*     */       
/* 596 */       if (!this.initialized)
/*     */       {
/* 598 */         initialize();
/*     */       }
/* 600 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 603 */     this.height = h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer getReadSpContainer() {
/* 614 */     if (!this.initialized)
/*     */     {
/* 616 */       initialize();
/*     */     }
/*     */     
/* 619 */     return this.readSpContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getImageData() {
/* 629 */     Assert.verify((this.origin == Origin.READ || this.origin == Origin.READ_WRITE));
/*     */     
/* 631 */     if (!this.initialized)
/*     */     {
/* 633 */       initialize();
/*     */     }
/*     */     
/* 636 */     return this.drawingGroup.getImageData(this.blipId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShapeType getType() {
/* 646 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTextObject(TextObjectRecord t) {
/* 654 */     this.txo = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(ContinueRecord t) {
/* 662 */     this.text = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormatting(ContinueRecord t) {
/* 670 */     this.formatting = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getImageBytes() {
/* 680 */     Assert.verify(false);
/* 681 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImageFilePath() {
/* 693 */     Assert.verify(false);
/* 694 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void addMso(MsoDrawingRecord d) {
/* 699 */     this.mso = d;
/* 700 */     this.drawingData.addRawData(this.mso.getData());
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeAdditionalRecords(File outputFile) throws IOException {
/* 705 */     if (this.origin == Origin.READ) {
/*     */       
/* 707 */       outputFile.write((ByteData)this.objRecord);
/*     */       
/* 709 */       if (this.mso != null)
/*     */       {
/* 711 */         outputFile.write((ByteData)this.mso);
/*     */       }
/* 713 */       outputFile.write((ByteData)this.txo);
/* 714 */       outputFile.write((ByteData)this.text);
/* 715 */       if (this.formatting != null)
/*     */       {
/* 717 */         outputFile.write((ByteData)this.formatting);
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 722 */     Assert.verify(false);
/*     */ 
/*     */     
/* 725 */     ObjRecord objRecord = new ObjRecord(this.objectId, ObjRecord.EXCELNOTE);
/*     */ 
/*     */     
/* 728 */     outputFile.write((ByteData)objRecord);
/*     */ 
/*     */ 
/*     */     
/* 732 */     ClientTextBox textBox = new ClientTextBox();
/* 733 */     MsoDrawingRecord msod = new MsoDrawingRecord(textBox.getData());
/* 734 */     outputFile.write((ByteData)msod);
/*     */     
/* 736 */     TextObjectRecord txo = new TextObjectRecord(getText());
/* 737 */     outputFile.write((ByteData)txo);
/*     */ 
/*     */     
/* 740 */     byte[] textData = new byte[this.commentText.length() * 2 + 1];
/* 741 */     textData[0] = 1;
/* 742 */     StringHelper.getUnicodeBytes(this.commentText, textData, 1);
/*     */     
/* 744 */     ContinueRecord textContinue = new ContinueRecord(textData);
/* 745 */     outputFile.write((ByteData)textContinue);
/*     */ 
/*     */ 
/*     */     
/* 749 */     byte[] frData = new byte[16];
/*     */ 
/*     */     
/* 752 */     IntegerHelper.getTwoBytes(0, frData, 0);
/* 753 */     IntegerHelper.getTwoBytes(0, frData, 2);
/*     */     
/* 755 */     IntegerHelper.getTwoBytes(this.commentText.length(), frData, 8);
/* 756 */     IntegerHelper.getTwoBytes(0, frData, 10);
/*     */     
/* 758 */     ContinueRecord frContinue = new ContinueRecord(frData);
/* 759 */     outputFile.write((ByteData)frContinue);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTailRecords(File outputFile) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRow() {
/* 776 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 784 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 792 */     if (this.commentText == null) {
/*     */       
/* 794 */       Assert.verify((this.text != null));
/*     */       
/* 796 */       byte[] td = this.text.getData();
/* 797 */       if (td[0] == 0) {
/*     */         
/* 799 */         this.commentText = StringHelper.getString(td, td.length - 1, 1, this.workbookSettings);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 804 */         this.commentText = StringHelper.getUnicodeString(td, (td.length - 1) / 2, 1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 809 */     return this.commentText;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 817 */     return this.commentText.hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setButtonText(String t) {
/* 827 */     this.commentText = t;
/*     */     
/* 829 */     if (this.origin == Origin.READ)
/*     */     {
/* 831 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFirst() {
/* 844 */     return this.mso.isFirst();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFormObject() {
/* 856 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\Button.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
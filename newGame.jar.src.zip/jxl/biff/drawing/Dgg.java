/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.util.ArrayList;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Dgg
/*     */   extends EscherAtom
/*     */ {
/*  34 */   private static Logger logger = Logger.getLogger(Dgg.class);
/*     */   
/*     */   private byte[] data;
/*     */   
/*     */   private int numClusters;
/*     */   
/*     */   private int maxShapeId;
/*     */   private int shapesSaved;
/*     */   private int drawingsSaved;
/*     */   private ArrayList clusters;
/*     */   
/*     */   static final class Cluster
/*     */   {
/*     */     int drawingGroupId;
/*     */     int shapeIdsUsed;
/*     */     
/*     */     Cluster(int dgId, int sids) {
/*  51 */       this.drawingGroupId = dgId;
/*  52 */       this.shapeIdsUsed = sids;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Dgg(EscherRecordData erd) {
/*  58 */     super(erd);
/*  59 */     this.clusters = new ArrayList();
/*  60 */     byte[] bytes = getBytes();
/*  61 */     this.maxShapeId = IntegerHelper.getInt(bytes[0], bytes[1], bytes[2], bytes[3]);
/*     */     
/*  63 */     this.numClusters = IntegerHelper.getInt(bytes[4], bytes[5], bytes[6], bytes[7]);
/*     */     
/*  65 */     this.shapesSaved = IntegerHelper.getInt(bytes[8], bytes[9], bytes[10], bytes[11]);
/*     */     
/*  67 */     this.drawingsSaved = IntegerHelper.getInt(bytes[12], bytes[13], bytes[14], bytes[15]);
/*     */ 
/*     */     
/*  70 */     int pos = 16;
/*  71 */     for (int i = 0; i < this.numClusters; i++) {
/*     */       
/*  73 */       int dgId = IntegerHelper.getInt(bytes[pos], bytes[pos + 1]);
/*  74 */       int sids = IntegerHelper.getInt(bytes[pos + 2], bytes[pos + 3]);
/*  75 */       Cluster c = new Cluster(dgId, sids);
/*  76 */       this.clusters.add(c);
/*  77 */       pos += 4;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Dgg(int numShapes, int numDrawings) {
/*  83 */     super(EscherRecordType.DGG);
/*  84 */     this.shapesSaved = numShapes;
/*  85 */     this.drawingsSaved = numDrawings;
/*  86 */     this.clusters = new ArrayList();
/*     */   }
/*     */ 
/*     */   
/*     */   void addCluster(int dgid, int sids) {
/*  91 */     Cluster c = new Cluster(dgid, sids);
/*  92 */     this.clusters.add(c);
/*     */   }
/*     */ 
/*     */   
/*     */   byte[] getData() {
/*  97 */     this.numClusters = this.clusters.size();
/*  98 */     this.data = new byte[16 + this.numClusters * 4];
/*     */ 
/*     */     
/* 101 */     IntegerHelper.getFourBytes(1024 + this.shapesSaved, this.data, 0);
/*     */ 
/*     */     
/* 104 */     IntegerHelper.getFourBytes(this.numClusters, this.data, 4);
/*     */ 
/*     */     
/* 107 */     IntegerHelper.getFourBytes(this.shapesSaved, this.data, 8);
/*     */ 
/*     */ 
/*     */     
/* 111 */     IntegerHelper.getFourBytes(1, this.data, 12);
/*     */     
/* 113 */     int pos = 16;
/* 114 */     for (int i = 0; i < this.numClusters; i++) {
/*     */       
/* 116 */       Cluster c = this.clusters.get(i);
/* 117 */       IntegerHelper.getTwoBytes(c.drawingGroupId, this.data, pos);
/* 118 */       IntegerHelper.getTwoBytes(c.shapeIdsUsed, this.data, pos + 2);
/* 119 */       pos += 4;
/*     */     } 
/*     */     
/* 122 */     return setHeaderData(this.data);
/*     */   }
/*     */ 
/*     */   
/*     */   int getShapesSaved() {
/* 127 */     return this.shapesSaved;
/*     */   }
/*     */ 
/*     */   
/*     */   int getDrawingsSaved() {
/* 132 */     return this.drawingsSaved;
/*     */   }
/*     */ 
/*     */   
/*     */   Cluster getCluster(int i) {
/* 137 */     return this.clusters.get(i);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\Dgg.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff.drawing;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import jxl.Image;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.write.biff.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Drawing
/*     */   implements DrawingGroupObject, Image
/*     */ {
/*  47 */   private static Logger logger = Logger.getLogger(Drawing.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer readSpContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MsoDrawingRecord msoDrawingRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ObjRecord objRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File imageFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] imageData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int objectId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int blipId;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double x;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double y;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double width;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double height;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int referenceCount;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer escherData;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Origin origin;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DrawingGroup drawingGroup;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DrawingData drawingData;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ShapeType type;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int shapeId;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int drawingNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Drawing(MsoDrawingRecord mso, ObjRecord obj, DrawingData dd, DrawingGroup dg) {
/* 162 */     this.drawingGroup = dg;
/* 163 */     this.msoDrawingRecord = mso;
/* 164 */     this.drawingData = dd;
/* 165 */     this.objRecord = obj;
/* 166 */     this.initialized = false;
/* 167 */     this.origin = Origin.READ;
/* 168 */     this.drawingData.addData(this.msoDrawingRecord.getData());
/* 169 */     this.drawingNumber = this.drawingData.getNumDrawings() - 1;
/* 170 */     this.drawingGroup.addDrawing(this);
/*     */     
/* 172 */     Assert.verify((mso != null && obj != null));
/*     */     
/* 174 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Drawing(DrawingGroupObject dgo, DrawingGroup dg) {
/* 184 */     Drawing d = (Drawing)dgo;
/* 185 */     Assert.verify((d.origin == Origin.READ));
/* 186 */     this.msoDrawingRecord = d.msoDrawingRecord;
/* 187 */     this.objRecord = d.objRecord;
/* 188 */     this.initialized = false;
/* 189 */     this.origin = Origin.READ;
/* 190 */     this.drawingData = d.drawingData;
/* 191 */     this.drawingGroup = dg;
/* 192 */     this.drawingNumber = d.drawingNumber;
/* 193 */     this.drawingGroup.addDrawing(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Drawing(double x, double y, double width, double height, File image) {
/* 208 */     this.imageFile = image;
/* 209 */     this.initialized = true;
/* 210 */     this.origin = Origin.WRITE;
/* 211 */     this.x = x;
/* 212 */     this.y = y;
/* 213 */     this.width = width;
/* 214 */     this.height = height;
/* 215 */     this.referenceCount = 1;
/* 216 */     this.type = ShapeType.PICTURE_FRAME;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Drawing(double x, double y, double width, double height, byte[] image) {
/* 231 */     this.imageData = image;
/* 232 */     this.initialized = true;
/* 233 */     this.origin = Origin.WRITE;
/* 234 */     this.x = x;
/* 235 */     this.y = y;
/* 236 */     this.width = width;
/* 237 */     this.height = height;
/* 238 */     this.referenceCount = 1;
/* 239 */     this.type = ShapeType.PICTURE_FRAME;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/* 247 */     this.readSpContainer = this.drawingData.getSpContainer(this.drawingNumber);
/* 248 */     Assert.verify((this.readSpContainer != null));
/*     */     
/* 250 */     EscherRecord[] children = this.readSpContainer.getChildren();
/*     */     
/* 252 */     Sp sp = (Sp)this.readSpContainer.getChildren()[0];
/* 253 */     this.shapeId = sp.getShapeId();
/* 254 */     this.objectId = this.objRecord.getObjectId();
/* 255 */     this.type = ShapeType.getType(sp.getShapeType());
/*     */     
/* 257 */     if (this.type == ShapeType.UNKNOWN)
/*     */     {
/* 259 */       logger.warn("Unknown shape type");
/*     */     }
/*     */     
/* 262 */     Opt opt = (Opt)this.readSpContainer.getChildren()[1];
/*     */     
/* 264 */     if (opt.getProperty(260) != null)
/*     */     {
/* 266 */       this.blipId = (opt.getProperty(260)).value;
/*     */     }
/*     */     
/* 269 */     if (opt.getProperty(261) != null) {
/*     */       
/* 271 */       this.imageFile = new File((opt.getProperty(261)).stringValue);
/*     */ 
/*     */     
/*     */     }
/* 275 */     else if (this.type == ShapeType.PICTURE_FRAME) {
/*     */       
/* 277 */       logger.warn("no filename property for drawing");
/* 278 */       this.imageFile = new File(Integer.toString(this.blipId));
/*     */     } 
/*     */ 
/*     */     
/* 282 */     ClientAnchor clientAnchor = null;
/* 283 */     for (int i = 0; i < children.length && clientAnchor == null; i++) {
/*     */       
/* 285 */       if (children[i].getType() == EscherRecordType.CLIENT_ANCHOR)
/*     */       {
/* 287 */         clientAnchor = (ClientAnchor)children[i];
/*     */       }
/*     */     } 
/*     */     
/* 291 */     if (clientAnchor == null) {
/*     */       
/* 293 */       logger.warn("client anchor not found");
/*     */     }
/*     */     else {
/*     */       
/* 297 */       this.x = clientAnchor.getX1();
/* 298 */       this.y = clientAnchor.getY1();
/* 299 */       this.width = clientAnchor.getX2() - this.x;
/* 300 */       this.height = clientAnchor.getY2() - this.y;
/*     */     } 
/*     */     
/* 303 */     if (this.blipId == 0)
/*     */     {
/* 305 */       logger.warn("linked drawings are not supported");
/*     */     }
/*     */     
/* 308 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getImageFile() {
/* 318 */     return this.imageFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getImageFilePath() {
/* 330 */     if (this.imageFile == null)
/*     */     {
/*     */       
/* 333 */       return (this.blipId != 0) ? Integer.toString(this.blipId) : "__new__image__";
/*     */     }
/*     */     
/* 336 */     return this.imageFile.getPath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setObjectId(int objid, int bip, int sid) {
/* 349 */     this.objectId = objid;
/* 350 */     this.blipId = bip;
/* 351 */     this.shapeId = sid;
/*     */     
/* 353 */     if (this.origin == Origin.READ)
/*     */     {
/* 355 */       this.origin = Origin.READ_WRITE;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getObjectId() {
/* 366 */     if (!this.initialized)
/*     */     {
/* 368 */       initialize();
/*     */     }
/*     */     
/* 371 */     return this.objectId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getShapeId() {
/* 381 */     if (!this.initialized)
/*     */     {
/* 383 */       initialize();
/*     */     }
/*     */     
/* 386 */     return this.shapeId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getBlipId() {
/* 396 */     if (!this.initialized)
/*     */     {
/* 398 */       initialize();
/*     */     }
/*     */     
/* 401 */     return this.blipId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MsoDrawingRecord getMsoDrawingRecord() {
/* 411 */     return this.msoDrawingRecord;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public EscherContainer getSpContainer() {
/* 421 */     if (!this.initialized)
/*     */     {
/* 423 */       initialize();
/*     */     }
/*     */     
/* 426 */     if (this.origin == Origin.READ)
/*     */     {
/* 428 */       return getReadSpContainer();
/*     */     }
/*     */     
/* 431 */     SpContainer spContainer = new SpContainer();
/* 432 */     Sp sp = new Sp(this.type, this.shapeId, 2560);
/* 433 */     spContainer.add(sp);
/* 434 */     Opt opt = new Opt();
/* 435 */     opt.addProperty(260, true, false, this.blipId);
/*     */     
/* 437 */     if (this.type == ShapeType.PICTURE_FRAME) {
/*     */       
/* 439 */       String filePath = (this.imageFile != null) ? this.imageFile.getPath() : "";
/* 440 */       opt.addProperty(261, true, true, filePath.length() * 2, filePath);
/* 441 */       opt.addProperty(447, false, false, 65536);
/* 442 */       opt.addProperty(959, false, false, 524288);
/* 443 */       spContainer.add(opt);
/*     */     } 
/*     */     
/* 446 */     ClientAnchor clientAnchor = new ClientAnchor(this.x, this.y, this.x + this.width, this.y + this.height);
/* 447 */     spContainer.add(clientAnchor);
/* 448 */     ClientData clientData = new ClientData();
/* 449 */     spContainer.add(clientData);
/*     */     
/* 451 */     return spContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDrawingGroup(DrawingGroup dg) {
/* 462 */     this.drawingGroup = dg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DrawingGroup getDrawingGroup() {
/* 472 */     return this.drawingGroup;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Origin getOrigin() {
/* 482 */     return this.origin;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getReferenceCount() {
/* 492 */     return this.referenceCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReferenceCount(int r) {
/* 502 */     this.referenceCount = r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getX() {
/* 512 */     if (!this.initialized)
/*     */     {
/* 514 */       initialize();
/*     */     }
/* 516 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setX(double x) {
/* 526 */     if (this.origin == Origin.READ) {
/*     */       
/* 528 */       if (!this.initialized)
/*     */       {
/* 530 */         initialize();
/*     */       }
/* 532 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 535 */     this.x = x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getY() {
/* 545 */     if (!this.initialized)
/*     */     {
/* 547 */       initialize();
/*     */     }
/*     */     
/* 550 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setY(double y) {
/* 560 */     if (this.origin == Origin.READ) {
/*     */       
/* 562 */       if (!this.initialized)
/*     */       {
/* 564 */         initialize();
/*     */       }
/* 566 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 569 */     this.y = y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getWidth() {
/* 580 */     if (!this.initialized)
/*     */     {
/* 582 */       initialize();
/*     */     }
/*     */     
/* 585 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWidth(double w) {
/* 595 */     if (this.origin == Origin.READ) {
/*     */       
/* 597 */       if (!this.initialized)
/*     */       {
/* 599 */         initialize();
/*     */       }
/* 601 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 604 */     this.width = w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getHeight() {
/* 614 */     if (!this.initialized)
/*     */     {
/* 616 */       initialize();
/*     */     }
/*     */     
/* 619 */     return this.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeight(double h) {
/* 629 */     if (this.origin == Origin.READ) {
/*     */       
/* 631 */       if (!this.initialized)
/*     */       {
/* 633 */         initialize();
/*     */       }
/* 635 */       this.origin = Origin.READ_WRITE;
/*     */     } 
/*     */     
/* 638 */     this.height = h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private EscherContainer getReadSpContainer() {
/* 649 */     if (!this.initialized)
/*     */     {
/* 651 */       initialize();
/*     */     }
/*     */     
/* 654 */     return this.readSpContainer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getImageData() {
/* 664 */     Assert.verify((this.origin == Origin.READ || this.origin == Origin.READ_WRITE));
/*     */     
/* 666 */     if (!this.initialized)
/*     */     {
/* 668 */       initialize();
/*     */     }
/*     */     
/* 671 */     return this.drawingGroup.getImageData(this.blipId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getImageBytes() throws IOException {
/* 681 */     if (this.origin == Origin.READ || this.origin == Origin.READ_WRITE)
/*     */     {
/* 683 */       return getImageData();
/*     */     }
/*     */     
/* 686 */     Assert.verify((this.origin == Origin.WRITE));
/*     */     
/* 688 */     if (this.imageFile == null) {
/*     */       
/* 690 */       Assert.verify((this.imageData != null));
/* 691 */       return this.imageData;
/*     */     } 
/*     */     
/* 694 */     byte[] data = new byte[(int)this.imageFile.length()];
/* 695 */     FileInputStream fis = new FileInputStream(this.imageFile);
/* 696 */     fis.read(data, 0, data.length);
/* 697 */     fis.close();
/* 698 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ShapeType getType() {
/* 708 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeAdditionalRecords(File outputFile) throws IOException {
/* 716 */     if (this.origin == Origin.READ) {
/*     */       
/* 718 */       outputFile.write((ByteData)this.objRecord);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 723 */     ObjRecord objRecord = new ObjRecord(this.objectId, ObjRecord.PICTURE);
/*     */     
/* 725 */     outputFile.write((ByteData)objRecord);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeTailRecords(File outputFile) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getColumn() {
/* 745 */     return getX();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getRow() {
/* 755 */     return getY();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFirst() {
/* 767 */     return this.msoDrawingRecord.isFirst();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFormObject() {
/* 779 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\Drawing.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
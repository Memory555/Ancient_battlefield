/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class BlipType
/*    */ {
/*    */   private int value;
/*    */   private String desc;
/* 30 */   private static BlipType[] types = new BlipType[0];
/*    */ 
/*    */   
/*    */   private BlipType(int val, String d) {
/* 34 */     this.value = val;
/* 35 */     this.desc = d;
/*    */     
/* 37 */     BlipType[] newtypes = new BlipType[types.length + 1];
/* 38 */     System.arraycopy(types, 0, newtypes, 0, types.length);
/* 39 */     newtypes[types.length] = this;
/* 40 */     types = newtypes;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 45 */     return this.desc;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getValue() {
/* 50 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   public static BlipType getType(int val) {
/* 55 */     BlipType type = UNKNOWN;
/* 56 */     for (int i = 0; i < types.length; i++) {
/*    */       
/* 58 */       if ((types[i]).value == val) {
/*    */         
/* 60 */         type = types[i];
/*    */         
/*    */         break;
/*    */       } 
/*    */     } 
/* 65 */     return type;
/*    */   }
/*    */   
/* 68 */   public static final BlipType ERROR = new BlipType(0, "Error");
/* 69 */   public static final BlipType UNKNOWN = new BlipType(1, "Unknown");
/* 70 */   public static final BlipType EMF = new BlipType(2, "EMF");
/* 71 */   public static final BlipType WMF = new BlipType(3, "WMF");
/* 72 */   public static final BlipType PICT = new BlipType(4, "PICT");
/* 73 */   public static final BlipType JPEG = new BlipType(5, "JPEG");
/* 74 */   public static final BlipType PNG = new BlipType(6, "PNG");
/* 75 */   public static final BlipType DIB = new BlipType(7, "DIB");
/* 76 */   public static final BlipType FIRST_CLIENT = new BlipType(32, "FIRST");
/* 77 */   public static final BlipType LAST_CLIENT = new BlipType(255, "LAST");
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\BlipType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
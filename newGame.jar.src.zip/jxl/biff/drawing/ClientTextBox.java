/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ import common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ClientTextBox
/*    */   extends EscherAtom
/*    */ {
/* 34 */   private static Logger logger = Logger.getLogger(ClientTextBox.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private byte[] data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClientTextBox(EscherRecordData erd) {
/* 48 */     super(erd);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ClientTextBox() {
/* 56 */     super(EscherRecordType.CLIENT_TEXT_BOX);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getData() {
/* 66 */     this.data = new byte[0];
/* 67 */     return setHeaderData(this.data);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\ClientTextBox.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BStoreContainer
/*    */   extends EscherContainer
/*    */ {
/*    */   private int numBlips;
/*    */   
/*    */   public BStoreContainer(EscherRecordData erd) {
/* 41 */     super(erd);
/* 42 */     this.numBlips = getInstance();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BStoreContainer() {
/* 50 */     super(EscherRecordType.BSTORE_CONTAINER);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void setNumBlips(int count) {
/* 60 */     this.numBlips = count;
/* 61 */     setInstance(this.numBlips);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getNumBlips() {
/* 71 */     return this.numBlips;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void getDrawing(int i) {
/* 81 */     EscherRecord[] children = getChildren();
/* 82 */     BlipStoreEntry bse = (BlipStoreEntry)children[i];
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\BStoreContainer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.biff.drawing;
/*    */ 
/*    */ import common.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SpgrContainer
/*    */   extends EscherContainer
/*    */ {
/* 32 */   private static final Logger logger = Logger.getLogger(SpgrContainer.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SpgrContainer() {
/* 39 */     super(EscherRecordType.SPGR_CONTAINER);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SpgrContainer(EscherRecordData erd) {
/* 49 */     super(erd);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\drawing\SpgrContainer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import java.util.Stack;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class Operator
/*    */   extends ParseItem
/*    */ {
/* 42 */   private ParseItem[] operands = new ParseItem[0];
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setOperandAlternateCode() {
/* 50 */     for (int i = 0; i < this.operands.length; i++)
/*    */     {
/* 52 */       this.operands[i].setAlternateCode();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void add(ParseItem n) {
/* 61 */     n.setParent(this);
/*    */ 
/*    */     
/* 64 */     ParseItem[] newOperands = new ParseItem[this.operands.length + 1];
/* 65 */     System.arraycopy(this.operands, 0, newOperands, 0, this.operands.length);
/* 66 */     newOperands[this.operands.length] = n;
/* 67 */     this.operands = newOperands;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract void getOperands(Stack paramStack);
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected ParseItem[] getOperands() {
/* 80 */     return this.operands;
/*    */   }
/*    */   
/*    */   abstract int getPrecedence();
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\Operator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
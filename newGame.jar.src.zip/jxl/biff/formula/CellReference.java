/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.Cell;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CellReference
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(CellReference.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean columnRelative;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean rowRelative;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Cell relativeTo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellReference(Cell rt) {
/*  70 */     this.relativeTo = rt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellReference() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellReference(String s) {
/*  87 */     this.column = CellReferenceHelper.getColumn(s);
/*  88 */     this.row = CellReferenceHelper.getRow(s);
/*  89 */     this.columnRelative = CellReferenceHelper.isColumnRelative(s);
/*  90 */     this.rowRelative = CellReferenceHelper.isRowRelative(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/* 102 */     this.row = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 103 */     int columnMask = IntegerHelper.getInt(data[pos + 2], data[pos + 3]);
/* 104 */     this.column = columnMask & 0xFF;
/* 105 */     this.columnRelative = ((columnMask & 0x4000) != 0);
/* 106 */     this.rowRelative = ((columnMask & 0x8000) != 0);
/*     */     
/* 108 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 118 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRow() {
/* 128 */     return this.row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/* 138 */     CellReferenceHelper.getCellReference(this.column, !this.columnRelative, this.row, !this.rowRelative, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 150 */     byte[] data = new byte[5];
/* 151 */     data[0] = !useAlternateCode() ? Token.REF.getCode() : Token.REF.getCode2();
/*     */ 
/*     */     
/* 154 */     IntegerHelper.getTwoBytes(this.row, data, 1);
/*     */     
/* 156 */     int grcol = this.column;
/*     */ 
/*     */     
/* 159 */     if (this.rowRelative)
/*     */     {
/* 161 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 164 */     if (this.columnRelative)
/*     */     {
/* 166 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 169 */     IntegerHelper.getTwoBytes(grcol, data, 3);
/*     */     
/* 171 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/* 183 */     if (this.columnRelative)
/*     */     {
/* 185 */       this.column += colAdjust;
/*     */     }
/*     */     
/* 188 */     if (this.rowRelative)
/*     */     {
/* 190 */       this.row += rowAdjust;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/* 206 */     if (!currentSheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 211 */     if (this.column >= col)
/*     */     {
/* 213 */       this.column++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 229 */     if (!currentSheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 234 */     if (this.column >= col)
/*     */     {
/* 236 */       this.column--;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(int sheetIndex, int r, boolean currentSheet) {
/* 252 */     if (!currentSheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 257 */     if (this.row >= r)
/*     */     {
/* 259 */       this.row++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(int sheetIndex, int r, boolean currentSheet) {
/* 275 */     if (!currentSheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 280 */     if (this.row >= r)
/*     */     {
/* 282 */       this.row--;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\CellReference.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
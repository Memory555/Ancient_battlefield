/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SharedFormulaArea
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*     */   private int columnFirst;
/*     */   private int rowFirst;
/*     */   private int columnLast;
/*     */   private int rowLast;
/*     */   private boolean columnFirstRelative;
/*     */   private boolean rowFirstRelative;
/*     */   private boolean columnLastRelative;
/*     */   private boolean rowLastRelative;
/*     */   private Cell relativeTo;
/*     */   
/*     */   public SharedFormulaArea(Cell rt) {
/*  54 */     this.relativeTo = rt;
/*     */   }
/*     */ 
/*     */   
/*     */   int getFirstColumn() {
/*  59 */     return this.columnFirst;
/*     */   }
/*     */ 
/*     */   
/*     */   int getFirstRow() {
/*  64 */     return this.rowFirst;
/*     */   }
/*     */ 
/*     */   
/*     */   int getLastColumn() {
/*  69 */     return this.columnLast;
/*     */   }
/*     */ 
/*     */   
/*     */   int getLastRow() {
/*  74 */     return this.rowLast;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/*  89 */     this.rowFirst = IntegerHelper.getShort(data[pos], data[pos + 1]);
/*  90 */     this.rowLast = IntegerHelper.getShort(data[pos + 2], data[pos + 3]);
/*     */     
/*  92 */     int columnMask = IntegerHelper.getInt(data[pos + 4], data[pos + 5]);
/*  93 */     this.columnFirst = columnMask & 0xFF;
/*  94 */     this.columnFirstRelative = ((columnMask & 0x4000) != 0);
/*  95 */     this.rowFirstRelative = ((columnMask & 0x8000) != 0);
/*     */     
/*  97 */     if (this.columnFirstRelative)
/*     */     {
/*  99 */       this.columnFirst = this.relativeTo.getColumn() + this.columnFirst;
/*     */     }
/*     */     
/* 102 */     if (this.rowFirstRelative)
/*     */     {
/* 104 */       this.rowFirst = this.relativeTo.getRow() + this.rowFirst;
/*     */     }
/*     */     
/* 107 */     columnMask = IntegerHelper.getInt(data[pos + 6], data[pos + 7]);
/* 108 */     this.columnLast = columnMask & 0xFF;
/*     */     
/* 110 */     this.columnLastRelative = ((columnMask & 0x4000) != 0);
/* 111 */     this.rowLastRelative = ((columnMask & 0x8000) != 0);
/*     */     
/* 113 */     if (this.columnLastRelative)
/*     */     {
/* 115 */       this.columnLast = this.relativeTo.getColumn() + this.columnLast;
/*     */     }
/*     */     
/* 118 */     if (this.rowLastRelative)
/*     */     {
/* 120 */       this.rowLast = this.relativeTo.getRow() + this.rowLast;
/*     */     }
/*     */ 
/*     */     
/* 124 */     return 8;
/*     */   }
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/* 129 */     CellReferenceHelper.getCellReference(this.columnFirst, this.rowFirst, buf);
/* 130 */     buf.append(':');
/* 131 */     CellReferenceHelper.getCellReference(this.columnLast, this.rowLast, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 141 */     byte[] data = new byte[9];
/* 142 */     data[0] = Token.AREA.getCode();
/*     */ 
/*     */ 
/*     */     
/* 146 */     IntegerHelper.getTwoBytes(this.rowFirst, data, 1);
/* 147 */     IntegerHelper.getTwoBytes(this.rowLast, data, 3);
/* 148 */     IntegerHelper.getTwoBytes(this.columnFirst, data, 5);
/* 149 */     IntegerHelper.getTwoBytes(this.columnLast, data, 7);
/*     */     
/* 151 */     return data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\SharedFormulaArea.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
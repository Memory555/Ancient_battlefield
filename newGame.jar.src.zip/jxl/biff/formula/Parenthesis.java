/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Parenthesis
/*     */   extends Operator
/*     */   implements ParsedThing
/*     */ {
/*     */   public int read(byte[] data, int pos) {
/*  48 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getOperands(Stack s) {
/*  56 */     ParseItem pi = s.pop();
/*     */     
/*  58 */     add(pi);
/*     */   }
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/*  63 */     ParseItem[] operands = getOperands();
/*  64 */     buf.append('(');
/*  65 */     operands[0].getString(buf);
/*  66 */     buf.append(')');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/*  78 */     ParseItem[] operands = getOperands();
/*  79 */     operands[0].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/*  94 */     ParseItem[] operands = getOperands();
/*  95 */     operands[0].columnInserted(sheetIndex, col, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 110 */     ParseItem[] operands = getOperands();
/* 111 */     operands[0].columnRemoved(sheetIndex, col, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet) {
/* 126 */     ParseItem[] operands = getOperands();
/* 127 */     operands[0].rowInserted(sheetIndex, row, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet) {
/* 142 */     ParseItem[] operands = getOperands();
/* 143 */     operands[0].rowRemoved(sheetIndex, row, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Token getToken() {
/* 153 */     return Token.PARENTHESIS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 164 */     ParseItem[] operands = getOperands();
/* 165 */     byte[] data = operands[0].getBytes();
/*     */ 
/*     */     
/* 168 */     byte[] newdata = new byte[data.length + 1];
/* 169 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 170 */     newdata[data.length] = getToken().getCode();
/*     */     
/* 172 */     return newdata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getPrecedence() {
/* 183 */     return 4;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\Parenthesis.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Area
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(Area.class);
/*     */ 
/*     */   
/*     */   private int columnFirst;
/*     */ 
/*     */   
/*     */   private int rowFirst;
/*     */   
/*     */   private int columnLast;
/*     */   
/*     */   private int rowLast;
/*     */   
/*     */   private boolean columnFirstRelative;
/*     */   
/*     */   private boolean rowFirstRelative;
/*     */   
/*     */   private boolean columnLastRelative;
/*     */   
/*     */   private boolean rowLastRelative;
/*     */ 
/*     */   
/*     */   Area() {}
/*     */ 
/*     */   
/*     */   Area(String s) {
/*  66 */     int seppos = s.indexOf(":");
/*  67 */     Assert.verify((seppos != -1));
/*  68 */     String startcell = s.substring(0, seppos);
/*  69 */     String endcell = s.substring(seppos + 1);
/*     */     
/*  71 */     this.columnFirst = CellReferenceHelper.getColumn(startcell);
/*  72 */     this.rowFirst = CellReferenceHelper.getRow(startcell);
/*  73 */     this.columnLast = CellReferenceHelper.getColumn(endcell);
/*  74 */     this.rowLast = CellReferenceHelper.getRow(endcell);
/*     */     
/*  76 */     this.columnFirstRelative = CellReferenceHelper.isColumnRelative(startcell);
/*  77 */     this.rowFirstRelative = CellReferenceHelper.isRowRelative(startcell);
/*  78 */     this.columnLastRelative = CellReferenceHelper.isColumnRelative(endcell);
/*  79 */     this.rowLastRelative = CellReferenceHelper.isRowRelative(endcell);
/*     */   }
/*     */ 
/*     */   
/*     */   int getFirstColumn() {
/*  84 */     return this.columnFirst;
/*     */   }
/*     */ 
/*     */   
/*     */   int getFirstRow() {
/*  89 */     return this.rowFirst;
/*     */   }
/*     */ 
/*     */   
/*     */   int getLastColumn() {
/*  94 */     return this.columnLast;
/*     */   }
/*     */ 
/*     */   
/*     */   int getLastRow() {
/*  99 */     return this.rowLast;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/* 111 */     this.rowFirst = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 112 */     this.rowLast = IntegerHelper.getInt(data[pos + 2], data[pos + 3]);
/* 113 */     int columnMask = IntegerHelper.getInt(data[pos + 4], data[pos + 5]);
/* 114 */     this.columnFirst = columnMask & 0xFF;
/* 115 */     this.columnFirstRelative = ((columnMask & 0x4000) != 0);
/* 116 */     this.rowFirstRelative = ((columnMask & 0x8000) != 0);
/* 117 */     columnMask = IntegerHelper.getInt(data[pos + 6], data[pos + 7]);
/* 118 */     this.columnLast = columnMask & 0xFF;
/* 119 */     this.columnLastRelative = ((columnMask & 0x4000) != 0);
/* 120 */     this.rowLastRelative = ((columnMask & 0x8000) != 0);
/*     */     
/* 122 */     return 8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/* 132 */     CellReferenceHelper.getCellReference(this.columnFirst, this.rowFirst, buf);
/* 133 */     buf.append(':');
/* 134 */     CellReferenceHelper.getCellReference(this.columnLast, this.rowLast, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 144 */     byte[] data = new byte[9];
/* 145 */     data[0] = !useAlternateCode() ? Token.AREA.getCode() : Token.AREA.getCode2();
/*     */ 
/*     */     
/* 148 */     IntegerHelper.getTwoBytes(this.rowFirst, data, 1);
/* 149 */     IntegerHelper.getTwoBytes(this.rowLast, data, 3);
/*     */     
/* 151 */     int grcol = this.columnFirst;
/*     */ 
/*     */     
/* 154 */     if (this.rowFirstRelative)
/*     */     {
/* 156 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 159 */     if (this.columnFirstRelative)
/*     */     {
/* 161 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 164 */     IntegerHelper.getTwoBytes(grcol, data, 5);
/*     */     
/* 166 */     grcol = this.columnLast;
/*     */ 
/*     */     
/* 169 */     if (this.rowLastRelative)
/*     */     {
/* 171 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 174 */     if (this.columnLastRelative)
/*     */     {
/* 176 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 179 */     IntegerHelper.getTwoBytes(grcol, data, 7);
/*     */     
/* 181 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/* 193 */     if (this.columnFirstRelative)
/*     */     {
/* 195 */       this.columnFirst += colAdjust;
/*     */     }
/*     */     
/* 198 */     if (this.columnLastRelative)
/*     */     {
/* 200 */       this.columnLast += colAdjust;
/*     */     }
/*     */     
/* 203 */     if (this.rowFirstRelative)
/*     */     {
/* 205 */       this.rowFirst += rowAdjust;
/*     */     }
/*     */     
/* 208 */     if (this.rowLastRelative)
/*     */     {
/* 210 */       this.rowLast += rowAdjust;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/* 226 */     if (!currentSheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 231 */     if (col <= this.columnFirst)
/*     */     {
/* 233 */       this.columnFirst++;
/*     */     }
/*     */     
/* 236 */     if (col <= this.columnLast)
/*     */     {
/* 238 */       this.columnLast++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 254 */     if (!currentSheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 259 */     if (col < this.columnFirst)
/*     */     {
/* 261 */       this.columnFirst--;
/*     */     }
/*     */     
/* 264 */     if (col <= this.columnLast)
/*     */     {
/* 266 */       this.columnLast--;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet) {
/* 282 */     if (!currentSheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 287 */     if (row <= this.rowFirst)
/*     */     {
/* 289 */       this.rowFirst++;
/*     */     }
/*     */     
/* 292 */     if (row <= this.rowLast)
/*     */     {
/* 294 */       this.rowLast++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet) {
/* 310 */     if (!currentSheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 315 */     if (row < this.rowFirst)
/*     */     {
/* 317 */       this.rowFirst--;
/*     */     }
/*     */     
/* 320 */     if (row <= this.rowLast)
/*     */     {
/* 322 */       this.rowLast--;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\Area.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
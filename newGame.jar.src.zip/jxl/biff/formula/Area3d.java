/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Area3d
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(Area3d.class);
/*     */   
/*     */   private int sheet;
/*     */   
/*     */   private int columnFirst;
/*     */   
/*     */   private int rowFirst;
/*     */   
/*     */   private int columnLast;
/*     */   
/*     */   private int rowLast;
/*     */   
/*     */   private boolean columnFirstRelative;
/*     */   private boolean rowFirstRelative;
/*     */   private boolean columnLastRelative;
/*     */   private boolean rowLastRelative;
/*     */   private ExternalSheet workbook;
/*     */   
/*     */   Area3d(ExternalSheet es) {
/*  60 */     this.workbook = es;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Area3d(String s, ExternalSheet es) throws FormulaException {
/*  70 */     this.workbook = es;
/*  71 */     int seppos = s.lastIndexOf(":");
/*  72 */     Assert.verify((seppos != -1));
/*  73 */     String startcell = s.substring(0, seppos);
/*  74 */     String endcell = s.substring(seppos + 1);
/*     */ 
/*     */     
/*  77 */     int sep = s.indexOf('!');
/*  78 */     String cellString = s.substring(sep + 1, seppos);
/*  79 */     this.columnFirst = CellReferenceHelper.getColumn(cellString);
/*  80 */     this.rowFirst = CellReferenceHelper.getRow(cellString);
/*     */ 
/*     */     
/*  83 */     String sheetName = s.substring(0, sep);
/*  84 */     int sheetNamePos = sheetName.lastIndexOf(']');
/*     */ 
/*     */     
/*  87 */     if (sheetName.charAt(0) == '\'' && sheetName.charAt(sheetName.length() - 1) == '\'')
/*     */     {
/*     */       
/*  90 */       sheetName = sheetName.substring(1, sheetName.length() - 1);
/*     */     }
/*     */     
/*  93 */     this.sheet = es.getExternalSheetIndex(sheetName);
/*     */     
/*  95 */     if (this.sheet < 0)
/*     */     {
/*  97 */       throw new FormulaException(FormulaException.sheetRefNotFound, sheetName);
/*     */     }
/*     */ 
/*     */     
/* 101 */     this.columnLast = CellReferenceHelper.getColumn(endcell);
/* 102 */     this.rowLast = CellReferenceHelper.getRow(endcell);
/*     */     
/* 104 */     this.columnFirstRelative = true;
/* 105 */     this.rowFirstRelative = true;
/* 106 */     this.columnLastRelative = true;
/* 107 */     this.rowLastRelative = true;
/*     */   }
/*     */   
/* 110 */   int getFirstColumn() { return this.columnFirst; }
/* 111 */   int getFirstRow() { return this.rowFirst; }
/* 112 */   int getLastColumn() { return this.columnLast; } int getLastRow() {
/* 113 */     return this.rowLast;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/* 124 */     this.sheet = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 125 */     this.rowFirst = IntegerHelper.getInt(data[pos + 2], data[pos + 3]);
/* 126 */     this.rowLast = IntegerHelper.getInt(data[pos + 4], data[pos + 5]);
/* 127 */     int columnMask = IntegerHelper.getInt(data[pos + 6], data[pos + 7]);
/* 128 */     this.columnFirst = columnMask & 0xFF;
/* 129 */     this.columnFirstRelative = ((columnMask & 0x4000) != 0);
/* 130 */     this.rowFirstRelative = ((columnMask & 0x8000) != 0);
/* 131 */     columnMask = IntegerHelper.getInt(data[pos + 8], data[pos + 9]);
/* 132 */     this.columnLast = columnMask & 0xFF;
/* 133 */     this.columnLastRelative = ((columnMask & 0x4000) != 0);
/* 134 */     this.rowLastRelative = ((columnMask & 0x8000) != 0);
/*     */     
/* 136 */     return 10;
/*     */   }
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/* 141 */     CellReferenceHelper.getCellReference(this.sheet, this.columnFirst, this.rowFirst, this.workbook, buf);
/*     */     
/* 143 */     buf.append(':');
/* 144 */     CellReferenceHelper.getCellReference(this.columnLast, this.rowLast, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 154 */     byte[] data = new byte[11];
/* 155 */     data[0] = Token.AREA3D.getCode();
/*     */     
/* 157 */     IntegerHelper.getTwoBytes(this.sheet, data, 1);
/*     */     
/* 159 */     IntegerHelper.getTwoBytes(this.rowFirst, data, 3);
/* 160 */     IntegerHelper.getTwoBytes(this.rowLast, data, 5);
/*     */     
/* 162 */     int grcol = this.columnFirst;
/*     */ 
/*     */     
/* 165 */     if (this.rowFirstRelative)
/*     */     {
/* 167 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 170 */     if (this.columnFirstRelative)
/*     */     {
/* 172 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 175 */     IntegerHelper.getTwoBytes(grcol, data, 7);
/*     */     
/* 177 */     grcol = this.columnLast;
/*     */ 
/*     */     
/* 180 */     if (this.rowLastRelative)
/*     */     {
/* 182 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 185 */     if (this.columnLastRelative)
/*     */     {
/* 187 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 190 */     IntegerHelper.getTwoBytes(grcol, data, 9);
/*     */     
/* 192 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/* 204 */     if (this.columnFirstRelative)
/*     */     {
/* 206 */       this.columnFirst += colAdjust;
/*     */     }
/*     */     
/* 209 */     if (this.columnLastRelative)
/*     */     {
/* 211 */       this.columnLast += colAdjust;
/*     */     }
/*     */     
/* 214 */     if (this.rowFirstRelative)
/*     */     {
/* 216 */       this.rowFirst += rowAdjust;
/*     */     }
/*     */     
/* 219 */     if (this.rowLastRelative)
/*     */     {
/* 221 */       this.rowLast += rowAdjust;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/* 237 */     if (sheetIndex != this.sheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 242 */     if (this.columnFirst >= col)
/*     */     {
/* 244 */       this.columnFirst++;
/*     */     }
/*     */     
/* 247 */     if (this.columnLast >= col)
/*     */     {
/* 249 */       this.columnLast++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 265 */     if (sheetIndex != this.sheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 270 */     if (col < this.columnFirst)
/*     */     {
/* 272 */       this.columnFirst--;
/*     */     }
/*     */     
/* 275 */     if (col <= this.columnLast)
/*     */     {
/* 277 */       this.columnLast--;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet) {
/* 293 */     if (sheetIndex != this.sheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 298 */     if (row <= this.rowFirst)
/*     */     {
/* 300 */       this.rowFirst++;
/*     */     }
/*     */     
/* 303 */     if (row <= this.rowLast)
/*     */     {
/* 305 */       this.rowLast++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet) {
/* 321 */     if (sheetIndex != this.sheet) {
/*     */       return;
/*     */     }
/*     */     
/* 325 */     if (row < this.rowFirst)
/*     */     {
/* 327 */       this.rowFirst--;
/*     */     }
/*     */     
/* 330 */     if (row <= this.rowLast)
/*     */     {
/* 332 */       this.rowLast--;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\Area3d.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
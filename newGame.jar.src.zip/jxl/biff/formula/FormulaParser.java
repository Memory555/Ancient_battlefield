/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormulaParser
/*     */ {
/*     */   private Parser parser;
/*     */   
/*     */   public FormulaParser(byte[] tokens, Cell rt, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws) throws FormulaException {
/*  56 */     if (es.getWorkbookBof() != null && !es.getWorkbookBof().isBiff8())
/*     */     {
/*     */       
/*  59 */       throw new FormulaException(FormulaException.biff8Supported);
/*     */     }
/*  61 */     this.parser = new TokenFormulaParser(tokens, rt, es, nt, ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormulaParser(String form, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws) {
/*  75 */     this.parser = new StringFormulaParser(form, es, nt, ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/*  88 */     this.parser.adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse() throws FormulaException {
/*  98 */     this.parser.parse();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormula() throws FormulaException {
/* 108 */     return this.parser.getFormula();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/* 119 */     return this.parser.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/* 134 */     this.parser.columnInserted(sheetIndex, col, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 149 */     this.parser.columnRemoved(sheetIndex, col, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rowInserted(int sheetIndex, int row, boolean currentSheet) {
/* 164 */     this.parser.rowInserted(sheetIndex, row, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rowRemoved(int sheetIndex, int row, boolean currentSheet) {
/* 179 */     this.parser.rowRemoved(sheetIndex, row, currentSheet);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\FormulaParser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
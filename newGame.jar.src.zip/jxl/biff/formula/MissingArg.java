/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MissingArg
/*    */   extends Operand
/*    */   implements ParsedThing
/*    */ {
/*    */   public int read(byte[] data, int pos) {
/* 47 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getBytes() {
/* 57 */     byte[] data = new byte[1];
/* 58 */     data[0] = Token.MISSING_ARG.getCode();
/*    */     
/* 60 */     return data;
/*    */   }
/*    */   
/*    */   public void getString(StringBuffer buf) {}
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\MissingArg.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MemFunc
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*     */   private int length;
/*     */   private ParseItem[] subExpression;
/*     */   
/*     */   public int read(byte[] data, int pos) {
/*  60 */     this.length = IntegerHelper.getInt(data[pos], data[pos + 1]);
/*  61 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getOperands(Stack s) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/*  73 */     if (this.subExpression.length == 1) {
/*     */       
/*  75 */       this.subExpression[0].getString(buf);
/*     */     }
/*  77 */     else if (this.subExpression.length == 2) {
/*     */       
/*  79 */       this.subExpression[1].getString(buf);
/*  80 */       buf.append(':');
/*  81 */       this.subExpression[0].getString(buf);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/*  94 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getPrecedence() {
/* 106 */     return 5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 116 */     return this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSubExpression(ParseItem[] pi) {
/* 121 */     this.subExpression = pi;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\MemFunc.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
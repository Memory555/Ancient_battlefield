/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Percent
/*    */   extends UnaryOperator
/*    */   implements ParsedThing
/*    */ {
/*    */   public String getSymbol() {
/* 40 */     return "%";
/*    */   }
/*    */ 
/*    */   
/*    */   public void getString(StringBuffer buf) {
/* 45 */     ParseItem[] operands = getOperands();
/* 46 */     operands[0].getString(buf);
/* 47 */     buf.append(getSymbol());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Token getToken() {
/* 58 */     return Token.PERCENT;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   int getPrecedence() {
/* 69 */     return 5;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\Percent.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
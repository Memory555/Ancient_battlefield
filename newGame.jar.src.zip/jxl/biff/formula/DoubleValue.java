/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.DoubleHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DoubleValue
/*     */   extends NumberValue
/*     */   implements ParsedThing
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(DoubleValue.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DoubleValue() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DoubleValue(double v) {
/*  55 */     this.value = v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DoubleValue(String s) {
/*     */     try {
/*  65 */       this.value = Double.parseDouble(s);
/*     */     }
/*  67 */     catch (NumberFormatException e) {
/*     */       
/*  69 */       logger.warn(e, e);
/*  70 */       this.value = 0.0D;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/*  83 */     this.value = DoubleHelper.getIEEEDouble(data, pos);
/*     */     
/*  85 */     return 8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/*  95 */     byte[] data = new byte[9];
/*  96 */     data[0] = Token.DOUBLE.getCode();
/*     */     
/*  98 */     DoubleHelper.getIEEEBytes(this.value, data, 1);
/*     */     
/* 100 */     return data;
/*     */   }
/*     */ 
/*     */   
/*     */   public double getValue() {
/* 105 */     return this.value;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\DoubleValue.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
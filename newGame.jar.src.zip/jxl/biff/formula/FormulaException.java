/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import jxl.JXLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FormulaException
/*    */   extends JXLException
/*    */ {
/*    */   private static class FormulaMessage
/*    */   {
/*    */     public String message;
/*    */     
/*    */     FormulaMessage(String m) {
/* 40 */       this.message = m;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/* 45 */   static FormulaMessage unrecognizedToken = new FormulaMessage("Unrecognized token");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   static FormulaMessage unrecognizedFunction = new FormulaMessage("Unrecognized function");
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public static FormulaMessage biff8Supported = new FormulaMessage("Only biff8 formulas are supported");
/*    */ 
/*    */   
/* 58 */   static FormulaMessage lexicalError = new FormulaMessage("Lexical error:  ");
/*    */ 
/*    */   
/* 61 */   static FormulaMessage incorrectArguments = new FormulaMessage("Incorrect arguments supplied to function");
/*    */ 
/*    */   
/* 64 */   static FormulaMessage sheetRefNotFound = new FormulaMessage("Could not find sheet");
/*    */ 
/*    */   
/* 67 */   static FormulaMessage cellNameNotFound = new FormulaMessage("Could not find named cell");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FormulaException(FormulaMessage m) {
/* 78 */     super(m.message);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FormulaException(FormulaMessage m, int val) {
/* 88 */     super(m.message + " " + val);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FormulaException(FormulaMessage m, String val) {
/* 98 */     super(m.message + " " + val);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\FormulaException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
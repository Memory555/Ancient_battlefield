/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NameRange
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*     */   private WorkbookMethods nameTable;
/*     */   private String name;
/*     */   private int index;
/*     */   
/*     */   public NameRange(WorkbookMethods nt) {
/*  50 */     this.nameTable = nt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameRange(String nm, WorkbookMethods nt) throws FormulaException {
/*  61 */     this.name = nm;
/*  62 */     this.nameTable = nt;
/*     */     
/*  64 */     this.index = this.nameTable.getNameIndex(this.name);
/*     */     
/*  66 */     if (this.index < 0)
/*     */     {
/*  68 */       throw new FormulaException(FormulaException.cellNameNotFound, this.name);
/*     */     }
/*     */     
/*  71 */     this.index++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/*  83 */     this.index = IntegerHelper.getInt(data[pos], data[pos + 1]);
/*     */     
/*  85 */     this.name = this.nameTable.getName(this.index - 1);
/*     */     
/*  87 */     return 4;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/*  97 */     byte[] data = new byte[5];
/*  98 */     data[0] = Token.NAMED_RANGE.getCode();
/*     */     
/* 100 */     IntegerHelper.getTwoBytes(this.index, data, 1);
/*     */     
/* 102 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/* 113 */     buf.append(this.name);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\NameRange.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
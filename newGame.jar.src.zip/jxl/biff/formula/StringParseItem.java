/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringParseItem
/*    */   extends ParseItem
/*    */ {
/*    */   void getString(StringBuffer buf) {}
/*    */   
/*    */   byte[] getBytes() {
/* 54 */     return new byte[0];
/*    */   }
/*    */   
/*    */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {}
/*    */   
/*    */   void columnInserted(int sheetIndex, int col, boolean currentSheet) {}
/*    */   
/*    */   void columnRemoved(int sheetIndex, int col, boolean currentSheet) {}
/*    */   
/*    */   void rowInserted(int sheetIndex, int row, boolean currentSheet) {}
/*    */   
/*    */   void rowRemoved(int sheetIndex, int row, boolean currentSheet) {}
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\StringParseItem.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Stack;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StringFormulaParser
/*     */   implements Parser
/*     */ {
/*  43 */   private static Logger logger = Logger.getLogger(StringFormulaParser.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String formula;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String parsedFormula;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ParseItem root;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Stack arguments;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings settings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExternalSheet externalSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookMethods nameTable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringFormulaParser(String f, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws) {
/*  89 */     this.formula = f;
/*  90 */     this.settings = ws;
/*  91 */     this.externalSheet = es;
/*  92 */     this.nameTable = nt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse() throws FormulaException {
/* 102 */     ArrayList tokens = getTokens();
/*     */     
/* 104 */     Iterator i = tokens.iterator();
/*     */     
/* 106 */     this.root = parseCurrent(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ParseItem parseCurrent(Iterator i) throws FormulaException {
/* 119 */     Stack stack = new Stack();
/* 120 */     Stack operators = new Stack();
/* 121 */     Stack args = null;
/*     */     
/* 123 */     boolean parenthesesClosed = false;
/* 124 */     ParseItem lastParseItem = null;
/*     */     
/* 126 */     while (i.hasNext() && !parenthesesClosed) {
/*     */       
/* 128 */       ParseItem pi = i.next();
/*     */       
/* 130 */       if (pi instanceof Operand) {
/*     */         
/* 132 */         handleOperand((Operand)pi, stack);
/*     */       }
/* 134 */       else if (pi instanceof StringFunction) {
/*     */         
/* 136 */         handleFunction((StringFunction)pi, i, stack);
/*     */       }
/* 138 */       else if (pi instanceof Operator) {
/*     */         
/* 140 */         Operator op = (Operator)pi;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 145 */         if (op instanceof StringOperator) {
/*     */           
/* 147 */           StringOperator sop = (StringOperator)op;
/* 148 */           if (stack.isEmpty() || lastParseItem instanceof Operator) {
/*     */             
/* 150 */             op = sop.getUnaryOperator();
/*     */           }
/*     */           else {
/*     */             
/* 154 */             op = sop.getBinaryOperator();
/*     */           } 
/*     */         } 
/*     */         
/* 158 */         if (operators.empty()) {
/*     */ 
/*     */           
/* 161 */           operators.push(op);
/*     */         }
/*     */         else {
/*     */           
/* 165 */           Operator operator = operators.peek();
/*     */ 
/*     */ 
/*     */           
/* 169 */           if (op.getPrecedence() < operator.getPrecedence())
/*     */           {
/* 171 */             operators.push(op);
/*     */           
/*     */           }
/*     */           else
/*     */           {
/*     */             
/* 177 */             operators.pop();
/* 178 */             operator.getOperands(stack);
/* 179 */             stack.push(operator);
/* 180 */             operators.push(op);
/*     */           }
/*     */         
/*     */         } 
/* 184 */       } else if (pi instanceof ArgumentSeparator) {
/*     */ 
/*     */         
/* 187 */         while (!operators.isEmpty()) {
/*     */           
/* 189 */           Operator o = operators.pop();
/* 190 */           o.getOperands(stack);
/* 191 */           stack.push(o);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 197 */         if (args == null)
/*     */         {
/* 199 */           args = new Stack();
/*     */         }
/*     */         
/* 202 */         args.push(stack.pop());
/* 203 */         stack.clear();
/*     */       }
/* 205 */       else if (pi instanceof OpenParentheses) {
/*     */         
/* 207 */         ParseItem pi2 = parseCurrent(i);
/* 208 */         Parenthesis p = new Parenthesis();
/* 209 */         pi2.setParent(p);
/* 210 */         p.add(pi2);
/* 211 */         stack.push(p);
/*     */       }
/* 213 */       else if (pi instanceof CloseParentheses) {
/*     */         
/* 215 */         parenthesesClosed = true;
/*     */       } 
/*     */       
/* 218 */       lastParseItem = pi;
/*     */     } 
/*     */     
/* 221 */     while (!operators.isEmpty()) {
/*     */       
/* 223 */       Operator o = operators.pop();
/* 224 */       o.getOperands(stack);
/* 225 */       stack.push(o);
/*     */     } 
/*     */     
/* 228 */     ParseItem rt = !stack.empty() ? stack.pop() : null;
/*     */ 
/*     */ 
/*     */     
/* 232 */     if (args != null && rt != null)
/*     */     {
/* 234 */       args.push(rt);
/*     */     }
/*     */     
/* 237 */     this.arguments = args;
/*     */     
/* 239 */     if (!stack.empty() || !operators.empty())
/*     */     {
/* 241 */       logger.warn("Formula " + this.formula + " has a non-empty parse stack");
/*     */     }
/*     */ 
/*     */     
/* 245 */     return rt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList getTokens() throws FormulaException {
/* 256 */     ArrayList tokens = new ArrayList();
/*     */     
/* 258 */     StringReader sr = new StringReader(this.formula);
/* 259 */     Yylex lex = new Yylex(sr);
/* 260 */     lex.setExternalSheet(this.externalSheet);
/* 261 */     lex.setNameTable(this.nameTable);
/*     */     
/*     */     try {
/* 264 */       ParseItem pi = lex.yylex();
/* 265 */       while (pi != null)
/*     */       {
/* 267 */         tokens.add(pi);
/* 268 */         pi = lex.yylex();
/*     */       }
/*     */     
/* 271 */     } catch (IOException e) {
/*     */       
/* 273 */       logger.warn(e.toString());
/*     */     }
/* 275 */     catch (Error e) {
/*     */       
/* 277 */       throw new FormulaException(FormulaException.lexicalError, this.formula + " at char  " + lex.getPos());
/*     */     } 
/*     */ 
/*     */     
/* 281 */     return tokens;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormula() {
/* 290 */     if (this.parsedFormula == null) {
/*     */       
/* 292 */       StringBuffer sb = new StringBuffer();
/* 293 */       this.root.getString(sb);
/* 294 */       this.parsedFormula = sb.toString();
/*     */     } 
/*     */     
/* 297 */     return this.parsedFormula;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/* 307 */     byte[] bytes = this.root.getBytes();
/*     */     
/* 309 */     if (this.root.isVolatile()) {
/*     */       
/* 311 */       byte[] newBytes = new byte[bytes.length + 4];
/* 312 */       System.arraycopy(bytes, 0, newBytes, 4, bytes.length);
/* 313 */       newBytes[0] = Token.ATTRIBUTE.getCode();
/* 314 */       newBytes[1] = 1;
/* 315 */       bytes = newBytes;
/*     */     } 
/*     */     
/* 318 */     return bytes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleFunction(StringFunction sf, Iterator i, Stack stack) throws FormulaException {
/* 333 */     ParseItem pi2 = parseCurrent(i);
/*     */ 
/*     */     
/* 336 */     if (sf.getFunction(this.settings) == Function.UNKNOWN)
/*     */     {
/* 338 */       throw new FormulaException(FormulaException.unrecognizedFunction);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 343 */     if (sf.getFunction(this.settings) == Function.SUM && this.arguments == null) {
/*     */ 
/*     */       
/* 346 */       Attribute a = new Attribute(sf, this.settings);
/* 347 */       a.add(pi2);
/* 348 */       stack.push(a);
/*     */       
/*     */       return;
/*     */     } 
/* 352 */     if (sf.getFunction(this.settings) == Function.IF) {
/*     */ 
/*     */       
/* 355 */       Attribute a = new Attribute(sf, this.settings);
/*     */ 
/*     */ 
/*     */       
/* 359 */       VariableArgFunction vaf = new VariableArgFunction(this.settings);
/* 360 */       int k = this.arguments.size();
/* 361 */       for (int j = 0; j < k; j++) {
/*     */         
/* 363 */         ParseItem pi3 = this.arguments.get(j);
/* 364 */         vaf.add(pi3);
/*     */       } 
/*     */       
/* 367 */       a.setIfConditions(vaf);
/* 368 */       stack.push(a);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 374 */     if (sf.getFunction(this.settings).getNumArgs() == 255) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 379 */       if (this.arguments == null) {
/*     */         
/* 381 */         int numArgs = (pi2 != null) ? 1 : 0;
/* 382 */         VariableArgFunction vaf = new VariableArgFunction(sf.getFunction(this.settings), numArgs, this.settings);
/*     */ 
/*     */         
/* 385 */         if (pi2 != null)
/*     */         {
/* 387 */           vaf.add(pi2);
/*     */         }
/*     */         
/* 390 */         stack.push(vaf);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 395 */         int k = this.arguments.size();
/* 396 */         VariableArgFunction vaf = new VariableArgFunction(sf.getFunction(this.settings), k, this.settings);
/*     */ 
/*     */         
/* 399 */         ParseItem[] args = new ParseItem[k]; int j;
/* 400 */         for (j = 0; j < k; j++) {
/*     */           
/* 402 */           ParseItem pi3 = this.arguments.pop();
/* 403 */           args[k - j - 1] = pi3;
/*     */         } 
/*     */         
/* 406 */         for (j = 0; j < args.length; j++)
/*     */         {
/* 408 */           vaf.add(args[j]);
/*     */         }
/* 410 */         stack.push(vaf);
/* 411 */         this.arguments.clear();
/* 412 */         this.arguments = null;
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 418 */     BuiltInFunction bif = new BuiltInFunction(sf.getFunction(this.settings), this.settings);
/*     */ 
/*     */     
/* 421 */     int numargs = sf.getFunction(this.settings).getNumArgs();
/* 422 */     if (numargs == 1) {
/*     */ 
/*     */       
/* 425 */       bif.add(pi2);
/*     */     }
/*     */     else {
/*     */       
/* 429 */       if ((this.arguments == null && numargs != 0) || (this.arguments != null && numargs != this.arguments.size()))
/*     */       {
/*     */         
/* 432 */         throw new FormulaException(FormulaException.incorrectArguments);
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 437 */       for (int j = 0; j < numargs; j++) {
/*     */         
/* 439 */         ParseItem pi3 = this.arguments.get(j);
/* 440 */         bif.add(pi3);
/*     */       } 
/*     */     } 
/* 443 */     stack.push(bif);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/* 454 */     this.root.adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/* 469 */     this.root.columnInserted(sheetIndex, col, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 485 */     this.root.columnRemoved(sheetIndex, col, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rowInserted(int sheetIndex, int row, boolean currentSheet) {
/* 500 */     this.root.rowInserted(sheetIndex, row, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rowRemoved(int sheetIndex, int row, boolean currentSheet) {
/* 515 */     this.root.rowRemoved(sheetIndex, row, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleOperand(Operand o, Stack stack) {
/* 526 */     if (!(o instanceof IntegerValue)) {
/*     */       
/* 528 */       stack.push(o);
/*     */       
/*     */       return;
/*     */     } 
/* 532 */     if (o instanceof IntegerValue) {
/*     */       
/* 534 */       IntegerValue iv = (IntegerValue)o;
/* 535 */       if (!iv.isOutOfRange()) {
/*     */         
/* 537 */         stack.push(iv);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 542 */         DoubleValue dv = new DoubleValue(iv.getValue());
/* 543 */         stack.push(dv);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\StringFormulaParser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
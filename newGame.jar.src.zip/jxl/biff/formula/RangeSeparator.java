/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RangeSeparator
/*    */   extends BinaryOperator
/*    */   implements ParsedThing
/*    */ {
/*    */   public String getSymbol() {
/* 42 */     return ":";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Token getToken() {
/* 52 */     return Token.RANGE;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   int getPrecedence() {
/* 63 */     return 1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getBytes() {
/* 74 */     setVolatile();
/* 75 */     setOperandAlternateCode();
/*    */     
/* 77 */     byte[] funcBytes = super.getBytes();
/*    */     
/* 79 */     byte[] bytes = new byte[funcBytes.length + 3];
/* 80 */     System.arraycopy(funcBytes, 0, bytes, 3, funcBytes.length);
/*    */ 
/*    */     
/* 83 */     bytes[0] = Token.MEM_FUNC.getCode();
/* 84 */     IntegerHelper.getTwoBytes(funcBytes.length, bytes, 1);
/*    */     
/* 86 */     return bytes;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\RangeSeparator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
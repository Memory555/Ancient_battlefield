/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.util.Stack;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Attribute
/*     */   extends Operator
/*     */   implements ParsedThing
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(Attribute.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private int options;
/*     */ 
/*     */ 
/*     */   
/*     */   private int word;
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings settings;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int sumMask = 16;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int ifMask = 2;
/*     */ 
/*     */   
/*     */   private static final int gotoMask = 8;
/*     */ 
/*     */   
/*     */   private VariableArgFunction ifConditions;
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute(WorkbookSettings ws) {
/*  71 */     this.settings = ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attribute(StringFunction sf, WorkbookSettings ws) {
/*  82 */     this.settings = ws;
/*     */     
/*  84 */     if (sf.getFunction(this.settings) == Function.SUM) {
/*     */       
/*  86 */       this.options |= 0x10;
/*     */     }
/*  88 */     else if (sf.getFunction(this.settings) == Function.IF) {
/*     */       
/*  90 */       this.options |= 0x2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setIfConditions(VariableArgFunction vaf) {
/* 101 */     this.ifConditions = vaf;
/*     */ 
/*     */ 
/*     */     
/* 105 */     this.options |= 0x2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/* 117 */     this.options = data[pos];
/* 118 */     this.word = IntegerHelper.getInt(data[pos + 1], data[pos + 2]);
/* 119 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFunction() {
/* 129 */     return ((this.options & 0x12) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSum() {
/* 139 */     return ((this.options & 0x10) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIf() {
/* 149 */     return ((this.options & 0x2) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isGoto() {
/* 159 */     return ((this.options & 0x8) != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getOperands(Stack s) {
/* 167 */     if ((this.options & 0x10) != 0) {
/*     */       
/* 169 */       ParseItem o1 = s.pop();
/*     */       
/* 171 */       add(o1);
/*     */     }
/* 173 */     else if ((this.options & 0x2) != 0) {
/*     */       
/* 175 */       ParseItem o1 = s.pop();
/* 176 */       add(o1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/* 182 */     if ((this.options & 0x10) != 0) {
/*     */       
/* 184 */       ParseItem[] operands = getOperands();
/* 185 */       buf.append(Function.SUM.getName(this.settings));
/* 186 */       buf.append('(');
/* 187 */       operands[0].getString(buf);
/* 188 */       buf.append(')');
/*     */     }
/* 190 */     else if ((this.options & 0x2) != 0) {
/*     */       
/* 192 */       buf.append(Function.IF.getName(this.settings));
/* 193 */       buf.append('(');
/*     */       
/* 195 */       ParseItem[] operands = this.ifConditions.getOperands();
/*     */ 
/*     */       
/* 198 */       for (int i = 0; i < operands.length - 1; i++) {
/*     */         
/* 200 */         operands[i].getString(buf);
/* 201 */         buf.append(',');
/*     */       } 
/* 203 */       operands[operands.length - 1].getString(buf);
/* 204 */       buf.append(')');
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 217 */     byte[] data = new byte[0];
/* 218 */     if (isSum()) {
/*     */ 
/*     */       
/* 221 */       ParseItem[] operands = getOperands();
/*     */ 
/*     */       
/* 224 */       for (int i = operands.length - 1; i >= 0; i--) {
/*     */         
/* 226 */         byte[] opdata = operands[i].getBytes();
/*     */ 
/*     */         
/* 229 */         byte[] arrayOfByte1 = new byte[data.length + opdata.length];
/* 230 */         System.arraycopy(data, 0, arrayOfByte1, 0, data.length);
/* 231 */         System.arraycopy(opdata, 0, arrayOfByte1, data.length, opdata.length);
/* 232 */         data = arrayOfByte1;
/*     */       } 
/*     */ 
/*     */       
/* 236 */       byte[] newdata = new byte[data.length + 4];
/* 237 */       System.arraycopy(data, 0, newdata, 0, data.length);
/* 238 */       newdata[data.length] = Token.ATTRIBUTE.getCode();
/* 239 */       newdata[data.length + 1] = 16;
/* 240 */       data = newdata;
/*     */     }
/* 242 */     else if (isIf()) {
/*     */       
/* 244 */       return getIf();
/*     */     } 
/*     */     
/* 247 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getIf() {
/* 257 */     ParseItem[] operands = this.ifConditions.getOperands();
/*     */ 
/*     */     
/* 260 */     int falseOffsetPos = 0;
/* 261 */     int gotoEndPos = 0;
/* 262 */     int numArgs = operands.length;
/*     */ 
/*     */     
/* 265 */     byte[] data = operands[0].getBytes();
/*     */ 
/*     */     
/* 268 */     int pos = data.length;
/* 269 */     byte[] newdata = new byte[data.length + 4];
/* 270 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 271 */     data = newdata;
/* 272 */     data[pos] = Token.ATTRIBUTE.getCode();
/* 273 */     data[pos + 1] = 2;
/* 274 */     falseOffsetPos = pos + 2;
/*     */ 
/*     */     
/* 277 */     byte[] truedata = operands[1].getBytes();
/* 278 */     newdata = new byte[data.length + truedata.length];
/* 279 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 280 */     System.arraycopy(truedata, 0, newdata, data.length, truedata.length);
/* 281 */     data = newdata;
/*     */ 
/*     */     
/* 284 */     pos = data.length;
/* 285 */     newdata = new byte[data.length + 4];
/* 286 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 287 */     data = newdata;
/* 288 */     data[pos] = Token.ATTRIBUTE.getCode();
/* 289 */     data[pos + 1] = 8;
/* 290 */     gotoEndPos = pos + 2;
/*     */ 
/*     */     
/* 293 */     if (numArgs > 2) {
/*     */ 
/*     */       
/* 296 */       IntegerHelper.getTwoBytes(data.length - falseOffsetPos - 2, data, falseOffsetPos);
/*     */ 
/*     */ 
/*     */       
/* 300 */       byte[] falsedata = operands[numArgs - 1].getBytes();
/* 301 */       newdata = new byte[data.length + falsedata.length];
/* 302 */       System.arraycopy(data, 0, newdata, 0, data.length);
/* 303 */       System.arraycopy(falsedata, 0, newdata, data.length, falsedata.length);
/* 304 */       data = newdata;
/*     */ 
/*     */       
/* 307 */       pos = data.length;
/* 308 */       newdata = new byte[data.length + 4];
/* 309 */       System.arraycopy(data, 0, newdata, 0, data.length);
/* 310 */       data = newdata;
/* 311 */       data[pos] = Token.ATTRIBUTE.getCode();
/* 312 */       data[pos + 1] = 8;
/* 313 */       data[pos + 2] = 3;
/*     */     } 
/*     */ 
/*     */     
/* 317 */     pos = data.length;
/* 318 */     newdata = new byte[data.length + 4];
/* 319 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 320 */     data = newdata;
/* 321 */     data[pos] = Token.FUNCTIONVARARG.getCode();
/* 322 */     data[pos + 1] = (byte)numArgs;
/* 323 */     data[pos + 2] = 1;
/* 324 */     data[pos + 3] = 0;
/*     */ 
/*     */     
/* 327 */     int endPos = data.length - 1;
/*     */     
/* 329 */     if (numArgs < 3)
/*     */     {
/*     */       
/* 332 */       IntegerHelper.getTwoBytes(endPos - falseOffsetPos - 5, data, falseOffsetPos);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 337 */     IntegerHelper.getTwoBytes(endPos - gotoEndPos - 2, data, gotoEndPos);
/*     */ 
/*     */     
/* 340 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getPrecedence() {
/* 351 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/* 362 */     ParseItem[] operands = null;
/*     */     
/* 364 */     if (isIf()) {
/*     */       
/* 366 */       operands = this.ifConditions.getOperands();
/*     */     }
/*     */     else {
/*     */       
/* 370 */       operands = getOperands();
/*     */     } 
/*     */     
/* 373 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 375 */       operands[i].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/* 391 */     ParseItem[] operands = null;
/*     */     
/* 393 */     if (isIf()) {
/*     */       
/* 395 */       operands = this.ifConditions.getOperands();
/*     */     }
/*     */     else {
/*     */       
/* 399 */       operands = getOperands();
/*     */     } 
/*     */     
/* 402 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 404 */       operands[i].columnInserted(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 420 */     ParseItem[] operands = null;
/*     */     
/* 422 */     if (isIf()) {
/*     */       
/* 424 */       operands = this.ifConditions.getOperands();
/*     */     }
/*     */     else {
/*     */       
/* 428 */       operands = getOperands();
/*     */     } 
/*     */     
/* 431 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 433 */       operands[i].columnRemoved(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet) {
/* 449 */     ParseItem[] operands = null;
/*     */     
/* 451 */     if (isIf()) {
/*     */       
/* 453 */       operands = this.ifConditions.getOperands();
/*     */     }
/*     */     else {
/*     */       
/* 457 */       operands = getOperands();
/*     */     } 
/*     */     
/* 460 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 462 */       operands[i].rowInserted(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet) {
/* 478 */     ParseItem[] operands = null;
/*     */     
/* 480 */     if (isIf()) {
/*     */       
/* 482 */       operands = this.ifConditions.getOperands();
/*     */     }
/*     */     else {
/*     */       
/* 486 */       operands = getOperands();
/*     */     } 
/*     */     
/* 489 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 491 */       operands[i].rowRemoved(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\Attribute.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import java.util.Stack;
/*     */ import jxl.Cell;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TokenFormulaParser
/*     */   implements Parser
/*     */ {
/*  39 */   private static Logger logger = Logger.getLogger(TokenFormulaParser.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] tokenData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Cell relativeTo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int pos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ParseItem root;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Stack tokenStack;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExternalSheet workbook;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookMethods nameTable;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings settings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenFormulaParser(byte[] data, Cell c, ExternalSheet es, WorkbookMethods nt, WorkbookSettings ws) {
/*  90 */     this.tokenData = data;
/*  91 */     this.pos = 0;
/*  92 */     this.relativeTo = c;
/*  93 */     this.workbook = es;
/*  94 */     this.nameTable = nt;
/*  95 */     this.tokenStack = new Stack();
/*  96 */     this.settings = ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse() throws FormulaException {
/* 107 */     parseSubExpression(this.tokenData.length);
/*     */ 
/*     */ 
/*     */     
/* 111 */     this.root = this.tokenStack.pop();
/*     */     
/* 113 */     Assert.verify(this.tokenStack.empty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseSubExpression(int len) throws FormulaException {
/* 126 */     int tokenVal = 0;
/* 127 */     Token t = null;
/*     */ 
/*     */ 
/*     */     
/* 131 */     Stack ifStack = new Stack();
/*     */ 
/*     */     
/* 134 */     int endpos = this.pos + len;
/*     */     
/* 136 */     while (this.pos < endpos) {
/*     */       
/* 138 */       tokenVal = this.tokenData[this.pos];
/* 139 */       this.pos++;
/*     */       
/* 141 */       t = Token.getToken(tokenVal);
/*     */       
/* 143 */       if (t == Token.UNKNOWN)
/*     */       {
/* 145 */         throw new FormulaException(FormulaException.unrecognizedToken, tokenVal);
/*     */       }
/*     */ 
/*     */       
/* 149 */       Assert.verify((t != Token.UNKNOWN));
/*     */ 
/*     */       
/* 152 */       if (t == Token.REF) {
/*     */         
/* 154 */         CellReference cr = new CellReference(this.relativeTo);
/* 155 */         this.pos += cr.read(this.tokenData, this.pos);
/* 156 */         this.tokenStack.push(cr); continue;
/*     */       } 
/* 158 */       if (t == Token.REFV) {
/*     */         
/* 160 */         SharedFormulaCellReference cr = new SharedFormulaCellReference(this.relativeTo);
/*     */         
/* 162 */         this.pos += cr.read(this.tokenData, this.pos);
/* 163 */         this.tokenStack.push(cr); continue;
/*     */       } 
/* 165 */       if (t == Token.REF3D) {
/*     */         
/* 167 */         CellReference3d cr = new CellReference3d(this.relativeTo, this.workbook);
/* 168 */         this.pos += cr.read(this.tokenData, this.pos);
/* 169 */         this.tokenStack.push(cr); continue;
/*     */       } 
/* 171 */       if (t == Token.AREA) {
/*     */         
/* 173 */         Area a = new Area();
/* 174 */         this.pos += a.read(this.tokenData, this.pos);
/* 175 */         this.tokenStack.push(a); continue;
/*     */       } 
/* 177 */       if (t == Token.AREAV) {
/*     */         
/* 179 */         SharedFormulaArea a = new SharedFormulaArea(this.relativeTo);
/* 180 */         this.pos += a.read(this.tokenData, this.pos);
/* 181 */         this.tokenStack.push(a); continue;
/*     */       } 
/* 183 */       if (t == Token.AREA3D) {
/*     */         
/* 185 */         Area3d a = new Area3d(this.workbook);
/* 186 */         this.pos += a.read(this.tokenData, this.pos);
/* 187 */         this.tokenStack.push(a); continue;
/*     */       } 
/* 189 */       if (t == Token.NAME) {
/*     */         
/* 191 */         Name n = new Name();
/* 192 */         this.pos += n.read(this.tokenData, this.pos);
/* 193 */         this.tokenStack.push(n); continue;
/*     */       } 
/* 195 */       if (t == Token.NAMED_RANGE) {
/*     */         
/* 197 */         NameRange nr = new NameRange(this.nameTable);
/* 198 */         this.pos += nr.read(this.tokenData, this.pos);
/* 199 */         this.tokenStack.push(nr); continue;
/*     */       } 
/* 201 */       if (t == Token.INTEGER) {
/*     */         
/* 203 */         IntegerValue i = new IntegerValue();
/* 204 */         this.pos += i.read(this.tokenData, this.pos);
/* 205 */         this.tokenStack.push(i); continue;
/*     */       } 
/* 207 */       if (t == Token.DOUBLE) {
/*     */         
/* 209 */         DoubleValue d = new DoubleValue();
/* 210 */         this.pos += d.read(this.tokenData, this.pos);
/* 211 */         this.tokenStack.push(d); continue;
/*     */       } 
/* 213 */       if (t == Token.BOOL) {
/*     */         
/* 215 */         BooleanValue bv = new BooleanValue();
/* 216 */         this.pos += bv.read(this.tokenData, this.pos);
/* 217 */         this.tokenStack.push(bv); continue;
/*     */       } 
/* 219 */       if (t == Token.STRING) {
/*     */         
/* 221 */         StringValue sv = new StringValue(this.settings);
/* 222 */         this.pos += sv.read(this.tokenData, this.pos);
/* 223 */         this.tokenStack.push(sv); continue;
/*     */       } 
/* 225 */       if (t == Token.MISSING_ARG) {
/*     */         
/* 227 */         MissingArg ma = new MissingArg();
/* 228 */         this.pos += ma.read(this.tokenData, this.pos);
/* 229 */         this.tokenStack.push(ma);
/*     */         
/*     */         continue;
/*     */       } 
/* 233 */       if (t == Token.UNARY_PLUS) {
/*     */         
/* 235 */         UnaryPlus up = new UnaryPlus();
/* 236 */         this.pos += up.read(this.tokenData, this.pos);
/* 237 */         addOperator(up); continue;
/*     */       } 
/* 239 */       if (t == Token.UNARY_MINUS) {
/*     */         
/* 241 */         UnaryMinus um = new UnaryMinus();
/* 242 */         this.pos += um.read(this.tokenData, this.pos);
/* 243 */         addOperator(um); continue;
/*     */       } 
/* 245 */       if (t == Token.PERCENT) {
/*     */         
/* 247 */         Percent p = new Percent();
/* 248 */         this.pos += p.read(this.tokenData, this.pos);
/* 249 */         addOperator(p);
/*     */         
/*     */         continue;
/*     */       } 
/* 253 */       if (t == Token.SUBTRACT) {
/*     */         
/* 255 */         Subtract s = new Subtract();
/* 256 */         this.pos += s.read(this.tokenData, this.pos);
/* 257 */         addOperator(s); continue;
/*     */       } 
/* 259 */       if (t == Token.ADD) {
/*     */         
/* 261 */         Add s = new Add();
/* 262 */         this.pos += s.read(this.tokenData, this.pos);
/* 263 */         addOperator(s); continue;
/*     */       } 
/* 265 */       if (t == Token.MULTIPLY) {
/*     */         
/* 267 */         Multiply s = new Multiply();
/* 268 */         this.pos += s.read(this.tokenData, this.pos);
/* 269 */         addOperator(s); continue;
/*     */       } 
/* 271 */       if (t == Token.DIVIDE) {
/*     */         
/* 273 */         Divide s = new Divide();
/* 274 */         this.pos += s.read(this.tokenData, this.pos);
/* 275 */         addOperator(s); continue;
/*     */       } 
/* 277 */       if (t == Token.CONCAT) {
/*     */         
/* 279 */         Concatenate c = new Concatenate();
/* 280 */         this.pos += c.read(this.tokenData, this.pos);
/* 281 */         addOperator(c); continue;
/*     */       } 
/* 283 */       if (t == Token.POWER) {
/*     */         
/* 285 */         Power p = new Power();
/* 286 */         this.pos += p.read(this.tokenData, this.pos);
/* 287 */         addOperator(p); continue;
/*     */       } 
/* 289 */       if (t == Token.LESS_THAN) {
/*     */         
/* 291 */         LessThan lt = new LessThan();
/* 292 */         this.pos += lt.read(this.tokenData, this.pos);
/* 293 */         addOperator(lt); continue;
/*     */       } 
/* 295 */       if (t == Token.LESS_EQUAL) {
/*     */         
/* 297 */         LessEqual lte = new LessEqual();
/* 298 */         this.pos += lte.read(this.tokenData, this.pos);
/* 299 */         addOperator(lte); continue;
/*     */       } 
/* 301 */       if (t == Token.GREATER_THAN) {
/*     */         
/* 303 */         GreaterThan gt = new GreaterThan();
/* 304 */         this.pos += gt.read(this.tokenData, this.pos);
/* 305 */         addOperator(gt); continue;
/*     */       } 
/* 307 */       if (t == Token.GREATER_EQUAL) {
/*     */         
/* 309 */         GreaterEqual gte = new GreaterEqual();
/* 310 */         this.pos += gte.read(this.tokenData, this.pos);
/* 311 */         addOperator(gte); continue;
/*     */       } 
/* 313 */       if (t == Token.NOT_EQUAL) {
/*     */         
/* 315 */         NotEqual ne = new NotEqual();
/* 316 */         this.pos += ne.read(this.tokenData, this.pos);
/* 317 */         addOperator(ne); continue;
/*     */       } 
/* 319 */       if (t == Token.EQUAL) {
/*     */         
/* 321 */         Equal e = new Equal();
/* 322 */         this.pos += e.read(this.tokenData, this.pos);
/* 323 */         addOperator(e); continue;
/*     */       } 
/* 325 */       if (t == Token.PARENTHESIS) {
/*     */         
/* 327 */         Parenthesis p = new Parenthesis();
/* 328 */         this.pos += p.read(this.tokenData, this.pos);
/* 329 */         addOperator(p);
/*     */         
/*     */         continue;
/*     */       } 
/* 333 */       if (t == Token.ATTRIBUTE) {
/*     */         
/* 335 */         Attribute a = new Attribute(this.settings);
/* 336 */         this.pos += a.read(this.tokenData, this.pos);
/*     */         
/* 338 */         if (a.isSum()) {
/*     */           
/* 340 */           addOperator(a); continue;
/*     */         } 
/* 342 */         if (a.isIf())
/*     */         {
/*     */           
/* 345 */           ifStack.push(a); } 
/*     */         continue;
/*     */       } 
/* 348 */       if (t == Token.FUNCTION) {
/*     */         
/* 350 */         BuiltInFunction bif = new BuiltInFunction(this.settings);
/* 351 */         this.pos += bif.read(this.tokenData, this.pos);
/*     */         
/* 353 */         addOperator(bif); continue;
/*     */       } 
/* 355 */       if (t == Token.FUNCTIONVARARG) {
/*     */         
/* 357 */         VariableArgFunction vaf = new VariableArgFunction(this.settings);
/* 358 */         this.pos += vaf.read(this.tokenData, this.pos);
/*     */         
/* 360 */         if (vaf.getFunction() != Function.ATTRIBUTE) {
/*     */           
/* 362 */           addOperator(vaf);
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 368 */         vaf.getOperands(this.tokenStack);
/*     */         
/* 370 */         Attribute ifattr = null;
/* 371 */         if (ifStack.empty()) {
/*     */           
/* 373 */           ifattr = new Attribute(this.settings);
/*     */         }
/*     */         else {
/*     */           
/* 377 */           ifattr = ifStack.pop();
/*     */         } 
/*     */         
/* 380 */         ifattr.setIfConditions(vaf);
/* 381 */         this.tokenStack.push(ifattr);
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 386 */       if (t == Token.MEM_FUNC) {
/*     */         
/* 388 */         MemFunc memFunc = new MemFunc();
/* 389 */         this.pos += memFunc.read(this.tokenData, this.pos);
/*     */ 
/*     */         
/* 392 */         Stack oldStack = this.tokenStack;
/* 393 */         this.tokenStack = new Stack();
/*     */         
/* 395 */         parseSubExpression(memFunc.getLength());
/*     */         
/* 397 */         ParseItem[] subexpr = new ParseItem[this.tokenStack.size()];
/* 398 */         int i = 0;
/* 399 */         while (!this.tokenStack.isEmpty()) {
/*     */           
/* 401 */           subexpr[i] = this.tokenStack.pop();
/* 402 */           i++;
/*     */         } 
/*     */         
/* 405 */         memFunc.setSubExpression(subexpr);
/*     */         
/* 407 */         this.tokenStack = oldStack;
/* 408 */         this.tokenStack.push(memFunc);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addOperator(Operator o) {
/* 420 */     o.getOperands(this.tokenStack);
/*     */ 
/*     */     
/* 423 */     this.tokenStack.push(o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormula() {
/* 431 */     StringBuffer sb = new StringBuffer();
/* 432 */     this.root.getString(sb);
/* 433 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/* 445 */     this.root.adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes() {
/* 456 */     return this.root.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/* 471 */     this.root.columnInserted(sheetIndex, col, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 485 */     this.root.columnRemoved(sheetIndex, col, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rowInserted(int sheetIndex, int row, boolean currentSheet) {
/* 500 */     this.root.rowInserted(sheetIndex, row, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rowRemoved(int sheetIndex, int row, boolean currentSheet) {
/* 515 */     this.root.rowRemoved(sheetIndex, row, currentSheet);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\TokenFormulaParser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
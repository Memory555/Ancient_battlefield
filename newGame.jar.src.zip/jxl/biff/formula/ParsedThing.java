package jxl.biff.formula;

interface ParsedThing {
  int read(byte[] paramArrayOfbyte, int paramInt) throws FormulaException;
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\ParsedThing.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IntegerValue
/*     */   extends NumberValue
/*     */   implements ParsedThing
/*     */ {
/*  35 */   private static Logger logger = Logger.getLogger(IntegerValue.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean outOfRange;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerValue() {
/*  52 */     this.outOfRange = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntegerValue(String s) {
/*     */     try {
/*  62 */       this.value = Integer.parseInt(s);
/*     */     }
/*  64 */     catch (NumberFormatException e) {
/*     */       
/*  66 */       logger.warn(e, e);
/*  67 */       this.value = 0.0D;
/*     */     } 
/*     */     
/*  70 */     short v = (short)(int)this.value;
/*  71 */     this.outOfRange = (this.value != v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/*  83 */     this.value = IntegerHelper.getInt(data[pos], data[pos + 1]);
/*     */     
/*  85 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/*  95 */     byte[] data = new byte[3];
/*  96 */     data[0] = Token.INTEGER.getCode();
/*     */     
/*  98 */     IntegerHelper.getTwoBytes((int)this.value, data, 1);
/*     */     
/* 100 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue() {
/* 110 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isOutOfRange() {
/* 120 */     return this.outOfRange;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\IntegerValue.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
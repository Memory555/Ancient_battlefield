/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Power
/*    */   extends BinaryOperator
/*    */   implements ParsedThing
/*    */ {
/*    */   public String getSymbol() {
/* 40 */     return "^";
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Token getToken() {
/* 50 */     return Token.POWER;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   int getPrecedence() {
/* 61 */     return 1;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\Power.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.util.Stack;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class VariableArgFunction
/*     */   extends Operator
/*     */   implements ParsedThing
/*     */ {
/*  39 */   private static Logger logger = Logger.getLogger(VariableArgFunction.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Function function;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int arguments;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean readFromSheet;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings settings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VariableArgFunction(WorkbookSettings ws) {
/*  67 */     this.readFromSheet = true;
/*  68 */     this.settings = ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public VariableArgFunction(Function f, int a, WorkbookSettings ws) {
/*  79 */     this.function = f;
/*  80 */     this.arguments = a;
/*  81 */     this.readFromSheet = false;
/*  82 */     this.settings = ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) throws FormulaException {
/*  95 */     this.arguments = data[pos];
/*  96 */     int index = IntegerHelper.getInt(data[pos + 1], data[pos + 2]);
/*  97 */     this.function = Function.getFunction(index);
/*     */     
/*  99 */     if (this.function == Function.UNKNOWN)
/*     */     {
/* 101 */       throw new FormulaException(FormulaException.unrecognizedFunction, index);
/*     */     }
/*     */     
/* 104 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getOperands(Stack s) {
/* 113 */     ParseItem[] items = new ParseItem[this.arguments];
/*     */     int i;
/* 115 */     for (i = this.arguments - 1; i >= 0; i--) {
/*     */       
/* 117 */       ParseItem pi = s.pop();
/*     */       
/* 119 */       items[i] = pi;
/*     */     } 
/*     */     
/* 122 */     for (i = 0; i < this.arguments; i++)
/*     */     {
/* 124 */       add(items[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/* 130 */     buf.append(this.function.getName(this.settings));
/* 131 */     buf.append('(');
/*     */     
/* 133 */     if (this.arguments > 0) {
/*     */       
/* 135 */       ParseItem[] operands = getOperands();
/* 136 */       if (this.readFromSheet) {
/*     */ 
/*     */         
/* 139 */         operands[0].getString(buf);
/*     */         
/* 141 */         for (int i = 1; i < this.arguments; i++)
/*     */         {
/* 143 */           buf.append(',');
/* 144 */           operands[i].getString(buf);
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 151 */         operands[this.arguments - 1].getString(buf);
/*     */         
/* 153 */         for (int i = this.arguments - 2; i >= 0; i--) {
/*     */           
/* 155 */           buf.append(',');
/* 156 */           operands[i].getString(buf);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 161 */     buf.append(')');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/* 173 */     ParseItem[] operands = getOperands();
/*     */     
/* 175 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 177 */       operands[i].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/* 193 */     ParseItem[] operands = getOperands();
/* 194 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 196 */       operands[i].columnInserted(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 212 */     ParseItem[] operands = getOperands();
/* 213 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 215 */       operands[i].columnRemoved(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet) {
/* 231 */     ParseItem[] operands = getOperands();
/* 232 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 234 */       operands[i].rowInserted(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet) {
/* 250 */     ParseItem[] operands = getOperands();
/* 251 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 253 */       operands[i].rowRemoved(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Function getFunction() {
/* 262 */     return this.function;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 272 */     handleSpecialCases();
/*     */ 
/*     */     
/* 275 */     ParseItem[] operands = getOperands();
/* 276 */     byte[] data = new byte[0];
/*     */     
/* 278 */     for (int i = 0; i < operands.length; i++) {
/*     */       
/* 280 */       byte[] opdata = operands[i].getBytes();
/*     */ 
/*     */       
/* 283 */       byte[] arrayOfByte1 = new byte[data.length + opdata.length];
/* 284 */       System.arraycopy(data, 0, arrayOfByte1, 0, data.length);
/* 285 */       System.arraycopy(opdata, 0, arrayOfByte1, data.length, opdata.length);
/* 286 */       data = arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 290 */     byte[] newdata = new byte[data.length + 4];
/* 291 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 292 */     newdata[data.length] = !useAlternateCode() ? Token.FUNCTIONVARARG.getCode() : Token.FUNCTIONVARARG.getCode2();
/*     */     
/* 294 */     newdata[data.length + 1] = (byte)this.arguments;
/* 295 */     IntegerHelper.getTwoBytes(this.function.getCode(), newdata, data.length + 2);
/*     */     
/* 297 */     return newdata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getPrecedence() {
/* 308 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleSpecialCases() {
/* 318 */     if (this.function == Function.SUMPRODUCT) {
/*     */ 
/*     */       
/* 321 */       ParseItem[] operands = getOperands();
/*     */       
/* 323 */       for (int i = operands.length - 1; i >= 0; i--) {
/*     */         
/* 325 */         if (operands[i] instanceof Area)
/*     */         {
/* 327 */           operands[i].setAlternateCode();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\VariableArgFunction.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
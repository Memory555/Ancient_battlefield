/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class NumberValue
/*    */   extends Operand
/*    */   implements ParsedThing
/*    */ {
/*    */   public abstract double getValue();
/*    */   
/*    */   public void getString(StringBuffer buf) {
/* 38 */     buf.append(Double.toString(getValue()));
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\NumberValue.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
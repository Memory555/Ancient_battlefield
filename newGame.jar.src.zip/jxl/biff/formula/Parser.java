package jxl.biff.formula;

interface Parser {
  void parse() throws FormulaException;
  
  String getFormula();
  
  byte[] getBytes();
  
  void adjustRelativeCellReferences(int paramInt1, int paramInt2);
  
  void columnInserted(int paramInt1, int paramInt2, boolean paramBoolean);
  
  void columnRemoved(int paramInt1, int paramInt2, boolean paramBoolean);
  
  void rowInserted(int paramInt1, int paramInt2, boolean paramBoolean);
  
  void rowRemoved(int paramInt1, int paramInt2, boolean paramBoolean);
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\Parser.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
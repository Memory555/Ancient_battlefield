/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import common.Logger;
/*    */ import jxl.WorkbookSettings;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class StringFunction
/*    */   extends StringParseItem
/*    */ {
/* 35 */   private static Logger logger = Logger.getLogger(StringFunction.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private Function function;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String functionString;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   StringFunction(String s) {
/* 54 */     this.functionString = s.substring(0, s.length() - 1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Function getFunction(WorkbookSettings ws) {
/* 65 */     if (this.function == null)
/*    */     {
/* 67 */       this.function = Function.getFunction(this.functionString, ws);
/*    */     }
/* 69 */     return this.function;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\StringFunction.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
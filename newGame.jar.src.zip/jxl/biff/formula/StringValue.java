/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StringValue
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  37 */   private static final Logger logger = Logger.getLogger(StringValue.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings settings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringValue(WorkbookSettings ws) {
/*  54 */     this.settings = ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringValue(String s) {
/*  65 */     this.value = s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/*  77 */     int length = IntegerHelper.getInt(data[pos], data[pos + 1]);
/*  78 */     int consumed = 2;
/*     */     
/*  80 */     if ((data[pos + 1] & 0x1) == 0) {
/*     */       
/*  82 */       this.value = StringHelper.getString(data, length, pos + 2, this.settings);
/*  83 */       consumed += length;
/*     */     }
/*     */     else {
/*     */       
/*  87 */       this.value = StringHelper.getUnicodeString(data, length, pos + 2);
/*  88 */       consumed += length * 2;
/*     */     } 
/*     */     
/*  91 */     return consumed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 101 */     byte[] data = new byte[this.value.length() * 2 + 3];
/* 102 */     data[0] = Token.STRING.getCode();
/* 103 */     data[1] = (byte)this.value.length();
/* 104 */     data[2] = 1;
/* 105 */     StringHelper.getUnicodeBytes(this.value, data, 3);
/*     */     
/* 107 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/* 118 */     buf.append("\"");
/* 119 */     buf.append(this.value);
/* 120 */     buf.append("\"");
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\StringValue.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.Cell;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CellReference3d
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*  36 */   private static Logger logger = Logger.getLogger(CellReference3d.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean columnRelative;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean rowRelative;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Cell relativeTo;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int sheet;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExternalSheet workbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellReference3d(Cell rt, ExternalSheet w) {
/*  82 */     this.relativeTo = rt;
/*  83 */     this.workbook = w;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellReference3d(String s, ExternalSheet w) throws FormulaException {
/*  95 */     this.workbook = w;
/*  96 */     this.columnRelative = true;
/*  97 */     this.rowRelative = true;
/*     */ 
/*     */     
/* 100 */     int sep = s.indexOf('!');
/* 101 */     String cellString = s.substring(sep + 1);
/* 102 */     this.column = CellReferenceHelper.getColumn(cellString);
/* 103 */     this.row = CellReferenceHelper.getRow(cellString);
/*     */ 
/*     */     
/* 106 */     String sheetName = s.substring(0, sep);
/*     */ 
/*     */     
/* 109 */     if (sheetName.charAt(0) == '\'' && sheetName.charAt(sheetName.length() - 1) == '\'')
/*     */     {
/*     */       
/* 112 */       sheetName = sheetName.substring(1, sheetName.length() - 1);
/*     */     }
/* 114 */     this.sheet = w.getExternalSheetIndex(sheetName);
/*     */     
/* 116 */     if (this.sheet < 0)
/*     */     {
/* 118 */       throw new FormulaException(FormulaException.sheetRefNotFound, sheetName);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/* 131 */     this.sheet = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 132 */     this.row = IntegerHelper.getInt(data[pos + 2], data[pos + 3]);
/* 133 */     int columnMask = IntegerHelper.getInt(data[pos + 4], data[pos + 5]);
/* 134 */     this.column = columnMask & 0xFF;
/* 135 */     this.columnRelative = ((columnMask & 0x4000) != 0);
/* 136 */     this.rowRelative = ((columnMask & 0x8000) != 0);
/*     */     
/* 138 */     return 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 148 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRow() {
/* 158 */     return this.row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/* 168 */     CellReferenceHelper.getCellReference(this.sheet, this.column, !this.columnRelative, this.row, !this.rowRelative, this.workbook, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 180 */     byte[] data = new byte[7];
/* 181 */     data[0] = Token.REF3D.getCode();
/*     */     
/* 183 */     IntegerHelper.getTwoBytes(this.sheet, data, 1);
/* 184 */     IntegerHelper.getTwoBytes(this.row, data, 3);
/*     */     
/* 186 */     int grcol = this.column;
/*     */ 
/*     */     
/* 189 */     if (this.rowRelative)
/*     */     {
/* 191 */       grcol |= 0x8000;
/*     */     }
/*     */     
/* 194 */     if (this.columnRelative)
/*     */     {
/* 196 */       grcol |= 0x4000;
/*     */     }
/*     */     
/* 199 */     IntegerHelper.getTwoBytes(grcol, data, 5);
/*     */     
/* 201 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/* 213 */     if (this.columnRelative)
/*     */     {
/* 215 */       this.column += colAdjust;
/*     */     }
/*     */     
/* 218 */     if (this.rowRelative)
/*     */     {
/* 220 */       this.row += rowAdjust;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/* 236 */     if (sheetIndex != this.sheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 241 */     if (this.column >= col)
/*     */     {
/* 243 */       this.column++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 260 */     if (sheetIndex != this.sheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 265 */     if (this.column >= col)
/*     */     {
/* 267 */       this.column--;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(int sheetIndex, int r, boolean currentSheet) {
/* 283 */     if (sheetIndex != this.sheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 288 */     if (this.row >= r)
/*     */     {
/* 290 */       this.row++;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(int sheetIndex, int r, boolean currentSheet) {
/* 306 */     if (sheetIndex != this.sheet) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 311 */     if (this.row >= r)
/*     */     {
/* 313 */       this.row--;
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\CellReference3d.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import common.Logger;
/*    */ import java.util.HashMap;
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionNames
/*    */ {
/* 38 */   private static Logger logger = Logger.getLogger(FunctionNames.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private HashMap names;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private HashMap functions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FunctionNames(Locale l) {
/* 58 */     ResourceBundle rb = ResourceBundle.getBundle("functions", l);
/* 59 */     this.names = new HashMap(Function.functions.length);
/* 60 */     this.functions = new HashMap(Function.functions.length);
/*    */ 
/*    */     
/* 63 */     Function f = null;
/* 64 */     String n = null;
/* 65 */     String propname = null;
/* 66 */     for (int i = 0; i < Function.functions.length; i++) {
/*    */       
/* 68 */       f = Function.functions[i];
/* 69 */       propname = f.getPropertyName();
/*    */       
/* 71 */       n = (propname.length() != 0) ? rb.getString(propname) : null;
/*    */       
/* 73 */       if (n != null) {
/*    */         
/* 75 */         this.names.put(f, n);
/* 76 */         this.functions.put(n, f);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Function getFunction(String s) {
/* 86 */     return (Function)this.functions.get(s);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getName(Function f) {
/* 94 */     return (String)this.names.get(f);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\FunctionNames.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
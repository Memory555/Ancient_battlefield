package jxl.biff.formula;

import jxl.read.biff.BOFRecord;

public interface ExternalSheet {
  String getExternalSheetName(int paramInt);
  
  int getExternalSheetIndex(String paramString);
  
  int getExternalSheetIndex(int paramInt);
  
  int getLastExternalSheetIndex(String paramString);
  
  int getLastExternalSheetIndex(int paramInt);
  
  BOFRecord getWorkbookBof();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\ExternalSheet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
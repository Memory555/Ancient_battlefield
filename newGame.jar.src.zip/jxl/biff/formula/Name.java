/*    */ package jxl.biff.formula;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Name
/*    */   extends Operand
/*    */   implements ParsedThing
/*    */ {
/*    */   public int read(byte[] data, int pos) {
/* 44 */     int ixti = IntegerHelper.getInt(data[pos], data[pos + 1]);
/* 45 */     int ilbl = IntegerHelper.getInt(data[pos + 2], data[pos + 3]);
/*    */     
/* 47 */     return 6;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getBytes() {
/* 57 */     byte[] data = new byte[6];
/*    */     
/* 59 */     return data;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void getString(StringBuffer buf) {
/* 70 */     buf.append("[Name record not implemented]");
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\Name.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
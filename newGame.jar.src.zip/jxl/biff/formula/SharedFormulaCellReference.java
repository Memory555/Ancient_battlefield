/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import jxl.Cell;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SharedFormulaCellReference
/*     */   extends Operand
/*     */   implements ParsedThing
/*     */ {
/*     */   private boolean columnRelative;
/*     */   private boolean rowRelative;
/*     */   private int column;
/*     */   private int row;
/*     */   private Cell relativeTo;
/*     */   
/*     */   public SharedFormulaCellReference(Cell rt) {
/*  64 */     this.relativeTo = rt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/*  78 */     this.row = IntegerHelper.getShort(data[pos], data[pos + 1]);
/*     */     
/*  80 */     int columnMask = IntegerHelper.getInt(data[pos + 2], data[pos + 3]);
/*     */     
/*  82 */     this.column = (byte)(columnMask & 0xFF);
/*  83 */     this.columnRelative = ((columnMask & 0x4000) != 0);
/*  84 */     this.rowRelative = ((columnMask & 0x8000) != 0);
/*     */     
/*  86 */     if (this.columnRelative)
/*     */     {
/*  88 */       this.column = this.relativeTo.getColumn() + this.column;
/*     */     }
/*     */     
/*  91 */     if (this.rowRelative)
/*     */     {
/*  93 */       this.row = this.relativeTo.getRow() + this.row;
/*     */     }
/*     */     
/*  96 */     return 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 101 */     return this.column;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRow() {
/* 106 */     return this.row;
/*     */   }
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/* 111 */     CellReferenceHelper.getCellReference(this.column, this.row, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 121 */     byte[] data = new byte[5];
/* 122 */     data[0] = Token.REF.getCode();
/*     */     
/* 124 */     IntegerHelper.getTwoBytes(this.row, data, 1);
/*     */     
/* 126 */     int columnMask = this.column;
/*     */     
/* 128 */     if (this.columnRelative)
/*     */     {
/* 130 */       columnMask |= 0x4000;
/*     */     }
/*     */     
/* 133 */     if (this.rowRelative)
/*     */     {
/* 135 */       columnMask |= 0x8000;
/*     */     }
/*     */     
/* 138 */     IntegerHelper.getTwoBytes(columnMask, data, 3);
/*     */     
/* 140 */     return data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\SharedFormulaCellReference.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.biff.formula;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BooleanValue
/*    */   extends Operand
/*    */   implements ParsedThing
/*    */ {
/*    */   private boolean value;
/*    */   
/*    */   public BooleanValue() {}
/*    */   
/*    */   public BooleanValue(String s) {
/* 50 */     this.value = Boolean.valueOf(s).booleanValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int read(byte[] data, int pos) {
/* 63 */     this.value = (data[pos] == 1);
/* 64 */     return 1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   byte[] getBytes() {
/* 74 */     byte[] data = new byte[2];
/* 75 */     data[0] = Token.BOOL.getCode();
/* 76 */     data[1] = (byte)((this.value == true) ? 1 : 0);
/*    */     
/* 78 */     return data;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void getString(StringBuffer buf) {
/* 89 */     buf.append((new Boolean(this.value)).toString());
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\BooleanValue.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
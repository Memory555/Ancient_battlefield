package jxl.biff.formula;

class OpenParentheses extends StringParseItem {}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\OpenParentheses.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
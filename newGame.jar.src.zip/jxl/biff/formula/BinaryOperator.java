/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class BinaryOperator
/*     */   extends Operator
/*     */   implements ParsedThing
/*     */ {
/*     */   public int read(byte[] data, int pos) {
/*  47 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getOperands(Stack s) {
/*  55 */     ParseItem o1 = s.pop();
/*  56 */     ParseItem o2 = s.pop();
/*     */     
/*  58 */     add(o1);
/*  59 */     add(o2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/*  69 */     ParseItem[] operands = getOperands();
/*  70 */     operands[1].getString(buf);
/*  71 */     buf.append(getSymbol());
/*  72 */     operands[0].getString(buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/*  84 */     ParseItem[] operands = getOperands();
/*  85 */     operands[1].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*  86 */     operands[0].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/* 101 */     ParseItem[] operands = getOperands();
/* 102 */     operands[1].columnInserted(sheetIndex, col, currentSheet);
/* 103 */     operands[0].columnInserted(sheetIndex, col, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 118 */     ParseItem[] operands = getOperands();
/* 119 */     operands[1].columnRemoved(sheetIndex, col, currentSheet);
/* 120 */     operands[0].columnRemoved(sheetIndex, col, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet) {
/* 135 */     ParseItem[] operands = getOperands();
/* 136 */     operands[1].rowInserted(sheetIndex, row, currentSheet);
/* 137 */     operands[0].rowInserted(sheetIndex, row, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet) {
/* 152 */     ParseItem[] operands = getOperands();
/* 153 */     operands[1].rowRemoved(sheetIndex, row, currentSheet);
/* 154 */     operands[0].rowRemoved(sheetIndex, row, currentSheet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 165 */     ParseItem[] operands = getOperands();
/* 166 */     byte[] data = new byte[0];
/*     */ 
/*     */     
/* 169 */     for (int i = operands.length - 1; i >= 0; i--) {
/*     */       
/* 171 */       byte[] opdata = operands[i].getBytes();
/*     */ 
/*     */       
/* 174 */       byte[] arrayOfByte1 = new byte[data.length + opdata.length];
/* 175 */       System.arraycopy(data, 0, arrayOfByte1, 0, data.length);
/* 176 */       System.arraycopy(opdata, 0, arrayOfByte1, data.length, opdata.length);
/* 177 */       data = arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 181 */     byte[] newdata = new byte[data.length + 1];
/* 182 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 183 */     newdata[data.length] = getToken().getCode();
/*     */     
/* 185 */     return newdata;
/*     */   }
/*     */   
/*     */   abstract String getSymbol();
/*     */   
/*     */   abstract Token getToken();
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\BinaryOperator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.biff.formula;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import java.util.Stack;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.IntegerHelper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BuiltInFunction
/*     */   extends Operator
/*     */   implements ParsedThing
/*     */ {
/*  38 */   private static Logger logger = Logger.getLogger(BuiltInFunction.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Function function;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings settings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BuiltInFunction(WorkbookSettings ws) {
/*  56 */     this.settings = ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BuiltInFunction(Function f, WorkbookSettings ws) {
/*  67 */     this.function = f;
/*  68 */     this.settings = ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] data, int pos) {
/*  80 */     int index = IntegerHelper.getInt(data[pos], data[pos + 1]);
/*  81 */     this.function = Function.getFunction(index);
/*  82 */     Assert.verify((this.function != Function.UNKNOWN), "function code " + index);
/*  83 */     return 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getOperands(Stack s) {
/*  92 */     ParseItem[] items = new ParseItem[this.function.getNumArgs()];
/*     */     int i;
/*  94 */     for (i = this.function.getNumArgs() - 1; i >= 0; i--) {
/*     */       
/*  96 */       ParseItem pi = s.pop();
/*     */       
/*  98 */       items[i] = pi;
/*     */     } 
/*     */     
/* 101 */     for (i = 0; i < this.function.getNumArgs(); i++)
/*     */     {
/* 103 */       add(items[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getString(StringBuffer buf) {
/* 122 */     buf.append(this.function.getName(this.settings));
/* 123 */     buf.append('(');
/*     */     
/* 125 */     int numArgs = this.function.getNumArgs();
/*     */     
/* 127 */     if (numArgs > 0) {
/*     */       
/* 129 */       ParseItem[] operands = getOperands();
/*     */ 
/*     */       
/* 132 */       operands[0].getString(buf);
/*     */       
/* 134 */       for (int i = 1; i < numArgs; i++) {
/*     */         
/* 136 */         buf.append(',');
/* 137 */         operands[i].getString(buf);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     buf.append(')');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustRelativeCellReferences(int colAdjust, int rowAdjust) {
/* 164 */     ParseItem[] operands = getOperands();
/*     */     
/* 166 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 168 */       operands[i].adjustRelativeCellReferences(colAdjust, rowAdjust);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnInserted(int sheetIndex, int col, boolean currentSheet) {
/* 184 */     ParseItem[] operands = getOperands();
/* 185 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 187 */       operands[i].columnInserted(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(int sheetIndex, int col, boolean currentSheet) {
/* 203 */     ParseItem[] operands = getOperands();
/* 204 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 206 */       operands[i].columnRemoved(sheetIndex, col, currentSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(int sheetIndex, int row, boolean currentSheet) {
/* 223 */     ParseItem[] operands = getOperands();
/* 224 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 226 */       operands[i].rowInserted(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(int sheetIndex, int row, boolean currentSheet) {
/* 242 */     ParseItem[] operands = getOperands();
/* 243 */     for (int i = 0; i < operands.length; i++)
/*     */     {
/* 245 */       operands[i].rowRemoved(sheetIndex, row, currentSheet);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() {
/* 257 */     ParseItem[] operands = getOperands();
/* 258 */     byte[] data = new byte[0];
/*     */     
/* 260 */     for (int i = 0; i < operands.length; i++) {
/*     */       
/* 262 */       byte[] opdata = operands[i].getBytes();
/*     */ 
/*     */       
/* 265 */       byte[] arrayOfByte1 = new byte[data.length + opdata.length];
/* 266 */       System.arraycopy(data, 0, arrayOfByte1, 0, data.length);
/* 267 */       System.arraycopy(opdata, 0, arrayOfByte1, data.length, opdata.length);
/* 268 */       data = arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 272 */     byte[] newdata = new byte[data.length + 3];
/* 273 */     System.arraycopy(data, 0, newdata, 0, data.length);
/* 274 */     newdata[data.length] = !useAlternateCode() ? Token.FUNCTION.getCode() : Token.FUNCTION.getCode2();
/*     */     
/* 276 */     IntegerHelper.getTwoBytes(this.function.getCode(), newdata, data.length + 1);
/*     */     
/* 278 */     return newdata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getPrecedence() {
/* 289 */     return 3;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\biff\formula\BuiltInFunction.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl;
/*     */ 
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.write.WritableWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CellReferenceHelper
/*     */ {
/*     */   public static void getCellReference(int column, int row, StringBuffer buf) {
/*  46 */     CellReferenceHelper.getCellReference(column, row, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getCellReference(int column, boolean colabs, int row, boolean rowabs, StringBuffer buf) {
/*  62 */     CellReferenceHelper.getCellReference(column, colabs, row, rowabs, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCellReference(int column, int row) {
/*  77 */     return CellReferenceHelper.getCellReference(column, row);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getColumn(String s) {
/*  88 */     return CellReferenceHelper.getColumn(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getColumnReference(int c) {
/*  99 */     return CellReferenceHelper.getColumnReference(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getRow(String s) {
/* 109 */     return CellReferenceHelper.getRow(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isColumnRelative(String s) {
/* 120 */     return CellReferenceHelper.isColumnRelative(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRowRelative(String s) {
/* 131 */     return CellReferenceHelper.isRowRelative(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getCellReference(int sheet, int column, int row, Workbook workbook, StringBuffer buf) {
/* 148 */     CellReferenceHelper.getCellReference(sheet, column, row, (ExternalSheet)workbook, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getCellReference(int sheet, int column, int row, WritableWorkbook workbook, StringBuffer buf) {
/* 166 */     CellReferenceHelper.getCellReference(sheet, column, row, (ExternalSheet)workbook, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getCellReference(int sheet, int column, boolean colabs, int row, boolean rowabs, Workbook workbook, StringBuffer buf) {
/* 187 */     CellReferenceHelper.getCellReference(sheet, column, colabs, row, rowabs, (ExternalSheet)workbook, buf);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCellReference(int sheet, int column, int row, Workbook workbook) {
/* 206 */     return CellReferenceHelper.getCellReference(sheet, column, row, (ExternalSheet)workbook);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCellReference(int sheet, int column, int row, WritableWorkbook workbook) {
/* 224 */     return CellReferenceHelper.getCellReference(sheet, column, row, (ExternalSheet)workbook);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\CellReferenceHelper.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl;
/*    */ 
/*    */ import jxl.biff.BaseCellFeatures;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CellFeatures
/*    */   extends BaseCellFeatures
/*    */ {
/*    */   public CellFeatures() {}
/*    */   
/*    */   protected CellFeatures(CellFeatures cf) {
/* 44 */     super(cf);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getComment() {
/* 52 */     return super.getComment();
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\CellFeatures.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
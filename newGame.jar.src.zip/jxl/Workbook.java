/*     */ package jxl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import jxl.read.biff.BiffException;
/*     */ import jxl.read.biff.File;
/*     */ import jxl.read.biff.PasswordException;
/*     */ import jxl.read.biff.WorkbookParser;
/*     */ import jxl.write.WritableWorkbook;
/*     */ import jxl.write.biff.WritableWorkbookImpl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Workbook
/*     */ {
/*     */   private static final String version = "2.5.7";
/*     */   
/*     */   public abstract Sheet[] getSheets();
/*     */   
/*     */   public abstract String[] getSheetNames();
/*     */   
/*     */   public abstract Sheet getSheet(int paramInt) throws IndexOutOfBoundsException;
/*     */   
/*     */   public abstract Sheet getSheet(String paramString);
/*     */   
/*     */   public static String getVersion() {
/* 104 */     return "2.5.7";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getNumberOfSheets();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Cell findCellByName(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Range[] findByName(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String[] getRangeNames();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isProtected();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void parse() throws BiffException, PasswordException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void close();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Workbook getWorkbook(File file) throws IOException, BiffException {
/* 187 */     return getWorkbook(file, new WorkbookSettings());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Workbook getWorkbook(File file, WorkbookSettings ws) throws IOException, BiffException {
/* 202 */     FileInputStream fis = new FileInputStream(file);
/*     */ 
/*     */ 
/*     */     
/* 206 */     File dataFile = null;
/*     */ 
/*     */     
/*     */     try {
/* 210 */       dataFile = new File(fis, ws);
/*     */     }
/* 212 */     catch (IOException e) {
/*     */       
/* 214 */       fis.close();
/* 215 */       throw e;
/*     */     }
/* 217 */     catch (BiffException e) {
/*     */       
/* 219 */       fis.close();
/* 220 */       throw e;
/*     */     } 
/*     */     
/* 223 */     fis.close();
/*     */     
/* 225 */     WorkbookParser workbookParser = new WorkbookParser(dataFile, ws);
/* 226 */     workbookParser.parse();
/*     */     
/* 228 */     return (Workbook)workbookParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Workbook getWorkbook(InputStream is) throws IOException, BiffException {
/* 242 */     return getWorkbook(is, new WorkbookSettings());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Workbook getWorkbook(InputStream is, WorkbookSettings ws) throws IOException, BiffException {
/* 257 */     File dataFile = new File(is, ws);
/*     */     
/* 259 */     WorkbookParser workbookParser = new WorkbookParser(dataFile, ws);
/* 260 */     workbookParser.parse();
/*     */     
/* 262 */     return (Workbook)workbookParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WritableWorkbook createWorkbook(File file) throws IOException {
/* 274 */     return createWorkbook(file, new WorkbookSettings());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WritableWorkbook createWorkbook(File file, WorkbookSettings ws) throws IOException {
/* 288 */     FileOutputStream fos = new FileOutputStream(file);
/* 289 */     return (WritableWorkbook)new WritableWorkbookImpl(fos, true, ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WritableWorkbook createWorkbook(File file, Workbook in) throws IOException {
/* 306 */     return createWorkbook(file, in, new WorkbookSettings());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WritableWorkbook createWorkbook(File file, Workbook in, WorkbookSettings ws) throws IOException {
/* 324 */     FileOutputStream fos = new FileOutputStream(file);
/* 325 */     return (WritableWorkbook)new WritableWorkbookImpl(fos, in, true, ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WritableWorkbook createWorkbook(OutputStream os, Workbook in) throws IOException {
/* 342 */     return createWorkbook(os, in, ((WorkbookParser)in).getSettings());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WritableWorkbook createWorkbook(OutputStream os, Workbook in, WorkbookSettings ws) throws IOException {
/* 360 */     return (WritableWorkbook)new WritableWorkbookImpl(os, in, false, ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WritableWorkbook createWorkbook(OutputStream os) throws IOException {
/* 376 */     return createWorkbook(os, new WorkbookSettings());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WritableWorkbook createWorkbook(OutputStream os, WorkbookSettings ws) throws IOException {
/* 393 */     return (WritableWorkbook)new WritableWorkbookImpl(os, false, ws);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\Workbook.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
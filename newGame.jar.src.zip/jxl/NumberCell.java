package jxl;

import java.text.NumberFormat;

public interface NumberCell extends Cell {
  double getValue();
  
  NumberFormat getNumberFormat();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\NumberCell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
package jxl.format;

public interface Format {
  String getFormatString();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\format\Format.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
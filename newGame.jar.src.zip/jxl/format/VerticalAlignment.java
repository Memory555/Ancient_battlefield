/*     */ package jxl.format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VerticalAlignment
/*     */ {
/*     */   private int value;
/*     */   private String string;
/*  40 */   private static VerticalAlignment[] alignments = new VerticalAlignment[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected VerticalAlignment(int val, String s) {
/*  49 */     this.value = val;
/*  50 */     this.string = s;
/*     */     
/*  52 */     VerticalAlignment[] oldaligns = alignments;
/*  53 */     alignments = new VerticalAlignment[oldaligns.length + 1];
/*  54 */     System.arraycopy(oldaligns, 0, alignments, 0, oldaligns.length);
/*  55 */     alignments[oldaligns.length] = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValue() {
/*  65 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  73 */     return this.string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static VerticalAlignment getAlignment(int val) {
/*  84 */     for (int i = 0; i < alignments.length; i++) {
/*     */       
/*  86 */       if (alignments[i].getValue() == val)
/*     */       {
/*  88 */         return alignments[i];
/*     */       }
/*     */     } 
/*     */     
/*  92 */     return BOTTOM;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public static VerticalAlignment TOP = new VerticalAlignment(0, "top");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public static VerticalAlignment CENTRE = new VerticalAlignment(1, "centre");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public static VerticalAlignment BOTTOM = new VerticalAlignment(2, "bottom");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public static VerticalAlignment JUSTIFY = new VerticalAlignment(3, "Justify");
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\format\VerticalAlignment.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
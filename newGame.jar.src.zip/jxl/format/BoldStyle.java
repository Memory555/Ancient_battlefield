/*    */ package jxl.format;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoldStyle
/*    */ {
/*    */   private int value;
/*    */   private String string;
/*    */   
/*    */   protected BoldStyle(int val, String s) {
/* 44 */     this.value = val;
/* 45 */     this.string = s;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getValue() {
/* 56 */     return this.value;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 64 */     return this.string;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 70 */   public static final BoldStyle NORMAL = new BoldStyle(400, "Normal");
/*    */ 
/*    */ 
/*    */   
/* 74 */   public static final BoldStyle BOLD = new BoldStyle(700, "Bold");
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\format\BoldStyle.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
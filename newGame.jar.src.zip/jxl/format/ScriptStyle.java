/*     */ package jxl.format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ScriptStyle
/*     */ {
/*     */   private int value;
/*     */   private String string;
/*  43 */   private static ScriptStyle[] styles = new ScriptStyle[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ScriptStyle(int val, String s) {
/*  54 */     this.value = val;
/*  55 */     this.string = s;
/*     */     
/*  57 */     ScriptStyle[] oldstyles = styles;
/*  58 */     styles = new ScriptStyle[oldstyles.length + 1];
/*  59 */     System.arraycopy(oldstyles, 0, styles, 0, oldstyles.length);
/*  60 */     styles[oldstyles.length] = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValue() {
/*  71 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  81 */     return this.string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ScriptStyle getStyle(int val) {
/*  92 */     for (int i = 0; i < styles.length; i++) {
/*     */       
/*  94 */       if (styles[i].getValue() == val)
/*     */       {
/*  96 */         return styles[i];
/*     */       }
/*     */     } 
/*     */     
/* 100 */     return NORMAL_SCRIPT;
/*     */   }
/*     */ 
/*     */   
/* 104 */   public static final ScriptStyle NORMAL_SCRIPT = new ScriptStyle(0, "normal");
/* 105 */   public static final ScriptStyle SUPERSCRIPT = new ScriptStyle(1, "super");
/* 106 */   public static final ScriptStyle SUBSCRIPT = new ScriptStyle(2, "sub");
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\format\ScriptStyle.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
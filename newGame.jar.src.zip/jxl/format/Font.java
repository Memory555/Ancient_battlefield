package jxl.format;

public interface Font {
  String getName();
  
  int getPointSize();
  
  int getBoldWeight();
  
  boolean isItalic();
  
  UnderlineStyle getUnderlineStyle();
  
  Colour getColour();
  
  ScriptStyle getScriptStyle();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\format\Font.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
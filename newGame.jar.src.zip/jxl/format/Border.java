/*    */ package jxl.format;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Border
/*    */ {
/*    */   private String string;
/*    */   
/*    */   protected Border(String s) {
/* 37 */     this.string = s;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getDescription() {
/* 45 */     return this.string;
/*    */   }
/*    */   
/* 48 */   public static final Border NONE = new Border("none");
/* 49 */   public static final Border ALL = new Border("all");
/* 50 */   public static final Border TOP = new Border("top");
/* 51 */   public static final Border BOTTOM = new Border("bottom");
/* 52 */   public static final Border LEFT = new Border("left");
/* 53 */   public static final Border RIGHT = new Border("right");
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\format\Border.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PaperSize
/*     */ {
/*     */   private static final int LAST_PAPER_SIZE = 89;
/*     */   private int val;
/*  37 */   private static PaperSize[] paperSizes = new PaperSize[90];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PaperSize(int v, boolean growArray) {
/*  44 */     this.val = v;
/*     */     
/*  46 */     if (v >= paperSizes.length && growArray) {
/*     */ 
/*     */       
/*  49 */       PaperSize[] newarray = new PaperSize[v + 1];
/*  50 */       System.arraycopy(paperSizes, 0, newarray, 0, paperSizes.length);
/*  51 */       paperSizes = newarray;
/*     */     } 
/*  53 */     if (v < paperSizes.length)
/*     */     {
/*  55 */       paperSizes[v] = this;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PaperSize(int v) {
/*  64 */     this(v, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValue() {
/*  74 */     return this.val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PaperSize getPaperSize(int val) {
/*  85 */     PaperSize p = (val > paperSizes.length - 1) ? null : paperSizes[val];
/*  86 */     return (p == null) ? new PaperSize(val, false) : p;
/*     */   }
/*     */ 
/*     */   
/*  90 */   public static final PaperSize UNDEFINED = new PaperSize(0);
/*     */ 
/*     */   
/*  93 */   public static final PaperSize LETTER = new PaperSize(1);
/*     */ 
/*     */   
/*  96 */   public static final PaperSize LETTER_SMALL = new PaperSize(2);
/*     */ 
/*     */   
/*  99 */   public static final PaperSize TABLOID = new PaperSize(3);
/*     */ 
/*     */   
/* 102 */   public static final PaperSize LEDGER = new PaperSize(4);
/*     */ 
/*     */   
/* 105 */   public static final PaperSize LEGAL = new PaperSize(5);
/*     */ 
/*     */   
/* 108 */   public static final PaperSize STATEMENT = new PaperSize(6);
/*     */ 
/*     */   
/* 111 */   public static final PaperSize EXECUTIVE = new PaperSize(7);
/*     */ 
/*     */   
/* 114 */   public static final PaperSize A3 = new PaperSize(8);
/*     */ 
/*     */   
/* 117 */   public static final PaperSize A4 = new PaperSize(9);
/*     */ 
/*     */   
/* 120 */   public static final PaperSize A4_SMALL = new PaperSize(10);
/*     */ 
/*     */   
/* 123 */   public static final PaperSize A5 = new PaperSize(11);
/*     */ 
/*     */   
/* 126 */   public static final PaperSize B4 = new PaperSize(12);
/*     */ 
/*     */   
/* 129 */   public static final PaperSize B5 = new PaperSize(13);
/*     */ 
/*     */   
/* 132 */   public static final PaperSize FOLIO = new PaperSize(14);
/*     */ 
/*     */   
/* 135 */   public static final PaperSize QUARTO = new PaperSize(15);
/*     */ 
/*     */   
/* 138 */   public static final PaperSize SIZE_10x14 = new PaperSize(16);
/*     */ 
/*     */   
/* 141 */   public static final PaperSize SIZE_10x17 = new PaperSize(17);
/*     */ 
/*     */   
/* 144 */   public static final PaperSize NOTE = new PaperSize(18);
/*     */ 
/*     */   
/* 147 */   public static final PaperSize ENVELOPE_9 = new PaperSize(19);
/*     */ 
/*     */   
/* 150 */   public static final PaperSize ENVELOPE_10 = new PaperSize(20);
/*     */ 
/*     */   
/* 153 */   public static final PaperSize ENVELOPE_11 = new PaperSize(21);
/*     */ 
/*     */   
/* 156 */   public static final PaperSize ENVELOPE_12 = new PaperSize(22);
/*     */ 
/*     */   
/* 159 */   public static final PaperSize ENVELOPE_14 = new PaperSize(23);
/*     */ 
/*     */   
/* 162 */   public static final PaperSize C = new PaperSize(24);
/*     */ 
/*     */   
/* 165 */   public static final PaperSize D = new PaperSize(25);
/*     */ 
/*     */   
/* 168 */   public static final PaperSize E = new PaperSize(26);
/*     */ 
/*     */   
/* 171 */   public static final PaperSize ENVELOPE_DL = new PaperSize(27);
/*     */ 
/*     */   
/* 174 */   public static final PaperSize ENVELOPE_C5 = new PaperSize(28);
/*     */ 
/*     */   
/* 177 */   public static final PaperSize ENVELOPE_C3 = new PaperSize(29);
/*     */ 
/*     */   
/* 180 */   public static final PaperSize ENVELOPE_C4 = new PaperSize(30);
/*     */ 
/*     */   
/* 183 */   public static final PaperSize ENVELOPE_C6 = new PaperSize(31);
/*     */ 
/*     */   
/* 186 */   public static final PaperSize ENVELOPE_C6_C5 = new PaperSize(32);
/*     */ 
/*     */   
/* 189 */   public static final PaperSize B4_ISO = new PaperSize(33);
/*     */ 
/*     */   
/* 192 */   public static final PaperSize B5_ISO = new PaperSize(34);
/*     */ 
/*     */   
/* 195 */   public static final PaperSize B6_ISO = new PaperSize(35);
/*     */ 
/*     */   
/* 198 */   public static final PaperSize ENVELOPE_ITALY = new PaperSize(36);
/*     */ 
/*     */   
/* 201 */   public static final PaperSize ENVELOPE_MONARCH = new PaperSize(37);
/*     */ 
/*     */   
/* 204 */   public static final PaperSize ENVELOPE_6_75 = new PaperSize(38);
/*     */ 
/*     */   
/* 207 */   public static final PaperSize US_FANFOLD = new PaperSize(39);
/*     */ 
/*     */   
/* 210 */   public static final PaperSize GERMAN_FANFOLD = new PaperSize(40);
/*     */ 
/*     */   
/* 213 */   public static final PaperSize GERMAN_LEGAL_FANFOLD = new PaperSize(41);
/*     */ 
/*     */   
/* 216 */   public static final PaperSize B4_ISO_2 = new PaperSize(42);
/*     */ 
/*     */   
/* 219 */   public static final PaperSize JAPANESE_POSTCARD = new PaperSize(43);
/*     */ 
/*     */   
/* 222 */   public static final PaperSize SIZE_9x11 = new PaperSize(44);
/*     */ 
/*     */   
/* 225 */   public static final PaperSize SIZE_10x11 = new PaperSize(45);
/*     */ 
/*     */   
/* 228 */   public static final PaperSize SIZE_15x11 = new PaperSize(46);
/*     */ 
/*     */   
/* 231 */   public static final PaperSize ENVELOPE_INVITE = new PaperSize(47);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   public static final PaperSize LETTER_EXTRA = new PaperSize(50);
/*     */ 
/*     */   
/* 239 */   public static final PaperSize LEGAL_EXTRA = new PaperSize(51);
/*     */ 
/*     */   
/* 242 */   public static final PaperSize TABLOID_EXTRA = new PaperSize(52);
/*     */ 
/*     */   
/* 245 */   public static final PaperSize A4_EXTRA = new PaperSize(53);
/*     */ 
/*     */   
/* 248 */   public static final PaperSize LETTER_TRANSVERSE = new PaperSize(54);
/*     */ 
/*     */   
/* 251 */   public static final PaperSize A4_TRANSVERSE = new PaperSize(55);
/*     */ 
/*     */   
/* 254 */   public static final PaperSize LETTER_EXTRA_TRANSVERSE = new PaperSize(56);
/*     */ 
/*     */   
/* 257 */   public static final PaperSize SUPER_A_A4 = new PaperSize(57);
/*     */ 
/*     */   
/* 260 */   public static final PaperSize SUPER_B_A3 = new PaperSize(58);
/*     */ 
/*     */   
/* 263 */   public static final PaperSize LETTER_PLUS = new PaperSize(59);
/*     */ 
/*     */   
/* 266 */   public static final PaperSize A4_PLUS = new PaperSize(60);
/*     */ 
/*     */   
/* 269 */   public static final PaperSize A5_TRANSVERSE = new PaperSize(61);
/*     */ 
/*     */   
/* 272 */   public static final PaperSize B5_TRANSVERSE = new PaperSize(62);
/*     */ 
/*     */   
/* 275 */   public static final PaperSize A3_EXTRA = new PaperSize(63);
/*     */ 
/*     */   
/* 278 */   public static final PaperSize A5_EXTRA = new PaperSize(64);
/*     */ 
/*     */   
/* 281 */   public static final PaperSize B5_EXTRA = new PaperSize(65);
/*     */ 
/*     */   
/* 284 */   public static final PaperSize A2 = new PaperSize(66);
/*     */ 
/*     */   
/* 287 */   public static final PaperSize A3_TRANSVERSE = new PaperSize(67);
/*     */ 
/*     */   
/* 290 */   public static final PaperSize A3_EXTRA_TRANSVERSE = new PaperSize(68);
/*     */ 
/*     */   
/* 293 */   public static final PaperSize DOUBLE_JAPANESE_POSTCARD = new PaperSize(69);
/*     */ 
/*     */   
/* 296 */   public static final PaperSize A6 = new PaperSize(70);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 301 */   public static final PaperSize LETTER_ROTATED = new PaperSize(75);
/*     */ 
/*     */   
/* 304 */   public static final PaperSize A3_ROTATED = new PaperSize(76);
/*     */ 
/*     */   
/* 307 */   public static final PaperSize A4_ROTATED = new PaperSize(77);
/*     */ 
/*     */   
/* 310 */   public static final PaperSize A5_ROTATED = new PaperSize(78);
/*     */ 
/*     */   
/* 313 */   public static final PaperSize B4_ROTATED = new PaperSize(79);
/*     */ 
/*     */   
/* 316 */   public static final PaperSize B5_ROTATED = new PaperSize(80);
/*     */ 
/*     */   
/* 319 */   public static final PaperSize JAPANESE_POSTCARD_ROTATED = new PaperSize(81);
/*     */ 
/*     */   
/* 322 */   public static final PaperSize DOUBLE_JAPANESE_POSTCARD_ROTATED = new PaperSize(82);
/*     */ 
/*     */   
/* 325 */   public static final PaperSize A6_ROTATED = new PaperSize(83);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 330 */   public static final PaperSize B6 = new PaperSize(88);
/*     */ 
/*     */   
/* 333 */   public static final PaperSize B6_ROTATED = new PaperSize(89);
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\format\PaperSize.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
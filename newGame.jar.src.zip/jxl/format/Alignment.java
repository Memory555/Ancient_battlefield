/*     */ package jxl.format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Alignment
/*     */ {
/*     */   private int value;
/*     */   private String string;
/*  41 */   private static Alignment[] alignments = new Alignment[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Alignment(int val, String s) {
/*  51 */     this.value = val;
/*  52 */     this.string = s;
/*     */     
/*  54 */     Alignment[] oldaligns = alignments;
/*  55 */     alignments = new Alignment[oldaligns.length + 1];
/*  56 */     System.arraycopy(oldaligns, 0, alignments, 0, oldaligns.length);
/*  57 */     alignments[oldaligns.length] = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValue() {
/*  68 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  78 */     return this.string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Alignment getAlignment(int val) {
/*  89 */     for (int i = 0; i < alignments.length; i++) {
/*     */       
/*  91 */       if (alignments[i].getValue() == val)
/*     */       {
/*  93 */         return alignments[i];
/*     */       }
/*     */     } 
/*     */     
/*  97 */     return GENERAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public static Alignment GENERAL = new Alignment(0, "general");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public static Alignment LEFT = new Alignment(1, "left");
/*     */ 
/*     */ 
/*     */   
/* 112 */   public static Alignment CENTRE = new Alignment(2, "centre");
/*     */ 
/*     */ 
/*     */   
/* 116 */   public static Alignment RIGHT = new Alignment(3, "right");
/*     */ 
/*     */ 
/*     */   
/* 120 */   public static Alignment FILL = new Alignment(4, "fill");
/*     */ 
/*     */ 
/*     */   
/* 124 */   public static Alignment JUSTIFY = new Alignment(5, "justify");
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\format\Alignment.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
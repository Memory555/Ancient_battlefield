/*     */ package jxl.format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pattern
/*     */ {
/*     */   private int value;
/*     */   private String string;
/*  42 */   private static Pattern[] patterns = new Pattern[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Pattern(int val, String s) {
/*  52 */     this.value = val;
/*  53 */     this.string = s;
/*     */     
/*  55 */     Pattern[] oldcols = patterns;
/*  56 */     patterns = new Pattern[oldcols.length + 1];
/*  57 */     System.arraycopy(oldcols, 0, patterns, 0, oldcols.length);
/*  58 */     patterns[oldcols.length] = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getValue() {
/*  69 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/*  79 */     return this.string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pattern getPattern(int val) {
/*  90 */     for (int i = 0; i < patterns.length; i++) {
/*     */       
/*  92 */       if (patterns[i].getValue() == val)
/*     */       {
/*  94 */         return patterns[i];
/*     */       }
/*     */     } 
/*     */     
/*  98 */     return NONE;
/*     */   }
/*     */   
/* 101 */   public static final Pattern NONE = new Pattern(0, "None");
/* 102 */   public static final Pattern SOLID = new Pattern(1, "Solid");
/*     */   
/* 104 */   public static final Pattern GRAY_50 = new Pattern(2, "Gray 50%");
/* 105 */   public static final Pattern GRAY_75 = new Pattern(3, "Gray 75%");
/* 106 */   public static final Pattern GRAY_25 = new Pattern(4, "Gray 25%");
/*     */   
/* 108 */   public static final Pattern PATTERN1 = new Pattern(5, "Pattern 1");
/* 109 */   public static final Pattern PATTERN2 = new Pattern(6, "Pattern 2");
/* 110 */   public static final Pattern PATTERN3 = new Pattern(7, "Pattern 3");
/* 111 */   public static final Pattern PATTERN4 = new Pattern(8, "Pattern 4");
/* 112 */   public static final Pattern PATTERN5 = new Pattern(9, "Pattern 5");
/* 113 */   public static final Pattern PATTERN6 = new Pattern(10, "Pattern 6");
/* 114 */   public static final Pattern PATTERN7 = new Pattern(11, "Pattern 7");
/* 115 */   public static final Pattern PATTERN8 = new Pattern(12, "Pattern 8");
/* 116 */   public static final Pattern PATTERN9 = new Pattern(13, "Pattern 9");
/* 117 */   public static final Pattern PATTERN10 = new Pattern(14, "Pattern 10");
/* 118 */   public static final Pattern PATTERN11 = new Pattern(15, "Pattern 11");
/* 119 */   public static final Pattern PATTERN12 = new Pattern(16, "Pattern 12");
/* 120 */   public static final Pattern PATTERN13 = new Pattern(17, "Pattern 13");
/* 121 */   public static final Pattern PATTERN14 = new Pattern(18, "Pattern 14");
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\format\Pattern.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
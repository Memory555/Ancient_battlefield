/*      */ package jxl;
/*      */ 
/*      */ import common.Assert;
/*      */ import jxl.format.PageOrientation;
/*      */ import jxl.format.PaperSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class SheetSettings
/*      */ {
/*      */   private PageOrientation orientation;
/*      */   private PaperSize paperSize;
/*      */   private boolean sheetProtected;
/*      */   private boolean hidden;
/*      */   private boolean selected;
/*      */   private HeaderFooter header;
/*      */   private double headerMargin;
/*      */   private HeaderFooter footer;
/*      */   private double footerMargin;
/*      */   private int scaleFactor;
/*      */   private int zoomFactor;
/*      */   private int pageStart;
/*      */   private int fitWidth;
/*      */   private int fitHeight;
/*      */   private int horizontalPrintResolution;
/*      */   private int verticalPrintResolution;
/*      */   private double leftMargin;
/*      */   private double rightMargin;
/*      */   private double topMargin;
/*      */   private double bottomMargin;
/*      */   private boolean fitToPages;
/*      */   private boolean showGridLines;
/*      */   private boolean printGridLines;
/*      */   private boolean printHeaders;
/*      */   private boolean displayZeroValues;
/*      */   private String password;
/*      */   private int passwordHash;
/*      */   private int defaultColumnWidth;
/*      */   private int defaultRowHeight;
/*      */   private int horizontalFreeze;
/*      */   private int verticalFreeze;
/*      */   private boolean verticalCentre;
/*      */   private boolean horizontalCentre;
/*      */   private int copies;
/*  210 */   private static final PageOrientation defaultOrientation = PageOrientation.PORTRAIT;
/*      */   
/*  212 */   private static final PaperSize defaultPaperSize = PaperSize.A4;
/*      */ 
/*      */   
/*      */   private static final double defaultHeaderMargin = 0.5D;
/*      */   
/*      */   private static final double defaultFooterMargin = 0.5D;
/*      */   
/*      */   private static final int defaultPrintResolution = 300;
/*      */   
/*      */   private static final double defaultWidthMargin = 0.75D;
/*      */   
/*      */   private static final double defaultHeightMargin = 1.0D;
/*      */   
/*      */   private static final int defaultDefaultColumnWidth = 8;
/*      */   
/*      */   private static final int defaultZoomFactor = 100;
/*      */   
/*      */   public static final int DEFAULT_DEFAULT_ROW_HEIGHT = 255;
/*      */ 
/*      */   
/*      */   public SheetSettings() {
/*  233 */     this.orientation = defaultOrientation;
/*  234 */     this.paperSize = defaultPaperSize;
/*  235 */     this.sheetProtected = false;
/*  236 */     this.hidden = false;
/*  237 */     this.selected = false;
/*  238 */     this.headerMargin = 0.5D;
/*  239 */     this.footerMargin = 0.5D;
/*  240 */     this.horizontalPrintResolution = 300;
/*  241 */     this.verticalPrintResolution = 300;
/*  242 */     this.leftMargin = 0.75D;
/*  243 */     this.rightMargin = 0.75D;
/*  244 */     this.topMargin = 1.0D;
/*  245 */     this.bottomMargin = 1.0D;
/*  246 */     this.fitToPages = false;
/*  247 */     this.showGridLines = true;
/*  248 */     this.printGridLines = false;
/*  249 */     this.printHeaders = false;
/*  250 */     this.displayZeroValues = true;
/*  251 */     this.defaultColumnWidth = 8;
/*  252 */     this.defaultRowHeight = 255;
/*  253 */     this.zoomFactor = 100;
/*  254 */     this.horizontalFreeze = 0;
/*  255 */     this.verticalFreeze = 0;
/*  256 */     this.copies = 1;
/*  257 */     this.header = new HeaderFooter();
/*  258 */     this.footer = new HeaderFooter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SheetSettings(SheetSettings copy) {
/*  267 */     Assert.verify((copy != null));
/*      */     
/*  269 */     this.orientation = copy.orientation;
/*  270 */     this.paperSize = copy.paperSize;
/*  271 */     this.sheetProtected = copy.sheetProtected;
/*  272 */     this.hidden = copy.hidden;
/*  273 */     this.selected = false;
/*  274 */     this.headerMargin = copy.headerMargin;
/*  275 */     this.footerMargin = copy.footerMargin;
/*  276 */     this.scaleFactor = copy.scaleFactor;
/*  277 */     this.pageStart = copy.pageStart;
/*  278 */     this.fitWidth = copy.fitWidth;
/*  279 */     this.fitHeight = copy.fitHeight;
/*  280 */     this.horizontalPrintResolution = copy.horizontalPrintResolution;
/*  281 */     this.verticalPrintResolution = copy.verticalPrintResolution;
/*  282 */     this.leftMargin = copy.leftMargin;
/*  283 */     this.rightMargin = copy.rightMargin;
/*  284 */     this.topMargin = copy.topMargin;
/*  285 */     this.bottomMargin = copy.bottomMargin;
/*  286 */     this.fitToPages = copy.fitToPages;
/*  287 */     this.password = copy.password;
/*  288 */     this.passwordHash = copy.passwordHash;
/*  289 */     this.defaultColumnWidth = copy.defaultColumnWidth;
/*  290 */     this.defaultRowHeight = copy.defaultRowHeight;
/*  291 */     this.zoomFactor = copy.zoomFactor;
/*  292 */     this.showGridLines = copy.showGridLines;
/*  293 */     this.displayZeroValues = copy.displayZeroValues;
/*  294 */     this.horizontalFreeze = copy.horizontalFreeze;
/*  295 */     this.verticalFreeze = copy.verticalFreeze;
/*  296 */     this.horizontalCentre = copy.horizontalCentre;
/*  297 */     this.verticalCentre = copy.verticalCentre;
/*  298 */     this.copies = copy.copies;
/*  299 */     this.header = new HeaderFooter(copy.header);
/*  300 */     this.footer = new HeaderFooter(copy.footer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOrientation(PageOrientation po) {
/*  310 */     this.orientation = po;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PageOrientation getOrientation() {
/*  320 */     return this.orientation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPaperSize(PaperSize ps) {
/*  330 */     this.paperSize = ps;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PaperSize getPaperSize() {
/*  340 */     return this.paperSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isProtected() {
/*  350 */     return this.sheetProtected;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProtected(boolean p) {
/*  360 */     this.sheetProtected = p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHeaderMargin(double d) {
/*  370 */     this.headerMargin = d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getHeaderMargin() {
/*  380 */     return this.headerMargin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFooterMargin(double d) {
/*  390 */     this.footerMargin = d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getFooterMargin() {
/*  400 */     return this.footerMargin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHidden(boolean h) {
/*  410 */     this.hidden = h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isHidden() {
/*  420 */     return this.hidden;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSelected() {
/*  430 */     setSelected(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSelected(boolean s) {
/*  440 */     this.selected = s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSelected() {
/*  450 */     return this.selected;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setScaleFactor(int sf) {
/*  462 */     this.scaleFactor = sf;
/*  463 */     this.fitToPages = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getScaleFactor() {
/*  473 */     return this.scaleFactor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPageStart(int ps) {
/*  483 */     this.pageStart = ps;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPageStart() {
/*  493 */     return this.pageStart;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFitWidth(int fw) {
/*  504 */     this.fitWidth = fw;
/*  505 */     this.fitToPages = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFitWidth() {
/*  515 */     return this.fitWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFitHeight(int fh) {
/*  525 */     this.fitHeight = fh;
/*  526 */     this.fitToPages = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFitHeight() {
/*  536 */     return this.fitHeight;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHorizontalPrintResolution(int hpw) {
/*  546 */     this.horizontalPrintResolution = hpw;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHorizontalPrintResolution() {
/*  556 */     return this.horizontalPrintResolution;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVerticalPrintResolution(int vpw) {
/*  566 */     this.verticalPrintResolution = vpw;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getVerticalPrintResolution() {
/*  576 */     return this.verticalPrintResolution;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRightMargin(double m) {
/*  586 */     this.rightMargin = m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getRightMargin() {
/*  596 */     return this.rightMargin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLeftMargin(double m) {
/*  606 */     this.leftMargin = m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getLeftMargin() {
/*  616 */     return this.leftMargin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTopMargin(double m) {
/*  626 */     this.topMargin = m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getTopMargin() {
/*  636 */     return this.topMargin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBottomMargin(double m) {
/*  646 */     this.bottomMargin = m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getBottomMargin() {
/*  656 */     return this.bottomMargin;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDefaultWidthMargin() {
/*  666 */     return 0.75D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDefaultHeightMargin() {
/*  676 */     return 1.0D;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getFitToPages() {
/*  685 */     return this.fitToPages;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFitToPages(boolean b) {
/*  694 */     this.fitToPages = b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPassword() {
/*  704 */     return this.password;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPassword(String s) {
/*  714 */     this.password = s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPasswordHash() {
/*  724 */     return this.passwordHash;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPasswordHash(int ph) {
/*  734 */     this.passwordHash = ph;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDefaultColumnWidth() {
/*  744 */     return this.defaultColumnWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultColumnWidth(int w) {
/*  754 */     this.defaultColumnWidth = w;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDefaultRowHeight() {
/*  764 */     return this.defaultRowHeight;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefaultRowHeight(int h) {
/*  774 */     this.defaultRowHeight = h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getZoomFactor() {
/*  786 */     return this.zoomFactor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setZoomFactor(int zf) {
/*  798 */     this.zoomFactor = zf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getDisplayZeroValues() {
/*  808 */     return this.displayZeroValues;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisplayZeroValues(boolean b) {
/*  818 */     this.displayZeroValues = b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getShowGridLines() {
/*  828 */     return this.showGridLines;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShowGridLines(boolean b) {
/*  838 */     this.showGridLines = b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getPrintGridLines() {
/*  848 */     return this.printGridLines;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPrintGridLines(boolean b) {
/*  858 */     this.printGridLines = b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getPrintHeaders() {
/*  868 */     return this.printHeaders;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPrintHeaders(boolean b) {
/*  878 */     this.printHeaders = b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHorizontalFreeze() {
/*  889 */     return this.horizontalFreeze;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHorizontalFreeze(int row) {
/*  899 */     this.horizontalFreeze = Math.max(row, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getVerticalFreeze() {
/*  910 */     return this.verticalFreeze;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVerticalFreeze(int col) {
/*  920 */     this.verticalFreeze = Math.max(col, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCopies(int c) {
/*  930 */     this.copies = c;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getCopies() {
/*  940 */     return this.copies;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeaderFooter getHeader() {
/*  950 */     return this.header;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHeader(HeaderFooter h) {
/*  960 */     this.header = h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFooter(HeaderFooter f) {
/*  970 */     this.footer = f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HeaderFooter getFooter() {
/*  980 */     return this.footer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isHorizontalCentre() {
/*  990 */     return this.horizontalCentre;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHorizontalCentre(boolean horizontalCentre) {
/*  999 */     this.horizontalCentre = horizontalCentre;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isVerticalCentre() {
/* 1009 */     return this.verticalCentre;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVerticalCentre(boolean verticalCentre) {
/* 1018 */     this.verticalCentre = verticalCentre;
/*      */   }
/*      */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\SheetSettings.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write;
/*    */ 
/*    */ import jxl.format.CellFormat;
/*    */ import jxl.write.biff.FormulaRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Formula
/*    */   extends FormulaRecord
/*    */   implements WritableCell
/*    */ {
/*    */   public Formula(int c, int r, String form) {
/* 39 */     super(c, r, form);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Formula(int c, int r, String form, CellFormat st) {
/* 52 */     super(c, r, form, st);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Formula(int c, int r, Formula f) {
/* 64 */     super(c, r, f);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WritableCell copyTo(int col, int row) {
/* 75 */     return new Formula(col, row, this);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\Formula.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write;
/*     */ 
/*     */ import jxl.LabelCell;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.biff.LabelRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Label
/*     */   extends LabelRecord
/*     */   implements WritableCell, LabelCell
/*     */ {
/*     */   public Label(int c, int r, String cont) {
/*  41 */     super(c, r, cont);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Label(int c, int r, String cont, CellFormat st) {
/*  56 */     super(c, r, cont, st);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Label(int col, int row, Label l) {
/*  68 */     super(col, row, l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Label(LabelCell lc) {
/*  79 */     super(lc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setString(String s) {
/*  89 */     super.setString(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableCell copyTo(int col, int row) {
/* 101 */     return new Label(col, row, this);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\Label.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
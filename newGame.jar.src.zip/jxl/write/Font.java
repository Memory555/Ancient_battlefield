/*     */ package jxl.write;
/*     */ 
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.ScriptStyle;
/*     */ import jxl.format.UnderlineStyle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Font
/*     */   extends WritableFont
/*     */ {
/*  39 */   public static final WritableFont.FontName ARIAL = WritableFont.ARIAL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final WritableFont.FontName TIMES = WritableFont.TIMES;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final WritableFont.BoldStyle NO_BOLD = WritableFont.NO_BOLD;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public static final WritableFont.BoldStyle BOLD = WritableFont.BOLD;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public static final UnderlineStyle NO_UNDERLINE = UnderlineStyle.NO_UNDERLINE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public static final UnderlineStyle SINGLE = UnderlineStyle.SINGLE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public static final UnderlineStyle DOUBLE = UnderlineStyle.DOUBLE;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public static final UnderlineStyle SINGLE_ACCOUNTING = UnderlineStyle.SINGLE_ACCOUNTING;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public static final UnderlineStyle DOUBLE_ACCOUNTING = UnderlineStyle.DOUBLE_ACCOUNTING;
/*     */ 
/*     */ 
/*     */   
/*  90 */   public static final ScriptStyle NORMAL_SCRIPT = ScriptStyle.NORMAL_SCRIPT;
/*  91 */   public static final ScriptStyle SUPERSCRIPT = ScriptStyle.SUPERSCRIPT;
/*  92 */   public static final ScriptStyle SUBSCRIPT = ScriptStyle.SUBSCRIPT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font(WritableFont.FontName fn) {
/* 103 */     super(fn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font(WritableFont.FontName fn, int ps) {
/* 116 */     super(fn, ps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font(WritableFont.FontName fn, int ps, WritableFont.BoldStyle bs) {
/* 129 */     super(fn, ps, bs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font(WritableFont.FontName fn, int ps, WritableFont.BoldStyle bs, boolean italic) {
/* 144 */     super(fn, ps, bs, italic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font(WritableFont.FontName fn, int ps, WritableFont.BoldStyle bs, boolean it, UnderlineStyle us) {
/* 164 */     super(fn, ps, bs, it, us);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font(WritableFont.FontName fn, int ps, WritableFont.BoldStyle bs, boolean it, UnderlineStyle us, Colour c) {
/* 187 */     super(fn, ps, bs, it, us, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font(WritableFont.FontName fn, int ps, WritableFont.BoldStyle bs, boolean it, UnderlineStyle us, Colour c, ScriptStyle ss) {
/* 213 */     super(fn, ps, bs, it, us, c, ss);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\Font.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
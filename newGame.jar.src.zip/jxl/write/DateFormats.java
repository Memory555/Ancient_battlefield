/*     */ package jxl.write;
/*     */ 
/*     */ import jxl.biff.DisplayFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DateFormats
/*     */ {
/*     */   private static class BuiltInFormat
/*     */     implements DisplayFormat
/*     */   {
/*     */     private int index;
/*     */     private String formatString;
/*     */     
/*     */     public BuiltInFormat(int i, String s) {
/*  51 */       this.index = i;
/*  52 */       this.formatString = s;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getFormatIndex() {
/*  62 */       return this.index;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isInitialized() {
/*  73 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void initialize(int pos) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isBuiltIn() {
/*  92 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getFormatString() {
/* 103 */       return this.formatString;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 114 */       if (o == this)
/*     */       {
/* 116 */         return true;
/*     */       }
/*     */       
/* 119 */       if (!(o instanceof BuiltInFormat))
/*     */       {
/* 121 */         return false;
/*     */       }
/*     */       
/* 124 */       BuiltInFormat bif = (BuiltInFormat)o;
/*     */       
/* 126 */       return (this.index == bif.index);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 136 */       return this.index;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public static final DisplayFormat FORMAT1 = new BuiltInFormat(14, "M/d/yy");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public static final DisplayFormat DEFAULT = FORMAT1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public static final DisplayFormat FORMAT2 = new BuiltInFormat(15, "d-MMM-yy");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public static final DisplayFormat FORMAT3 = new BuiltInFormat(16, "d-MMM");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 167 */   public static final DisplayFormat FORMAT4 = new BuiltInFormat(17, "MMM-yy");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public static final DisplayFormat FORMAT5 = new BuiltInFormat(18, "h:mm a");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   public static final DisplayFormat FORMAT6 = new BuiltInFormat(19, "h:mm:ss a");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 185 */   public static final DisplayFormat FORMAT7 = new BuiltInFormat(20, "H:mm");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   public static final DisplayFormat FORMAT8 = new BuiltInFormat(21, "H:mm:ss");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   public static final DisplayFormat FORMAT9 = new BuiltInFormat(22, "M/d/yy H:mm");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   public static final DisplayFormat FORMAT10 = new BuiltInFormat(45, "mm:ss");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   public static final DisplayFormat FORMAT11 = new BuiltInFormat(46, "H:mm:ss");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   public static final DisplayFormat FORMAT12 = new BuiltInFormat(47, "H:mm:ss");
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\DateFormats.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
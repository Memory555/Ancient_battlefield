/*     */ package jxl.write;
/*     */ 
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.Font;
/*     */ import jxl.format.ScriptStyle;
/*     */ import jxl.format.UnderlineStyle;
/*     */ import jxl.write.biff.WritableFontRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WritableFont
/*     */   extends WritableFontRecord
/*     */ {
/*     */   public static class FontName
/*     */   {
/*     */     String name;
/*     */     
/*     */     FontName(String s) {
/*  52 */       this.name = s;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class BoldStyle
/*     */   {
/*     */     public int value;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     BoldStyle(int val) {
/*  73 */       this.value = val;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public static final FontName ARIAL = new FontName("Arial");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public static final FontName TIMES = new FontName("Times New Roman");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public static final FontName COURIER = new FontName("Courier New");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public static final FontName TAHOMA = new FontName("Tahoma");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public static final BoldStyle NO_BOLD = new BoldStyle(400);
/*     */ 
/*     */ 
/*     */   
/* 107 */   public static final BoldStyle BOLD = new BoldStyle(700);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int DEFAULT_POINT_SIZE = 10;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableFont(FontName fn) {
/* 122 */     this(fn, 10, NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableFont(Font f) {
/* 138 */     super(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableFont(FontName fn, int ps) {
/* 150 */     this(fn, ps, NO_BOLD, false, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableFont(FontName fn, int ps, BoldStyle bs) {
/* 165 */     this(fn, ps, bs, false, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableFont(FontName fn, int ps, BoldStyle bs, boolean italic) {
/* 182 */     this(fn, ps, bs, italic, UnderlineStyle.NO_UNDERLINE, Colour.BLACK, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableFont(FontName fn, int ps, BoldStyle bs, boolean it, UnderlineStyle us) {
/* 204 */     this(fn, ps, bs, it, us, Colour.BLACK, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableFont(FontName fn, int ps, BoldStyle bs, boolean it, UnderlineStyle us, Colour c) {
/* 226 */     this(fn, ps, bs, it, us, c, ScriptStyle.NORMAL_SCRIPT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableFont(FontName fn, int ps, BoldStyle bs, boolean it, UnderlineStyle us, Colour c, ScriptStyle ss) {
/* 251 */     super(fn.name, ps, bs.value, it, us.getValue(), c.getValue(), ss.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPointSize(int pointSize) throws WriteException {
/* 264 */     super.setPointSize(pointSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBoldStyle(BoldStyle boldStyle) throws WriteException {
/* 275 */     setBoldStyle(boldStyle.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setItalic(boolean italic) throws WriteException {
/* 287 */     super.setItalic(italic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnderlineStyle(UnderlineStyle us) throws WriteException {
/* 299 */     setUnderlineStyle(us.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColour(Colour colour) throws WriteException {
/* 311 */     setColour(colour.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScriptStyle(ScriptStyle scriptStyle) throws WriteException {
/* 323 */     setScriptStyle(scriptStyle.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FontName createFont(String fontName) {
/* 336 */     return new FontName(fontName);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\WritableFont.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write;
/*    */ 
/*    */ import jxl.format.BorderLineStyle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BorderLineStyle
/*    */   extends BorderLineStyle
/*    */ {
/*    */   private BorderLineStyle() {
/* 32 */     super(0, null);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\BorderLineStyle.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
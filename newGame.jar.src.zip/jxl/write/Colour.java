/*    */ package jxl.write;
/*    */ 
/*    */ import jxl.format.Colour;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Colour
/*    */   extends Colour
/*    */ {
/*    */   private Colour() {
/* 36 */     super(0, null, 0, 0, 0);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\Colour.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
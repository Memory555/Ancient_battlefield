/*    */ package jxl.write;
/*    */ 
/*    */ import jxl.CellFeatures;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WritableCellFeatures
/*    */   extends CellFeatures
/*    */ {
/*    */   public WritableCellFeatures() {}
/*    */   
/*    */   public WritableCellFeatures(CellFeatures cf) {
/* 44 */     super(cf);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setComment(String s) {
/* 54 */     super.setComment(s);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setComment(String s, double width, double height) {
/* 67 */     super.setComment(s, width, height);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeComment() {
/* 75 */     super.removeComment();
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\WritableCellFeatures.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
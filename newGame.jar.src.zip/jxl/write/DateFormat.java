/*    */ package jxl.write;
/*    */ 
/*    */ import java.text.SimpleDateFormat;
/*    */ import jxl.biff.DisplayFormat;
/*    */ import jxl.write.biff.DateFormatRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateFormat
/*    */   extends DateFormatRecord
/*    */   implements DisplayFormat
/*    */ {
/*    */   public DateFormat(String format) {
/* 47 */     super(format);
/*    */ 
/*    */     
/* 50 */     SimpleDateFormat df = new SimpleDateFormat(format);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\DateFormat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
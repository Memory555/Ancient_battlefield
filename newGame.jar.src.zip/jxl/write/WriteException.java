/*    */ package jxl.write;
/*    */ 
/*    */ import jxl.JXLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WriteException
/*    */   extends JXLException
/*    */ {
/*    */   protected WriteException(String s) {
/* 36 */     super(s);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\WriteException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write;
/*    */ 
/*    */ import jxl.format.Alignment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Alignment
/*    */   extends Alignment
/*    */ {
/*    */   private Alignment() {
/* 36 */     super(0, null);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\Alignment.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
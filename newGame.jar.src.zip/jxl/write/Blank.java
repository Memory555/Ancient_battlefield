/*    */ package jxl.write;
/*    */ 
/*    */ import jxl.Cell;
/*    */ import jxl.format.CellFormat;
/*    */ import jxl.write.biff.BlankRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Blank
/*    */   extends BlankRecord
/*    */   implements WritableCell
/*    */ {
/*    */   public Blank(int c, int r) {
/* 42 */     super(c, r);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Blank(int c, int r, CellFormat st) {
/* 56 */     super(c, r, st);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Blank(Cell lc) {
/* 67 */     super(lc);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Blank(int col, int row, Blank b) {
/* 80 */     super(col, row, b);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WritableCell copyTo(int col, int row) {
/* 92 */     return new Blank(col, row, this);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\Blank.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
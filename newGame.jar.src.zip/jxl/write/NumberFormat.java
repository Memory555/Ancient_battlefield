/*    */ package jxl.write;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import jxl.biff.DisplayFormat;
/*    */ import jxl.write.biff.NumberFormatRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NumberFormat
/*    */   extends NumberFormatRecord
/*    */   implements DisplayFormat
/*    */ {
/*    */   public NumberFormat(String format) {
/* 46 */     super(format);
/*    */ 
/*    */     
/* 49 */     DecimalFormat df = new DecimalFormat(format);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\NumberFormat.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
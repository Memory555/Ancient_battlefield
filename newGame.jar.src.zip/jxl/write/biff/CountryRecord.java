/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.CountryCode;
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CountryRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private int language;
/*    */   private int regionalSettings;
/*    */   
/*    */   public CountryRecord(CountryCode lang, CountryCode r) {
/* 48 */     super(Type.COUNTRY);
/*    */     
/* 50 */     this.language = lang.getValue();
/* 51 */     this.regionalSettings = r.getValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public CountryRecord(jxl.read.biff.CountryRecord cr) {
/* 56 */     super(Type.COUNTRY);
/*    */     
/* 58 */     this.language = cr.getLanguageCode();
/* 59 */     this.regionalSettings = cr.getRegionalSettingsCode();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 69 */     byte[] data = new byte[4];
/*    */     
/* 71 */     IntegerHelper.getTwoBytes(this.language, data, 0);
/* 72 */     IntegerHelper.getTwoBytes(this.regionalSettings, data, 2);
/*    */     
/* 74 */     return data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\CountryRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
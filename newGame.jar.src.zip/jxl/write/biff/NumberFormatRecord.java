/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.FormatRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NumberFormatRecord
/*     */   extends FormatRecord
/*     */ {
/*  30 */   private static Logger logger = Logger.getLogger(NumberFormatRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NumberFormatRecord(String fmt) {
/*  43 */     String fs = fmt;
/*     */     
/*  45 */     fs = replace(fs, "E0", "E+0");
/*     */     
/*  47 */     fs = trimInvalidChars(fs);
/*     */     
/*  49 */     setFormatString(fs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String trimInvalidChars(String fs) {
/*  61 */     int firstHash = fs.indexOf('#');
/*  62 */     int firstZero = fs.indexOf('0');
/*  63 */     int firstValidChar = 0;
/*     */     
/*  65 */     if (firstHash == -1 && firstZero == -1)
/*     */     {
/*     */       
/*  68 */       return "#.###";
/*     */     }
/*     */     
/*  71 */     if (firstHash != 0 && firstZero != 0 && firstHash != 1 && firstZero != 1) {
/*     */ 
/*     */ 
/*     */       
/*  75 */       firstHash = (firstHash == -1) ? (firstHash = Integer.MAX_VALUE) : firstHash;
/*  76 */       firstZero = (firstZero == -1) ? (firstZero = Integer.MAX_VALUE) : firstZero;
/*  77 */       firstValidChar = Math.min(firstHash, firstZero);
/*     */       
/*  79 */       StringBuffer tmp = new StringBuffer();
/*  80 */       tmp.append(fs.charAt(0));
/*  81 */       tmp.append(fs.substring(firstValidChar));
/*  82 */       fs = tmp.toString();
/*     */     } 
/*     */ 
/*     */     
/*  86 */     int lastHash = fs.lastIndexOf('#');
/*  87 */     int lastZero = fs.lastIndexOf('0');
/*     */     
/*  89 */     if (lastHash == fs.length() || lastZero == fs.length())
/*     */     {
/*     */       
/*  92 */       return fs;
/*     */     }
/*     */ 
/*     */     
/*  96 */     int lastValidChar = Math.max(lastHash, lastZero);
/*     */ 
/*     */     
/*  99 */     while (fs.length() > lastValidChar + 1 && (fs.charAt(lastValidChar + 1) == ')' || fs.charAt(lastValidChar + 1) == '%'))
/*     */     {
/*     */ 
/*     */       
/* 103 */       lastValidChar++;
/*     */     }
/*     */     
/* 106 */     return fs.substring(0, lastValidChar + 1);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\NumberFormatRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
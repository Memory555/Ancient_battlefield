/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class GuttersRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private int rowGutter;
/*    */   private int colGutter;
/*    */   private int maxRowOutline;
/*    */   private int maxColOutline;
/*    */   
/*    */   public GuttersRecord() {
/* 59 */     super(Type.GUTS);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 69 */     this.data = new byte[8];
/* 70 */     IntegerHelper.getTwoBytes(this.rowGutter, this.data, 0);
/* 71 */     IntegerHelper.getTwoBytes(this.colGutter, this.data, 2);
/* 72 */     IntegerHelper.getTwoBytes(this.maxRowOutline, this.data, 4);
/* 73 */     IntegerHelper.getTwoBytes(this.maxColOutline, this.data, 6);
/* 74 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\GuttersRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
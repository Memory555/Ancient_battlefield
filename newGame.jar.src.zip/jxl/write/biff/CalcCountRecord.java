/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CalcCountRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private int calcCount;
/*    */   private byte[] data;
/*    */   
/*    */   public CalcCountRecord(int cnt) {
/* 49 */     super(Type.CALCCOUNT);
/* 50 */     this.calcCount = cnt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 61 */     byte[] data = new byte[2];
/*    */     
/* 63 */     IntegerHelper.getTwoBytes(this.calcCount, data, 0);
/*    */     
/* 65 */     return data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\CalcCountRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
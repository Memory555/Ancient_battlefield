/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DBCellRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private int rowPos;
/*     */   private int cellOffset;
/*     */   private ArrayList cellRowPositions;
/*     */   private int position;
/*     */   
/*     */   public DBCellRecord(int rp) {
/*  63 */     super(Type.DBCELL);
/*  64 */     this.rowPos = rp;
/*  65 */     this.cellRowPositions = new ArrayList(10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setCellOffset(int pos) {
/*  75 */     this.cellOffset = pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addCellRowPosition(int pos) {
/*  85 */     this.cellRowPositions.add(new Integer(pos));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPosition(int pos) {
/*  95 */     this.position = pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] getData() {
/* 105 */     byte[] data = new byte[4 + 2 * this.cellRowPositions.size()];
/*     */ 
/*     */     
/* 108 */     IntegerHelper.getFourBytes(this.position - this.rowPos, data, 0);
/*     */ 
/*     */     
/* 111 */     int pos = 4;
/* 112 */     int lastCellPos = this.cellOffset;
/* 113 */     Iterator i = this.cellRowPositions.iterator();
/* 114 */     while (i.hasNext()) {
/*     */       
/* 116 */       int cellPos = ((Integer)i.next()).intValue();
/* 117 */       IntegerHelper.getTwoBytes(cellPos - lastCellPos, data, pos);
/* 118 */       lastCellPos = cellPos;
/* 119 */       pos += 2;
/*     */     } 
/*     */     
/* 122 */     return data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\DBCellRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*      */ package jxl.write.biff;
/*      */ 
/*      */ import common.Assert;
/*      */ import common.Logger;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import jxl.Range;
/*      */ import jxl.Sheet;
/*      */ import jxl.Workbook;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.ByteData;
/*      */ import jxl.biff.CountryCode;
/*      */ import jxl.biff.Fonts;
/*      */ import jxl.biff.FormattingRecords;
/*      */ import jxl.biff.IndexMapping;
/*      */ import jxl.biff.IntegerHelper;
/*      */ import jxl.biff.RangeImpl;
/*      */ import jxl.biff.WorkbookMethods;
/*      */ import jxl.biff.drawing.Drawing;
/*      */ import jxl.biff.drawing.DrawingGroup;
/*      */ import jxl.biff.drawing.DrawingGroupObject;
/*      */ import jxl.biff.drawing.Origin;
/*      */ import jxl.biff.formula.ExternalSheet;
/*      */ import jxl.format.Colour;
/*      */ import jxl.format.RGB;
/*      */ import jxl.read.biff.BOFRecord;
/*      */ import jxl.read.biff.NameRecord;
/*      */ import jxl.read.biff.SupbookRecord;
/*      */ import jxl.read.biff.WorkbookParser;
/*      */ import jxl.write.WritableCell;
/*      */ import jxl.write.WritableSheet;
/*      */ import jxl.write.WritableWorkbook;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WritableWorkbookImpl
/*      */   extends WritableWorkbook
/*      */   implements ExternalSheet, WorkbookMethods
/*      */ {
/*   65 */   private static Logger logger = Logger.getLogger(WritableWorkbookImpl.class);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FormattingRecords formatRecords;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private File outputFile;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList sheets;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Fonts fonts;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ExternalSheetRecord externSheet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList supbooks;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList names;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HashMap nameRecords;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SharedStrings sharedStrings;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean closeStream;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean wbProtected;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WorkbookSettings settings;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList rcirCells;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DrawingGroup drawingGroup;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Styles styles;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean containsMacros;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private CountryRecord countryRecord;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableWorkbookImpl(OutputStream os, boolean cs, WorkbookSettings ws) throws IOException {
/*  169 */     this.outputFile = new File(os, ws, null);
/*  170 */     this.sheets = new ArrayList();
/*  171 */     this.sharedStrings = new SharedStrings();
/*  172 */     this.nameRecords = new HashMap();
/*  173 */     this.closeStream = cs;
/*  174 */     this.wbProtected = false;
/*  175 */     this.containsMacros = false;
/*  176 */     this.settings = ws;
/*  177 */     this.rcirCells = new ArrayList();
/*  178 */     this.styles = new Styles();
/*      */ 
/*      */     
/*  181 */     WritableWorkbook.ARIAL_10_PT.uninitialize();
/*  182 */     WritableWorkbook.HYPERLINK_FONT.uninitialize();
/*  183 */     WritableWorkbook.NORMAL_STYLE.uninitialize();
/*  184 */     WritableWorkbook.HYPERLINK_STYLE.uninitialize();
/*  185 */     WritableWorkbook.HIDDEN_STYLE.uninitialize();
/*  186 */     DateRecord.defaultDateFormat.uninitialize();
/*      */     
/*  188 */     WritableFonts wf = new WritableFonts(this);
/*  189 */     this.fonts = wf;
/*      */     
/*  191 */     WritableFormattingRecords wfr = new WritableFormattingRecords(this.fonts, this.styles);
/*      */     
/*  193 */     this.formatRecords = wfr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableWorkbookImpl(OutputStream os, Workbook w, boolean cs, WorkbookSettings ws) throws IOException {
/*  212 */     WorkbookParser wp = (WorkbookParser)w;
/*      */ 
/*      */     
/*  215 */     WritableWorkbook.ARIAL_10_PT.uninitialize();
/*  216 */     WritableWorkbook.HYPERLINK_FONT.uninitialize();
/*  217 */     WritableWorkbook.NORMAL_STYLE.uninitialize();
/*  218 */     WritableWorkbook.HYPERLINK_STYLE.uninitialize();
/*  219 */     WritableWorkbook.HIDDEN_STYLE.uninitialize();
/*  220 */     DateRecord.defaultDateFormat.uninitialize();
/*      */     
/*  222 */     this.closeStream = cs;
/*  223 */     this.sheets = new ArrayList();
/*  224 */     this.sharedStrings = new SharedStrings();
/*  225 */     this.nameRecords = new HashMap();
/*  226 */     this.fonts = wp.getFonts();
/*  227 */     this.formatRecords = wp.getFormattingRecords();
/*  228 */     this.wbProtected = false;
/*  229 */     this.settings = ws;
/*  230 */     this.rcirCells = new ArrayList();
/*  231 */     this.styles = new Styles();
/*  232 */     this.outputFile = new File(os, ws, wp.getCompoundFile());
/*      */     
/*  234 */     this.containsMacros = false;
/*  235 */     if (!ws.getPropertySetsDisabled())
/*      */     {
/*  237 */       this.containsMacros = wp.containsMacros();
/*      */     }
/*      */ 
/*      */     
/*  241 */     if (wp.getCountryRecord() != null)
/*      */     {
/*  243 */       this.countryRecord = new CountryRecord(wp.getCountryRecord());
/*      */     }
/*      */ 
/*      */     
/*  247 */     if (wp.getExternalSheetRecord() != null) {
/*      */       
/*  249 */       this.externSheet = new ExternalSheetRecord(wp.getExternalSheetRecord());
/*      */ 
/*      */       
/*  252 */       SupbookRecord[] readsr = wp.getSupbookRecords();
/*  253 */       this.supbooks = new ArrayList(readsr.length);
/*      */       
/*  255 */       for (int i = 0; i < readsr.length; i++)
/*      */       {
/*  257 */         this.supbooks.add(new SupbookRecord(readsr[i], this.settings));
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  263 */     if (wp.getDrawingGroup() != null)
/*      */     {
/*  265 */       this.drawingGroup = new DrawingGroup(wp.getDrawingGroup());
/*      */     }
/*      */ 
/*      */     
/*  269 */     if (this.containsMacros && wp.getButtonPropertySet() != null)
/*      */     {
/*  271 */       this.buttonPropertySet = new ButtonPropertySetRecord(wp.getButtonPropertySet());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  276 */     if (!this.settings.getNamesDisabled()) {
/*      */       
/*  278 */       NameRecord[] na = wp.getNameRecords();
/*  279 */       this.names = new ArrayList(na.length);
/*      */       
/*  281 */       for (int i = 0; i < na.length; i++) {
/*      */         
/*  283 */         if (na[i].isBiff8()) {
/*      */           
/*  285 */           NameRecord n = new NameRecord(na[i], i);
/*  286 */           this.names.add(n);
/*  287 */           String name = n.getName();
/*  288 */           this.nameRecords.put(name, n);
/*      */         }
/*      */         else {
/*      */           
/*  292 */           logger.warn("Cannot copy Biff7 name records - ignoring");
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  297 */     copyWorkbook(w);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  302 */     if (this.drawingGroup != null)
/*      */     {
/*  304 */       this.drawingGroup.updateData(wp.getDrawingGroup());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableSheet[] getSheets() {
/*  316 */     WritableSheet[] sheetArray = new WritableSheet[getNumberOfSheets()];
/*      */     
/*  318 */     for (int i = 0; i < getNumberOfSheets(); i++)
/*      */     {
/*  320 */       sheetArray[i] = getSheet(i);
/*      */     }
/*  322 */     return sheetArray;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getSheetNames() {
/*  332 */     String[] sheetNames = new String[getNumberOfSheets()];
/*      */     
/*  334 */     for (int i = 0; i < sheetNames.length; i++)
/*      */     {
/*  336 */       sheetNames[i] = getSheet(i).getName();
/*      */     }
/*      */     
/*  339 */     return sheetNames;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Sheet getReadSheet(int index) {
/*  351 */     return (Sheet)getSheet(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableSheet getSheet(int index) {
/*  362 */     return this.sheets.get(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableSheet getSheet(String name) {
/*  374 */     boolean found = false;
/*  375 */     Iterator i = this.sheets.iterator();
/*  376 */     WritableSheet s = null;
/*      */     
/*  378 */     while (i.hasNext() && !found) {
/*      */       
/*  380 */       s = i.next();
/*      */       
/*  382 */       if (s.getName().equals(name))
/*      */       {
/*  384 */         found = true;
/*      */       }
/*      */     } 
/*      */     
/*  388 */     return found ? s : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfSheets() {
/*  398 */     return this.sheets.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws IOException, JxlWriteException {
/*  410 */     this.outputFile.close(this.closeStream);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOutputFile(File fileName) throws IOException {
/*  423 */     FileOutputStream fos = new FileOutputStream(fileName);
/*  424 */     this.outputFile.setOutputFile(fos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WritableSheet createSheet(String name, int index, boolean handleRefs) {
/*  440 */     WritableSheet w = new WritableSheetImpl(name, this.outputFile, this.formatRecords, this.sharedStrings, this.settings, this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  447 */     int pos = index;
/*      */     
/*  449 */     if (index <= 0) {
/*      */       
/*  451 */       pos = 0;
/*  452 */       this.sheets.add(0, w);
/*      */     }
/*  454 */     else if (index > this.sheets.size()) {
/*      */       
/*  456 */       pos = this.sheets.size();
/*  457 */       this.sheets.add(w);
/*      */     }
/*      */     else {
/*      */       
/*  461 */       this.sheets.add(index, w);
/*      */     } 
/*      */     
/*  464 */     if (handleRefs && this.externSheet != null)
/*      */     {
/*  466 */       this.externSheet.sheetInserted(pos);
/*      */     }
/*      */     
/*  469 */     if (this.supbooks != null && this.supbooks.size() > 0) {
/*      */       
/*  471 */       SupbookRecord supbook = this.supbooks.get(0);
/*  472 */       if (supbook.getType() == SupbookRecord.INTERNAL)
/*      */       {
/*  474 */         supbook.adjustInternal(this.sheets.size());
/*      */       }
/*      */     } 
/*      */     
/*  478 */     return w;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableSheet createSheet(String name, int index) {
/*  492 */     return createSheet(name, index, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeSheet(int index) {
/*  504 */     int pos = index;
/*  505 */     if (index <= 0) {
/*      */       
/*  507 */       pos = 0;
/*  508 */       this.sheets.remove(0);
/*      */     }
/*  510 */     else if (index >= this.sheets.size()) {
/*      */       
/*  512 */       pos = this.sheets.size() - 1;
/*  513 */       this.sheets.remove(this.sheets.size() - 1);
/*      */     }
/*      */     else {
/*      */       
/*  517 */       this.sheets.remove(index);
/*      */     } 
/*      */     
/*  520 */     if (this.externSheet != null)
/*      */     {
/*  522 */       this.externSheet.sheetRemoved(pos);
/*      */     }
/*      */     
/*  525 */     if (this.supbooks != null && this.supbooks.size() > 0) {
/*      */       
/*  527 */       SupbookRecord supbook = this.supbooks.get(0);
/*  528 */       if (supbook.getType() == SupbookRecord.INTERNAL)
/*      */       {
/*  530 */         supbook.adjustInternal(this.sheets.size());
/*      */       }
/*      */     } 
/*      */     
/*  534 */     if (this.names != null && this.names.size() > 0)
/*      */     {
/*  536 */       for (int i = 0; i < this.names.size(); i++) {
/*      */         
/*  538 */         NameRecord n = this.names.get(i);
/*  539 */         int oldRef = n.getSheetRef();
/*  540 */         if (oldRef == pos + 1) {
/*      */           
/*  542 */           n.setSheetRef(0);
/*      */         }
/*  544 */         else if (oldRef > pos + 1) {
/*      */           
/*  546 */           if (oldRef < 1)
/*      */           {
/*  548 */             oldRef = 1;
/*      */           }
/*  550 */           n.setSheetRef(oldRef - 1);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableSheet moveSheet(int fromIndex, int toIndex) {
/*  567 */     fromIndex = Math.max(fromIndex, 0);
/*  568 */     fromIndex = Math.min(fromIndex, this.sheets.size() - 1);
/*  569 */     toIndex = Math.max(toIndex, 0);
/*  570 */     toIndex = Math.min(toIndex, this.sheets.size() - 1);
/*      */     
/*  572 */     WritableSheet sheet = this.sheets.remove(fromIndex);
/*  573 */     this.sheets.add(toIndex, sheet);
/*      */     
/*  575 */     return sheet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write() throws IOException {
/*  589 */     WritableSheetImpl wsi = null;
/*  590 */     for (int i = 0; i < getNumberOfSheets(); i++) {
/*      */       
/*  592 */       wsi = (WritableSheetImpl)getSheet(i);
/*  593 */       wsi.checkMergedBorders();
/*      */     } 
/*      */ 
/*      */     
/*  597 */     if (!this.settings.getRationalizationDisabled())
/*      */     {
/*  599 */       rationalize();
/*      */     }
/*      */ 
/*      */     
/*  603 */     BOFRecord bof = new BOFRecord(BOFRecord.workbookGlobals);
/*  604 */     this.outputFile.write((ByteData)bof);
/*      */     
/*  606 */     InterfaceHeaderRecord ihr = new InterfaceHeaderRecord();
/*  607 */     this.outputFile.write((ByteData)ihr);
/*      */     
/*  609 */     MMSRecord mms = new MMSRecord(0, 0);
/*  610 */     this.outputFile.write((ByteData)mms);
/*      */     
/*  612 */     InterfaceEndRecord ier = new InterfaceEndRecord();
/*  613 */     this.outputFile.write((ByteData)ier);
/*      */     
/*  615 */     WriteAccessRecord wr = new WriteAccessRecord();
/*  616 */     this.outputFile.write((ByteData)wr);
/*      */     
/*  618 */     CodepageRecord cp = new CodepageRecord();
/*  619 */     this.outputFile.write((ByteData)cp);
/*      */     
/*  621 */     DSFRecord dsf = new DSFRecord();
/*  622 */     this.outputFile.write((ByteData)dsf);
/*      */     
/*  624 */     TabIdRecord tabid = new TabIdRecord(getNumberOfSheets());
/*  625 */     this.outputFile.write((ByteData)tabid);
/*      */     
/*  627 */     if (this.containsMacros) {
/*      */       
/*  629 */       ObjProjRecord objproj = new ObjProjRecord();
/*  630 */       this.outputFile.write((ByteData)objproj);
/*      */     } 
/*      */     
/*  633 */     if (this.buttonPropertySet != null)
/*      */     {
/*  635 */       this.outputFile.write((ByteData)this.buttonPropertySet);
/*      */     }
/*      */     
/*  638 */     FunctionGroupCountRecord fgcr = new FunctionGroupCountRecord();
/*  639 */     this.outputFile.write((ByteData)fgcr);
/*      */ 
/*      */     
/*  642 */     WindowProtectRecord wpr = new WindowProtectRecord(false);
/*  643 */     this.outputFile.write((ByteData)wpr);
/*      */     
/*  645 */     ProtectRecord pr = new ProtectRecord(this.wbProtected);
/*  646 */     this.outputFile.write((ByteData)pr);
/*      */     
/*  648 */     PasswordRecord pw = new PasswordRecord(null);
/*  649 */     this.outputFile.write((ByteData)pw);
/*      */     
/*  651 */     Prot4RevRecord p4r = new Prot4RevRecord(false);
/*  652 */     this.outputFile.write((ByteData)p4r);
/*      */     
/*  654 */     Prot4RevPassRecord p4rp = new Prot4RevPassRecord();
/*  655 */     this.outputFile.write((ByteData)p4rp);
/*      */     
/*  657 */     Window1Record w1r = new Window1Record();
/*  658 */     this.outputFile.write((ByteData)w1r);
/*      */     
/*  660 */     BackupRecord bkr = new BackupRecord(false);
/*  661 */     this.outputFile.write((ByteData)bkr);
/*      */     
/*  663 */     HideobjRecord ho = new HideobjRecord(false);
/*  664 */     this.outputFile.write((ByteData)ho);
/*      */     
/*  666 */     NineteenFourRecord nf = new NineteenFourRecord(false);
/*  667 */     this.outputFile.write((ByteData)nf);
/*      */     
/*  669 */     PrecisionRecord pc = new PrecisionRecord(false);
/*  670 */     this.outputFile.write((ByteData)pc);
/*      */     
/*  672 */     RefreshAllRecord rar = new RefreshAllRecord(false);
/*  673 */     this.outputFile.write((ByteData)rar);
/*      */     
/*  675 */     BookboolRecord bb = new BookboolRecord(true);
/*  676 */     this.outputFile.write((ByteData)bb);
/*      */ 
/*      */     
/*  679 */     this.fonts.write(this.outputFile);
/*      */ 
/*      */     
/*  682 */     this.formatRecords.write(this.outputFile);
/*      */ 
/*      */     
/*  685 */     if (this.formatRecords.getPalette() != null)
/*      */     {
/*  687 */       this.outputFile.write((ByteData)this.formatRecords.getPalette());
/*      */     }
/*      */ 
/*      */     
/*  691 */     UsesElfsRecord uer = new UsesElfsRecord();
/*  692 */     this.outputFile.write((ByteData)uer);
/*      */ 
/*      */ 
/*      */     
/*  696 */     int[] boundsheetPos = new int[getNumberOfSheets()];
/*  697 */     Sheet sheet = null;
/*      */     int j;
/*  699 */     for (j = 0; j < getNumberOfSheets(); j++) {
/*      */       
/*  701 */       boundsheetPos[j] = this.outputFile.getPos();
/*  702 */       WritableSheet writableSheet = getSheet(j);
/*  703 */       BoundsheetRecord br = new BoundsheetRecord(writableSheet.getName());
/*      */       
/*  705 */       if (writableSheet.getSettings().isHidden())
/*      */       {
/*  707 */         br.setHidden();
/*      */       }
/*      */       
/*  710 */       if (((WritableSheetImpl)this.sheets.get(j)).isChartOnly())
/*      */       {
/*  712 */         br.setChartOnly();
/*      */       }
/*      */       
/*  715 */       this.outputFile.write((ByteData)br);
/*      */     } 
/*      */     
/*  718 */     if (this.countryRecord == null) {
/*      */       
/*  720 */       CountryCode lang = CountryCode.getCountryCode(this.settings.getExcelDisplayLanguage());
/*      */       
/*  722 */       if (lang == CountryCode.UNKNOWN) {
/*      */         
/*  724 */         logger.warn("Unknown country code " + this.settings.getExcelDisplayLanguage() + " using " + CountryCode.USA.getCode());
/*      */ 
/*      */         
/*  727 */         lang = CountryCode.USA;
/*      */       } 
/*  729 */       CountryCode region = CountryCode.getCountryCode(this.settings.getExcelRegionalSettings());
/*      */       
/*  731 */       this.countryRecord = new CountryRecord(lang, region);
/*  732 */       if (region == CountryCode.UNKNOWN) {
/*      */         
/*  734 */         logger.warn("Unknown country code " + this.settings.getExcelDisplayLanguage() + " using " + CountryCode.UK.getCode());
/*      */ 
/*      */         
/*  737 */         region = CountryCode.UK;
/*      */       } 
/*      */     } 
/*      */     
/*  741 */     this.outputFile.write((ByteData)this.countryRecord);
/*      */ 
/*      */     
/*  744 */     if (this.externSheet != null) {
/*      */ 
/*      */       
/*  747 */       for (j = 0; j < this.supbooks.size(); j++) {
/*      */         
/*  749 */         SupbookRecord supbook = this.supbooks.get(j);
/*  750 */         this.outputFile.write((ByteData)supbook);
/*      */       } 
/*  752 */       this.outputFile.write((ByteData)this.externSheet);
/*      */     } 
/*      */ 
/*      */     
/*  756 */     if (this.names != null)
/*      */     {
/*  758 */       for (j = 0; j < this.names.size(); j++) {
/*      */         
/*  760 */         NameRecord n = this.names.get(j);
/*  761 */         this.outputFile.write((ByteData)n);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  766 */     if (this.drawingGroup != null)
/*      */     {
/*  768 */       this.drawingGroup.write(this.outputFile);
/*      */     }
/*      */     
/*  771 */     this.sharedStrings.write(this.outputFile);
/*      */     
/*  773 */     EOFRecord eof = new EOFRecord();
/*  774 */     this.outputFile.write((ByteData)eof);
/*      */ 
/*      */ 
/*      */     
/*  778 */     boolean sheetSelected = false;
/*  779 */     WritableSheetImpl wsheet = null; int k;
/*  780 */     for (k = 0; k < getNumberOfSheets() && !sheetSelected; k++) {
/*      */       
/*  782 */       wsheet = (WritableSheetImpl)getSheet(k);
/*  783 */       if (wsheet.getSettings().isSelected())
/*      */       {
/*  785 */         sheetSelected = true;
/*      */       }
/*      */     } 
/*      */     
/*  789 */     if (!sheetSelected) {
/*      */       
/*  791 */       wsheet = (WritableSheetImpl)getSheet(0);
/*  792 */       wsheet.getSettings().setSelected(true);
/*      */     } 
/*      */ 
/*      */     
/*  796 */     for (k = 0; k < getNumberOfSheets(); k++) {
/*      */ 
/*      */ 
/*      */       
/*  800 */       this.outputFile.setData(IntegerHelper.getFourBytes(this.outputFile.getPos()), boundsheetPos[k] + 4);
/*      */ 
/*      */ 
/*      */       
/*  804 */       wsheet = (WritableSheetImpl)getSheet(k);
/*  805 */       wsheet.write();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void copyWorkbook(Workbook w) {
/*  818 */     int numSheets = w.getNumberOfSheets();
/*  819 */     this.wbProtected = w.isProtected();
/*  820 */     Sheet s = null;
/*  821 */     WritableSheetImpl ws = null;
/*  822 */     for (int i = 0; i < numSheets; i++) {
/*      */       
/*  824 */       s = w.getSheet(i);
/*  825 */       ws = (WritableSheetImpl)createSheet(s.getName(), i, false);
/*  826 */       ws.copy(s);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copySheet(int s, String name, int index) {
/*  840 */     WritableSheet sheet = getSheet(s);
/*  841 */     WritableSheetImpl ws = (WritableSheetImpl)createSheet(name, index);
/*  842 */     ws.copy(sheet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copySheet(String s, String name, int index) {
/*  855 */     WritableSheet sheet = getSheet(s);
/*  856 */     WritableSheetImpl ws = (WritableSheetImpl)createSheet(name, index);
/*  857 */     ws.copy(sheet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProtected(boolean prot) {
/*  867 */     this.wbProtected = prot;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void rationalize() {
/*  876 */     IndexMapping fontMapping = this.formatRecords.rationalizeFonts();
/*  877 */     IndexMapping formatMapping = this.formatRecords.rationalizeDisplayFormats();
/*  878 */     IndexMapping xfMapping = this.formatRecords.rationalize(fontMapping, formatMapping);
/*      */ 
/*      */     
/*  881 */     WritableSheetImpl wsi = null;
/*  882 */     for (int i = 0; i < this.sheets.size(); i++) {
/*      */       
/*  884 */       wsi = this.sheets.get(i);
/*  885 */       wsi.rationalize(xfMapping, fontMapping, formatMapping);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getExternalSheetName(int index) {
/*  897 */     int supbookIndex = this.externSheet.getSupbookIndex(index);
/*  898 */     SupbookRecord sr = this.supbooks.get(supbookIndex);
/*      */     
/*  900 */     int firstTab = this.externSheet.getFirstTabIndex(index);
/*      */     
/*  902 */     if (sr.getType() == SupbookRecord.INTERNAL) {
/*      */ 
/*      */       
/*  905 */       WritableSheet ws = getSheet(firstTab);
/*      */       
/*  907 */       return ws.getName();
/*      */     } 
/*  909 */     if (sr.getType() == SupbookRecord.EXTERNAL) {
/*      */       
/*  911 */       String name = sr.getFileName() + sr.getSheetName(firstTab);
/*  912 */       return name;
/*      */     } 
/*      */ 
/*      */     
/*  916 */     return "[UNKNOWN]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLastExternalSheetName(int index) {
/*  927 */     int supbookIndex = this.externSheet.getSupbookIndex(index);
/*  928 */     SupbookRecord sr = this.supbooks.get(supbookIndex);
/*      */     
/*  930 */     int lastTab = this.externSheet.getLastTabIndex(index);
/*      */     
/*  932 */     if (sr.getType() == SupbookRecord.INTERNAL) {
/*      */ 
/*      */       
/*  935 */       WritableSheet ws = getSheet(lastTab);
/*      */       
/*  937 */       return ws.getName();
/*      */     } 
/*  939 */     if (sr.getType() == SupbookRecord.EXTERNAL)
/*      */     {
/*  941 */       Assert.verify(false);
/*      */     }
/*      */ 
/*      */     
/*  945 */     return "[UNKNOWN]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BOFRecord getWorkbookBof() {
/*  956 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getExternalSheetIndex(int index) {
/*  968 */     if (this.externSheet == null)
/*      */     {
/*  970 */       return index;
/*      */     }
/*      */     
/*  973 */     Assert.verify((this.externSheet != null));
/*      */     
/*  975 */     int firstTab = this.externSheet.getFirstTabIndex(index);
/*      */     
/*  977 */     return firstTab;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastExternalSheetIndex(int index) {
/*  988 */     if (this.externSheet == null)
/*      */     {
/*  990 */       return index;
/*      */     }
/*      */     
/*  993 */     Assert.verify((this.externSheet != null));
/*      */     
/*  995 */     int lastTab = this.externSheet.getLastTabIndex(index);
/*      */     
/*  997 */     return lastTab;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getExternalSheetIndex(String sheetName) {
/* 1007 */     if (this.externSheet == null) {
/*      */       
/* 1009 */       this.externSheet = new ExternalSheetRecord();
/* 1010 */       this.supbooks = new ArrayList();
/* 1011 */       this.supbooks.add(new SupbookRecord(getNumberOfSheets(), this.settings));
/*      */     } 
/*      */ 
/*      */     
/* 1015 */     boolean found = false;
/* 1016 */     Iterator i = this.sheets.iterator();
/* 1017 */     int sheetpos = 0;
/* 1018 */     WritableSheetImpl s = null;
/*      */     
/* 1020 */     while (i.hasNext() && !found) {
/*      */       
/* 1022 */       s = i.next();
/*      */       
/* 1024 */       if (s.getName().equals(sheetName)) {
/*      */         
/* 1026 */         found = true;
/*      */         
/*      */         continue;
/*      */       } 
/* 1030 */       sheetpos++;
/*      */     } 
/*      */ 
/*      */     
/* 1034 */     if (found) {
/*      */ 
/*      */ 
/*      */       
/* 1038 */       SupbookRecord supbook = this.supbooks.get(0);
/* 1039 */       Assert.verify((supbook.getType() == SupbookRecord.INTERNAL && supbook.getNumberOfSheets() == getNumberOfSheets()));
/*      */ 
/*      */       
/* 1042 */       return this.externSheet.getIndex(0, sheetpos);
/*      */     } 
/*      */ 
/*      */     
/* 1046 */     int closeSquareBracketsIndex = sheetName.lastIndexOf(']');
/* 1047 */     int openSquareBracketsIndex = sheetName.lastIndexOf('[');
/*      */     
/* 1049 */     if (closeSquareBracketsIndex == -1 || openSquareBracketsIndex == -1)
/*      */     {
/*      */       
/* 1052 */       return -1;
/*      */     }
/*      */     
/* 1055 */     String worksheetName = sheetName.substring(closeSquareBracketsIndex + 1);
/* 1056 */     String workbookName = sheetName.substring(openSquareBracketsIndex + 1, closeSquareBracketsIndex);
/*      */     
/* 1058 */     String path = sheetName.substring(0, openSquareBracketsIndex);
/* 1059 */     String fileName = path + workbookName;
/*      */     
/* 1061 */     boolean supbookFound = false;
/* 1062 */     SupbookRecord externalSupbook = null;
/* 1063 */     int supbookIndex = -1;
/* 1064 */     for (int ind = 0; ind < this.supbooks.size() && !supbookFound; ind++) {
/*      */       
/* 1066 */       externalSupbook = this.supbooks.get(ind);
/* 1067 */       if (externalSupbook.getType() == SupbookRecord.EXTERNAL && externalSupbook.getFileName().equals(fileName)) {
/*      */ 
/*      */         
/* 1070 */         supbookFound = true;
/* 1071 */         supbookIndex = ind;
/*      */       } 
/*      */     } 
/*      */     
/* 1075 */     if (!supbookFound) {
/*      */       
/* 1077 */       externalSupbook = new SupbookRecord(fileName, this.settings);
/* 1078 */       supbookIndex = this.supbooks.size();
/* 1079 */       this.supbooks.add(externalSupbook);
/*      */     } 
/*      */     
/* 1082 */     int sheetIndex = externalSupbook.getSheetIndex(worksheetName);
/*      */     
/* 1084 */     return this.externSheet.getIndex(supbookIndex, sheetIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastExternalSheetIndex(String sheetName) {
/* 1094 */     if (this.externSheet == null) {
/*      */       
/* 1096 */       this.externSheet = new ExternalSheetRecord();
/* 1097 */       this.supbooks = new ArrayList();
/* 1098 */       this.supbooks.add(new SupbookRecord(getNumberOfSheets(), this.settings));
/*      */     } 
/*      */ 
/*      */     
/* 1102 */     boolean found = false;
/* 1103 */     Iterator i = this.sheets.iterator();
/* 1104 */     int sheetpos = 0;
/* 1105 */     WritableSheetImpl s = null;
/*      */     
/* 1107 */     while (i.hasNext() && !found) {
/*      */       
/* 1109 */       s = i.next();
/*      */       
/* 1111 */       if (s.getName().equals(sheetName)) {
/*      */         
/* 1113 */         found = true;
/*      */         
/*      */         continue;
/*      */       } 
/* 1117 */       sheetpos++;
/*      */     } 
/*      */ 
/*      */     
/* 1121 */     if (!found)
/*      */     {
/* 1123 */       return -1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1128 */     SupbookRecord supbook = this.supbooks.get(0);
/* 1129 */     Assert.verify((supbook.getType() == SupbookRecord.INTERNAL && supbook.getNumberOfSheets() == getNumberOfSheets()));
/*      */ 
/*      */     
/* 1132 */     return this.externSheet.getIndex(0, sheetpos);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColourRGB(Colour c, int r, int g, int b) {
/* 1145 */     this.formatRecords.setColourRGB(c, r, g, b);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RGB getColourRGB(Colour c) {
/* 1155 */     return this.formatRecords.getColourRGB(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName(int index) {
/* 1166 */     Assert.verify((index >= 0 && index < this.names.size()));
/* 1167 */     NameRecord n = this.names.get(index);
/* 1168 */     return n.getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNameIndex(String name) {
/* 1179 */     NameRecord nr = (NameRecord)this.nameRecords.get(name);
/* 1180 */     return (nr != null) ? nr.getIndex() : -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void addRCIRCell(CellValue cv) {
/* 1191 */     this.rcirCells.add(cv);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void columnInserted(WritableSheetImpl s, int col) {
/* 1203 */     int externalSheetIndex = getExternalSheetIndex(s.getName());
/* 1204 */     for (Iterator i = this.rcirCells.iterator(); i.hasNext(); ) {
/*      */       
/* 1206 */       CellValue cv = i.next();
/* 1207 */       cv.columnInserted((Sheet)s, externalSheetIndex, col);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void columnRemoved(WritableSheetImpl s, int col) {
/* 1220 */     int externalSheetIndex = getExternalSheetIndex(s.getName());
/* 1221 */     for (Iterator i = this.rcirCells.iterator(); i.hasNext(); ) {
/*      */       
/* 1223 */       CellValue cv = i.next();
/* 1224 */       cv.columnRemoved((Sheet)s, externalSheetIndex, col);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void rowInserted(WritableSheetImpl s, int row) {
/* 1237 */     int externalSheetIndex = getExternalSheetIndex(s.getName());
/* 1238 */     for (Iterator i = this.rcirCells.iterator(); i.hasNext(); ) {
/*      */       
/* 1240 */       CellValue cv = i.next();
/* 1241 */       cv.rowInserted((Sheet)s, externalSheetIndex, row);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void rowRemoved(WritableSheetImpl s, int row) {
/* 1254 */     int externalSheetIndex = getExternalSheetIndex(s.getName());
/* 1255 */     for (Iterator i = this.rcirCells.iterator(); i.hasNext(); ) {
/*      */       
/* 1257 */       CellValue cv = i.next();
/* 1258 */       cv.rowRemoved((Sheet)s, externalSheetIndex, row);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableCell findCellByName(String name) {
/* 1273 */     NameRecord nr = (NameRecord)this.nameRecords.get(name);
/*      */     
/* 1275 */     if (nr == null)
/*      */     {
/* 1277 */       return null;
/*      */     }
/*      */     
/* 1280 */     NameRecord.NameRange[] ranges = nr.getRanges();
/*      */ 
/*      */     
/* 1283 */     int sheetIndex = getExternalSheetIndex(ranges[0].getExternalSheet());
/* 1284 */     WritableSheet s = getSheet(sheetIndex);
/* 1285 */     WritableCell cell = s.getWritableCell(ranges[0].getFirstColumn(), ranges[0].getFirstRow());
/*      */ 
/*      */     
/* 1288 */     return cell;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Range[] findByName(String name) {
/* 1307 */     NameRecord nr = (NameRecord)this.nameRecords.get(name);
/*      */     
/* 1309 */     if (nr == null)
/*      */     {
/* 1311 */       return null;
/*      */     }
/*      */     
/* 1314 */     NameRecord.NameRange[] ranges = nr.getRanges();
/*      */     
/* 1316 */     Range[] cellRanges = new Range[ranges.length];
/*      */     
/* 1318 */     for (int i = 0; i < ranges.length; i++)
/*      */     {
/* 1320 */       cellRanges[i] = (Range)new RangeImpl(this, getExternalSheetIndex(ranges[i].getExternalSheet()), ranges[i].getFirstColumn(), ranges[i].getFirstRow(), getLastExternalSheetIndex(ranges[i].getExternalSheet()), ranges[i].getLastColumn(), ranges[i].getLastRow());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1330 */     return cellRanges;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void addDrawing(DrawingGroupObject d) {
/* 1340 */     if (this.drawingGroup == null)
/*      */     {
/* 1342 */       this.drawingGroup = new DrawingGroup(Origin.WRITE);
/*      */     }
/*      */     
/* 1345 */     this.drawingGroup.add(d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void removeDrawing(Drawing d) {
/* 1355 */     Assert.verify((this.drawingGroup != null));
/*      */     
/* 1357 */     this.drawingGroup.remove((DrawingGroupObject)d);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   DrawingGroup getDrawingGroup() {
/* 1367 */     return this.drawingGroup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getRangeNames() {
/* 1377 */     String[] n = new String[this.names.size()];
/* 1378 */     for (int i = 0; i < this.names.size(); i++) {
/*      */       
/* 1380 */       NameRecord nr = this.names.get(i);
/* 1381 */       n[i] = nr.getName();
/*      */     } 
/*      */     
/* 1384 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Styles getStyles() {
/* 1394 */     return this.styles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNameArea(String name, WritableSheet sheet, int firstCol, int firstRow, int lastCol, int lastRow) {
/* 1414 */     if (this.names == null)
/*      */     {
/* 1416 */       this.names = new ArrayList();
/*      */     }
/*      */     
/* 1419 */     int externalSheetIndex = getExternalSheetIndex(sheet.getName());
/*      */ 
/*      */     
/* 1422 */     NameRecord nr = new NameRecord(name, this.names.size(), externalSheetIndex, firstRow, lastRow, firstCol, lastCol);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1429 */     this.names.add(nr);
/*      */ 
/*      */     
/* 1432 */     this.nameRecords.put(name, nr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   WorkbookSettings getSettings() {
/* 1440 */     return this.settings;
/*      */   }
/*      */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\WritableWorkbookImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
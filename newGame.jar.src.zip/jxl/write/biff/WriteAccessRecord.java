/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.Workbook;
/*    */ import jxl.biff.StringHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class WriteAccessRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private static final String authorString = "Java Excel API";
/*    */   
/*    */   public WriteAccessRecord() {
/* 50 */     super(Type.WRITEACCESS);
/*    */     
/* 52 */     this.data = new byte[112];
/* 53 */     String astring = "Java Excel API v" + Workbook.getVersion();
/* 54 */     StringHelper.getBytes(astring, this.data, 0);
/*    */ 
/*    */     
/* 57 */     for (int i = astring.length(); i < this.data.length; i++)
/*    */     {
/* 59 */       this.data[i] = 32;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 70 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\WriteAccessRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.DisplayFormat;
/*     */ import jxl.biff.FontRecord;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.format.Alignment;
/*     */ import jxl.format.Border;
/*     */ import jxl.format.BorderLineStyle;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.format.Colour;
/*     */ import jxl.format.Orientation;
/*     */ import jxl.format.Pattern;
/*     */ import jxl.format.VerticalAlignment;
/*     */ import jxl.write.WriteException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CellXFRecord
/*     */   extends XFRecord
/*     */ {
/*     */   protected CellXFRecord(FontRecord fnt, DisplayFormat form) {
/*  50 */     super(fnt, form);
/*  51 */     setXFDetails(XFRecord.cell, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CellXFRecord(XFRecord fmt) {
/*  61 */     super(fmt);
/*  62 */     setXFDetails(XFRecord.cell, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CellXFRecord(CellFormat format) {
/*  71 */     super(format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlignment(Alignment a) throws WriteException {
/*  82 */     if (isInitialized())
/*     */     {
/*  84 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*  86 */     setXFAlignment(a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBackground(Colour c, Pattern p) throws WriteException {
/*  98 */     if (isInitialized())
/*     */     {
/* 100 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/* 102 */     setXFBackground(c, p);
/* 103 */     setXFCellOptions(16384);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocked(boolean l) throws WriteException {
/* 114 */     if (isInitialized())
/*     */     {
/* 116 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/* 118 */     setXFLocked(l);
/* 119 */     setXFCellOptions(32768);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIndentation(int i) throws WriteException {
/* 129 */     if (isInitialized())
/*     */     {
/* 131 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/* 133 */     setXFIndentation(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setShrinkToFit(boolean s) throws WriteException {
/* 143 */     if (isInitialized())
/*     */     {
/* 145 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/* 147 */     setXFShrinkToFit(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVerticalAlignment(VerticalAlignment va) throws WriteException {
/* 159 */     if (isInitialized())
/*     */     {
/* 161 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 164 */     setXFVerticalAlignment(va);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrientation(Orientation o) throws WriteException {
/* 176 */     if (isInitialized())
/*     */     {
/* 178 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 181 */     setXFOrientation(o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWrap(boolean w) throws WriteException {
/* 194 */     if (isInitialized())
/*     */     {
/* 196 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 199 */     setXFWrap(w);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBorder(Border b, BorderLineStyle ls, Colour c) throws WriteException {
/* 212 */     if (isInitialized())
/*     */     {
/* 214 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 217 */     if (b == Border.ALL) {
/*     */ 
/*     */       
/* 220 */       setXFBorder(Border.LEFT, ls, c);
/* 221 */       setXFBorder(Border.RIGHT, ls, c);
/* 222 */       setXFBorder(Border.TOP, ls, c);
/* 223 */       setXFBorder(Border.BOTTOM, ls, c);
/*     */       
/*     */       return;
/*     */     } 
/* 227 */     if (b == Border.NONE) {
/*     */ 
/*     */       
/* 230 */       setXFBorder(Border.LEFT, BorderLineStyle.NONE, Colour.BLACK);
/* 231 */       setXFBorder(Border.RIGHT, BorderLineStyle.NONE, Colour.BLACK);
/* 232 */       setXFBorder(Border.TOP, BorderLineStyle.NONE, Colour.BLACK);
/* 233 */       setXFBorder(Border.BOTTOM, BorderLineStyle.NONE, Colour.BLACK);
/*     */       
/*     */       return;
/*     */     } 
/* 237 */     setXFBorder(b, ls, c);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\CellXFRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
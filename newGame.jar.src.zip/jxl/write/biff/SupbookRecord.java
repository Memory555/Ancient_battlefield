/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.EncodedURLHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SupbookRecord
/*     */   extends WritableRecordData
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(SupbookRecord.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private SupbookType type;
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */   
/*     */   private int numSheets;
/*     */ 
/*     */ 
/*     */   
/*     */   private String fileName;
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] sheetNames;
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings workbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SupbookType
/*     */   {
/*     */     private SupbookType() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final SupbookType INTERNAL = new SupbookType();
/*  79 */   public static final SupbookType EXTERNAL = new SupbookType();
/*  80 */   public static final SupbookType ADDIN = new SupbookType();
/*  81 */   public static final SupbookType LINK = new SupbookType();
/*  82 */   public static final SupbookType UNKNOWN = new SupbookType();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SupbookRecord(int sheets, WorkbookSettings ws) {
/*  89 */     super(Type.SUPBOOK);
/*     */     
/*  91 */     this.numSheets = sheets;
/*  92 */     this.type = INTERNAL;
/*  93 */     this.workbookSettings = ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SupbookRecord(String fn, WorkbookSettings ws) {
/* 104 */     super(Type.SUPBOOK);
/*     */     
/* 106 */     this.fileName = fn;
/* 107 */     this.numSheets = 1;
/* 108 */     this.sheetNames = new String[0];
/* 109 */     this.workbookSettings = ws;
/*     */     
/* 111 */     this.type = EXTERNAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SupbookRecord(jxl.read.biff.SupbookRecord sr, WorkbookSettings ws) {
/* 119 */     super(Type.SUPBOOK);
/*     */     
/* 121 */     this.workbookSettings = ws;
/* 122 */     if (sr.getType() == jxl.read.biff.SupbookRecord.INTERNAL) {
/*     */       
/* 124 */       this.type = INTERNAL;
/* 125 */       this.numSheets = sr.getNumberOfSheets();
/*     */     }
/* 127 */     else if (sr.getType() == jxl.read.biff.SupbookRecord.EXTERNAL) {
/*     */       
/* 129 */       this.type = EXTERNAL;
/* 130 */       this.numSheets = sr.getNumberOfSheets();
/* 131 */       this.fileName = sr.getFileName();
/* 132 */       this.sheetNames = new String[this.numSheets];
/*     */       
/* 134 */       for (int i = 0; i < this.numSheets; i++)
/*     */       {
/* 136 */         this.sheetNames[i] = sr.getSheetName(i);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initInternal(jxl.read.biff.SupbookRecord sr) {
/* 148 */     this.numSheets = sr.getNumberOfSheets();
/* 149 */     initInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initInternal() {
/* 157 */     this.data = new byte[4];
/*     */     
/* 159 */     IntegerHelper.getTwoBytes(this.numSheets, this.data, 0);
/* 160 */     this.data[2] = 1;
/* 161 */     this.data[3] = 4;
/* 162 */     this.type = INTERNAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void adjustInternal(int sheets) {
/* 173 */     Assert.verify((this.type == INTERNAL));
/* 174 */     this.numSheets = sheets;
/* 175 */     initInternal();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initExternal() {
/* 183 */     int totalSheetNameLength = 0;
/* 184 */     for (int i = 0; i < this.numSheets; i++)
/*     */     {
/* 186 */       totalSheetNameLength += this.sheetNames[i].length();
/*     */     }
/*     */     
/* 189 */     byte[] fileNameData = EncodedURLHelper.getEncodedURL(this.fileName, this.workbookSettings);
/*     */     
/* 191 */     int dataLength = 6 + fileNameData.length + this.numSheets * 3 + totalSheetNameLength * 2;
/*     */ 
/*     */ 
/*     */     
/* 195 */     this.data = new byte[dataLength];
/*     */     
/* 197 */     IntegerHelper.getTwoBytes(this.numSheets, this.data, 0);
/*     */ 
/*     */ 
/*     */     
/* 201 */     int pos = 2;
/* 202 */     IntegerHelper.getTwoBytes(fileNameData.length + 1, this.data, pos);
/* 203 */     this.data[pos + 2] = 0;
/* 204 */     this.data[pos + 3] = 1;
/* 205 */     System.arraycopy(fileNameData, 0, this.data, pos + 4, fileNameData.length);
/*     */     
/* 207 */     pos += 4 + fileNameData.length;
/*     */ 
/*     */     
/* 210 */     for (int j = 0; j < this.sheetNames.length; j++) {
/*     */       
/* 212 */       IntegerHelper.getTwoBytes(this.sheetNames[j].length(), this.data, pos);
/* 213 */       this.data[pos + 2] = 1;
/* 214 */       StringHelper.getUnicodeBytes(this.sheetNames[j], this.data, pos + 3);
/* 215 */       pos += 3 + this.sheetNames[j].length() * 2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 226 */     if (this.type == INTERNAL) {
/*     */       
/* 228 */       initInternal();
/*     */     }
/* 230 */     else if (this.type == EXTERNAL) {
/*     */       
/* 232 */       initExternal();
/*     */     }
/*     */     else {
/*     */       
/* 236 */       logger.warn("unsupported supbook type - defaulting to internal");
/* 237 */       initInternal();
/*     */     } 
/*     */     
/* 240 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SupbookType getType() {
/* 250 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfSheets() {
/* 261 */     return this.numSheets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileName() {
/* 271 */     return this.fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSheetIndex(String s) {
/* 282 */     boolean found = false;
/* 283 */     int sheetIndex = 0;
/* 284 */     for (int i = 0; i < this.sheetNames.length && !found; i++) {
/*     */       
/* 286 */       if (this.sheetNames[i].equals(s)) {
/*     */         
/* 288 */         found = true;
/* 289 */         sheetIndex = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 293 */     if (found)
/*     */     {
/* 295 */       return sheetIndex;
/*     */     }
/*     */ 
/*     */     
/* 299 */     String[] names = new String[this.sheetNames.length + 1];
/* 300 */     names[this.sheetNames.length] = s;
/* 301 */     this.sheetNames = names;
/* 302 */     return this.sheetNames.length - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSheetName(int s) {
/* 312 */     return this.sheetNames[s];
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\SupbookRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
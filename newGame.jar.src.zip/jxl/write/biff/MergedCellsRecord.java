/*    */ package jxl.write.biff;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import jxl.Cell;
/*    */ import jxl.Range;
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MergedCellsRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private ArrayList ranges;
/*    */   
/*    */   protected MergedCellsRecord(ArrayList mc) {
/* 59 */     super(Type.MERGEDCELLS);
/*    */     
/* 61 */     this.ranges = mc;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 71 */     byte[] data = new byte[this.ranges.size() * 8 + 2];
/*    */ 
/*    */     
/* 74 */     IntegerHelper.getTwoBytes(this.ranges.size(), data, 0);
/*    */     
/* 76 */     int pos = 2;
/* 77 */     Range range = null;
/* 78 */     for (int i = 0; i < this.ranges.size(); i++) {
/*    */       
/* 80 */       range = this.ranges.get(i);
/*    */ 
/*    */       
/* 83 */       Cell tl = range.getTopLeft();
/* 84 */       Cell br = range.getBottomRight();
/*    */       
/* 86 */       IntegerHelper.getTwoBytes(tl.getRow(), data, pos);
/* 87 */       IntegerHelper.getTwoBytes(br.getRow(), data, pos + 2);
/* 88 */       IntegerHelper.getTwoBytes(tl.getColumn(), data, pos + 4);
/* 89 */       IntegerHelper.getTwoBytes(br.getColumn(), data, pos + 6);
/*    */       
/* 91 */       pos += 8;
/*    */     } 
/*    */     
/* 94 */     return data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\MergedCellsRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.FormatRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateFormatRecord
/*    */   extends FormatRecord
/*    */ {
/*    */   protected DateFormatRecord(String fmt) {
/* 41 */     String fs = fmt;
/*    */     
/* 43 */     fs = replace(fs, "a", "AM/PM");
/* 44 */     fs = replace(fs, "S", "0");
/*    */     
/* 46 */     setFormatString(fs);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\DateFormatRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IndexMapping;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.biff.XFRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ColumnInfoRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private byte[] data;
/*     */   private int column;
/*     */   private XFRecord style;
/*     */   private int xfIndex;
/*     */   private int width;
/*     */   private boolean hidden;
/*     */   
/*     */   public ColumnInfoRecord(int col, int w, XFRecord xf) {
/*  72 */     super(Type.COLINFO);
/*     */     
/*  74 */     this.column = col;
/*  75 */     this.width = w;
/*  76 */     this.style = xf;
/*  77 */     this.xfIndex = this.style.getXFIndex();
/*  78 */     this.hidden = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColumnInfoRecord(jxl.read.biff.ColumnInfoRecord cir, int col, FormattingRecords fr) {
/*  92 */     super(Type.COLINFO);
/*     */     
/*  94 */     this.column = col;
/*  95 */     this.width = cir.getWidth();
/*  96 */     this.xfIndex = cir.getXFIndex();
/*  97 */     this.style = fr.getXFRecord(this.xfIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 107 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void incrementColumn() {
/* 116 */     this.column++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void decrementColumn() {
/* 125 */     this.column--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getWidth() {
/* 135 */     return this.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 145 */     this.data = new byte[12];
/*     */     
/* 147 */     IntegerHelper.getTwoBytes(this.column, this.data, 0);
/* 148 */     IntegerHelper.getTwoBytes(this.column, this.data, 2);
/* 149 */     IntegerHelper.getTwoBytes(this.width, this.data, 4);
/* 150 */     IntegerHelper.getTwoBytes(this.xfIndex, this.data, 6);
/*     */ 
/*     */     
/* 153 */     int options = 6;
/* 154 */     if (this.hidden)
/*     */     {
/* 156 */       options |= 0x1;
/*     */     }
/* 158 */     IntegerHelper.getTwoBytes(options, this.data, 8);
/*     */ 
/*     */     
/* 161 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XFRecord getCellFormat() {
/* 171 */     return this.style;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rationalize(IndexMapping xfmapping) {
/* 180 */     this.xfIndex = xfmapping.getNewIndex(this.xfIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setHidden(boolean h) {
/* 190 */     this.hidden = h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean getHidden() {
/* 200 */     return this.hidden;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 210 */     if (o == this)
/*     */     {
/* 212 */       return true;
/*     */     }
/*     */     
/* 215 */     if (!(o instanceof ColumnInfoRecord))
/*     */     {
/* 217 */       return false;
/*     */     }
/*     */     
/* 220 */     ColumnInfoRecord cir = (ColumnInfoRecord)o;
/*     */     
/* 222 */     int col2 = cir.column;
/*     */     
/* 224 */     if (this.column != cir.column || this.xfIndex != cir.xfIndex || this.width != cir.width || this.hidden != cir.hidden)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 229 */       return false;
/*     */     }
/*     */     
/* 232 */     if ((this.style == null && cir.style != null) || (this.style != null && cir.style == null))
/*     */     {
/*     */       
/* 235 */       return false;
/*     */     }
/*     */     
/* 238 */     return this.style.equals(cir.style);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 248 */     int hashValue = 137;
/* 249 */     int oddPrimeNumber = 79;
/*     */     
/* 251 */     hashValue = hashValue * oddPrimeNumber + this.column;
/* 252 */     hashValue = hashValue * oddPrimeNumber + this.xfIndex;
/* 253 */     hashValue = hashValue * oddPrimeNumber + this.width;
/* 254 */     hashValue = hashValue * oddPrimeNumber + (this.hidden ? 1 : 0);
/*     */     
/* 256 */     if (this.style != null)
/*     */     {
/* 258 */       hashValue ^= this.style.hashCode();
/*     */     }
/*     */     
/* 261 */     return hashValue;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ColumnInfoRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
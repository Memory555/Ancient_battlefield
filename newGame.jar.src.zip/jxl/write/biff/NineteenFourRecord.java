/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class NineteenFourRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean nineteenFourDate;
/*    */   private byte[] data;
/*    */   
/*    */   public NineteenFourRecord(boolean oldDate) {
/* 51 */     super(Type.NINETEENFOUR);
/*    */     
/* 53 */     this.nineteenFourDate = oldDate;
/* 54 */     this.data = new byte[2];
/*    */     
/* 56 */     if (this.nineteenFourDate)
/*    */     {
/* 58 */       IntegerHelper.getTwoBytes(1, this.data, 0);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 68 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\NineteenFourRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
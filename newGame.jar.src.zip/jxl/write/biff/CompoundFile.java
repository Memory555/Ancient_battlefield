/*      */ package jxl.write.biff;
/*      */ 
/*      */ import common.Logger;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import jxl.biff.BaseCompoundFile;
/*      */ import jxl.biff.IntegerHelper;
/*      */ import jxl.read.biff.BiffException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class CompoundFile
/*      */   extends BaseCompoundFile
/*      */ {
/*   51 */   private static Logger logger = Logger.getLogger(CompoundFile.class);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private OutputStream out;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] excelData;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int size;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int requiredSize;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int numBigBlockDepotBlocks;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int numSmallBlockDepotChainBlocks;
/*      */ 
/*      */ 
/*      */   
/*      */   private int numSmallBlockDepotBlocks;
/*      */ 
/*      */ 
/*      */   
/*      */   private int numExtensionBlocks;
/*      */ 
/*      */ 
/*      */   
/*      */   private int extensionBlock;
/*      */ 
/*      */ 
/*      */   
/*      */   private int excelDataBlocks;
/*      */ 
/*      */ 
/*      */   
/*      */   private int rootStartBlock;
/*      */ 
/*      */ 
/*      */   
/*      */   private int excelDataStartBlock;
/*      */ 
/*      */ 
/*      */   
/*      */   private int bbdStartBlock;
/*      */ 
/*      */ 
/*      */   
/*      */   private int sbdStartBlockChain;
/*      */ 
/*      */ 
/*      */   
/*      */   private int sbdStartBlock;
/*      */ 
/*      */ 
/*      */   
/*      */   private int additionalPropertyBlocks;
/*      */ 
/*      */ 
/*      */   
/*      */   private int numSmallBlocks;
/*      */ 
/*      */ 
/*      */   
/*      */   private int numPropertySets;
/*      */ 
/*      */ 
/*      */   
/*      */   private int numRootEntryBlocks;
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList additionalPropertySets;
/*      */ 
/*      */ 
/*      */   
/*      */   private HashMap readPropertySets;
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] standardPropertySetMappings;
/*      */ 
/*      */ 
/*      */   
/*      */   private ReadPropertyStorage rootEntryPropertySet;
/*      */ 
/*      */ 
/*      */   
/*      */   private int bbdPos;
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] bigBlockDepot;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class ReadPropertyStorage
/*      */   {
/*      */     BaseCompoundFile.PropertyStorage propertyStorage;
/*      */ 
/*      */ 
/*      */     
/*      */     byte[] data;
/*      */ 
/*      */ 
/*      */     
/*      */     int number;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ReadPropertyStorage(BaseCompoundFile.PropertyStorage ps, byte[] d, int n) {
/*  178 */       this.propertyStorage = ps;
/*  179 */       this.data = d;
/*  180 */       this.number = n;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CompoundFile(byte[] data, int l, OutputStream os, jxl.read.biff.CompoundFile rcf) throws CopyAdditionalPropertySetsException, IOException {
/*  212 */     this.size = l;
/*  213 */     this.excelData = data;
/*      */     
/*  215 */     readAdditionalPropertySets(rcf);
/*      */     
/*  217 */     this.numRootEntryBlocks = 1;
/*  218 */     this.numPropertySets = 4 + ((this.additionalPropertySets != null) ? this.additionalPropertySets.size() : 0);
/*      */ 
/*      */ 
/*      */     
/*  222 */     if (this.additionalPropertySets != null) {
/*      */       
/*  224 */       this.numSmallBlockDepotChainBlocks = getBigBlocksRequired(this.numSmallBlocks * 4);
/*  225 */       this.numSmallBlockDepotBlocks = getBigBlocksRequired(this.numSmallBlocks * 64);
/*      */ 
/*      */       
/*  228 */       this.numRootEntryBlocks += getBigBlocksRequired(this.additionalPropertySets.size() * 128);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  233 */     int blocks = getBigBlocksRequired(l);
/*      */ 
/*      */ 
/*      */     
/*  237 */     if (l < 4096) {
/*      */       
/*  239 */       this.requiredSize = 4096;
/*      */     }
/*      */     else {
/*      */       
/*  243 */       this.requiredSize = blocks * 512;
/*      */     } 
/*      */     
/*  246 */     this.out = os;
/*      */ 
/*      */ 
/*      */     
/*  250 */     this.excelDataBlocks = this.requiredSize / 512;
/*  251 */     this.numBigBlockDepotBlocks = 1;
/*      */     
/*  253 */     int blockChainLength = 109;
/*      */     
/*  255 */     int startTotalBlocks = this.excelDataBlocks + 8 + 8 + this.additionalPropertyBlocks + this.numSmallBlockDepotBlocks + this.numSmallBlockDepotChainBlocks + this.numRootEntryBlocks;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  263 */     int totalBlocks = startTotalBlocks + this.numBigBlockDepotBlocks;
/*      */ 
/*      */     
/*  266 */     this.numBigBlockDepotBlocks = (int)Math.ceil(totalBlocks / 128.0D);
/*      */ 
/*      */ 
/*      */     
/*  270 */     totalBlocks = startTotalBlocks + this.numBigBlockDepotBlocks;
/*      */ 
/*      */     
/*  273 */     this.numBigBlockDepotBlocks = (int)Math.ceil(totalBlocks / 128.0D);
/*      */ 
/*      */ 
/*      */     
/*  277 */     totalBlocks = startTotalBlocks + this.numBigBlockDepotBlocks;
/*      */ 
/*      */ 
/*      */     
/*  281 */     if (this.numBigBlockDepotBlocks > blockChainLength - 1) {
/*      */ 
/*      */ 
/*      */       
/*  285 */       this.extensionBlock = 0;
/*      */ 
/*      */       
/*  288 */       int bbdBlocksLeft = this.numBigBlockDepotBlocks - blockChainLength + 1;
/*      */       
/*  290 */       this.numExtensionBlocks = (int)Math.ceil(bbdBlocksLeft / 127.0D);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  295 */       totalBlocks = startTotalBlocks + this.numExtensionBlocks + this.numBigBlockDepotBlocks;
/*      */ 
/*      */       
/*  298 */       this.numBigBlockDepotBlocks = (int)Math.ceil(totalBlocks / 128.0D);
/*      */ 
/*      */ 
/*      */       
/*  302 */       totalBlocks = startTotalBlocks + this.numExtensionBlocks + this.numBigBlockDepotBlocks;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  308 */       this.extensionBlock = -2;
/*  309 */       this.numExtensionBlocks = 0;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  314 */     this.excelDataStartBlock = this.numExtensionBlocks;
/*      */ 
/*      */     
/*  317 */     this.sbdStartBlock = -2;
/*  318 */     if (this.additionalPropertySets != null)
/*      */     {
/*  320 */       this.sbdStartBlock = this.excelDataStartBlock + this.excelDataBlocks + this.additionalPropertyBlocks + 16;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  328 */     this.sbdStartBlockChain = -2;
/*      */     
/*  330 */     if (this.sbdStartBlock != -2)
/*      */     {
/*  332 */       this.sbdStartBlockChain = this.sbdStartBlock + this.numSmallBlockDepotBlocks;
/*      */     }
/*      */ 
/*      */     
/*  336 */     if (this.sbdStartBlockChain != -2) {
/*      */       
/*  338 */       this.bbdStartBlock = this.sbdStartBlockChain + this.numSmallBlockDepotChainBlocks;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  343 */       this.bbdStartBlock = this.excelDataStartBlock + this.excelDataBlocks + this.additionalPropertyBlocks + 16;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  350 */     this.rootStartBlock = this.bbdStartBlock + this.numBigBlockDepotBlocks;
/*      */ 
/*      */ 
/*      */     
/*  354 */     if (totalBlocks != this.rootStartBlock + this.numRootEntryBlocks) {
/*      */       
/*  356 */       logger.warn("Root start block and total blocks are inconsistent  generated file may be corrupt");
/*      */       
/*  358 */       logger.warn("RootStartBlock " + this.rootStartBlock + " totalBlocks " + totalBlocks);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readAdditionalPropertySets(jxl.read.biff.CompoundFile readCompoundFile) throws CopyAdditionalPropertySetsException, IOException {
/*  371 */     if (readCompoundFile == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  376 */     this.additionalPropertySets = new ArrayList();
/*  377 */     this.readPropertySets = new HashMap();
/*      */     
/*  379 */     String[] psnames = readCompoundFile.getPropertySetNames();
/*  380 */     int blocksRequired = 0;
/*  381 */     this.standardPropertySetMappings = new int[STANDARD_PROPERTY_SETS.length];
/*      */     
/*  383 */     for (int i = 0; i < psnames.length; i++) {
/*      */ 
/*      */       
/*  386 */       BaseCompoundFile.PropertyStorage ps = readCompoundFile.getPropertySet(psnames[i]);
/*      */ 
/*      */ 
/*      */       
/*  390 */       boolean standard = false;
/*  391 */       for (int j = 0; j < STANDARD_PROPERTY_SETS.length && !standard; j++) {
/*      */         
/*  393 */         if (psnames[i].equalsIgnoreCase(STANDARD_PROPERTY_SETS[j])) {
/*      */           
/*  395 */           standard = true;
/*  396 */           ReadPropertyStorage rps = new ReadPropertyStorage(ps, null, i);
/*  397 */           this.readPropertySets.put(psnames[i], rps);
/*      */         } 
/*      */       } 
/*      */       
/*  401 */       if (!standard) {
/*      */         
/*      */         try {
/*      */           
/*  405 */           byte[] data = null;
/*  406 */           if (ps.size > 0) {
/*      */             
/*  408 */             data = readCompoundFile.getStream(ps.name);
/*      */           }
/*      */           else {
/*      */             
/*  412 */             data = new byte[0];
/*      */           } 
/*  414 */           ReadPropertyStorage rps = new ReadPropertyStorage(ps, data, i);
/*  415 */           this.readPropertySets.put(psnames[i], rps);
/*  416 */           this.additionalPropertySets.add(rps);
/*      */           
/*  418 */           if (data.length > 4096)
/*      */           {
/*  420 */             int blocks = getBigBlocksRequired(data.length);
/*  421 */             blocksRequired += blocks;
/*      */           }
/*      */           else
/*      */           {
/*  425 */             int blocks = getSmallBlocksRequired(data.length);
/*  426 */             this.numSmallBlocks += blocks;
/*      */           }
/*      */         
/*  429 */         } catch (BiffException e) {
/*      */           
/*  431 */           logger.error(e);
/*  432 */           throw new CopyAdditionalPropertySetsException();
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/*  437 */     this.additionalPropertyBlocks = blocksRequired;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write() throws IOException {
/*  448 */     writeHeader();
/*  449 */     writeExcelData();
/*  450 */     writeDocumentSummaryData();
/*  451 */     writeSummaryData();
/*  452 */     writeAdditionalPropertySets();
/*  453 */     writeSmallBlockDepot();
/*  454 */     writeSmallBlockDepotChain();
/*  455 */     writeBigBlockDepot();
/*  456 */     writePropertySets();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeAdditionalPropertySets() throws IOException {
/*  467 */     if (this.additionalPropertySets == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  472 */     for (Iterator i = this.additionalPropertySets.iterator(); i.hasNext(); ) {
/*      */       
/*  474 */       ReadPropertyStorage rps = i.next();
/*  475 */       byte[] data = rps.data;
/*      */       
/*  477 */       if (data.length > 4096) {
/*      */         
/*  479 */         int numBlocks = getBigBlocksRequired(data.length);
/*  480 */         int requiredSize = numBlocks * 512;
/*      */         
/*  482 */         this.out.write(data, 0, data.length);
/*      */         
/*  484 */         byte[] padding = new byte[requiredSize - data.length];
/*  485 */         this.out.write(padding, 0, padding.length);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeExcelData() throws IOException {
/*  509 */     this.out.write(this.excelData, 0, this.size);
/*      */     
/*  511 */     byte[] padding = new byte[this.requiredSize - this.size];
/*  512 */     this.out.write(padding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeDocumentSummaryData() throws IOException {
/*  522 */     byte[] padding = new byte[4096];
/*      */ 
/*      */     
/*  525 */     this.out.write(padding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeSummaryData() throws IOException {
/*  535 */     byte[] padding = new byte[4096];
/*      */ 
/*      */     
/*  538 */     this.out.write(padding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeHeader() throws IOException {
/*  549 */     byte[] headerBlock = new byte[512];
/*  550 */     byte[] extensionBlockData = new byte[512 * this.numExtensionBlocks];
/*      */ 
/*      */     
/*  553 */     System.arraycopy(IDENTIFIER, 0, headerBlock, 0, IDENTIFIER.length);
/*      */ 
/*      */     
/*  556 */     headerBlock[24] = 62;
/*  557 */     headerBlock[26] = 3;
/*  558 */     headerBlock[28] = -2;
/*  559 */     headerBlock[29] = -1;
/*  560 */     headerBlock[30] = 9;
/*  561 */     headerBlock[32] = 6;
/*  562 */     headerBlock[57] = 16;
/*      */ 
/*      */     
/*  565 */     IntegerHelper.getFourBytes(this.numBigBlockDepotBlocks, headerBlock, 44);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  570 */     IntegerHelper.getFourBytes(this.sbdStartBlockChain, headerBlock, 60);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  575 */     IntegerHelper.getFourBytes(this.numSmallBlockDepotChainBlocks, headerBlock, 64);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  580 */     IntegerHelper.getFourBytes(this.extensionBlock, headerBlock, 68);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  585 */     IntegerHelper.getFourBytes(this.numExtensionBlocks, headerBlock, 72);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  590 */     IntegerHelper.getFourBytes(this.rootStartBlock, headerBlock, 48);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  596 */     int pos = 76;
/*      */ 
/*      */     
/*  599 */     int blocksToWrite = Math.min(this.numBigBlockDepotBlocks, 109);
/*      */ 
/*      */     
/*  602 */     int extensionBlock = 0;
/*  603 */     int blocksWritten = 0;
/*      */     int i;
/*  605 */     for (i = 0; i < blocksToWrite; i++) {
/*      */       
/*  607 */       IntegerHelper.getFourBytes(this.bbdStartBlock + i, headerBlock, pos);
/*      */ 
/*      */       
/*  610 */       pos += 4;
/*  611 */       blocksWritten++;
/*      */     } 
/*      */ 
/*      */     
/*  615 */     for (i = pos; i < 512; i++)
/*      */     {
/*  617 */       headerBlock[i] = -1;
/*      */     }
/*      */     
/*  620 */     this.out.write(headerBlock);
/*      */ 
/*      */     
/*  623 */     pos = 0;
/*      */     
/*  625 */     for (int extBlock = 0; extBlock < this.numExtensionBlocks; extBlock++) {
/*      */       
/*  627 */       blocksToWrite = Math.min(this.numBigBlockDepotBlocks - blocksWritten, 127);
/*      */ 
/*      */       
/*  630 */       for (int j = 0; j < blocksToWrite; j++) {
/*      */         
/*  632 */         IntegerHelper.getFourBytes(this.bbdStartBlock + blocksWritten + j, extensionBlockData, pos);
/*      */ 
/*      */         
/*  635 */         pos += 4;
/*      */       } 
/*      */       
/*  638 */       blocksWritten += blocksToWrite;
/*      */ 
/*      */       
/*  641 */       int nextBlock = (blocksWritten == this.numBigBlockDepotBlocks) ? -2 : (extBlock + 1);
/*      */       
/*  643 */       IntegerHelper.getFourBytes(nextBlock, extensionBlockData, pos);
/*  644 */       pos += 4;
/*      */     } 
/*      */     
/*  647 */     if (this.numExtensionBlocks > 0) {
/*      */ 
/*      */       
/*  650 */       for (int j = pos; j < extensionBlockData.length; j++)
/*      */       {
/*  652 */         extensionBlockData[j] = -1;
/*      */       }
/*      */       
/*  655 */       this.out.write(extensionBlockData);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkBbdPos() throws IOException {
/*  667 */     if (this.bbdPos >= 512) {
/*      */ 
/*      */       
/*  670 */       this.out.write(this.bigBlockDepot);
/*      */ 
/*      */       
/*  673 */       this.bigBlockDepot = new byte[512];
/*  674 */       this.bbdPos = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeBlockChain(int startBlock, int numBlocks) throws IOException {
/*  688 */     int blocksToWrite = numBlocks - 1;
/*  689 */     int blockNumber = startBlock + 1;
/*      */     
/*  691 */     while (blocksToWrite > 0) {
/*      */       
/*  693 */       int bbdBlocks = Math.min(blocksToWrite, (512 - this.bbdPos) / 4);
/*      */       
/*  695 */       for (int i = 0; i < bbdBlocks; i++) {
/*      */         
/*  697 */         IntegerHelper.getFourBytes(blockNumber, this.bigBlockDepot, this.bbdPos);
/*  698 */         this.bbdPos += 4;
/*  699 */         blockNumber++;
/*      */       } 
/*      */       
/*  702 */       blocksToWrite -= bbdBlocks;
/*  703 */       checkBbdPos();
/*      */     } 
/*      */ 
/*      */     
/*  707 */     IntegerHelper.getFourBytes(-2, this.bigBlockDepot, this.bbdPos);
/*  708 */     this.bbdPos += 4;
/*  709 */     checkBbdPos();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeAdditionalPropertySetBlockChains() throws IOException {
/*  719 */     if (this.additionalPropertySets == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  724 */     int blockNumber = this.excelDataStartBlock + this.excelDataBlocks + 16;
/*  725 */     for (Iterator i = this.additionalPropertySets.iterator(); i.hasNext(); ) {
/*      */       
/*  727 */       ReadPropertyStorage rps = i.next();
/*  728 */       if (rps.data.length > 4096) {
/*      */         
/*  730 */         String psname = rps.propertyStorage.name;
/*  731 */         int numBlocks = getBigBlocksRequired(rps.data.length);
/*      */         
/*  733 */         writeBlockChain(blockNumber, numBlocks);
/*  734 */         blockNumber += numBlocks;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeSmallBlockDepotChain() throws IOException {
/*  744 */     if (this.sbdStartBlockChain == -2) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  749 */     byte[] smallBlockDepotChain = new byte[this.numSmallBlockDepotChainBlocks * 512];
/*      */ 
/*      */     
/*  752 */     int pos = 0;
/*  753 */     int sbdBlockNumber = 1;
/*      */     
/*  755 */     for (Iterator i = this.additionalPropertySets.iterator(); i.hasNext(); ) {
/*      */       
/*  757 */       ReadPropertyStorage rps = i.next();
/*      */       
/*  759 */       if (rps.data.length <= 4096 && rps.data.length != 0) {
/*      */ 
/*      */         
/*  762 */         int numSmallBlocks = getSmallBlocksRequired(rps.data.length);
/*  763 */         for (int j = 0; j < numSmallBlocks - 1; j++) {
/*      */           
/*  765 */           IntegerHelper.getFourBytes(sbdBlockNumber, smallBlockDepotChain, pos);
/*      */ 
/*      */           
/*  768 */           pos += 4;
/*  769 */           sbdBlockNumber++;
/*      */         } 
/*      */ 
/*      */         
/*  773 */         IntegerHelper.getFourBytes(-2, smallBlockDepotChain, pos);
/*  774 */         pos += 4;
/*  775 */         sbdBlockNumber++;
/*      */       } 
/*      */     } 
/*      */     
/*  779 */     this.out.write(smallBlockDepotChain);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeSmallBlockDepot() throws IOException {
/*  789 */     if (this.additionalPropertySets == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  794 */     byte[] smallBlockDepot = new byte[this.numSmallBlockDepotBlocks * 512];
/*      */ 
/*      */     
/*  797 */     int pos = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  806 */     for (Iterator i = this.additionalPropertySets.iterator(); i.hasNext(); ) {
/*      */       
/*  808 */       ReadPropertyStorage rps = i.next();
/*      */       
/*  810 */       if (rps.data.length <= 4096) {
/*      */         
/*  812 */         int smallBlocks = getSmallBlocksRequired(rps.data.length);
/*  813 */         int length = smallBlocks * 64;
/*  814 */         System.arraycopy(rps.data, 0, smallBlockDepot, pos, rps.data.length);
/*  815 */         pos += length;
/*      */       } 
/*      */     } 
/*      */     
/*  819 */     this.out.write(smallBlockDepot);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeBigBlockDepot() throws IOException {
/*  831 */     this.bigBlockDepot = new byte[512];
/*  832 */     this.bbdPos = 0;
/*      */ 
/*      */     
/*  835 */     for (int i = 0; i < this.numExtensionBlocks; i++) {
/*      */       
/*  837 */       IntegerHelper.getFourBytes(-3, this.bigBlockDepot, this.bbdPos);
/*  838 */       this.bbdPos += 4;
/*  839 */       checkBbdPos();
/*      */     } 
/*      */     
/*  842 */     writeBlockChain(this.excelDataStartBlock, this.excelDataBlocks);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  847 */     int summaryInfoBlock = this.excelDataStartBlock + this.excelDataBlocks + this.additionalPropertyBlocks;
/*      */     
/*      */     int j;
/*      */     
/*  851 */     for (j = summaryInfoBlock; j < summaryInfoBlock + 7; j++) {
/*      */       
/*  853 */       IntegerHelper.getFourBytes(j + 1, this.bigBlockDepot, this.bbdPos);
/*  854 */       this.bbdPos += 4;
/*  855 */       checkBbdPos();
/*      */     } 
/*      */ 
/*      */     
/*  859 */     IntegerHelper.getFourBytes(-2, this.bigBlockDepot, this.bbdPos);
/*  860 */     this.bbdPos += 4;
/*  861 */     checkBbdPos();
/*      */ 
/*      */     
/*  864 */     for (j = summaryInfoBlock + 8; j < summaryInfoBlock + 15; j++) {
/*      */       
/*  866 */       IntegerHelper.getFourBytes(j + 1, this.bigBlockDepot, this.bbdPos);
/*  867 */       this.bbdPos += 4;
/*  868 */       checkBbdPos();
/*      */     } 
/*      */ 
/*      */     
/*  872 */     IntegerHelper.getFourBytes(-2, this.bigBlockDepot, this.bbdPos);
/*  873 */     this.bbdPos += 4;
/*  874 */     checkBbdPos();
/*      */ 
/*      */     
/*  877 */     writeAdditionalPropertySetBlockChains();
/*      */     
/*  879 */     if (this.sbdStartBlock != -2) {
/*      */ 
/*      */       
/*  882 */       writeBlockChain(this.sbdStartBlock, this.numSmallBlockDepotBlocks);
/*      */ 
/*      */       
/*  885 */       writeBlockChain(this.sbdStartBlockChain, this.numSmallBlockDepotChainBlocks);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  890 */     for (j = 0; j < this.numBigBlockDepotBlocks; j++) {
/*      */       
/*  892 */       IntegerHelper.getFourBytes(-3, this.bigBlockDepot, this.bbdPos);
/*  893 */       this.bbdPos += 4;
/*  894 */       checkBbdPos();
/*      */     } 
/*      */ 
/*      */     
/*  898 */     writeBlockChain(this.rootStartBlock, this.numRootEntryBlocks);
/*      */ 
/*      */     
/*  901 */     if (this.bbdPos != 0) {
/*      */       
/*  903 */       for (j = this.bbdPos; j < 512; j++)
/*      */       {
/*  905 */         this.bigBlockDepot[j] = -1;
/*      */       }
/*  907 */       this.out.write(this.bigBlockDepot);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getBigBlocksRequired(int length) {
/*  920 */     int blocks = length / 512;
/*      */     
/*  922 */     return (length % 512 > 0) ? (blocks + 1) : blocks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getSmallBlocksRequired(int length) {
/*  934 */     int blocks = length / 64;
/*      */     
/*  936 */     return (length % 64 > 0) ? (blocks + 1) : blocks;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writePropertySets() throws IOException {
/*  946 */     byte[] propertySetStorage = new byte[512 * this.numRootEntryBlocks];
/*      */     
/*  948 */     int pos = 0;
/*  949 */     int[] mappings = null;
/*      */ 
/*      */     
/*  952 */     if (this.additionalPropertySets != null) {
/*      */       
/*  954 */       mappings = new int[this.numPropertySets];
/*      */ 
/*      */       
/*  957 */       for (int j = 0; j < STANDARD_PROPERTY_SETS.length; j++) {
/*      */         
/*  959 */         ReadPropertyStorage rps = (ReadPropertyStorage)this.readPropertySets.get(STANDARD_PROPERTY_SETS[j]);
/*      */ 
/*      */         
/*  962 */         if (rps != null) {
/*      */           
/*  964 */           mappings[rps.number] = j;
/*      */         }
/*      */         else {
/*      */           
/*  968 */           logger.warn("Standard property set " + STANDARD_PROPERTY_SETS[j] + " not present in source file");
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  974 */       int newMapping = STANDARD_PROPERTY_SETS.length;
/*  975 */       for (Iterator iterator = this.additionalPropertySets.iterator(); iterator.hasNext(); ) {
/*      */         
/*  977 */         ReadPropertyStorage rps = iterator.next();
/*  978 */         mappings[rps.number] = newMapping;
/*  979 */         newMapping++;
/*      */       } 
/*      */     } 
/*      */     
/*  983 */     int child = 0;
/*  984 */     int previous = 0;
/*  985 */     int next = 0;
/*      */ 
/*      */     
/*  988 */     int size = 0;
/*      */     
/*  990 */     if (this.additionalPropertySets != null) {
/*      */ 
/*      */       
/*  993 */       size += getBigBlocksRequired(this.requiredSize) * 512;
/*      */ 
/*      */       
/*  996 */       size += getBigBlocksRequired(4096) * 512;
/*  997 */       size += getBigBlocksRequired(4096) * 512;
/*      */ 
/*      */       
/* 1000 */       for (Iterator iterator = this.additionalPropertySets.iterator(); iterator.hasNext(); ) {
/*      */         
/* 1002 */         ReadPropertyStorage rps = iterator.next();
/* 1003 */         if (rps.propertyStorage.type != 1) {
/*      */           
/* 1005 */           if (rps.propertyStorage.size >= 4096) {
/*      */             
/* 1007 */             size += getBigBlocksRequired(rps.propertyStorage.size) * 512;
/*      */             
/*      */             continue;
/*      */           } 
/*      */           
/* 1012 */           size += getSmallBlocksRequired(rps.propertyStorage.size) * 64;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1020 */     BaseCompoundFile.PropertyStorage ps = new BaseCompoundFile.PropertyStorage(this, "Root Entry");
/* 1021 */     ps.setType(5);
/* 1022 */     ps.setStartBlock(this.sbdStartBlock);
/* 1023 */     ps.setSize(size);
/* 1024 */     ps.setPrevious(-1);
/* 1025 */     ps.setNext(-1);
/* 1026 */     ps.setColour(0);
/*      */     
/* 1028 */     child = 1;
/* 1029 */     if (this.additionalPropertySets != null) {
/*      */       
/* 1031 */       ReadPropertyStorage rps = (ReadPropertyStorage)this.readPropertySets.get("Root Entry");
/*      */       
/* 1033 */       child = mappings[rps.propertyStorage.child];
/*      */     } 
/* 1035 */     ps.setChild(child);
/*      */     
/* 1037 */     System.arraycopy(ps.data, 0, propertySetStorage, pos, 128);
/*      */ 
/*      */     
/* 1040 */     pos += 128;
/*      */ 
/*      */ 
/*      */     
/* 1044 */     ps = new BaseCompoundFile.PropertyStorage(this, "Workbook");
/* 1045 */     ps.setType(2);
/* 1046 */     ps.setStartBlock(this.excelDataStartBlock);
/*      */     
/* 1048 */     ps.setSize(this.requiredSize);
/*      */ 
/*      */ 
/*      */     
/* 1052 */     previous = 3;
/* 1053 */     next = -1;
/*      */     
/* 1055 */     if (this.additionalPropertySets != null) {
/*      */       
/* 1057 */       ReadPropertyStorage rps = (ReadPropertyStorage)this.readPropertySets.get("Workbook");
/*      */       
/* 1059 */       previous = (rps.propertyStorage.previous != -1) ? mappings[rps.propertyStorage.previous] : -1;
/*      */       
/* 1061 */       next = (rps.propertyStorage.next != -1) ? mappings[rps.propertyStorage.next] : -1;
/*      */     } 
/*      */ 
/*      */     
/* 1065 */     ps.setPrevious(previous);
/* 1066 */     ps.setNext(next);
/* 1067 */     ps.setChild(-1);
/*      */     
/* 1069 */     System.arraycopy(ps.data, 0, propertySetStorage, pos, 128);
/*      */ 
/*      */     
/* 1072 */     pos += 128;
/*      */ 
/*      */     
/* 1075 */     ps = new BaseCompoundFile.PropertyStorage(this, "\005SummaryInformation");
/* 1076 */     ps.setType(2);
/* 1077 */     ps.setStartBlock(this.excelDataStartBlock + this.excelDataBlocks);
/* 1078 */     ps.setSize(4096);
/*      */     
/* 1080 */     previous = 1;
/* 1081 */     next = 3;
/*      */     
/* 1083 */     if (this.additionalPropertySets != null) {
/*      */       
/* 1085 */       ReadPropertyStorage rps = (ReadPropertyStorage)this.readPropertySets.get("\005SummaryInformation");
/*      */ 
/*      */       
/* 1088 */       if (rps != null) {
/*      */         
/* 1090 */         previous = (rps.propertyStorage.previous != -1) ? mappings[rps.propertyStorage.previous] : -1;
/*      */         
/* 1092 */         next = (rps.propertyStorage.next != -1) ? mappings[rps.propertyStorage.next] : -1;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1097 */     ps.setPrevious(previous);
/* 1098 */     ps.setNext(next);
/* 1099 */     ps.setChild(-1);
/*      */     
/* 1101 */     System.arraycopy(ps.data, 0, propertySetStorage, pos, 128);
/*      */ 
/*      */     
/* 1104 */     pos += 128;
/*      */ 
/*      */     
/* 1107 */     ps = new BaseCompoundFile.PropertyStorage(this, "\005DocumentSummaryInformation");
/* 1108 */     ps.setType(2);
/* 1109 */     ps.setStartBlock(this.excelDataStartBlock + this.excelDataBlocks + 8);
/* 1110 */     ps.setSize(4096);
/* 1111 */     ps.setPrevious(-1);
/* 1112 */     ps.setNext(-1);
/* 1113 */     ps.setChild(-1);
/*      */     
/* 1115 */     System.arraycopy(ps.data, 0, propertySetStorage, pos, 128);
/*      */ 
/*      */     
/* 1118 */     pos += 128;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1123 */     if (this.additionalPropertySets == null) {
/*      */       
/* 1125 */       this.out.write(propertySetStorage);
/*      */       
/*      */       return;
/*      */     } 
/* 1129 */     int bigBlock = this.excelDataStartBlock + this.excelDataBlocks + 16;
/* 1130 */     int smallBlock = 0;
/* 1131 */     int sz = 0;
/*      */     
/* 1133 */     for (Iterator i = this.additionalPropertySets.iterator(); i.hasNext(); ) {
/*      */       
/* 1135 */       ReadPropertyStorage rps = i.next();
/*      */       
/* 1137 */       int block = (rps.data.length > 4096) ? bigBlock : smallBlock;
/*      */ 
/*      */       
/* 1140 */       ps = new BaseCompoundFile.PropertyStorage(this, rps.propertyStorage.name);
/* 1141 */       ps.setType(rps.propertyStorage.type);
/* 1142 */       ps.setStartBlock(block);
/* 1143 */       ps.setSize(rps.propertyStorage.size);
/*      */ 
/*      */       
/* 1146 */       previous = (rps.propertyStorage.previous != -1) ? mappings[rps.propertyStorage.previous] : -1;
/*      */       
/* 1148 */       next = (rps.propertyStorage.next != -1) ? mappings[rps.propertyStorage.next] : -1;
/*      */       
/* 1150 */       child = (rps.propertyStorage.child != -1) ? mappings[rps.propertyStorage.child] : -1;
/*      */ 
/*      */       
/* 1153 */       ps.setPrevious(previous);
/* 1154 */       ps.setNext(next);
/* 1155 */       ps.setChild(child);
/*      */       
/* 1157 */       System.arraycopy(ps.data, 0, propertySetStorage, pos, 128);
/*      */ 
/*      */       
/* 1160 */       pos += 128;
/*      */       
/* 1162 */       if (rps.data.length > 4096) {
/*      */         
/* 1164 */         bigBlock += getBigBlocksRequired(rps.data.length);
/*      */         
/*      */         continue;
/*      */       } 
/* 1168 */       smallBlock += getSmallBlocksRequired(rps.data.length);
/*      */     } 
/*      */ 
/*      */     
/* 1172 */     this.out.write(propertySetStorage);
/*      */   }
/*      */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\CompoundFile.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
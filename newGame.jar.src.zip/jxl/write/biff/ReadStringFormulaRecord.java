/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.StringFormulaCell;
/*    */ import jxl.biff.FormulaData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReadStringFormulaRecord
/*    */   extends ReadFormulaRecord
/*    */   implements StringFormulaCell
/*    */ {
/*    */   public ReadStringFormulaRecord(FormulaData f) {
/* 38 */     super(f);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getString() {
/* 48 */     return ((StringFormulaCell)getReadFormula()).getString();
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ReadStringFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
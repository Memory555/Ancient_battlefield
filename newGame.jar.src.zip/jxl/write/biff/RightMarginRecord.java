/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RightMarginRecord
/*    */   extends MarginRecord
/*    */ {
/*    */   RightMarginRecord(double v) {
/* 31 */     super(Type.RIGHTMARGIN, v);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\RightMarginRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.biff.Type;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BlankRecord
/*     */   extends CellValue
/*     */ {
/*  41 */   private static Logger logger = Logger.getLogger(BlankRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BlankRecord(int c, int r) {
/*  52 */     super(Type.BLANK, c, r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BlankRecord(int c, int r, CellFormat st) {
/*  65 */     super(Type.BLANK, c, r, st);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BlankRecord(Cell c) {
/*  76 */     super(Type.BLANK, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BlankRecord(int c, int r, BlankRecord br) {
/*  88 */     super(Type.BLANK, c, r, br);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/*  98 */     return CellType.EMPTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 108 */     return "";
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\BlankRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
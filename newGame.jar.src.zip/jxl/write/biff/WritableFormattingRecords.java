/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import jxl.biff.FontRecord;
/*     */ import jxl.biff.Fonts;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.NumFormatRecordsException;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.write.NumberFormats;
/*     */ import jxl.write.WritableCellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WritableFormattingRecords
/*     */   extends FormattingRecords
/*     */ {
/*     */   public static WritableCellFormat normalStyle;
/*     */   
/*     */   public WritableFormattingRecords(Fonts f, Styles styles) {
/*  61 */     super(f);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  66 */       StyleXFRecord sxf = new StyleXFRecord((FontRecord)styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/*  68 */       sxf.setLocked(true);
/*  69 */       addStyle(sxf);
/*     */       
/*  71 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.DEFAULT);
/*  72 */       sxf.setLocked(true);
/*  73 */       sxf.setCellOptions(62464);
/*  74 */       addStyle(sxf);
/*     */       
/*  76 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.DEFAULT);
/*  77 */       sxf.setLocked(true);
/*  78 */       sxf.setCellOptions(62464);
/*  79 */       addStyle(sxf);
/*     */       
/*  81 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.DEFAULT);
/*  82 */       sxf.setLocked(true);
/*  83 */       sxf.setCellOptions(62464);
/*  84 */       addStyle(sxf);
/*     */       
/*  86 */       sxf = new StyleXFRecord(getFonts().getFont(2), NumberFormats.DEFAULT);
/*  87 */       sxf.setLocked(true);
/*  88 */       sxf.setCellOptions(62464);
/*  89 */       addStyle(sxf);
/*     */       
/*  91 */       sxf = new StyleXFRecord(getFonts().getFont(3), NumberFormats.DEFAULT);
/*  92 */       sxf.setLocked(true);
/*  93 */       sxf.setCellOptions(62464);
/*  94 */       addStyle(sxf);
/*     */       
/*  96 */       sxf = new StyleXFRecord((FontRecord)styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/*  98 */       sxf.setLocked(true);
/*  99 */       sxf.setCellOptions(62464);
/* 100 */       addStyle(sxf);
/*     */       
/* 102 */       sxf = new StyleXFRecord((FontRecord)styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 104 */       sxf.setLocked(true);
/* 105 */       sxf.setCellOptions(62464);
/* 106 */       addStyle(sxf);
/*     */       
/* 108 */       sxf = new StyleXFRecord((FontRecord)styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 110 */       sxf.setLocked(true);
/* 111 */       sxf.setCellOptions(62464);
/* 112 */       addStyle(sxf);
/*     */       
/* 114 */       sxf = new StyleXFRecord((FontRecord)styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 116 */       sxf.setLocked(true);
/* 117 */       sxf.setCellOptions(62464);
/* 118 */       addStyle(sxf);
/*     */       
/* 120 */       sxf = new StyleXFRecord((FontRecord)styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 122 */       sxf.setLocked(true);
/* 123 */       sxf.setCellOptions(62464);
/* 124 */       addStyle(sxf);
/*     */       
/* 126 */       sxf = new StyleXFRecord((FontRecord)styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 128 */       sxf.setLocked(true);
/* 129 */       sxf.setCellOptions(62464);
/* 130 */       addStyle(sxf);
/*     */       
/* 132 */       sxf = new StyleXFRecord((FontRecord)styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 134 */       sxf.setLocked(true);
/* 135 */       sxf.setCellOptions(62464);
/* 136 */       addStyle(sxf);
/*     */       
/* 138 */       sxf = new StyleXFRecord((FontRecord)styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 140 */       sxf.setLocked(true);
/* 141 */       sxf.setCellOptions(62464);
/* 142 */       addStyle(sxf);
/*     */       
/* 144 */       sxf = new StyleXFRecord((FontRecord)styles.getArial10Pt(), NumberFormats.DEFAULT);
/*     */       
/* 146 */       sxf.setLocked(true);
/* 147 */       sxf.setCellOptions(62464);
/* 148 */       addStyle(sxf);
/*     */ 
/*     */ 
/*     */       
/* 152 */       addStyle((XFRecord)styles.getNormalStyle());
/*     */ 
/*     */       
/* 155 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.FORMAT7);
/*     */       
/* 157 */       sxf.setLocked(true);
/* 158 */       sxf.setCellOptions(63488);
/* 159 */       addStyle(sxf);
/*     */       
/* 161 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.FORMAT5);
/*     */       
/* 163 */       sxf.setLocked(true);
/* 164 */       sxf.setCellOptions(63488);
/* 165 */       addStyle(sxf);
/*     */       
/* 167 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.FORMAT8);
/*     */       
/* 169 */       sxf.setLocked(true);
/* 170 */       sxf.setCellOptions(63488);
/* 171 */       addStyle(sxf);
/*     */       
/* 173 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.FORMAT6);
/*     */       
/* 175 */       sxf.setLocked(true);
/* 176 */       sxf.setCellOptions(63488);
/* 177 */       addStyle(sxf);
/*     */       
/* 179 */       sxf = new StyleXFRecord(getFonts().getFont(1), NumberFormats.PERCENT_INTEGER);
/*     */       
/* 181 */       sxf.setLocked(true);
/* 182 */       sxf.setCellOptions(63488);
/* 183 */       addStyle(sxf);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 224 */     catch (NumFormatRecordsException e) {
/*     */ 
/*     */ 
/*     */       
/* 228 */       Assert.verify(false, e.getMessage());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\WritableFormattingRecords.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
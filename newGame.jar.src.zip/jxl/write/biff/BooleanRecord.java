/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.BooleanCell;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.biff.Type;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BooleanRecord
/*     */   extends CellValue
/*     */ {
/*     */   private boolean value;
/*     */   
/*     */   protected BooleanRecord(int c, int r, boolean val) {
/*  48 */     super(Type.BOOLERR, c, r);
/*  49 */     this.value = val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BooleanRecord(int c, int r, boolean val, CellFormat st) {
/*  63 */     super(Type.BOOLERR, c, r, st);
/*  64 */     this.value = val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BooleanRecord(BooleanCell nc) {
/*  74 */     super(Type.BOOLERR, (Cell)nc);
/*  75 */     this.value = nc.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected BooleanRecord(int c, int r, BooleanRecord br) {
/*  87 */     super(Type.BOOLERR, c, r, br);
/*  88 */     this.value = br.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getValue() {
/* 101 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 112 */     return (new Boolean(this.value)).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 122 */     return CellType.BOOLEAN;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setValue(boolean val) {
/* 132 */     this.value = val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 142 */     byte[] celldata = super.getData();
/* 143 */     byte[] data = new byte[celldata.length + 2];
/* 144 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/*     */     
/* 146 */     if (this.value)
/*     */     {
/* 148 */       data[celldata.length] = 1;
/*     */     }
/*     */     
/* 151 */     return data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\BooleanRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
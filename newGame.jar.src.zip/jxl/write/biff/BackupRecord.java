/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BackupRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean backup;
/*    */   private byte[] data;
/*    */   
/*    */   public BackupRecord(boolean bu) {
/* 48 */     super(Type.BACKUP);
/*    */     
/* 50 */     this.backup = bu;
/*    */ 
/*    */     
/* 53 */     this.data = new byte[2];
/*    */     
/* 55 */     if (this.backup)
/*    */     {
/* 57 */       IntegerHelper.getTwoBytes(1, this.data, 0);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 68 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\BackupRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
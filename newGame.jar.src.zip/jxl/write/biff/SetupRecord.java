/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.SheetSettings;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.format.PageOrientation;
/*     */ import jxl.format.PaperSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SetupRecord
/*     */   extends WritableRecordData
/*     */ {
/*  40 */   Logger logger = Logger.getLogger(SetupRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double headerMargin;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double footerMargin;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PageOrientation orientation;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int paperSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int scaleFactor;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int pageStart;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int fitWidth;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int fitHeight;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int horizontalPrintResolution;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int verticalPrintResolution;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int copies;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetupRecord() {
/* 109 */     super(Type.SETUP);
/*     */     
/* 111 */     this.orientation = PageOrientation.PORTRAIT;
/* 112 */     this.headerMargin = 0.5D;
/* 113 */     this.footerMargin = 0.5D;
/* 114 */     this.paperSize = PaperSize.A4.getValue();
/* 115 */     this.horizontalPrintResolution = 300;
/* 116 */     this.verticalPrintResolution = 300;
/* 117 */     this.copies = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetupRecord(SheetSettings s) {
/* 128 */     super(Type.SETUP);
/*     */     
/* 130 */     this.orientation = s.getOrientation();
/* 131 */     this.headerMargin = s.getHeaderMargin();
/* 132 */     this.footerMargin = s.getFooterMargin();
/* 133 */     this.paperSize = s.getPaperSize().getValue();
/* 134 */     this.horizontalPrintResolution = s.getHorizontalPrintResolution();
/* 135 */     this.verticalPrintResolution = s.getVerticalPrintResolution();
/* 136 */     this.fitWidth = s.getFitWidth();
/* 137 */     this.fitHeight = s.getFitHeight();
/* 138 */     this.pageStart = s.getPageStart();
/* 139 */     this.scaleFactor = s.getScaleFactor();
/* 140 */     this.copies = s.getCopies();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SetupRecord(jxl.read.biff.SetupRecord sr) {
/* 149 */     super(Type.SETUP);
/*     */     
/* 151 */     this.orientation = sr.isPortrait() ? PageOrientation.PORTRAIT : PageOrientation.LANDSCAPE;
/*     */ 
/*     */     
/* 154 */     this.paperSize = sr.getPaperSize();
/* 155 */     this.headerMargin = sr.getHeaderMargin();
/* 156 */     this.footerMargin = sr.getFooterMargin();
/* 157 */     this.scaleFactor = sr.getScaleFactor();
/* 158 */     this.pageStart = sr.getPageStart();
/* 159 */     this.fitWidth = sr.getFitWidth();
/* 160 */     this.fitHeight = sr.getFitHeight();
/* 161 */     this.horizontalPrintResolution = sr.getHorizontalPrintResolution();
/* 162 */     this.verticalPrintResolution = sr.getVerticalPrintResolution();
/* 163 */     this.copies = sr.getCopies();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrientation(PageOrientation o) {
/* 173 */     this.orientation = o;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMargins(double hm, double fm) {
/* 184 */     this.headerMargin = hm;
/* 185 */     this.footerMargin = fm;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPaperSize(PaperSize ps) {
/* 195 */     this.paperSize = ps.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 205 */     this.data = new byte[34];
/*     */ 
/*     */     
/* 208 */     IntegerHelper.getTwoBytes(this.paperSize, this.data, 0);
/*     */ 
/*     */     
/* 211 */     IntegerHelper.getTwoBytes(this.scaleFactor, this.data, 2);
/*     */ 
/*     */     
/* 214 */     IntegerHelper.getTwoBytes(this.pageStart, this.data, 4);
/*     */ 
/*     */     
/* 217 */     IntegerHelper.getTwoBytes(this.fitWidth, this.data, 6);
/*     */ 
/*     */     
/* 220 */     IntegerHelper.getTwoBytes(this.fitHeight, this.data, 8);
/*     */ 
/*     */     
/* 223 */     if (this.orientation == PageOrientation.PORTRAIT)
/*     */     {
/* 225 */       IntegerHelper.getTwoBytes(2, this.data, 10);
/*     */     }
/*     */ 
/*     */     
/* 229 */     IntegerHelper.getTwoBytes(this.horizontalPrintResolution, this.data, 12);
/*     */ 
/*     */     
/* 232 */     IntegerHelper.getTwoBytes(this.verticalPrintResolution, this.data, 14);
/*     */ 
/*     */     
/* 235 */     DoubleHelper.getIEEEBytes(this.headerMargin, this.data, 16);
/*     */ 
/*     */     
/* 238 */     DoubleHelper.getIEEEBytes(this.footerMargin, this.data, 24);
/*     */ 
/*     */     
/* 241 */     IntegerHelper.getTwoBytes(this.copies, this.data, 32);
/*     */     
/* 243 */     return this.data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\SetupRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SSTContinueRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private String firstString;
/*     */   private boolean includeLength;
/*     */   private int firstStringLength;
/*     */   private ArrayList strings;
/*     */   private ArrayList stringLengths;
/*     */   private byte[] data;
/*     */   private int byteCount;
/*  67 */   private static int maxBytes = 8224;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SSTContinueRecord() {
/*  78 */     super(Type.CONTINUE);
/*     */     
/*  80 */     this.byteCount = 0;
/*  81 */     this.strings = new ArrayList(50);
/*  82 */     this.stringLengths = new ArrayList(50);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setFirstString(String s, boolean b) {
/*  94 */     this.includeLength = b;
/*  95 */     this.firstStringLength = s.length();
/*     */     
/*  97 */     int bytes = 0;
/*     */     
/*  99 */     if (!this.includeLength) {
/*     */       
/* 101 */       bytes = s.length() * 2 + 1;
/*     */     }
/*     */     else {
/*     */       
/* 105 */       bytes = s.length() * 2 + 3;
/*     */     } 
/*     */     
/* 108 */     if (bytes <= maxBytes) {
/*     */       
/* 110 */       this.firstString = s;
/* 111 */       this.byteCount += bytes;
/* 112 */       return 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 117 */     int charsAvailable = this.includeLength ? ((maxBytes - 4) / 2) : ((maxBytes - 2) / 2);
/*     */ 
/*     */ 
/*     */     
/* 121 */     this.firstString = s.substring(0, charsAvailable);
/* 122 */     this.byteCount = maxBytes - 1;
/*     */     
/* 124 */     return s.length() - charsAvailable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 134 */     return this.byteCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int add(String s) {
/* 147 */     int bytes = s.length() * 2 + 3;
/*     */ 
/*     */ 
/*     */     
/* 151 */     if (this.byteCount >= maxBytes - 5)
/*     */     {
/* 153 */       return s.length();
/*     */     }
/*     */     
/* 156 */     this.stringLengths.add(new Integer(s.length()));
/*     */     
/* 158 */     if (bytes + this.byteCount < maxBytes) {
/*     */ 
/*     */       
/* 161 */       this.strings.add(s);
/* 162 */       this.byteCount += bytes;
/* 163 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 167 */     int bytesLeft = maxBytes - 3 - this.byteCount;
/* 168 */     int charsAvailable = (bytesLeft % 2 == 0) ? (bytesLeft / 2) : ((bytesLeft - 1) / 2);
/*     */ 
/*     */ 
/*     */     
/* 172 */     this.strings.add(s.substring(0, charsAvailable));
/* 173 */     this.byteCount += charsAvailable * 2 + 3;
/*     */     
/* 175 */     return s.length() - charsAvailable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 185 */     this.data = new byte[this.byteCount];
/*     */     
/* 187 */     int pos = 0;
/*     */ 
/*     */     
/* 190 */     if (this.includeLength) {
/*     */       
/* 192 */       IntegerHelper.getTwoBytes(this.firstStringLength, this.data, 0);
/* 193 */       this.data[2] = 1;
/* 194 */       pos = 3;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 199 */       this.data[0] = 1;
/* 200 */       pos = 1;
/*     */     } 
/*     */     
/* 203 */     StringHelper.getUnicodeBytes(this.firstString, this.data, pos);
/* 204 */     pos += this.firstString.length() * 2;
/*     */ 
/*     */     
/* 207 */     Iterator i = this.strings.iterator();
/* 208 */     String s = null;
/* 209 */     int length = 0;
/* 210 */     int count = 0;
/* 211 */     while (i.hasNext()) {
/*     */       
/* 213 */       s = i.next();
/* 214 */       length = ((Integer)this.stringLengths.get(count)).intValue();
/* 215 */       IntegerHelper.getTwoBytes(length, this.data, pos);
/* 216 */       this.data[pos + 2] = 1;
/* 217 */       StringHelper.getUnicodeBytes(s, this.data, pos + 3);
/* 218 */       pos += s.length() * 2 + 3;
/* 219 */       count++;
/*     */     } 
/*     */     
/* 222 */     return this.data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\SSTContinueRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
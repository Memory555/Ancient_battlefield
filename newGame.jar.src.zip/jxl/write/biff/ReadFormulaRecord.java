/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.Cell;
/*     */ import jxl.CellReferenceHelper;
/*     */ import jxl.CellType;
/*     */ import jxl.FormulaCell;
/*     */ import jxl.Sheet;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.write.WritableCell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReadFormulaRecord
/*     */   extends CellValue
/*     */   implements FormulaData
/*     */ {
/*  51 */   private static Logger logger = Logger.getLogger(ReadFormulaRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FormulaData formula;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FormulaParser parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ReadFormulaRecord(FormulaData f) {
/*  70 */     super(Type.FORMULA, (Cell)f);
/*  71 */     this.formula = f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/*  83 */     byte[] celldata = super.getData();
/*  84 */     byte[] expressiondata = null;
/*     */ 
/*     */     
/*     */     try {
/*  88 */       if (this.parser == null)
/*     */       {
/*  90 */         expressiondata = this.formula.getFormulaData();
/*     */       }
/*     */       else
/*     */       {
/*  94 */         byte[] formulaBytes = this.parser.getBytes();
/*  95 */         expressiondata = new byte[formulaBytes.length + 16];
/*  96 */         IntegerHelper.getTwoBytes(formulaBytes.length, expressiondata, 14);
/*  97 */         System.arraycopy(formulaBytes, 0, expressiondata, 16, formulaBytes.length);
/*     */       }
/*     */     
/*     */     }
/* 101 */     catch (FormulaException e) {
/*     */ 
/*     */ 
/*     */       
/* 105 */       logger.warn(CellReferenceHelper.getCellReference(getColumn(), getRow()) + " " + e.getMessage());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 110 */       WritableWorkbookImpl w = getSheet().getWorkbook();
/* 111 */       if (this.formula.getType() == CellType.STRING_FORMULA) {
/*     */         
/* 113 */         this.parser = new FormulaParser("\"" + getContents() + "\"", w, w, w.getSettings());
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 118 */         this.parser = new FormulaParser(getContents(), w, w, w.getSettings());
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 125 */         this.parser.parse();
/*     */       }
/* 127 */       catch (FormulaException e2) {
/*     */         
/* 129 */         logger.warn(e2.getMessage());
/* 130 */         this.parser = new FormulaParser("\"ERROR\"", w, w, w.getSettings()); 
/* 131 */         try { this.parser.parse(); }
/* 132 */         catch (FormulaException e3) { Assert.verify(false); }
/*     */       
/* 134 */       }  byte[] formulaBytes = this.parser.getBytes();
/* 135 */       expressiondata = new byte[formulaBytes.length + 16];
/* 136 */       IntegerHelper.getTwoBytes(formulaBytes.length, expressiondata, 14);
/* 137 */       System.arraycopy(formulaBytes, 0, expressiondata, 16, formulaBytes.length);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 142 */     expressiondata[8] = (byte)(expressiondata[8] | 0x2);
/*     */     
/* 144 */     byte[] data = new byte[celldata.length + expressiondata.length];
/*     */     
/* 146 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 147 */     System.arraycopy(expressiondata, 0, data, celldata.length, expressiondata.length);
/*     */     
/* 149 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 159 */     return this.formula.getType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 169 */     return this.formula.getContents();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getFormulaData() throws FormulaException {
/* 180 */     byte[] d = this.formula.getFormulaData();
/* 181 */     byte[] data = new byte[d.length];
/*     */     
/* 183 */     System.arraycopy(d, 0, data, 0, d.length);
/*     */ 
/*     */     
/* 186 */     data[8] = (byte)(data[8] | 0x2);
/*     */     
/* 188 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableCell copyTo(int col, int row) {
/* 200 */     return new FormulaRecord(col, row, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setCellDetails(FormattingRecords fr, SharedStrings ss, WritableSheetImpl s) {
/* 214 */     super.setCellDetails(fr, ss, s);
/* 215 */     s.getWorkbook().addRCIRCell(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnInserted(Sheet s, int sheetIndex, int col) {
/*     */     try {
/* 230 */       if (this.parser == null) {
/*     */         
/* 232 */         byte[] formulaData = this.formula.getFormulaData();
/* 233 */         byte[] formulaBytes = new byte[formulaData.length - 16];
/* 234 */         System.arraycopy(formulaData, 16, formulaBytes, 0, formulaBytes.length);
/*     */         
/* 236 */         this.parser = new FormulaParser(formulaBytes, (Cell)this, getSheet().getWorkbook(), getSheet().getWorkbook(), getSheet().getWorkbookSettings());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 241 */         this.parser.parse();
/*     */       } 
/*     */       
/* 244 */       this.parser.columnInserted(sheetIndex, col, (s == getSheet()));
/*     */     }
/* 246 */     catch (FormulaException e) {
/*     */       
/* 248 */       logger.warn("cannot insert column within formula:  " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(Sheet s, int sheetIndex, int col) {
/*     */     try {
/* 264 */       if (this.parser == null) {
/*     */         
/* 266 */         byte[] formulaData = this.formula.getFormulaData();
/* 267 */         byte[] formulaBytes = new byte[formulaData.length - 16];
/* 268 */         System.arraycopy(formulaData, 16, formulaBytes, 0, formulaBytes.length);
/*     */         
/* 270 */         this.parser = new FormulaParser(formulaBytes, (Cell)this, getSheet().getWorkbook(), getSheet().getWorkbook(), getSheet().getWorkbookSettings());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 275 */         this.parser.parse();
/*     */       } 
/*     */       
/* 278 */       this.parser.columnRemoved(sheetIndex, col, (s == getSheet()));
/*     */     }
/* 280 */     catch (FormulaException e) {
/*     */       
/* 282 */       logger.warn("cannot remove column within formula:  " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(Sheet s, int sheetIndex, int row) {
/*     */     try {
/* 298 */       if (this.parser == null) {
/*     */         
/* 300 */         byte[] formulaData = this.formula.getFormulaData();
/* 301 */         byte[] formulaBytes = new byte[formulaData.length - 16];
/* 302 */         System.arraycopy(formulaData, 16, formulaBytes, 0, formulaBytes.length);
/*     */         
/* 304 */         this.parser = new FormulaParser(formulaBytes, (Cell)this, getSheet().getWorkbook(), getSheet().getWorkbook(), getSheet().getWorkbookSettings());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 309 */         this.parser.parse();
/*     */       } 
/*     */       
/* 312 */       this.parser.rowInserted(sheetIndex, row, (s == getSheet()));
/*     */     }
/* 314 */     catch (FormulaException e) {
/*     */       
/* 316 */       logger.warn("cannot insert row within formula:  " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(Sheet s, int sheetIndex, int row) {
/*     */     try {
/* 332 */       if (this.parser == null) {
/*     */         
/* 334 */         byte[] formulaData = this.formula.getFormulaData();
/* 335 */         byte[] formulaBytes = new byte[formulaData.length - 16];
/* 336 */         System.arraycopy(formulaData, 16, formulaBytes, 0, formulaBytes.length);
/*     */         
/* 338 */         this.parser = new FormulaParser(formulaBytes, (Cell)this, getSheet().getWorkbook(), getSheet().getWorkbook(), getSheet().getWorkbookSettings());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 343 */         this.parser.parse();
/*     */       } 
/*     */       
/* 346 */       this.parser.rowRemoved(sheetIndex, row, (s == getSheet()));
/*     */     }
/* 348 */     catch (FormulaException e) {
/*     */       
/* 350 */       logger.warn("cannot remove row within formula:  " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FormulaData getReadFormula() {
/* 361 */     return this.formula;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormula() throws FormulaException {
/* 371 */     return ((FormulaCell)this.formula).getFormula();
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ReadFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
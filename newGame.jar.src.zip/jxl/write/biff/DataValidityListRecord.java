/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.DValParser;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataValidityListRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private byte[] data;
/*     */   private DValParser dvalParser;
/*     */   
/*     */   DataValidityListRecord(jxl.read.biff.DataValidityListRecord dvlr) {
/*  48 */     super(Type.DVAL);
/*     */     
/*  50 */     this.data = dvlr.getData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DataValidityListRecord(DataValidityListRecord dvlr) {
/*  60 */     super(Type.DVAL);
/*     */     
/*  62 */     this.data = new byte[dvlr.data.length];
/*  63 */     System.arraycopy(dvlr.data, 0, this.data, 0, this.data.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/*  73 */     if (this.dvalParser == null)
/*     */     {
/*  75 */       return this.data;
/*     */     }
/*     */     
/*  78 */     return this.dvalParser.getData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dvRemoved() {
/*  87 */     if (this.dvalParser == null)
/*     */     {
/*  89 */       this.dvalParser = new DValParser(this.data);
/*     */     }
/*     */     
/*  92 */     this.dvalParser.dvRemoved();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasDVRecords() {
/* 102 */     if (this.dvalParser == null)
/*     */     {
/* 104 */       return true;
/*     */     }
/*     */     
/* 107 */     return (this.dvalParser.getNumberOfDVRecords() > 0);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\DataValidityListRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
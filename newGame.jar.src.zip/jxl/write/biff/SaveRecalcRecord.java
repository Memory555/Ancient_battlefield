/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SaveRecalcRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private boolean recalc;
/*    */   
/*    */   public SaveRecalcRecord(boolean r) {
/* 48 */     super(Type.SAVERECALC);
/* 49 */     this.recalc = r;
/*    */     
/* 51 */     this.data = new byte[2];
/*    */     
/* 53 */     if (this.recalc)
/*    */     {
/* 55 */       this.data[0] = 1;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 66 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\SaveRecalcRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
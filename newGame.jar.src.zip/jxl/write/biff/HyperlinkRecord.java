/*      */ package jxl.write.biff;
/*      */ 
/*      */ import common.Assert;
/*      */ import common.Logger;
/*      */ import java.io.File;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import jxl.CellType;
/*      */ import jxl.Hyperlink;
/*      */ import jxl.Range;
/*      */ import jxl.Sheet;
/*      */ import jxl.biff.CellReferenceHelper;
/*      */ import jxl.biff.IntegerHelper;
/*      */ import jxl.biff.SheetRangeImpl;
/*      */ import jxl.biff.StringHelper;
/*      */ import jxl.biff.Type;
/*      */ import jxl.biff.WritableRecordData;
/*      */ import jxl.write.Label;
/*      */ import jxl.write.WritableCell;
/*      */ import jxl.write.WritableSheet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HyperlinkRecord
/*      */   extends WritableRecordData
/*      */ {
/*   53 */   private static Logger logger = Logger.getLogger(HyperlinkRecord.class);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int firstRow;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lastRow;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int firstColumn;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lastColumn;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private URL url;
/*      */ 
/*      */ 
/*      */   
/*      */   private File file;
/*      */ 
/*      */ 
/*      */   
/*      */   private String location;
/*      */ 
/*      */ 
/*      */   
/*      */   private String contents;
/*      */ 
/*      */ 
/*      */   
/*      */   private LinkType linkType;
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] data;
/*      */ 
/*      */ 
/*      */   
/*      */   private Range range;
/*      */ 
/*      */ 
/*      */   
/*      */   private WritableSheet sheet;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean modified;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class LinkType
/*      */   {
/*      */     private LinkType() {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  123 */   private static final LinkType urlLink = new LinkType();
/*  124 */   private static final LinkType fileLink = new LinkType();
/*  125 */   private static final LinkType uncLink = new LinkType();
/*  126 */   private static final LinkType workbookLink = new LinkType();
/*  127 */   private static final LinkType unknown = new LinkType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected HyperlinkRecord(Hyperlink h, WritableSheet s) {
/*  136 */     super(Type.HLINK);
/*      */     
/*  138 */     Assert.verify(h instanceof jxl.read.biff.HyperlinkRecord);
/*      */     
/*  140 */     jxl.read.biff.HyperlinkRecord hl = (jxl.read.biff.HyperlinkRecord)h;
/*      */     
/*  142 */     this.data = hl.getRecord().getData();
/*  143 */     this.sheet = s;
/*      */ 
/*      */     
/*  146 */     this.firstRow = hl.getRow();
/*  147 */     this.firstColumn = hl.getColumn();
/*  148 */     this.lastRow = hl.getLastRow();
/*  149 */     this.lastColumn = hl.getLastColumn();
/*  150 */     this.range = (Range)new SheetRangeImpl((Sheet)s, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */ 
/*      */ 
/*      */     
/*  154 */     this.linkType = unknown;
/*      */     
/*  156 */     if (hl.isFile()) {
/*      */       
/*  158 */       this.linkType = fileLink;
/*  159 */       this.file = hl.getFile();
/*      */     }
/*  161 */     else if (hl.isURL()) {
/*      */       
/*  163 */       this.linkType = urlLink;
/*  164 */       this.url = hl.getURL();
/*      */     }
/*  166 */     else if (hl.isLocation()) {
/*      */       
/*  168 */       this.linkType = workbookLink;
/*  169 */       this.location = hl.getLocation();
/*      */     } 
/*      */     
/*  172 */     this.modified = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected HyperlinkRecord(int col, int row, int lastcol, int lastrow, URL url, String desc) {
/*  190 */     super(Type.HLINK);
/*      */     
/*  192 */     this.firstColumn = col;
/*  193 */     this.firstRow = row;
/*      */     
/*  195 */     this.lastColumn = Math.max(this.firstColumn, lastcol);
/*  196 */     this.lastRow = Math.max(this.firstRow, lastrow);
/*      */     
/*  198 */     this.url = url;
/*  199 */     this.contents = desc;
/*      */     
/*  201 */     this.linkType = urlLink;
/*      */     
/*  203 */     this.modified = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected HyperlinkRecord(int col, int row, int lastcol, int lastrow, File file, String desc) {
/*  219 */     super(Type.HLINK);
/*      */     
/*  221 */     this.firstColumn = col;
/*  222 */     this.firstRow = row;
/*      */     
/*  224 */     this.lastColumn = Math.max(this.firstColumn, lastcol);
/*  225 */     this.lastRow = Math.max(this.firstRow, lastrow);
/*  226 */     this.contents = desc;
/*      */     
/*  228 */     this.file = file;
/*      */     
/*  230 */     if (file.getPath().startsWith("\\\\")) {
/*      */       
/*  232 */       this.linkType = uncLink;
/*      */     }
/*      */     else {
/*      */       
/*  236 */       this.linkType = fileLink;
/*      */     } 
/*      */     
/*  239 */     this.modified = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected HyperlinkRecord(int col, int row, int lastcol, int lastrow, String desc, WritableSheet s, int destcol, int destrow, int lastdestcol, int lastdestrow) {
/*  263 */     super(Type.HLINK);
/*      */     
/*  265 */     this.firstColumn = col;
/*  266 */     this.firstRow = row;
/*      */     
/*  268 */     this.lastColumn = Math.max(this.firstColumn, lastcol);
/*  269 */     this.lastRow = Math.max(this.firstRow, lastrow);
/*      */     
/*  271 */     setLocation(s, destcol, destrow, lastdestcol, lastdestrow);
/*  272 */     this.contents = desc;
/*      */     
/*  274 */     this.linkType = workbookLink;
/*      */     
/*  276 */     this.modified = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFile() {
/*  286 */     return (this.linkType == fileLink);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUNC() {
/*  296 */     return (this.linkType == uncLink);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isURL() {
/*  306 */     return (this.linkType == urlLink);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLocation() {
/*  316 */     return (this.linkType == workbookLink);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() {
/*  326 */     return this.firstRow;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getColumn() {
/*  336 */     return this.firstColumn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastRow() {
/*  346 */     return this.lastRow;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLastColumn() {
/*  356 */     return this.lastColumn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL() {
/*  366 */     return this.url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public File getFile() {
/*  376 */     return this.file;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getData() {
/*  386 */     if (!this.modified)
/*      */     {
/*  388 */       return this.data;
/*      */     }
/*      */ 
/*      */     
/*  392 */     byte[] commonData = new byte[32];
/*      */ 
/*      */     
/*  395 */     IntegerHelper.getTwoBytes(this.firstRow, commonData, 0);
/*  396 */     IntegerHelper.getTwoBytes(this.lastRow, commonData, 2);
/*  397 */     IntegerHelper.getTwoBytes(this.firstColumn, commonData, 4);
/*  398 */     IntegerHelper.getTwoBytes(this.lastColumn, commonData, 6);
/*      */ 
/*      */     
/*  401 */     commonData[8] = -48;
/*  402 */     commonData[9] = -55;
/*  403 */     commonData[10] = -22;
/*  404 */     commonData[11] = 121;
/*  405 */     commonData[12] = -7;
/*  406 */     commonData[13] = -70;
/*  407 */     commonData[14] = -50;
/*  408 */     commonData[15] = 17;
/*  409 */     commonData[16] = -116;
/*  410 */     commonData[17] = -126;
/*  411 */     commonData[18] = 0;
/*  412 */     commonData[19] = -86;
/*  413 */     commonData[20] = 0;
/*  414 */     commonData[21] = 75;
/*  415 */     commonData[22] = -87;
/*  416 */     commonData[23] = 11;
/*  417 */     commonData[24] = 2;
/*  418 */     commonData[25] = 0;
/*  419 */     commonData[26] = 0;
/*  420 */     commonData[27] = 0;
/*      */ 
/*      */ 
/*      */     
/*  424 */     int optionFlags = 0;
/*  425 */     if (isURL()) {
/*      */       
/*  427 */       optionFlags = 3;
/*      */       
/*  429 */       if (this.contents != null)
/*      */       {
/*  431 */         optionFlags |= 0x14;
/*      */       }
/*      */     }
/*  434 */     else if (isFile()) {
/*      */       
/*  436 */       optionFlags = 3;
/*      */       
/*  438 */       if (this.contents == null)
/*      */       {
/*  440 */         optionFlags |= 0x14;
/*      */       }
/*      */     }
/*  443 */     else if (isLocation()) {
/*      */       
/*  445 */       optionFlags = 8;
/*      */     }
/*  447 */     else if (isUNC()) {
/*      */       
/*  449 */       optionFlags = 259;
/*      */     } 
/*      */     
/*  452 */     IntegerHelper.getFourBytes(optionFlags, commonData, 28);
/*      */     
/*  454 */     if (isURL()) {
/*      */       
/*  456 */       this.data = getURLData(commonData);
/*      */     }
/*  458 */     else if (isFile()) {
/*      */       
/*  460 */       this.data = getFileData(commonData);
/*      */     }
/*  462 */     else if (isLocation()) {
/*      */       
/*  464 */       this.data = getLocationData(commonData);
/*      */     }
/*  466 */     else if (isUNC()) {
/*      */       
/*  468 */       this.data = getUNCData(commonData);
/*      */     } 
/*      */     
/*  471 */     return this.data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  481 */     if (isFile())
/*      */     {
/*  483 */       return this.file.toString();
/*      */     }
/*  485 */     if (isURL())
/*      */     {
/*  487 */       return this.url.toString();
/*      */     }
/*  489 */     if (isUNC())
/*      */     {
/*  491 */       return this.file.toString();
/*      */     }
/*      */ 
/*      */     
/*  495 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Range getRange() {
/*  509 */     return this.range;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(URL url) {
/*  519 */     this.linkType = urlLink;
/*  520 */     this.file = null;
/*  521 */     this.location = null;
/*  522 */     this.contents = null;
/*  523 */     this.url = url;
/*  524 */     this.modified = true;
/*      */     
/*  526 */     if (this.sheet == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  533 */     WritableCell wc = this.sheet.getWritableCell(this.firstColumn, this.firstRow);
/*      */     
/*  535 */     Assert.verify((wc.getType() == CellType.LABEL));
/*      */     
/*  537 */     Label l = (Label)wc;
/*  538 */     l.setString(url.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFile(File file) {
/*  548 */     this.linkType = fileLink;
/*  549 */     this.url = null;
/*  550 */     this.location = null;
/*  551 */     this.contents = null;
/*  552 */     this.file = file;
/*  553 */     this.modified = true;
/*      */     
/*  555 */     if (this.sheet == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  562 */     WritableCell wc = this.sheet.getWritableCell(this.firstColumn, this.firstRow);
/*      */     
/*  564 */     Assert.verify((wc.getType() == CellType.LABEL));
/*      */     
/*  566 */     Label l = (Label)wc;
/*  567 */     l.setString(file.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setLocation(String desc, WritableSheet sheet, int destcol, int destrow, int lastdestcol, int lastdestrow) {
/*  585 */     this.linkType = workbookLink;
/*  586 */     this.url = null;
/*  587 */     this.file = null;
/*  588 */     this.modified = true;
/*  589 */     this.contents = desc;
/*      */     
/*  591 */     setLocation(sheet, destcol, destrow, lastdestcol, lastdestrow);
/*      */     
/*  593 */     if (sheet == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  600 */     WritableCell wc = sheet.getWritableCell(this.firstColumn, this.firstRow);
/*      */     
/*  602 */     Assert.verify((wc.getType() == CellType.LABEL));
/*      */     
/*  604 */     Label l = (Label)wc;
/*  605 */     l.setString(desc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setLocation(WritableSheet sheet, int destcol, int destrow, int lastdestcol, int lastdestrow) {
/*  621 */     StringBuffer sb = new StringBuffer();
/*  622 */     sb.append('\'');
/*      */     
/*  624 */     if (sheet.getName().indexOf('\'') == -1) {
/*      */       
/*  626 */       sb.append(sheet.getName());
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  634 */       String sheetName = sheet.getName();
/*  635 */       int pos = 0;
/*  636 */       int nextPos = sheetName.indexOf('\'', pos);
/*      */       
/*  638 */       while (nextPos != -1 && pos < sheetName.length()) {
/*      */         
/*  640 */         sb.append(sheetName.substring(pos, nextPos));
/*  641 */         sb.append("''");
/*  642 */         pos = nextPos + 1;
/*  643 */         nextPos = sheetName.indexOf('\'', pos);
/*      */       } 
/*  645 */       sb.append(sheetName.substring(pos));
/*      */     } 
/*      */     
/*  648 */     sb.append('\'');
/*  649 */     sb.append('!');
/*      */     
/*  651 */     lastdestcol = Math.max(destcol, lastdestcol);
/*  652 */     lastdestrow = Math.max(destrow, lastdestrow);
/*      */     
/*  654 */     CellReferenceHelper.getCellReference(destcol, destrow, sb);
/*  655 */     sb.append(':');
/*  656 */     CellReferenceHelper.getCellReference(lastdestcol, lastdestrow, sb);
/*      */     
/*  658 */     this.location = sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void insertRow(int r) {
/*  670 */     Assert.verify((this.sheet != null && this.range != null));
/*      */     
/*  672 */     if (r > this.lastRow) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  677 */     if (r <= this.firstRow) {
/*      */       
/*  679 */       this.firstRow++;
/*  680 */       this.modified = true;
/*      */     } 
/*      */     
/*  683 */     if (r <= this.lastRow) {
/*      */       
/*  685 */       this.lastRow++;
/*  686 */       this.modified = true;
/*      */     } 
/*      */     
/*  689 */     if (this.modified)
/*      */     {
/*  691 */       this.range = (Range)new SheetRangeImpl((Sheet)this.sheet, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void insertColumn(int c) {
/*  706 */     Assert.verify((this.sheet != null && this.range != null));
/*      */     
/*  708 */     if (c > this.lastColumn) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  713 */     if (c <= this.firstColumn) {
/*      */       
/*  715 */       this.firstColumn++;
/*  716 */       this.modified = true;
/*      */     } 
/*      */     
/*  719 */     if (c <= this.lastColumn) {
/*      */       
/*  721 */       this.lastColumn++;
/*  722 */       this.modified = true;
/*      */     } 
/*      */     
/*  725 */     if (this.modified)
/*      */     {
/*  727 */       this.range = (Range)new SheetRangeImpl((Sheet)this.sheet, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void removeRow(int r) {
/*  742 */     Assert.verify((this.sheet != null && this.range != null));
/*      */     
/*  744 */     if (r > this.lastRow) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  749 */     if (r < this.firstRow) {
/*      */       
/*  751 */       this.firstRow--;
/*  752 */       this.modified = true;
/*      */     } 
/*      */     
/*  755 */     if (r < this.lastRow) {
/*      */       
/*  757 */       this.lastRow--;
/*  758 */       this.modified = true;
/*      */     } 
/*      */     
/*  761 */     if (this.modified) {
/*      */       
/*  763 */       Assert.verify((this.range != null));
/*  764 */       this.range = (Range)new SheetRangeImpl((Sheet)this.sheet, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void removeColumn(int c) {
/*  779 */     Assert.verify((this.sheet != null && this.range != null));
/*      */     
/*  781 */     if (c > this.lastColumn) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  786 */     if (c < this.firstColumn) {
/*      */       
/*  788 */       this.firstColumn--;
/*  789 */       this.modified = true;
/*      */     } 
/*      */     
/*  792 */     if (c < this.lastColumn) {
/*      */       
/*  794 */       this.lastColumn--;
/*  795 */       this.modified = true;
/*      */     } 
/*      */     
/*  798 */     if (this.modified) {
/*      */       
/*  800 */       Assert.verify((this.range != null));
/*  801 */       this.range = (Range)new SheetRangeImpl((Sheet)this.sheet, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] getURLData(byte[] cd) {
/*  815 */     String urlString = this.url.toString();
/*      */     
/*  817 */     int dataLength = cd.length + 20 + (urlString.length() + 1) * 2;
/*      */     
/*  819 */     if (this.contents != null)
/*      */     {
/*  821 */       dataLength += 4 + (this.contents.length() + 1) * 2;
/*      */     }
/*      */     
/*  824 */     byte[] d = new byte[dataLength];
/*      */     
/*  826 */     System.arraycopy(cd, 0, d, 0, cd.length);
/*      */     
/*  828 */     int urlPos = cd.length;
/*      */     
/*  830 */     if (this.contents != null) {
/*      */       
/*  832 */       IntegerHelper.getFourBytes(this.contents.length() + 1, d, urlPos);
/*  833 */       StringHelper.getUnicodeBytes(this.contents, d, urlPos + 4);
/*  834 */       urlPos += (this.contents.length() + 1) * 2 + 4;
/*      */     } 
/*      */ 
/*      */     
/*  838 */     d[urlPos] = -32;
/*  839 */     d[urlPos + 1] = -55;
/*  840 */     d[urlPos + 2] = -22;
/*  841 */     d[urlPos + 3] = 121;
/*  842 */     d[urlPos + 4] = -7;
/*  843 */     d[urlPos + 5] = -70;
/*  844 */     d[urlPos + 6] = -50;
/*  845 */     d[urlPos + 7] = 17;
/*  846 */     d[urlPos + 8] = -116;
/*  847 */     d[urlPos + 9] = -126;
/*  848 */     d[urlPos + 10] = 0;
/*  849 */     d[urlPos + 11] = -86;
/*  850 */     d[urlPos + 12] = 0;
/*  851 */     d[urlPos + 13] = 75;
/*  852 */     d[urlPos + 14] = -87;
/*  853 */     d[urlPos + 15] = 11;
/*      */ 
/*      */     
/*  856 */     IntegerHelper.getFourBytes((urlString.length() + 1) * 2, d, urlPos + 16);
/*      */ 
/*      */     
/*  859 */     StringHelper.getUnicodeBytes(urlString, d, urlPos + 20);
/*      */     
/*  861 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] getUNCData(byte[] cd) {
/*  872 */     String uncString = this.file.getPath();
/*      */     
/*  874 */     byte[] d = new byte[cd.length + uncString.length() * 2 + 2 + 4];
/*  875 */     System.arraycopy(cd, 0, d, 0, cd.length);
/*      */     
/*  877 */     int urlPos = cd.length;
/*      */ 
/*      */     
/*  880 */     int length = uncString.length() + 1;
/*  881 */     IntegerHelper.getFourBytes(length, d, urlPos);
/*      */ 
/*      */     
/*  884 */     StringHelper.getUnicodeBytes(uncString, d, urlPos + 4);
/*      */     
/*  886 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] getFileData(byte[] cd) {
/*  898 */     ArrayList path = new ArrayList();
/*  899 */     ArrayList shortFileName = new ArrayList();
/*  900 */     path.add(this.file.getName());
/*  901 */     shortFileName.add(getShortName(this.file.getName()));
/*      */     
/*  903 */     File parent = this.file.getParentFile();
/*  904 */     while (parent != null) {
/*      */       
/*  906 */       path.add(parent.getName());
/*  907 */       shortFileName.add(getShortName(parent.getName()));
/*  908 */       parent = parent.getParentFile();
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  913 */     int upLevelCount = 0;
/*  914 */     int pos = path.size() - 1;
/*  915 */     boolean upDir = true;
/*      */     
/*  917 */     while (upDir) {
/*      */       
/*  919 */       String s = path.get(pos);
/*  920 */       if (s.equals("..")) {
/*      */         
/*  922 */         upLevelCount++;
/*  923 */         path.remove(pos);
/*  924 */         shortFileName.remove(pos);
/*      */       }
/*      */       else {
/*      */         
/*  928 */         upDir = false;
/*      */       } 
/*      */       
/*  931 */       pos--;
/*      */     } 
/*      */     
/*  934 */     StringBuffer filePathSB = new StringBuffer();
/*  935 */     StringBuffer shortFilePathSB = new StringBuffer();
/*      */     
/*  937 */     if (this.file.getPath().charAt(1) == ':') {
/*      */       
/*  939 */       char driveLetter = this.file.getPath().charAt(0);
/*  940 */       if (driveLetter != 'C' && driveLetter != 'c') {
/*      */         
/*  942 */         filePathSB.append(driveLetter);
/*  943 */         filePathSB.append(':');
/*  944 */         shortFilePathSB.append(driveLetter);
/*  945 */         shortFilePathSB.append(':');
/*      */       } 
/*      */     } 
/*      */     
/*  949 */     for (int i = path.size() - 1; i >= 0; i--) {
/*      */       
/*  951 */       filePathSB.append(path.get(i));
/*  952 */       shortFilePathSB.append(shortFileName.get(i));
/*      */       
/*  954 */       if (i != 0) {
/*      */         
/*  956 */         filePathSB.append("\\");
/*  957 */         shortFilePathSB.append("\\");
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  962 */     String filePath = filePathSB.toString();
/*  963 */     String shortFilePath = shortFilePathSB.toString();
/*      */     
/*  965 */     int dataLength = cd.length + 4 + (shortFilePath.length() + 1) * 2 + 16 + 2 + 4 + filePath.length() + 1 + 4 + 24;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  973 */     if (this.contents != null)
/*      */     {
/*  975 */       dataLength += 4 + (this.contents.length() + 1) * 2;
/*      */     }
/*      */ 
/*      */     
/*  979 */     byte[] d = new byte[dataLength];
/*      */     
/*  981 */     System.arraycopy(cd, 0, d, 0, cd.length);
/*      */     
/*  983 */     int filePos = cd.length;
/*      */     
/*  985 */     if (this.contents != null) {
/*      */       
/*  987 */       IntegerHelper.getFourBytes(this.contents.length() + 1, d, filePos);
/*  988 */       StringHelper.getUnicodeBytes(this.contents, d, filePos + 4);
/*  989 */       filePos += (this.contents.length() + 1) * 2 + 4;
/*      */     } 
/*      */     
/*  992 */     int curPos = filePos;
/*      */ 
/*      */     
/*  995 */     IntegerHelper.getFourBytes(shortFilePath.length() + 1, d, curPos);
/*      */ 
/*      */     
/*  998 */     StringHelper.getUnicodeBytes(shortFilePath, d, curPos + 4);
/*      */     
/* 1000 */     curPos += 4 + (shortFilePath.length() + 1) * 2;
/*      */ 
/*      */     
/* 1003 */     d[curPos] = 3;
/* 1004 */     d[curPos + 1] = 3;
/* 1005 */     d[curPos + 2] = 0;
/* 1006 */     d[curPos + 3] = 0;
/* 1007 */     d[curPos + 4] = 0;
/* 1008 */     d[curPos + 5] = 0;
/* 1009 */     d[curPos + 6] = 0;
/* 1010 */     d[curPos + 7] = 0;
/* 1011 */     d[curPos + 8] = -64;
/* 1012 */     d[curPos + 9] = 0;
/* 1013 */     d[curPos + 10] = 0;
/* 1014 */     d[curPos + 11] = 0;
/* 1015 */     d[curPos + 12] = 0;
/* 1016 */     d[curPos + 13] = 0;
/* 1017 */     d[curPos + 14] = 0;
/* 1018 */     d[curPos + 15] = 70;
/*      */     
/* 1020 */     curPos += 16;
/*      */ 
/*      */     
/* 1023 */     IntegerHelper.getTwoBytes(upLevelCount, d, curPos);
/* 1024 */     curPos += 2;
/*      */ 
/*      */ 
/*      */     
/* 1028 */     IntegerHelper.getFourBytes(filePath.length() + 1, d, curPos);
/* 1029 */     curPos += 4;
/*      */ 
/*      */     
/* 1032 */     StringHelper.getBytes(filePath, d, curPos);
/* 1033 */     curPos += filePath.length() + 1;
/*      */ 
/*      */     
/* 1036 */     d[curPos] = -1;
/* 1037 */     d[curPos + 1] = -1;
/* 1038 */     d[curPos + 2] = -83;
/* 1039 */     d[curPos + 3] = -34;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1058 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getShortName(String s) {
/* 1069 */     int sep = s.indexOf('.');
/*      */     
/* 1071 */     String prefix = null;
/* 1072 */     String suffix = null;
/*      */     
/* 1074 */     if (sep == -1) {
/*      */       
/* 1076 */       prefix = s;
/* 1077 */       suffix = "";
/*      */     }
/*      */     else {
/*      */       
/* 1081 */       prefix = s.substring(0, sep);
/* 1082 */       suffix = s.substring(sep + 1);
/*      */     } 
/*      */     
/* 1085 */     if (prefix.length() > 8) {
/*      */       
/* 1087 */       prefix = prefix.substring(0, 6) + "~" + (prefix.length() - 6);
/* 1088 */       prefix = prefix.substring(0, 8);
/*      */     } 
/*      */     
/* 1091 */     suffix = suffix.substring(0, Math.min(3, suffix.length()));
/*      */     
/* 1093 */     if (suffix.length() > 0)
/*      */     {
/* 1095 */       return prefix + '.' + suffix;
/*      */     }
/*      */ 
/*      */     
/* 1099 */     return prefix;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] getLocationData(byte[] cd) {
/* 1111 */     byte[] d = new byte[cd.length + 4 + (this.location.length() + 1) * 2];
/* 1112 */     System.arraycopy(cd, 0, d, 0, cd.length);
/*      */     
/* 1114 */     int locPos = cd.length;
/*      */ 
/*      */     
/* 1117 */     IntegerHelper.getFourBytes(this.location.length() + 1, d, locPos);
/*      */ 
/*      */     
/* 1120 */     StringHelper.getUnicodeBytes(this.location, d, locPos + 4);
/*      */     
/* 1122 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initialize(WritableSheet s) {
/* 1133 */     this.sheet = s;
/* 1134 */     this.range = (Range)new SheetRangeImpl((Sheet)s, this.firstColumn, this.firstRow, this.lastColumn, this.lastRow);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getContents() {
/* 1147 */     return this.contents;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setContents(String desc) {
/* 1157 */     this.contents = desc;
/* 1158 */     this.modified = true;
/*      */   }
/*      */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\HyperlinkRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ButtonPropertySetRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   
/*    */   public ButtonPropertySetRecord(jxl.read.biff.ButtonPropertySetRecord bps) {
/* 40 */     super(Type.BUTTONPROPERTYSET);
/*    */     
/* 42 */     this.data = bps.getData();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ButtonPropertySetRecord(ButtonPropertySetRecord bps) {
/* 50 */     super(Type.BUTTONPROPERTYSET);
/*    */     
/* 52 */     this.data = bps.getData();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 62 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ButtonPropertySetRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
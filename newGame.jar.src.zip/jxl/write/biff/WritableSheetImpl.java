/*      */ package jxl.write.biff;
/*      */ 
/*      */ import common.Assert;
/*      */ import common.Logger;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Comparator;
/*      */ import java.util.Iterator;
/*      */ import java.util.TreeSet;
/*      */ import jxl.BooleanCell;
/*      */ import jxl.Cell;
/*      */ import jxl.CellType;
/*      */ import jxl.CellView;
/*      */ import jxl.DateCell;
/*      */ import jxl.HeaderFooter;
/*      */ import jxl.Hyperlink;
/*      */ import jxl.Image;
/*      */ import jxl.LabelCell;
/*      */ import jxl.NumberCell;
/*      */ import jxl.Range;
/*      */ import jxl.Sheet;
/*      */ import jxl.SheetSettings;
/*      */ import jxl.WorkbookSettings;
/*      */ import jxl.biff.EmptyCell;
/*      */ import jxl.biff.FormattingRecords;
/*      */ import jxl.biff.FormulaData;
/*      */ import jxl.biff.IndexMapping;
/*      */ import jxl.biff.NumFormatRecordsException;
/*      */ import jxl.biff.SheetRangeImpl;
/*      */ import jxl.biff.WorkspaceInformationRecord;
/*      */ import jxl.biff.XFRecord;
/*      */ import jxl.biff.drawing.Button;
/*      */ import jxl.biff.drawing.Chart;
/*      */ import jxl.biff.drawing.Comment;
/*      */ import jxl.biff.drawing.Drawing;
/*      */ import jxl.biff.drawing.DrawingGroupObject;
/*      */ import jxl.format.CellFormat;
/*      */ import jxl.format.PageOrientation;
/*      */ import jxl.format.PaperSize;
/*      */ import jxl.read.biff.ColumnInfoRecord;
/*      */ import jxl.read.biff.DataValidation;
/*      */ import jxl.read.biff.RowRecord;
/*      */ import jxl.read.biff.SheetImpl;
/*      */ import jxl.write.Blank;
/*      */ import jxl.write.Boolean;
/*      */ import jxl.write.DateTime;
/*      */ import jxl.write.Label;
/*      */ import jxl.write.Number;
/*      */ import jxl.write.WritableCell;
/*      */ import jxl.write.WritableCellFormat;
/*      */ import jxl.write.WritableHyperlink;
/*      */ import jxl.write.WritableImage;
/*      */ import jxl.write.WritableSheet;
/*      */ import jxl.write.WritableWorkbook;
/*      */ import jxl.write.WriteException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class WritableSheetImpl
/*      */   implements WritableSheet
/*      */ {
/*   87 */   private static Logger logger = Logger.getLogger(WritableSheetImpl.class);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String name;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private File outputFile;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RowRecord[] rows;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private FormattingRecords formatRecords;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SharedStrings sharedStrings;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private TreeSet columnFormats;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList hyperlinks;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MergedCells mergedCells;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int numRows;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int numColumns;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PLSRecord plsRecord;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ButtonPropertySetRecord buttonPropertySet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean chartOnly;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DataValidation dataValidation;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList rowBreaks;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList drawings;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList images;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean drawingsModified;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SheetSettings settings;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SheetWriter sheetWriter;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WorkbookSettings workbookSettings;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WritableWorkbookImpl workbook;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int rowGrowSize = 10;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int numRowsPerSheet = 65536;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int maxSheetNameLength = 31;
/*      */ 
/*      */ 
/*      */   
/*  214 */   private static final char[] illegalSheetNameCharacters = new char[] { '*', ':', '?', '\\' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  220 */   private static final String[] imageTypes = new String[] { "png" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ColumnInfoComparator
/*      */     implements Comparator
/*      */   {
/*      */     private ColumnInfoComparator() {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean equals(Object o) {
/*  235 */       return (o == this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int compare(Object o1, Object o2) {
/*  247 */       if (o1 == o2)
/*      */       {
/*  249 */         return 0;
/*      */       }
/*      */       
/*  252 */       Assert.verify(o1 instanceof ColumnInfoRecord);
/*  253 */       Assert.verify(o2 instanceof ColumnInfoRecord);
/*      */       
/*  255 */       ColumnInfoRecord ci1 = (ColumnInfoRecord)o1;
/*  256 */       ColumnInfoRecord ci2 = (ColumnInfoRecord)o2;
/*      */       
/*  258 */       return ci1.getColumn() - ci2.getColumn();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableSheetImpl(String n, File of, FormattingRecords fr, SharedStrings ss, WorkbookSettings ws, WritableWorkbookImpl ww) {
/*  279 */     this.name = validateName(n);
/*  280 */     this.outputFile = of;
/*  281 */     this.rows = new RowRecord[0];
/*  282 */     this.numRows = 0;
/*  283 */     this.numColumns = 0;
/*  284 */     this.chartOnly = false;
/*  285 */     this.workbook = ww;
/*      */     
/*  287 */     this.formatRecords = fr;
/*  288 */     this.sharedStrings = ss;
/*  289 */     this.workbookSettings = ws;
/*  290 */     this.drawingsModified = false;
/*  291 */     this.columnFormats = new TreeSet(new ColumnInfoComparator());
/*  292 */     this.hyperlinks = new ArrayList();
/*  293 */     this.mergedCells = new MergedCells(this);
/*  294 */     this.rowBreaks = new ArrayList();
/*  295 */     this.drawings = new ArrayList();
/*  296 */     this.images = new ArrayList();
/*  297 */     this.settings = new SheetSettings();
/*      */ 
/*      */     
/*  300 */     this.sheetWriter = new SheetWriter(this.outputFile, this, this.workbookSettings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Cell getCell(int column, int row) {
/*  314 */     return (Cell)getWritableCell(column, row);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableCell getWritableCell(int column, int row) {
/*      */     EmptyCell emptyCell;
/*  326 */     WritableCell c = null;
/*      */     
/*  328 */     if (row < this.rows.length && this.rows[row] != null)
/*      */     {
/*  330 */       c = this.rows[row].getCell(column);
/*      */     }
/*      */     
/*  333 */     if (c == null)
/*      */     {
/*  335 */       emptyCell = new EmptyCell(column, row);
/*      */     }
/*      */     
/*  338 */     return (WritableCell)emptyCell;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRows() {
/*  348 */     return this.numRows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getColumns() {
/*  358 */     return this.numColumns;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Cell findCell(String contents) {
/*  372 */     Cell cell = null;
/*  373 */     boolean found = false;
/*      */     
/*  375 */     for (int i = 0; i < getRows() && !found; i++) {
/*      */       
/*  377 */       Cell[] row = getRow(i);
/*  378 */       for (int j = 0; j < row.length && !found; j++) {
/*      */         
/*  380 */         if (row[j].getContents().equals(contents)) {
/*      */           
/*  382 */           cell = row[j];
/*  383 */           found = true;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  388 */     return cell;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LabelCell findLabelCell(String contents) {
/*  405 */     LabelCell cell = null;
/*  406 */     boolean found = false;
/*      */     
/*  408 */     for (int i = 0; i < getRows() && !found; i++) {
/*      */       
/*  410 */       Cell[] row = getRow(i);
/*  411 */       for (int j = 0; j < row.length && !found; j++) {
/*      */         
/*  413 */         if ((row[j].getType() == CellType.LABEL || row[j].getType() == CellType.STRING_FORMULA) && row[j].getContents().equals(contents)) {
/*      */ 
/*      */ 
/*      */           
/*  417 */           cell = (LabelCell)row[j];
/*  418 */           found = true;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  423 */     return cell;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Cell[] getRow(int row) {
/*  435 */     boolean found = false;
/*  436 */     int col = this.numColumns - 1;
/*  437 */     while (col >= 0 && !found) {
/*      */       
/*  439 */       if (getCell(col, row).getType() != CellType.EMPTY) {
/*      */         
/*  441 */         found = true;
/*      */         
/*      */         continue;
/*      */       } 
/*  445 */       col--;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  450 */     Cell[] cells = new Cell[col + 1];
/*      */     
/*  452 */     for (int i = 0; i <= col; i++)
/*      */     {
/*  454 */       cells[i] = getCell(i, row);
/*      */     }
/*  456 */     return cells;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Cell[] getColumn(int col) {
/*  468 */     boolean found = false;
/*  469 */     int row = this.numRows - 1;
/*      */     
/*  471 */     while (row >= 0 && !found) {
/*      */       
/*  473 */       if (getCell(col, row).getType() != CellType.EMPTY) {
/*      */         
/*  475 */         found = true;
/*      */         
/*      */         continue;
/*      */       } 
/*  479 */       row--;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  484 */     Cell[] cells = new Cell[row + 1];
/*      */     
/*  486 */     for (int i = 0; i <= row; i++)
/*      */     {
/*  488 */       cells[i] = getCell(col, i);
/*      */     }
/*  490 */     return cells;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  500 */     return this.name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertRow(int row) {
/*  511 */     if (row < 0 || row >= this.numRows) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  517 */     RowRecord[] oldRows = this.rows;
/*      */     
/*  519 */     if (this.numRows == this.rows.length) {
/*      */       
/*  521 */       this.rows = new RowRecord[oldRows.length + 10];
/*      */     }
/*      */     else {
/*      */       
/*  525 */       this.rows = new RowRecord[oldRows.length];
/*      */     } 
/*      */ 
/*      */     
/*  529 */     System.arraycopy(oldRows, 0, this.rows, 0, row);
/*      */ 
/*      */     
/*  532 */     System.arraycopy(oldRows, row, this.rows, row + 1, this.numRows - row);
/*      */ 
/*      */     
/*  535 */     for (int i = row + 1; i <= this.numRows; i++) {
/*      */       
/*  537 */       if (this.rows[i] != null)
/*      */       {
/*  539 */         this.rows[i].incrementRow();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  544 */     HyperlinkRecord hr = null;
/*  545 */     Iterator iterator = this.hyperlinks.iterator();
/*  546 */     while (iterator.hasNext()) {
/*      */       
/*  548 */       hr = iterator.next();
/*  549 */       hr.insertRow(row);
/*      */     } 
/*      */ 
/*      */     
/*  553 */     if (this.dataValidation != null)
/*      */     {
/*  555 */       this.dataValidation.insertRow(row);
/*      */     }
/*      */ 
/*      */     
/*  559 */     this.mergedCells.insertRow(row);
/*      */ 
/*      */     
/*  562 */     ArrayList newRowBreaks = new ArrayList();
/*  563 */     Iterator ri = this.rowBreaks.iterator();
/*  564 */     while (ri.hasNext()) {
/*      */       
/*  566 */       int val = ((Integer)ri.next()).intValue();
/*  567 */       if (val >= row)
/*      */       {
/*  569 */         val++;
/*      */       }
/*      */       
/*  572 */       newRowBreaks.add(new Integer(val));
/*      */     } 
/*  574 */     this.rowBreaks = newRowBreaks;
/*      */ 
/*      */     
/*  577 */     if (this.workbookSettings.getFormulaAdjust())
/*      */     {
/*  579 */       this.workbook.rowInserted(this, row);
/*      */     }
/*      */ 
/*      */     
/*  583 */     this.numRows++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertColumn(int col) {
/*  594 */     if (col < 0 || col >= this.numColumns) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  600 */     for (int i = 0; i < this.numRows; i++) {
/*      */       
/*  602 */       if (this.rows[i] != null)
/*      */       {
/*  604 */         this.rows[i].insertColumn(col);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  609 */     HyperlinkRecord hr = null;
/*  610 */     Iterator iterator = this.hyperlinks.iterator();
/*  611 */     while (iterator.hasNext()) {
/*      */       
/*  613 */       hr = iterator.next();
/*  614 */       hr.insertColumn(col);
/*      */     } 
/*      */ 
/*      */     
/*  618 */     iterator = this.columnFormats.iterator();
/*  619 */     while (iterator.hasNext()) {
/*      */       
/*  621 */       ColumnInfoRecord cir = (ColumnInfoRecord)iterator.next();
/*      */       
/*  623 */       if (cir.getColumn() >= col)
/*      */       {
/*  625 */         cir.incrementColumn();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  630 */     if (this.dataValidation != null)
/*      */     {
/*  632 */       this.dataValidation.insertColumn(col);
/*      */     }
/*      */ 
/*      */     
/*  636 */     this.mergedCells.insertColumn(col);
/*      */ 
/*      */     
/*  639 */     if (this.workbookSettings.getFormulaAdjust())
/*      */     {
/*  641 */       this.workbook.columnInserted(this, col);
/*      */     }
/*      */     
/*  644 */     this.numColumns++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeColumn(int col) {
/*  655 */     if (col < 0 || col >= this.numColumns) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  661 */     for (int i = 0; i < this.numRows; i++) {
/*      */       
/*  663 */       if (this.rows[i] != null)
/*      */       {
/*  665 */         this.rows[i].removeColumn(col);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  670 */     HyperlinkRecord hr = null;
/*  671 */     Iterator iterator = this.hyperlinks.iterator();
/*  672 */     while (iterator.hasNext()) {
/*      */       
/*  674 */       hr = iterator.next();
/*      */       
/*  676 */       if (hr.getColumn() == col && hr.getLastColumn() == col) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  681 */         this.hyperlinks.remove(this.hyperlinks.indexOf(hr));
/*      */         
/*      */         continue;
/*      */       } 
/*  685 */       hr.removeColumn(col);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  690 */     if (this.dataValidation != null)
/*      */     {
/*  692 */       this.dataValidation.removeColumn(col);
/*      */     }
/*      */ 
/*      */     
/*  696 */     this.mergedCells.removeColumn(col);
/*      */ 
/*      */     
/*  699 */     iterator = this.columnFormats.iterator();
/*  700 */     ColumnInfoRecord removeColumn = null;
/*  701 */     while (iterator.hasNext()) {
/*      */       
/*  703 */       ColumnInfoRecord cir = (ColumnInfoRecord)iterator.next();
/*      */       
/*  705 */       if (cir.getColumn() == col) {
/*      */         
/*  707 */         removeColumn = cir; continue;
/*      */       } 
/*  709 */       if (cir.getColumn() > col)
/*      */       {
/*  711 */         cir.decrementColumn();
/*      */       }
/*      */     } 
/*      */     
/*  715 */     if (removeColumn != null)
/*      */     {
/*  717 */       this.columnFormats.remove(removeColumn);
/*      */     }
/*      */ 
/*      */     
/*  721 */     if (this.workbookSettings.getFormulaAdjust())
/*      */     {
/*  723 */       this.workbook.columnRemoved(this, col);
/*      */     }
/*      */     
/*  726 */     this.numColumns--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeRow(int row) {
/*  737 */     if (row < 0 || row >= this.numRows) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  743 */     RowRecord[] oldRows = this.rows;
/*      */     
/*  745 */     this.rows = new RowRecord[oldRows.length];
/*      */ 
/*      */     
/*  748 */     System.arraycopy(oldRows, 0, this.rows, 0, row);
/*      */ 
/*      */     
/*  751 */     System.arraycopy(oldRows, row + 1, this.rows, row, this.numRows - row + 1);
/*      */ 
/*      */     
/*  754 */     for (int i = row; i < this.numRows; i++) {
/*      */       
/*  756 */       if (this.rows[i] != null)
/*      */       {
/*  758 */         this.rows[i].decrementRow();
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  763 */     HyperlinkRecord hr = null;
/*  764 */     Iterator iterator = this.hyperlinks.iterator();
/*  765 */     while (iterator.hasNext()) {
/*      */       
/*  767 */       hr = iterator.next();
/*      */       
/*  769 */       if (hr.getRow() == row && hr.getLastRow() == row) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  774 */         iterator.remove();
/*      */         
/*      */         continue;
/*      */       } 
/*  778 */       hr.removeRow(row);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  783 */     if (this.dataValidation != null)
/*      */     {
/*  785 */       this.dataValidation.removeRow(row);
/*      */     }
/*      */ 
/*      */     
/*  789 */     this.mergedCells.removeRow(row);
/*      */ 
/*      */     
/*  792 */     ArrayList newRowBreaks = new ArrayList();
/*  793 */     Iterator ri = this.rowBreaks.iterator();
/*  794 */     while (ri.hasNext()) {
/*      */       
/*  796 */       int val = ((Integer)ri.next()).intValue();
/*      */       
/*  798 */       if (val != row) {
/*      */         
/*  800 */         if (val > row)
/*      */         {
/*  802 */           val--;
/*      */         }
/*      */         
/*  805 */         newRowBreaks.add(new Integer(val));
/*      */       } 
/*      */     } 
/*      */     
/*  809 */     this.rowBreaks = newRowBreaks;
/*      */ 
/*      */     
/*  812 */     if (this.workbookSettings.getFormulaAdjust())
/*      */     {
/*  814 */       this.workbook.rowRemoved(this, row);
/*      */     }
/*      */ 
/*      */     
/*  818 */     this.numRows--;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addCell(WritableCell cell) throws WriteException, RowsExceededException {
/*  841 */     if (cell.getType() == CellType.EMPTY)
/*      */     {
/*  843 */       if (cell != null && cell.getCellFormat() == null) {
/*      */         return;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  851 */     CellValue cv = (CellValue)cell;
/*      */     
/*  853 */     if (cv.isReferenced())
/*      */     {
/*  855 */       throw new JxlWriteException(JxlWriteException.cellReferenced);
/*      */     }
/*      */     
/*  858 */     int row = cell.getRow();
/*  859 */     RowRecord rowrec = getRowRecord(row);
/*  860 */     rowrec.addCell(cv);
/*      */ 
/*      */     
/*  863 */     this.numRows = Math.max(row + 1, this.numRows);
/*  864 */     this.numColumns = Math.max(this.numColumns, rowrec.getMaxColumn());
/*      */ 
/*      */ 
/*      */     
/*  868 */     cv.setCellDetails(this.formatRecords, this.sharedStrings, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RowRecord getRowRecord(int row) throws RowsExceededException {
/*  881 */     if (row >= 65536)
/*      */     {
/*  883 */       throw new RowsExceededException();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  889 */     if (row >= this.rows.length) {
/*      */       
/*  891 */       RowRecord[] oldRows = this.rows;
/*  892 */       this.rows = new RowRecord[Math.max(oldRows.length + 10, row + 1)];
/*  893 */       System.arraycopy(oldRows, 0, this.rows, 0, oldRows.length);
/*  894 */       oldRows = null;
/*      */     } 
/*      */     
/*  897 */     RowRecord rowrec = this.rows[row];
/*      */     
/*  899 */     if (rowrec == null) {
/*      */       
/*  901 */       rowrec = new RowRecord(row);
/*  902 */       this.rows[row] = rowrec;
/*      */     } 
/*      */     
/*  905 */     return rowrec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   RowRecord getRowInfo(int r) {
/*  916 */     if (r < 0 || r > this.rows.length)
/*      */     {
/*  918 */       return null;
/*      */     }
/*      */     
/*  921 */     return this.rows[r];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ColumnInfoRecord getColumnInfo(int c) {
/*  932 */     Iterator i = this.columnFormats.iterator();
/*  933 */     ColumnInfoRecord cir = null;
/*  934 */     boolean stop = false;
/*      */     
/*  936 */     while (i.hasNext() && !stop) {
/*      */       
/*  938 */       cir = i.next();
/*      */       
/*  940 */       if (cir.getColumn() >= c)
/*      */       {
/*  942 */         stop = true;
/*      */       }
/*      */     } 
/*      */     
/*  946 */     if (!stop)
/*      */     {
/*  948 */       return null;
/*      */     }
/*      */     
/*  951 */     return (cir.getColumn() == c) ? cir : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String n) {
/*  961 */     this.name = n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHidden(boolean h) {
/*  972 */     this.settings.setHidden(h);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProtected(boolean prot) {
/*  983 */     this.settings.setProtected(prot);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSelected() {
/*  992 */     this.settings.setSelected();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isHidden() {
/* 1003 */     return this.settings.isHidden();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColumnView(int col, int width) {
/* 1014 */     CellView cv = new CellView();
/* 1015 */     cv.setSize(width * 256);
/* 1016 */     setColumnView(col, cv);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColumnView(int col, int width, CellFormat format) {
/* 1029 */     CellView cv = new CellView();
/* 1030 */     cv.setSize(width * 256);
/* 1031 */     cv.setFormat(format);
/* 1032 */     setColumnView(col, cv);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColumnView(int col, CellView view) {
/*      */     WritableCellFormat writableCellFormat;
/* 1043 */     XFRecord xfr = (XFRecord)view.getFormat();
/* 1044 */     if (xfr == null) {
/*      */       
/* 1046 */       Styles styles = getWorkbook().getStyles();
/* 1047 */       writableCellFormat = styles.getNormalStyle();
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 1052 */       if (!writableCellFormat.isInitialized())
/*      */       {
/* 1054 */         this.formatRecords.addStyle((XFRecord)writableCellFormat);
/*      */       }
/*      */       
/* 1057 */       int width = view.depUsed() ? (view.getDimension() * 256) : view.getSize();
/*      */       
/* 1059 */       ColumnInfoRecord cir = new ColumnInfoRecord(col, width, (XFRecord)writableCellFormat);
/*      */ 
/*      */ 
/*      */       
/* 1063 */       if (view.isHidden())
/*      */       {
/* 1065 */         cir.setHidden(true);
/*      */       }
/*      */       
/* 1068 */       if (!this.columnFormats.contains(cir))
/*      */       {
/* 1070 */         this.columnFormats.add(cir);
/*      */       }
/*      */       else
/*      */       {
/* 1074 */         boolean removed = this.columnFormats.remove(cir);
/* 1075 */         this.columnFormats.add(cir);
/*      */       }
/*      */     
/* 1078 */     } catch (NumFormatRecordsException e) {
/*      */       
/* 1080 */       logger.warn("Maximum number of format records exceeded.  Using default format.");
/*      */ 
/*      */       
/* 1083 */       ColumnInfoRecord cir = new ColumnInfoRecord(col, view.getDimension() * 256, (XFRecord)WritableWorkbook.NORMAL_STYLE);
/*      */ 
/*      */       
/* 1086 */       if (!this.columnFormats.contains(cir))
/*      */       {
/* 1088 */         this.columnFormats.add(cir);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowView(int row, int height) throws RowsExceededException {
/* 1103 */     setRowView(row, height, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowView(int row, boolean collapsed) throws RowsExceededException {
/* 1116 */     RowRecord rowrec = getRowRecord(row);
/* 1117 */     rowrec.setCollapsed(collapsed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowView(int row, int height, boolean collapsed) throws RowsExceededException {
/* 1133 */     RowRecord rowrec = getRowRecord(row);
/* 1134 */     rowrec.setRowHeight(height);
/* 1135 */     rowrec.setCollapsed(collapsed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write() throws IOException {
/* 1147 */     boolean dmod = this.drawingsModified;
/* 1148 */     if (this.workbook.getDrawingGroup() != null)
/*      */     {
/* 1150 */       dmod |= this.workbook.getDrawingGroup().hasDrawingsOmitted();
/*      */     }
/*      */     
/* 1153 */     this.sheetWriter.setWriteData(this.rows, this.rowBreaks, this.hyperlinks, this.mergedCells, this.columnFormats);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1158 */     this.sheetWriter.setDimensions(getRows(), getColumns());
/* 1159 */     this.sheetWriter.setSettings(this.settings);
/* 1160 */     this.sheetWriter.setPLS(this.plsRecord);
/* 1161 */     this.sheetWriter.setDrawings(this.drawings, dmod);
/* 1162 */     this.sheetWriter.setButtonPropertySet(this.buttonPropertySet);
/* 1163 */     this.sheetWriter.setDataValidation(this.dataValidation);
/*      */     
/* 1165 */     this.sheetWriter.write();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void copyCells(Sheet s) {
/* 1176 */     int cells = s.getRows();
/* 1177 */     Cell[] row = null;
/* 1178 */     Cell cell = null;
/* 1179 */     for (int i = 0; i < cells; i++) {
/*      */       
/* 1181 */       row = s.getRow(i);
/*      */       
/* 1183 */       for (int j = 0; j < row.length; j++) {
/*      */         
/* 1185 */         cell = row[j];
/* 1186 */         CellType ct = cell.getType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1195 */           if (ct == CellType.LABEL) {
/*      */             
/* 1197 */             Label l = new Label((LabelCell)cell);
/* 1198 */             addCell((WritableCell)l);
/*      */           }
/* 1200 */           else if (ct == CellType.NUMBER) {
/*      */             
/* 1202 */             Number n = new Number((NumberCell)cell);
/* 1203 */             addCell((WritableCell)n);
/*      */           }
/* 1205 */           else if (ct == CellType.DATE) {
/*      */             
/* 1207 */             DateTime dt = new DateTime((DateCell)cell);
/* 1208 */             addCell((WritableCell)dt);
/*      */           }
/* 1210 */           else if (ct == CellType.BOOLEAN) {
/*      */             
/* 1212 */             Boolean b = new Boolean((BooleanCell)cell);
/* 1213 */             addCell((WritableCell)b);
/*      */           }
/* 1215 */           else if (ct == CellType.NUMBER_FORMULA) {
/*      */             
/* 1217 */             ReadNumberFormulaRecord fr = new ReadNumberFormulaRecord((FormulaData)cell);
/*      */             
/* 1219 */             addCell(fr);
/*      */           }
/* 1221 */           else if (ct == CellType.STRING_FORMULA) {
/*      */             
/* 1223 */             ReadStringFormulaRecord fr = new ReadStringFormulaRecord((FormulaData)cell);
/*      */             
/* 1225 */             addCell(fr);
/*      */           }
/* 1227 */           else if (ct == CellType.BOOLEAN_FORMULA) {
/*      */             
/* 1229 */             ReadBooleanFormulaRecord fr = new ReadBooleanFormulaRecord((FormulaData)cell);
/*      */             
/* 1231 */             addCell(fr);
/*      */           }
/* 1233 */           else if (ct == CellType.DATE_FORMULA) {
/*      */             
/* 1235 */             ReadDateFormulaRecord fr = new ReadDateFormulaRecord((FormulaData)cell);
/*      */             
/* 1237 */             addCell(fr);
/*      */           }
/* 1239 */           else if (ct == CellType.FORMULA_ERROR) {
/*      */             
/* 1241 */             ReadErrorFormulaRecord fr = new ReadErrorFormulaRecord((FormulaData)cell);
/*      */             
/* 1243 */             addCell(fr);
/*      */           }
/* 1245 */           else if (ct == CellType.EMPTY) {
/*      */             
/* 1247 */             if (cell.getCellFormat() != null)
/*      */             {
/*      */ 
/*      */ 
/*      */               
/* 1252 */               Blank b = new Blank(cell);
/* 1253 */               addCell((WritableCell)b);
/*      */             }
/*      */           
/*      */           } 
/* 1257 */         } catch (WriteException e) {
/*      */           
/* 1259 */           Assert.verify(false);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void copy(Sheet s) {
/* 1273 */     this.settings = new SheetSettings(s.getSettings());
/*      */     
/* 1275 */     copyCells(s);
/*      */ 
/*      */     
/* 1278 */     SheetImpl si = (SheetImpl)s;
/* 1279 */     ColumnInfoRecord[] readCirs = si.getColumnInfos();
/*      */     
/* 1281 */     for (int i = 0; i < readCirs.length; i++) {
/*      */       
/* 1283 */       ColumnInfoRecord rcir = readCirs[i];
/* 1284 */       for (int n = rcir.getStartColumn(); n <= rcir.getEndColumn(); n++) {
/*      */         
/* 1286 */         ColumnInfoRecord cir = new ColumnInfoRecord(rcir, n, this.formatRecords);
/*      */         
/* 1288 */         cir.setHidden(rcir.getHidden());
/* 1289 */         this.columnFormats.add(cir);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1294 */     Hyperlink[] hls = s.getHyperlinks();
/* 1295 */     for (int j = 0; j < hls.length; j++) {
/*      */       
/* 1297 */       WritableHyperlink hr = new WritableHyperlink(hls[j], this);
/*      */       
/* 1299 */       this.hyperlinks.add(hr);
/*      */     } 
/*      */ 
/*      */     
/* 1303 */     Range[] merged = s.getMergedCells();
/*      */     
/* 1305 */     for (int k = 0; k < merged.length; k++)
/*      */     {
/* 1307 */       this.mergedCells.add((Range)new SheetRangeImpl((SheetRangeImpl)merged[k], (Sheet)this));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1313 */       RowRecord[] rowprops = si.getRowProperties();
/*      */       
/* 1315 */       for (int n = 0; n < rowprops.length; n++)
/*      */       {
/* 1317 */         RowRecord rr = getRowRecord(rowprops[n].getRowNumber());
/* 1318 */         XFRecord format = rowprops[n].hasDefaultFormat() ? this.formatRecords.getXFRecord(rowprops[n].getXFIndex()) : null;
/*      */         
/* 1320 */         rr.setRowDetails(rowprops[n].getRowHeight(), rowprops[n].matchesDefaultFontHeight(), rowprops[n].isCollapsed(), format);
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1326 */     catch (RowsExceededException e) {
/*      */ 
/*      */ 
/*      */       
/* 1330 */       Assert.verify(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1338 */     int[] rowbreaks = si.getRowPageBreaks();
/*      */     
/* 1340 */     if (rowbreaks != null)
/*      */     {
/* 1342 */       for (int n = 0; n < rowbreaks.length; n++)
/*      */       {
/* 1344 */         this.rowBreaks.add(new Integer(rowbreaks[n]));
/*      */       }
/*      */     }
/*      */ 
/*      */     
/* 1349 */     DataValidation rdv = si.getDataValidation();
/* 1350 */     if (rdv != null)
/*      */     {
/* 1352 */       this.dataValidation = new DataValidation(rdv, this.workbook, this.workbookSettings);
/*      */     }
/*      */ 
/*      */     
/* 1356 */     this.sheetWriter.setCharts(si.getCharts());
/*      */ 
/*      */     
/* 1359 */     DrawingGroupObject[] dr = si.getDrawings();
/* 1360 */     for (int m = 0; m < dr.length; m++) {
/*      */       
/* 1362 */       if (dr[m] instanceof Drawing) {
/*      */         
/* 1364 */         WritableImage wi = new WritableImage(dr[m], this.workbook.getDrawingGroup());
/*      */         
/* 1366 */         this.drawings.add(wi);
/* 1367 */         this.images.add(wi);
/*      */       }
/* 1369 */       else if (dr[m] instanceof Comment) {
/*      */         
/* 1371 */         Comment c = new Comment(dr[m], this.workbook.getDrawingGroup(), this.workbookSettings);
/*      */ 
/*      */ 
/*      */         
/* 1375 */         this.drawings.add(c);
/*      */ 
/*      */         
/* 1378 */         CellValue cv = (CellValue)getWritableCell(c.getColumn(), c.getRow());
/* 1379 */         Assert.verify((cv.getCellFeatures() != null));
/* 1380 */         cv.getWritableCellFeatures().setCommentDrawing(c);
/*      */       }
/* 1382 */       else if (dr[m] instanceof Button) {
/*      */         
/* 1384 */         Button b = new Button(dr[m], this.workbook.getDrawingGroup(), this.workbookSettings);
/*      */ 
/*      */ 
/*      */         
/* 1388 */         this.drawings.add(b);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1394 */     this.sheetWriter.setWorkspaceOptions(si.getWorkspaceOptions());
/*      */ 
/*      */ 
/*      */     
/* 1398 */     if (si.getSheetBof().isChart()) {
/*      */       
/* 1400 */       this.chartOnly = true;
/* 1401 */       this.sheetWriter.setChartOnly();
/*      */     } 
/*      */ 
/*      */     
/* 1405 */     if (si.getPLS() != null)
/*      */     {
/* 1407 */       if (si.getWorkbookBof().isBiff7()) {
/*      */         
/* 1409 */         logger.warn("Cannot copy Biff7 print settings record - ignoring");
/*      */       }
/*      */       else {
/*      */         
/* 1413 */         this.plsRecord = new PLSRecord(si.getPLS());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1418 */     if (si.getButtonPropertySet() != null)
/*      */     {
/* 1420 */       this.buttonPropertySet = new ButtonPropertySetRecord(si.getButtonPropertySet());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void copy(WritableSheet s) {
/* 1432 */     this.settings = new SheetSettings(s.getSettings());
/*      */     
/* 1434 */     copyCells((Sheet)s);
/*      */ 
/*      */     
/* 1437 */     this.columnFormats = ((WritableSheetImpl)s).columnFormats;
/*      */ 
/*      */     
/* 1440 */     Range[] merged = s.getMergedCells();
/*      */     
/* 1442 */     for (int i = 0; i < merged.length; i++)
/*      */     {
/* 1444 */       this.mergedCells.add((Range)new SheetRangeImpl((SheetRangeImpl)merged[i], (Sheet)this));
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1450 */       RowRecord[] copyRows = ((WritableSheetImpl)s).rows;
/* 1451 */       RowRecord row = null;
/* 1452 */       for (int k = 0; k < copyRows.length; k++)
/*      */       {
/* 1454 */         row = copyRows[k];
/*      */         
/* 1456 */         if (row != null && (!row.isDefaultHeight() || row.isCollapsed()))
/*      */         {
/*      */ 
/*      */           
/* 1460 */           RowRecord rr = getRowRecord(k);
/* 1461 */           rr.setRowDetails(row.getRowHeight(), row.matchesDefaultFontHeight(), row.isCollapsed(), row.getStyle());
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1468 */     catch (RowsExceededException e) {
/*      */ 
/*      */ 
/*      */       
/* 1472 */       Assert.verify(false);
/*      */     } 
/*      */ 
/*      */     
/* 1476 */     WritableSheetImpl si = (WritableSheetImpl)s;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1482 */     this.rowBreaks = new ArrayList(si.rowBreaks);
/*      */ 
/*      */     
/* 1485 */     DataValidation rdv = si.dataValidation;
/* 1486 */     if (rdv != null)
/*      */     {
/* 1488 */       this.dataValidation = new DataValidation(rdv, this.workbook, this.workbookSettings);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1494 */     this.sheetWriter.setCharts(si.getCharts());
/*      */ 
/*      */     
/* 1497 */     DrawingGroupObject[] dr = si.getDrawings();
/* 1498 */     for (int j = 0; j < dr.length; j++) {
/*      */       
/* 1500 */       if (dr[j] instanceof Drawing) {
/*      */         
/* 1502 */         WritableImage wi = new WritableImage(dr[j], this.workbook.getDrawingGroup());
/*      */         
/* 1504 */         this.drawings.add(wi);
/* 1505 */         this.images.add(wi);
/*      */       }
/* 1507 */       else if (dr[j] instanceof Comment) {
/*      */         
/* 1509 */         Comment c = new Comment(dr[j], this.workbook.getDrawingGroup(), this.workbookSettings);
/*      */ 
/*      */ 
/*      */         
/* 1513 */         this.drawings.add(c);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1518 */     this.sheetWriter.setWorkspaceOptions(si.getWorkspaceOptions());
/*      */ 
/*      */     
/* 1521 */     if (si.plsRecord != null)
/*      */     {
/* 1523 */       this.plsRecord = new PLSRecord(si.plsRecord);
/*      */     }
/*      */ 
/*      */     
/* 1527 */     if (si.buttonPropertySet != null)
/*      */     {
/* 1529 */       this.buttonPropertySet = new ButtonPropertySetRecord(si.buttonPropertySet);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final HeaderRecord getHeader() {
/* 1540 */     return this.sheetWriter.getHeader();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final FooterRecord getFooter() {
/* 1550 */     return this.sheetWriter.getFooter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isProtected() {
/* 1560 */     return this.settings.isProtected();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Hyperlink[] getHyperlinks() {
/* 1570 */     Hyperlink[] hl = new Hyperlink[this.hyperlinks.size()];
/*      */     
/* 1572 */     for (int i = 0; i < this.hyperlinks.size(); i++)
/*      */     {
/* 1574 */       hl[i] = this.hyperlinks.get(i);
/*      */     }
/*      */     
/* 1577 */     return hl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Range[] getMergedCells() {
/* 1587 */     return this.mergedCells.getMergedCells();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableHyperlink[] getWritableHyperlinks() {
/* 1597 */     WritableHyperlink[] hl = new WritableHyperlink[this.hyperlinks.size()];
/*      */     
/* 1599 */     for (int i = 0; i < this.hyperlinks.size(); i++)
/*      */     {
/* 1601 */       hl[i] = this.hyperlinks.get(i);
/*      */     }
/*      */     
/* 1604 */     return hl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeHyperlink(WritableHyperlink h) {
/* 1621 */     removeHyperlink(h, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeHyperlink(WritableHyperlink h, boolean preserveLabel) {
/* 1641 */     this.hyperlinks.remove(this.hyperlinks.indexOf(h));
/*      */     
/* 1643 */     if (!preserveLabel) {
/*      */ 
/*      */ 
/*      */       
/* 1647 */       Assert.verify((this.rows.length > h.getRow() && this.rows[h.getRow()] != null));
/* 1648 */       this.rows[h.getRow()].removeCell(h.getColumn());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addHyperlink(WritableHyperlink h) throws WriteException, RowsExceededException {
/* 1663 */     Cell c = getCell(h.getColumn(), h.getRow());
/*      */     
/* 1665 */     String contents = null;
/* 1666 */     if (h.isFile() || h.isUNC()) {
/*      */       
/* 1668 */       String cnts = h.getContents();
/* 1669 */       if (cnts == null)
/*      */       {
/* 1671 */         contents = h.getFile().getPath();
/*      */       }
/*      */       else
/*      */       {
/* 1675 */         contents = cnts;
/*      */       }
/*      */     
/* 1678 */     } else if (h.isURL()) {
/*      */       
/* 1680 */       String cnts = h.getContents();
/* 1681 */       if (cnts == null)
/*      */       {
/* 1683 */         contents = h.getURL().toString();
/*      */       }
/*      */       else
/*      */       {
/* 1687 */         contents = cnts;
/*      */       }
/*      */     
/* 1690 */     } else if (h.isLocation()) {
/*      */       
/* 1692 */       contents = h.getContents();
/*      */     } 
/*      */     
/* 1695 */     if (c.getType() == CellType.LABEL) {
/*      */       
/* 1697 */       Label l = (Label)c;
/* 1698 */       l.setString(contents);
/* 1699 */       l.setCellFormat((CellFormat)WritableWorkbook.HYPERLINK_STYLE);
/*      */     }
/*      */     else {
/*      */       
/* 1703 */       Label l = new Label(h.getColumn(), h.getRow(), contents, (CellFormat)WritableWorkbook.HYPERLINK_STYLE);
/*      */       
/* 1705 */       addCell((WritableCell)l);
/*      */     } 
/*      */ 
/*      */     
/* 1709 */     for (int i = h.getRow(); i <= h.getLastRow(); i++) {
/*      */       
/* 1711 */       for (int j = h.getColumn(); j <= h.getLastColumn(); j++) {
/*      */         
/* 1713 */         if (i != h.getRow() && j != h.getColumn())
/*      */         {
/*      */           
/* 1716 */           if (this.rows[i] != null)
/*      */           {
/* 1718 */             this.rows[i].removeCell(j);
/*      */           }
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1724 */     h.initialize(this);
/* 1725 */     this.hyperlinks.add(h);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Range mergeCells(int col1, int row1, int col2, int row2) throws WriteException, RowsExceededException {
/* 1744 */     if (col2 < col1 || row2 < row1)
/*      */     {
/* 1746 */       logger.warn("Cannot merge cells - top left and bottom right incorrectly specified");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1751 */     if (col2 >= this.numColumns || row2 >= this.numRows)
/*      */     {
/* 1753 */       addCell((WritableCell)new Blank(col2, row2));
/*      */     }
/*      */     
/* 1756 */     SheetRangeImpl range = new SheetRangeImpl((Sheet)this, col1, row1, col2, row2);
/* 1757 */     this.mergedCells.add((Range)range);
/*      */     
/* 1759 */     return (Range)range;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unmergeCells(Range r) {
/* 1770 */     this.mergedCells.unmergeCells(r);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHeader(String l, String c, String r) {
/* 1783 */     HeaderFooter header = new HeaderFooter();
/* 1784 */     header.getLeft().append(l);
/* 1785 */     header.getCentre().append(c);
/* 1786 */     header.getRight().append(r);
/* 1787 */     this.settings.setHeader(header);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFooter(String l, String c, String r) {
/* 1800 */     HeaderFooter footer = new HeaderFooter();
/* 1801 */     footer.getLeft().append(l);
/* 1802 */     footer.getCentre().append(c);
/* 1803 */     footer.getRight().append(r);
/* 1804 */     this.settings.setFooter(footer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPageSetup(PageOrientation p) {
/* 1815 */     this.settings.setOrientation(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPageSetup(PageOrientation p, double hm, double fm) {
/* 1828 */     this.settings.setOrientation(p);
/* 1829 */     this.settings.setHeaderMargin(hm);
/* 1830 */     this.settings.setFooterMargin(fm);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPageSetup(PageOrientation p, PaperSize ps, double hm, double fm) {
/* 1845 */     this.settings.setPaperSize(ps);
/* 1846 */     this.settings.setOrientation(p);
/* 1847 */     this.settings.setHeaderMargin(hm);
/* 1848 */     this.settings.setFooterMargin(fm);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SheetSettings getSettings() {
/* 1858 */     return this.settings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   WorkbookSettings getWorkbookSettings() {
/* 1866 */     return this.workbookSettings;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addRowPageBreak(int row) {
/* 1877 */     Iterator i = this.rowBreaks.iterator();
/* 1878 */     boolean found = false;
/*      */     
/* 1880 */     while (i.hasNext() && !found) {
/*      */       
/* 1882 */       if (((Integer)i.next()).intValue() == row)
/*      */       {
/* 1884 */         found = true;
/*      */       }
/*      */     } 
/*      */     
/* 1888 */     if (!found)
/*      */     {
/* 1890 */       this.rowBreaks.add(new Integer(row));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Chart[] getCharts() {
/* 1901 */     return this.sheetWriter.getCharts();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private DrawingGroupObject[] getDrawings() {
/* 1911 */     DrawingGroupObject[] dr = new DrawingGroupObject[this.drawings.size()];
/* 1912 */     dr = (DrawingGroupObject[])this.drawings.toArray((Object[])dr);
/* 1913 */     return dr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void checkMergedBorders() {
/* 1924 */     this.sheetWriter.setWriteData(this.rows, this.rowBreaks, this.hyperlinks, this.mergedCells, this.columnFormats);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1929 */     this.sheetWriter.setDimensions(getRows(), getColumns());
/* 1930 */     this.sheetWriter.checkMergedBorders();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private WorkspaceInformationRecord getWorkspaceOptions() {
/* 1940 */     return this.sheetWriter.getWorkspaceOptions();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void rationalize(IndexMapping xfMapping, IndexMapping fontMapping, IndexMapping formatMapping) {
/* 1954 */     for (Iterator iterator = this.columnFormats.iterator(); iterator.hasNext(); ) {
/*      */       
/* 1956 */       ColumnInfoRecord cir = iterator.next();
/* 1957 */       cir.rationalize(xfMapping);
/*      */     } 
/*      */ 
/*      */     
/* 1961 */     for (int i = 0; i < this.rows.length; i++) {
/*      */       
/* 1963 */       if (this.rows[i] != null)
/*      */       {
/* 1965 */         this.rows[i].rationalize(xfMapping);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1970 */     Chart[] charts = getCharts();
/* 1971 */     for (int c = 0; c < charts.length; c++)
/*      */     {
/* 1973 */       charts[c].rationalize(xfMapping, fontMapping, formatMapping);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   WritableWorkbookImpl getWorkbook() {
/* 1983 */     return this.workbook;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CellFormat getColumnFormat(int col) {
/* 1995 */     return getColumnView(col).getFormat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getColumnWidth(int col) {
/* 2008 */     return getColumnView(col).getDimension();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRowHeight(int row) {
/* 2021 */     return getRowView(row).getDimension();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isChartOnly() {
/* 2031 */     return this.chartOnly;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CellView getRowView(int row) {
/* 2043 */     CellView cv = new CellView();
/*      */ 
/*      */     
/*      */     try {
/* 2047 */       RowRecord rr = getRowRecord(row);
/*      */       
/* 2049 */       if (rr == null || rr.isDefaultHeight()) {
/*      */         
/* 2051 */         cv.setDimension(this.settings.getDefaultRowHeight());
/* 2052 */         cv.setSize(this.settings.getDefaultRowHeight());
/*      */       }
/* 2054 */       else if (rr.isCollapsed()) {
/*      */         
/* 2056 */         cv.setHidden(true);
/*      */       }
/*      */       else {
/*      */         
/* 2060 */         cv.setDimension(rr.getRowHeight());
/* 2061 */         cv.setSize(rr.getRowHeight());
/*      */       } 
/* 2063 */       return cv;
/*      */     }
/* 2065 */     catch (RowsExceededException e) {
/*      */ 
/*      */       
/* 2068 */       cv.setDimension(this.settings.getDefaultRowHeight());
/* 2069 */       cv.setSize(this.settings.getDefaultRowHeight());
/* 2070 */       return cv;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CellView getColumnView(int col) {
/* 2083 */     ColumnInfoRecord cir = getColumnInfo(col);
/* 2084 */     CellView cv = new CellView();
/*      */     
/* 2086 */     if (cir != null) {
/*      */       
/* 2088 */       cv.setDimension(cir.getWidth() / 256);
/* 2089 */       cv.setSize(cir.getWidth());
/* 2090 */       cv.setHidden(cir.getHidden());
/* 2091 */       cv.setFormat((CellFormat)cir.getCellFormat());
/*      */     }
/*      */     else {
/*      */       
/* 2095 */       cv.setDimension(this.settings.getDefaultColumnWidth() / 256);
/* 2096 */       cv.setSize(this.settings.getDefaultColumnWidth());
/*      */     } 
/*      */     
/* 2099 */     return cv;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addImage(WritableImage image) {
/* 2109 */     boolean supported = false;
/* 2110 */     File imageFile = image.getImageFile();
/* 2111 */     String fileType = "?";
/*      */     
/* 2113 */     if (imageFile != null) {
/*      */ 
/*      */       
/* 2116 */       String fileName = imageFile.getName();
/* 2117 */       int fileTypeIndex = fileName.lastIndexOf('.');
/* 2118 */       fileType = (fileTypeIndex != -1) ? fileName.substring(fileTypeIndex + 1) : "";
/*      */ 
/*      */       
/* 2121 */       for (int i = 0; i < imageTypes.length && !supported; i++)
/*      */       {
/* 2123 */         if (fileType.equalsIgnoreCase(imageTypes[i]))
/*      */         {
/* 2125 */           supported = true;
/*      */         }
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 2131 */       supported = true;
/*      */     } 
/*      */     
/* 2134 */     if (supported) {
/*      */       
/* 2136 */       this.workbook.addDrawing((DrawingGroupObject)image);
/* 2137 */       this.drawings.add(image);
/* 2138 */       this.images.add(image);
/*      */     }
/*      */     else {
/*      */       
/* 2142 */       StringBuffer message = new StringBuffer("Image type ");
/* 2143 */       message.append(fileType);
/* 2144 */       message.append(" not supported.  Supported types are ");
/* 2145 */       message.append(imageTypes[0]);
/* 2146 */       for (int i = 1; i < imageTypes.length; i++) {
/*      */         
/* 2148 */         message.append(", ");
/* 2149 */         message.append(imageTypes[i]);
/*      */       } 
/* 2151 */       logger.warn(message.toString());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumberOfImages() {
/* 2162 */     return this.images.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public WritableImage getImage(int i) {
/* 2173 */     return this.images.get(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Image getDrawing(int i) {
/* 2184 */     return this.images.get(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeImage(WritableImage wi) {
/* 2195 */     boolean removed = this.drawings.remove(wi);
/* 2196 */     this.images.remove(wi);
/* 2197 */     this.drawingsModified = true;
/* 2198 */     this.workbook.removeDrawing((Drawing)wi);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String validateName(String n) {
/* 2206 */     if (n.length() > 31) {
/*      */       
/* 2208 */       logger.warn("Sheet name " + n + " too long - truncating");
/* 2209 */       n = n.substring(0, 31);
/*      */     } 
/*      */     
/* 2212 */     if (n.charAt(0) == '\'') {
/*      */       
/* 2214 */       logger.warn("Sheet naming cannot start with ' - removing");
/* 2215 */       n = n.substring(1);
/*      */     } 
/*      */     
/* 2218 */     for (int i = 0; i < illegalSheetNameCharacters.length; i++) {
/*      */       
/* 2220 */       String newname = n.replace(illegalSheetNameCharacters[i], '@');
/* 2221 */       if (n != newname)
/*      */       {
/* 2223 */         logger.warn(illegalSheetNameCharacters[i] + " is not a valid character within a sheet name - replacing");
/*      */       }
/*      */       
/* 2226 */       n = newname;
/*      */     } 
/*      */     
/* 2229 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void addDrawing(DrawingGroupObject o) {
/* 2239 */     this.drawings.add(o);
/* 2240 */     Assert.verify(!(o instanceof Drawing));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void removeDrawing(DrawingGroupObject o) {
/* 2250 */     int origSize = this.drawings.size();
/* 2251 */     this.drawings.remove(o);
/* 2252 */     int newSize = this.drawings.size();
/* 2253 */     this.drawingsModified = true;
/* 2254 */     Assert.verify((newSize == origSize - 1));
/*      */   }
/*      */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\WritableSheetImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
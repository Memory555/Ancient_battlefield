/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class LeftMarginRecord
/*    */   extends MarginRecord
/*    */ {
/*    */   LeftMarginRecord(double v) {
/* 31 */     super(Type.LEFTMARGIN, v);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\LeftMarginRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ObjectProtectRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean protection;
/*    */   private byte[] data;
/*    */   
/*    */   public ObjectProtectRecord(boolean prot) {
/* 47 */     super(Type.OBJPROTECT);
/*    */     
/* 49 */     this.protection = prot;
/*    */     
/* 51 */     this.data = new byte[2];
/*    */     
/* 53 */     if (this.protection)
/*    */     {
/* 55 */       IntegerHelper.getTwoBytes(1, this.data, 0);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 66 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ObjectProtectRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
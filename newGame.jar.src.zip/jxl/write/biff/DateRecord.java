/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.DateCell;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.DateFormats;
/*     */ import jxl.write.WritableCellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DateRecord
/*     */   extends CellValue
/*     */ {
/*  45 */   private static Logger logger = Logger.getLogger(DateRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double value;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Date date;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean time;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int utcOffsetDays = 25569;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final long msInADay = 86400000L;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   static final WritableCellFormat defaultDateFormat = new WritableCellFormat(DateFormats.DEFAULT);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int nonLeapDay = 61;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final class GMTDate {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DateRecord(int c, int r, Date d) {
/* 104 */     this(c, r, d, (CellFormat)defaultDateFormat, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DateRecord(int c, int r, Date d, GMTDate a) {
/* 117 */     this(c, r, d, (CellFormat)defaultDateFormat, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DateRecord(int c, int r, Date d, CellFormat st) {
/* 130 */     super(Type.NUMBER, c, r, st);
/* 131 */     this.date = d;
/* 132 */     calculateValue(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DateRecord(int c, int r, Date d, CellFormat st, GMTDate a) {
/* 146 */     super(Type.NUMBER, c, r, st);
/* 147 */     this.date = d;
/* 148 */     calculateValue(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DateRecord(int c, int r, Date d, CellFormat st, boolean tim) {
/* 162 */     super(Type.NUMBER, c, r, st);
/* 163 */     this.date = d;
/* 164 */     this.time = tim;
/* 165 */     calculateValue(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DateRecord(DateCell dc) {
/* 175 */     super(Type.NUMBER, (Cell)dc);
/* 176 */     this.date = dc.getDate();
/* 177 */     this.time = dc.isTime();
/* 178 */     calculateValue(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DateRecord(int c, int r, DateRecord dr) {
/* 190 */     super(Type.NUMBER, c, r, dr);
/* 191 */     this.value = dr.value;
/* 192 */     this.time = dr.time;
/* 193 */     this.date = dr.date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void calculateValue(boolean adjust) {
/* 206 */     long zoneOffset = 0L;
/* 207 */     long dstOffset = 0L;
/*     */ 
/*     */ 
/*     */     
/* 211 */     if (adjust) {
/*     */ 
/*     */       
/* 214 */       Calendar cal = Calendar.getInstance();
/* 215 */       cal.setTime(this.date);
/*     */       
/* 217 */       zoneOffset = cal.get(15);
/* 218 */       dstOffset = cal.get(16);
/*     */     } 
/*     */     
/* 221 */     long utcValue = this.date.getTime() + zoneOffset + dstOffset;
/*     */ 
/*     */ 
/*     */     
/* 225 */     double utcDays = utcValue / 8.64E7D;
/*     */ 
/*     */     
/* 228 */     this.value = utcDays + 25569.0D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 234 */     if (!this.time && this.value < 61.0D)
/*     */     {
/* 236 */       this.value--;
/*     */     }
/*     */ 
/*     */     
/* 240 */     if (this.time)
/*     */     {
/* 242 */       this.value -= (int)this.value;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 253 */     return CellType.DATE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 263 */     byte[] celldata = super.getData();
/* 264 */     byte[] data = new byte[celldata.length + 8];
/* 265 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 266 */     DoubleHelper.getIEEEBytes(this.value, data, celldata.length);
/*     */     
/* 268 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 280 */     return this.date.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDate(Date d) {
/* 290 */     this.date = d;
/* 291 */     calculateValue(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDate(Date d, GMTDate a) {
/* 302 */     this.date = d;
/* 303 */     calculateValue(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Date getDate() {
/* 314 */     return this.date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTime() {
/* 326 */     return this.time;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateFormat getDateFormat() {
/* 339 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\DateRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.LabelCell;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LabelRecord
/*     */   extends CellValue
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(LabelRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String contents;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SharedStrings sharedStrings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LabelRecord(int c, int r, String cont) {
/*  68 */     super(Type.LABELSST, c, r);
/*  69 */     this.contents = cont;
/*  70 */     if (this.contents == null)
/*     */     {
/*  72 */       this.contents = "";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LabelRecord(int c, int r, String cont, CellFormat st) {
/*  87 */     super(Type.LABELSST, c, r, st);
/*  88 */     this.contents = cont;
/*     */     
/*  90 */     if (this.contents == null)
/*     */     {
/*  92 */       this.contents = "";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LabelRecord(int c, int r, LabelRecord lr) {
/* 106 */     super(Type.LABELSST, c, r, lr);
/* 107 */     this.contents = lr.contents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LabelRecord(LabelCell lc) {
/* 118 */     super(Type.LABELSST, (Cell)lc);
/* 119 */     this.contents = lc.getString();
/* 120 */     if (this.contents == null)
/*     */     {
/* 122 */       this.contents = "";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 133 */     return CellType.LABEL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 143 */     byte[] celldata = super.getData();
/* 144 */     byte[] data = new byte[celldata.length + 4];
/* 145 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 146 */     IntegerHelper.getFourBytes(this.index, data, celldata.length);
/*     */     
/* 148 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 160 */     return this.contents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString() {
/* 171 */     return this.contents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setString(String s) {
/* 181 */     if (s == null)
/*     */     {
/* 183 */       s = "";
/*     */     }
/*     */     
/* 186 */     this.contents = s;
/*     */ 
/*     */ 
/*     */     
/* 190 */     if (!isReferenced()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 195 */     Assert.verify((this.sharedStrings != null));
/*     */ 
/*     */     
/* 198 */     this.index = this.sharedStrings.getIndex(this.contents);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     this.contents = this.sharedStrings.get(this.index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setCellDetails(FormattingRecords fr, SharedStrings ss, WritableSheetImpl s) {
/* 218 */     super.setCellDetails(fr, ss, s);
/*     */     
/* 220 */     this.sharedStrings = ss;
/*     */     
/* 222 */     this.index = this.sharedStrings.getIndex(this.contents);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 227 */     this.contents = this.sharedStrings.get(this.index);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\LabelRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
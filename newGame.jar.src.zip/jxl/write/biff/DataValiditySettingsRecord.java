/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.DVParser;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DataValiditySettingsRecord
/*     */   extends WritableRecordData
/*     */ {
/*  38 */   private static final Logger logger = Logger.getLogger(DataValiditySettingsRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DVParser dvParser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WritableWorkbookImpl workbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings workbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DataValiditySettingsRecord(jxl.read.biff.DataValiditySettingsRecord dvsr, WritableWorkbookImpl w, WorkbookSettings ws) {
/*  70 */     super(Type.DV);
/*  71 */     this.workbook = w;
/*  72 */     this.workbookSettings = ws;
/*     */ 
/*     */     
/*  75 */     this.data = dvsr.getData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DataValiditySettingsRecord(DataValiditySettingsRecord dvsr, WritableWorkbookImpl w, WorkbookSettings ws) {
/*  87 */     super(Type.DV);
/*  88 */     this.workbook = w;
/*  89 */     this.workbookSettings = ws;
/*     */     
/*  91 */     this.data = new byte[dvsr.data.length];
/*  92 */     System.arraycopy(dvsr.data, 0, this.data, 0, this.data.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize() {
/*     */     try {
/* 102 */       if (this.dvParser == null)
/*     */       {
/* 104 */         this.dvParser = new DVParser(this.data, this.workbook, this.workbook, this.workbookSettings);
/*     */       }
/*     */     }
/* 107 */     catch (FormulaException e) {
/*     */       
/* 109 */       logger.warn("Cannot read drop down range " + e.getMessage());
/* 110 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 120 */     if (this.dvParser == null)
/*     */     {
/* 122 */       return this.data;
/*     */     }
/*     */     
/* 125 */     return this.dvParser.getData();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertRow(int row) {
/* 135 */     if (this.dvParser == null)
/*     */     {
/* 137 */       initialize();
/*     */     }
/*     */     
/* 140 */     this.dvParser.insertRow(row);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRow(int row) {
/* 150 */     if (this.dvParser == null)
/*     */     {
/* 152 */       initialize();
/*     */     }
/*     */     
/* 155 */     this.dvParser.removeRow(row);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertColumn(int col) {
/* 165 */     if (this.dvParser == null)
/*     */     {
/* 167 */       initialize();
/*     */     }
/*     */     
/* 170 */     this.dvParser.insertColumn(col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeColumn(int col) {
/* 180 */     if (this.dvParser == null)
/*     */     {
/* 182 */       initialize();
/*     */     }
/*     */     
/* 185 */     this.dvParser.removeColumn(col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstColumn() {
/* 195 */     if (this.dvParser == null)
/*     */     {
/* 197 */       initialize();
/*     */     }
/*     */     
/* 200 */     return this.dvParser.getFirstColumn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastColumn() {
/* 210 */     if (this.dvParser == null)
/*     */     {
/* 212 */       initialize();
/*     */     }
/*     */     
/* 215 */     return this.dvParser.getLastColumn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFirstRow() {
/* 225 */     if (this.dvParser == null)
/*     */     {
/* 227 */       initialize();
/*     */     }
/*     */     
/* 230 */     return this.dvParser.getFirstRow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLastRow() {
/* 240 */     if (this.dvParser == null)
/*     */     {
/* 242 */       initialize();
/*     */     }
/*     */     
/* 245 */     return this.dvParser.getLastRow();
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\DataValiditySettingsRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
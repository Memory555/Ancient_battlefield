/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.read.biff.DataValiditySettingsRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataValidation
/*     */ {
/*  39 */   private static final Logger logger = Logger.getLogger(DataValidation.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataValidityListRecord validityList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList validitySettings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int pos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WritableWorkbookImpl workbook;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings workbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DataValidation(jxl.read.biff.DataValidation dv, WritableWorkbookImpl w, WorkbookSettings ws) {
/*  75 */     this.workbook = w;
/*  76 */     this.workbookSettings = ws;
/*  77 */     this.validityList = new DataValidityListRecord(dv.getDataValidityList());
/*     */     
/*  79 */     DataValiditySettingsRecord[] settings = dv.getDataValiditySettings();
/*     */ 
/*     */     
/*  82 */     this.validitySettings = new ArrayList(settings.length);
/*  83 */     for (int i = 0; i < settings.length; i++)
/*     */     {
/*  85 */       this.validitySettings.add(new DataValiditySettingsRecord(settings[i], this.workbook, this.workbookSettings));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DataValidation(DataValidation dv, WritableWorkbookImpl w, WorkbookSettings ws) {
/* 101 */     this.workbook = w;
/* 102 */     this.workbookSettings = ws;
/* 103 */     this.validityList = new DataValidityListRecord(dv.validityList);
/*     */     
/* 105 */     this.validitySettings = new ArrayList(dv.validitySettings.size());
/*     */     
/* 107 */     for (Iterator i = dv.validitySettings.iterator(); i.hasNext(); ) {
/*     */       
/* 109 */       DataValiditySettingsRecord dvsr = i.next();
/* 110 */       this.validitySettings.add(new DataValiditySettingsRecord(dvsr, this.workbook, this.workbookSettings));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(File outputFile) throws IOException {
/* 126 */     if (!this.validityList.hasDVRecords()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 131 */     outputFile.write((ByteData)this.validityList);
/*     */     
/* 133 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext(); ) {
/*     */       
/* 135 */       DataValiditySettingsRecord dv = i.next();
/* 136 */       outputFile.write((ByteData)dv);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertRow(int row) {
/* 147 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext(); ) {
/*     */       
/* 149 */       DataValiditySettingsRecord dv = i.next();
/* 150 */       dv.insertRow(row);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeRow(int row) {
/* 161 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext(); ) {
/*     */       
/* 163 */       DataValiditySettingsRecord dv = i.next();
/*     */       
/* 165 */       if (dv.getFirstRow() == row && dv.getLastRow() == row) {
/*     */         
/* 167 */         i.remove();
/* 168 */         this.validityList.dvRemoved();
/*     */         
/*     */         continue;
/*     */       } 
/* 172 */       dv.removeRow(row);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertColumn(int col) {
/* 184 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext(); ) {
/*     */       
/* 186 */       DataValiditySettingsRecord dv = i.next();
/* 187 */       dv.insertColumn(col);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeColumn(int col) {
/* 198 */     for (Iterator i = this.validitySettings.iterator(); i.hasNext(); ) {
/*     */       
/* 200 */       DataValiditySettingsRecord dv = i.next();
/*     */       
/* 202 */       if (dv.getFirstColumn() == col && dv.getLastColumn() == col) {
/*     */         
/* 204 */         i.remove();
/* 205 */         this.validityList.dvRemoved();
/*     */         
/*     */         continue;
/*     */       } 
/* 209 */       dv.removeColumn(col);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\DataValidation.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
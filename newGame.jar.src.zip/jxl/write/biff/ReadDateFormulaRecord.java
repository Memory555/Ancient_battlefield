/*    */ package jxl.write.biff;
/*    */ 
/*    */ import java.text.DateFormat;
/*    */ import java.util.Date;
/*    */ import jxl.DateFormulaCell;
/*    */ import jxl.biff.FormulaData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReadDateFormulaRecord
/*    */   extends ReadFormulaRecord
/*    */   implements DateFormulaCell
/*    */ {
/*    */   public ReadDateFormulaRecord(FormulaData f) {
/* 41 */     super(f);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Date getDate() {
/* 51 */     return ((DateFormulaCell)getReadFormula()).getDate();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isTime() {
/* 62 */     return ((DateFormulaCell)getReadFormula()).isTime();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DateFormat getDateFormat() {
/* 74 */     return ((DateFormulaCell)getReadFormula()).getDateFormat();
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ReadDateFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
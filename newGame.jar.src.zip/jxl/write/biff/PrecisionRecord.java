/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class PrecisionRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean asDisplayed;
/*    */   private byte[] data;
/*    */   
/*    */   public PrecisionRecord(boolean disp) {
/* 49 */     super(Type.PRECISION);
/*    */     
/* 51 */     this.asDisplayed = disp;
/* 52 */     this.data = new byte[2];
/*    */     
/* 54 */     if (!this.asDisplayed)
/*    */     {
/* 56 */       IntegerHelper.getTwoBytes(1, this.data, 0);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 67 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\PrecisionRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
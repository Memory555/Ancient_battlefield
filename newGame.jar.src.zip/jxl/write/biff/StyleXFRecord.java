/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.DisplayFormat;
/*    */ import jxl.biff.FontRecord;
/*    */ import jxl.biff.XFRecord;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StyleXFRecord
/*    */   extends XFRecord
/*    */ {
/*    */   public StyleXFRecord(FontRecord fnt, DisplayFormat form) {
/* 41 */     super(fnt, form);
/*    */     
/* 43 */     setXFDetails(XFRecord.style, 65520);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void setCellOptions(int opt) {
/* 55 */     setXFCellOptions(opt);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setLocked(boolean l) {
/* 66 */     setXFLocked(l);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\StyleXFRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
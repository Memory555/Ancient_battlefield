/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.FontRecord;
/*     */ import jxl.format.Font;
/*     */ import jxl.write.WriteException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WritableFontRecord
/*     */   extends FontRecord
/*     */ {
/*     */   protected WritableFontRecord(String fn, int ps, int bold, boolean it, int us, int ci, int ss) {
/*  46 */     super(fn, ps, bold, it, us, ci, ss);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WritableFontRecord(Font f) {
/*  56 */     super(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setPointSize(int pointSize) throws WriteException {
/*  68 */     if (isInitialized())
/*     */     {
/*  70 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/*  73 */     setFontPointSize(pointSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setBoldStyle(int boldStyle) throws WriteException {
/*  84 */     if (isInitialized())
/*     */     {
/*  86 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/*  89 */     setFontBoldStyle(boldStyle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setItalic(boolean italic) throws WriteException {
/* 101 */     if (isInitialized())
/*     */     {
/* 103 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 106 */     setFontItalic(italic);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setUnderlineStyle(int us) throws WriteException {
/* 118 */     if (isInitialized())
/*     */     {
/* 120 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 123 */     setFontUnderlineStyle(us);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColour(int colour) throws WriteException {
/* 135 */     if (isInitialized())
/*     */     {
/* 137 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 140 */     setFontColour(colour);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setScriptStyle(int scriptStyle) throws WriteException {
/* 152 */     if (isInitialized())
/*     */     {
/* 154 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/*     */     
/* 157 */     setFontScriptStyle(scriptStyle);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setStruckout(boolean os) throws WriteException {
/* 168 */     if (isInitialized())
/*     */     {
/* 170 */       throw new JxlWriteException(JxlWriteException.formatInitialized);
/*     */     }
/* 172 */     setFontStruckout(os);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\WritableFontRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
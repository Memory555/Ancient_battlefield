/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MMSRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte numMenuItemsAdded;
/*    */   private byte numMenuItemsDeleted;
/*    */   private byte[] data;
/*    */   
/*    */   public MMSRecord(int menuItemsAdded, int menuItemsDeleted) {
/* 52 */     super(Type.MMS);
/*    */     
/* 54 */     this.numMenuItemsAdded = (byte)menuItemsAdded;
/* 55 */     this.numMenuItemsDeleted = (byte)menuItemsDeleted;
/*    */     
/* 57 */     this.data = new byte[2];
/*    */     
/* 59 */     this.data[0] = this.numMenuItemsAdded;
/* 60 */     this.data[1] = this.numMenuItemsDeleted;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 70 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\MMSRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
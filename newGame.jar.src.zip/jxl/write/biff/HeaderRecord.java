/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.StringHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HeaderRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private String header;
/*    */   
/*    */   public HeaderRecord(String h) {
/* 48 */     super(Type.HEADER);
/*    */     
/* 50 */     this.header = h;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public HeaderRecord(HeaderRecord hr) {
/* 60 */     super(Type.HEADER);
/*    */     
/* 62 */     this.header = hr.header;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 72 */     if (this.header == null || this.header.length() == 0) {
/*    */       
/* 74 */       this.data = new byte[0];
/* 75 */       return this.data;
/*    */     } 
/*    */     
/* 78 */     this.data = new byte[this.header.length() * 2 + 3];
/* 79 */     IntegerHelper.getTwoBytes(this.header.length(), this.data, 0);
/* 80 */     this.data[2] = 1;
/*    */     
/* 82 */     StringHelper.getUnicodeBytes(this.header, this.data, 3);
/*    */     
/* 84 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\HeaderRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.Cell;
/*     */ import jxl.CellFeatures;
/*     */ import jxl.Sheet;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.NumFormatRecordsException;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.biff.drawing.Comment;
/*     */ import jxl.biff.drawing.DrawingGroupObject;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.WritableCell;
/*     */ import jxl.write.WritableCellFeatures;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CellValue
/*     */   extends WritableRecordData
/*     */   implements WritableCell
/*     */ {
/*  59 */   private static Logger logger = Logger.getLogger(CellValue.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int row;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int column;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private XFRecord format;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FormattingRecords formattingRecords;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean referenced;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WritableSheetImpl sheet;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WritableCellFeatures features;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean copied;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CellValue(Type t, int c, int r) {
/* 112 */     this(t, c, r, (CellFormat)WritableWorkbookImpl.NORMAL_STYLE);
/* 113 */     this.copied = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CellValue(Type t, Cell c) {
/* 125 */     this(t, c.getColumn(), c.getRow());
/* 126 */     this.copied = true;
/*     */     
/* 128 */     this.format = (XFRecord)c.getCellFormat();
/*     */     
/* 130 */     if (c.getCellFeatures() != null) {
/*     */       
/* 132 */       this.features = new WritableCellFeatures(c.getCellFeatures());
/* 133 */       this.features.setWritableCell(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CellValue(Type t, int c, int r, CellFormat st) {
/* 148 */     super(t);
/* 149 */     this.row = r;
/* 150 */     this.column = c;
/* 151 */     this.format = (XFRecord)st;
/* 152 */     this.referenced = false;
/* 153 */     this.copied = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CellValue(Type t, int c, int r, CellValue cv) {
/* 166 */     super(t);
/* 167 */     this.row = r;
/* 168 */     this.column = c;
/* 169 */     this.format = cv.format;
/* 170 */     this.referenced = false;
/* 171 */     this.copied = false;
/*     */ 
/*     */     
/* 174 */     if (cv.features != null) {
/*     */       
/* 176 */       this.features = new WritableCellFeatures((CellFeatures)cv.features);
/* 177 */       this.features.setWritableCell(this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCellFormat(CellFormat cf) {
/* 188 */     this.format = (XFRecord)cf;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     if (!this.referenced) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 200 */     Assert.verify((this.formattingRecords != null));
/*     */     
/* 202 */     addCellFormat();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRow() {
/* 212 */     return this.row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumn() {
/* 222 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHidden() {
/* 233 */     ColumnInfoRecord cir = this.sheet.getColumnInfo(this.column);
/*     */     
/* 235 */     if (cir != null && cir.getWidth() == 0)
/*     */     {
/* 237 */       return true;
/*     */     }
/*     */     
/* 240 */     RowRecord rr = this.sheet.getRowInfo(this.row);
/*     */     
/* 242 */     if (rr != null && (rr.getRowHeight() == 0 || rr.isCollapsed()))
/*     */     {
/* 244 */       return true;
/*     */     }
/*     */     
/* 247 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 257 */     byte[] mydata = new byte[6];
/* 258 */     IntegerHelper.getTwoBytes(this.row, mydata, 0);
/* 259 */     IntegerHelper.getTwoBytes(this.column, mydata, 2);
/* 260 */     IntegerHelper.getTwoBytes(this.format.getXFIndex(), mydata, 4);
/* 261 */     return mydata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setCellDetails(FormattingRecords fr, SharedStrings ss, WritableSheetImpl s) {
/* 277 */     this.referenced = true;
/* 278 */     this.sheet = s;
/* 279 */     this.formattingRecords = fr;
/*     */     
/* 281 */     addCellFormat();
/* 282 */     addCellFeatures();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isReferenced() {
/* 293 */     return this.referenced;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int getXFIndex() {
/* 303 */     return this.format.getXFIndex();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellFormat getCellFormat() {
/* 313 */     return (CellFormat)this.format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void incrementRow() {
/* 322 */     this.row++;
/*     */     
/* 324 */     if (this.features != null) {
/*     */       
/* 326 */       Comment c = this.features.getCommentDrawing();
/* 327 */       c.setX(this.column);
/* 328 */       c.setY(this.row);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void decrementRow() {
/* 338 */     this.row--;
/*     */     
/* 340 */     if (this.features != null) {
/*     */       
/* 342 */       Comment c = this.features.getCommentDrawing();
/* 343 */       c.setX(this.column);
/* 344 */       c.setY(this.row);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void incrementColumn() {
/* 354 */     this.column++;
/*     */     
/* 356 */     if (this.features != null) {
/*     */       
/* 358 */       Comment c = this.features.getCommentDrawing();
/* 359 */       c.setX(this.column);
/* 360 */       c.setY(this.row);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void decrementColumn() {
/* 371 */     this.column--;
/*     */     
/* 373 */     if (this.features != null) {
/*     */       
/* 375 */       Comment c = this.features.getCommentDrawing();
/* 376 */       c.setX(this.column);
/* 377 */       c.setY(this.row);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnInserted(Sheet s, int sheetIndex, int col) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(Sheet s, int sheetIndex, int col) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(Sheet s, int sheetIndex, int row) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(Sheet s, int sheetIndex, int row) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WritableSheetImpl getSheet() {
/* 437 */     return this.sheet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addCellFormat() {
/* 449 */     Styles styles = this.sheet.getWorkbook().getStyles();
/* 450 */     this.format = styles.getFormat(this.format);
/*     */ 
/*     */     
/*     */     try {
/* 454 */       if (!this.format.isInitialized())
/*     */       {
/* 456 */         this.formattingRecords.addStyle(this.format);
/*     */       }
/*     */     }
/* 459 */     catch (NumFormatRecordsException e) {
/*     */       
/* 461 */       logger.warn("Maximum number of format records exceeded.  Using default format.");
/*     */       
/* 463 */       this.format = (XFRecord)styles.getNormalStyle();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellFeatures getCellFeatures() {
/* 474 */     return (CellFeatures)this.features;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableCellFeatures getWritableCellFeatures() {
/* 484 */     return this.features;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCellFeatures(WritableCellFeatures cf) {
/* 494 */     if (this.features != null)
/*     */     {
/* 496 */       logger.warn("current cell features not null - overwriting");
/*     */     }
/*     */     
/* 499 */     this.features = cf;
/* 500 */     cf.setWritableCell(this);
/*     */ 
/*     */ 
/*     */     
/* 504 */     if (this.referenced)
/*     */     {
/* 506 */       addCellFeatures();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addCellFeatures() {
/* 518 */     if (this.features == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 523 */     if (this.copied == true) {
/*     */       
/* 525 */       this.copied = false;
/*     */       
/*     */       return;
/*     */     } 
/* 529 */     if (this.features.getComment() != null) {
/*     */       
/* 531 */       Comment comment = new Comment(this.features.getComment(), this.column, this.row);
/*     */       
/* 533 */       comment.setWidth(this.features.getCommentWidth());
/* 534 */       comment.setHeight(this.features.getCommentHeight());
/* 535 */       this.sheet.addDrawing((DrawingGroupObject)comment);
/* 536 */       this.sheet.getWorkbook().addDrawing((DrawingGroupObject)comment);
/* 537 */       this.features.setCommentDrawing(comment);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void removeComment(Comment c) {
/* 548 */     this.sheet.removeDrawing((DrawingGroupObject)c);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\CellValue.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
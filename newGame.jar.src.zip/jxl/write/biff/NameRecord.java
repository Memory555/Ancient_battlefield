/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NameRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private byte[] data;
/*     */   private String name;
/*     */   private int index;
/*  53 */   private int sheetRef = 0; private NameRange[] ranges;
/*     */   private static final int cellReference = 58;
/*     */   private static final int areaReference = 59;
/*     */   private static final int subExpression = 41;
/*     */   private static final int union = 16;
/*     */   
/*     */   class NameRange { private int columnFirst;
/*     */     private int rowFirst;
/*     */     private int columnLast;
/*     */     private int rowLast;
/*     */     private int externalSheet;
/*     */     private final NameRecord this$0;
/*     */     
/*     */     NameRange(NameRecord this$0, jxl.read.biff.NameRecord.NameRange nr) {
/*  67 */       this.this$0 = this$0;
/*  68 */       this.columnFirst = nr.getFirstColumn();
/*  69 */       this.rowFirst = nr.getFirstRow();
/*  70 */       this.columnLast = nr.getLastColumn();
/*  71 */       this.rowLast = nr.getLastRow();
/*  72 */       this.externalSheet = nr.getExternalSheet();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     NameRange(NameRecord this$0, int theSheet, int theStartRow, int theEndRow, int theStartCol, int theEndCol) {
/*  83 */       this.this$0 = this$0;
/*  84 */       this.columnFirst = theStartCol;
/*  85 */       this.rowFirst = theStartRow;
/*  86 */       this.columnLast = theEndCol;
/*  87 */       this.rowLast = theEndRow;
/*  88 */       this.externalSheet = theSheet;
/*     */     }
/*     */     
/*  91 */     int getFirstColumn() { return this.columnFirst; }
/*  92 */     int getFirstRow() { return this.rowFirst; }
/*  93 */     int getLastColumn() { return this.columnLast; }
/*  94 */     int getLastRow() { return this.rowLast; } int getExternalSheet() {
/*  95 */       return this.externalSheet;
/*     */     }
/*     */     
/*     */     byte[] getData() {
/*  99 */       byte[] d = new byte[10];
/*     */ 
/*     */       
/* 102 */       IntegerHelper.getTwoBytes(this.this$0.sheetRef, d, 0);
/*     */ 
/*     */       
/* 105 */       IntegerHelper.getTwoBytes(this.rowFirst, d, 2);
/*     */ 
/*     */       
/* 108 */       IntegerHelper.getTwoBytes(this.rowLast, d, 4);
/*     */ 
/*     */       
/* 111 */       IntegerHelper.getTwoBytes(this.columnFirst & 0xFF, d, 6);
/*     */ 
/*     */       
/* 114 */       IntegerHelper.getTwoBytes(this.columnLast & 0xFF, d, 8);
/*     */       
/* 116 */       return d;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameRecord(jxl.read.biff.NameRecord sr, int ind) {
/* 139 */     super(Type.NAME);
/*     */     
/* 141 */     this.data = sr.getData();
/* 142 */     this.name = sr.getName();
/* 143 */     this.sheetRef = sr.getSheetRef();
/* 144 */     this.index = ind;
/*     */ 
/*     */     
/* 147 */     jxl.read.biff.NameRecord.NameRange[] r = sr.getRanges();
/* 148 */     this.ranges = new NameRange[r.length];
/* 149 */     for (int i = 0; i < this.ranges.length; i++)
/*     */     {
/* 151 */       this.ranges[i] = new NameRange(this, r[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NameRecord(String theName, int theIndex, int theSheet, int theStartRow, int theEndRow, int theStartCol, int theEndCol) {
/* 174 */     super(Type.NAME);
/*     */     
/* 176 */     this.name = theName;
/* 177 */     this.index = theIndex;
/* 178 */     this.sheetRef = 0;
/*     */     
/* 180 */     this.ranges = new NameRange[1];
/* 181 */     this.ranges[0] = new NameRange(this, theSheet, theStartRow, theEndRow, theStartCol, theEndCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 195 */     if (this.data != null)
/*     */     {
/*     */       
/* 198 */       return this.data;
/*     */     }
/*     */     
/* 201 */     int NAME_HEADER_LENGTH = 15;
/* 202 */     byte AREA_RANGE_LENGTH = 11;
/* 203 */     byte AREA_REFERENCE = 59;
/*     */     
/* 205 */     this.data = new byte[15 + this.name.length() + 11];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 210 */     int options = 0;
/* 211 */     IntegerHelper.getTwoBytes(options, this.data, 0);
/*     */ 
/*     */     
/* 214 */     this.data[2] = 0;
/*     */ 
/*     */     
/* 217 */     this.data[3] = (byte)this.name.length();
/*     */ 
/*     */     
/* 220 */     IntegerHelper.getTwoBytes(11, this.data, 4);
/*     */ 
/*     */     
/* 223 */     IntegerHelper.getTwoBytes((this.ranges[0]).externalSheet, this.data, 6);
/* 224 */     IntegerHelper.getTwoBytes((this.ranges[0]).externalSheet, this.data, 8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     StringHelper.getBytes(this.name, this.data, 15);
/*     */ 
/*     */ 
/*     */     
/* 234 */     int pos = this.name.length() + 15;
/*     */ 
/*     */     
/* 237 */     this.data[pos] = 59;
/*     */ 
/*     */     
/* 240 */     byte[] rd = this.ranges[0].getData();
/* 241 */     System.arraycopy(rd, 0, this.data, pos + 1, rd.length);
/*     */     
/* 243 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 253 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex() {
/* 263 */     return this.index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSheetRef() {
/* 274 */     return this.sheetRef;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSheetRef(int i) {
/* 284 */     this.sheetRef = i;
/* 285 */     IntegerHelper.getTwoBytes(this.sheetRef, this.data, 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NameRange[] getRanges() {
/* 294 */     return this.ranges;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\NameRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
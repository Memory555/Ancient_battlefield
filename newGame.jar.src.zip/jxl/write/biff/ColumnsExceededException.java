/*    */ package jxl.write.biff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ColumnsExceededException
/*    */   extends JxlWriteException
/*    */ {
/*    */   public ColumnsExceededException() {
/* 35 */     super(maxColumnsExceeded);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ColumnsExceededException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
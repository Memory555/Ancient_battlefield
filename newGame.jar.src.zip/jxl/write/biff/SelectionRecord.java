/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SelectionRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private PaneType pane;
/*    */   private int column;
/*    */   private int row;
/*    */   
/*    */   private static class PaneType
/*    */   {
/*    */     int val;
/*    */     
/*    */     PaneType(int v) {
/* 52 */       this.val = v;
/*    */     }
/*    */   }
/*    */   
/* 56 */   public static final PaneType lowerRight = new PaneType(0);
/* 57 */   public static final PaneType upperRight = new PaneType(1);
/* 58 */   public static final PaneType lowerLeft = new PaneType(2);
/* 59 */   public static final PaneType upperLeft = new PaneType(3);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SelectionRecord(PaneType pt, int col, int r) {
/* 66 */     super(Type.SELECTION);
/* 67 */     this.column = col;
/* 68 */     this.row = r;
/* 69 */     this.pane = pt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 80 */     byte[] data = new byte[15];
/*    */     
/* 82 */     data[0] = (byte)this.pane.val;
/* 83 */     IntegerHelper.getTwoBytes(this.row, data, 1);
/* 84 */     IntegerHelper.getTwoBytes(this.column, data, 3);
/*    */     
/* 86 */     data[7] = 1;
/*    */     
/* 88 */     IntegerHelper.getTwoBytes(this.row, data, 9);
/* 89 */     IntegerHelper.getTwoBytes(this.row, data, 11);
/* 90 */     data[13] = (byte)this.column;
/* 91 */     data[14] = (byte)this.column;
/*    */     
/* 93 */     return data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\SelectionRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
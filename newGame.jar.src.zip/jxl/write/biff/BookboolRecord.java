/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BookboolRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean externalLink;
/*    */   private byte[] data;
/*    */   
/*    */   public BookboolRecord(boolean extlink) {
/* 50 */     super(Type.BOOKBOOL);
/*    */     
/* 52 */     this.externalLink = extlink;
/* 53 */     this.data = new byte[2];
/*    */     
/* 55 */     if (!this.externalLink)
/*    */     {
/* 57 */       IntegerHelper.getTwoBytes(1, this.data, 0);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 68 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\BookboolRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write.biff;
/*    */ 
/*    */ import java.text.NumberFormat;
/*    */ import jxl.NumberFormulaCell;
/*    */ import jxl.biff.FormulaData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReadNumberFormulaRecord
/*    */   extends ReadFormulaRecord
/*    */   implements NumberFormulaCell
/*    */ {
/*    */   public ReadNumberFormulaRecord(FormulaData f) {
/* 40 */     super(f);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public double getValue() {
/* 50 */     return ((NumberFormulaCell)getReadFormula()).getValue();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NumberFormat getNumberFormat() {
/* 61 */     return ((NumberFormulaCell)getReadFormula()).getNumberFormat();
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ReadNumberFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import jxl.biff.ByteData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SharedStrings
/*     */ {
/*  55 */   private HashMap strings = new HashMap(100);
/*  56 */   private ArrayList stringList = new ArrayList(100);
/*  57 */   private int totalOccurrences = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIndex(String s) {
/*  70 */     Integer i = (Integer)this.strings.get(s);
/*     */     
/*  72 */     if (i == null) {
/*     */       
/*  74 */       i = new Integer(this.strings.size());
/*  75 */       this.strings.put(s, i);
/*  76 */       this.stringList.add(s);
/*     */     } 
/*     */     
/*  79 */     this.totalOccurrences++;
/*     */     
/*  81 */     return i.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get(int i) {
/*  92 */     return this.stringList.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(File outputFile) throws IOException {
/* 105 */     int numStrings = 0;
/* 106 */     int charsLeft = 0;
/* 107 */     String curString = null;
/* 108 */     SSTRecord sst = new SSTRecord(this.totalOccurrences, this.stringList.size());
/* 109 */     ExtendedSSTRecord extsst = new ExtendedSSTRecord(this.stringList.size());
/* 110 */     int bucketSize = extsst.getNumberOfStringsPerBucket();
/*     */     
/* 112 */     Iterator i = this.stringList.iterator();
/* 113 */     int stringIndex = 0;
/* 114 */     while (i.hasNext() && charsLeft == 0) {
/*     */       
/* 116 */       curString = i.next();
/*     */       
/* 118 */       int relativePosition = sst.getOffset() + 4;
/* 119 */       charsLeft = sst.add(curString);
/* 120 */       if (stringIndex % bucketSize == 0) {
/* 121 */         extsst.addString(outputFile.getPos(), relativePosition);
/*     */       }
/* 123 */       stringIndex++;
/*     */     } 
/* 125 */     outputFile.write((ByteData)sst);
/*     */     
/* 127 */     if (charsLeft != 0 || i.hasNext()) {
/*     */ 
/*     */       
/* 130 */       SSTContinueRecord cont = createContinueRecord(curString, charsLeft, outputFile);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 135 */       while (i.hasNext()) {
/*     */         
/* 137 */         curString = i.next();
/* 138 */         int relativePosition = cont.getOffset() + 4;
/* 139 */         charsLeft = cont.add(curString);
/* 140 */         if (stringIndex % bucketSize == 0) {
/* 141 */           extsst.addString(outputFile.getPos(), relativePosition);
/*     */         }
/* 143 */         stringIndex++;
/*     */         
/* 145 */         if (charsLeft != 0) {
/*     */           
/* 147 */           outputFile.write((ByteData)cont);
/* 148 */           cont = createContinueRecord(curString, charsLeft, outputFile);
/*     */         } 
/*     */       } 
/*     */       
/* 152 */       outputFile.write((ByteData)cont);
/*     */     } 
/*     */     
/* 155 */     outputFile.write((ByteData)extsst);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SSTContinueRecord createContinueRecord(String curString, int charsLeft, File outputFile) throws IOException {
/* 166 */     SSTContinueRecord cont = null;
/* 167 */     while (charsLeft != 0) {
/*     */       
/* 169 */       cont = new SSTContinueRecord();
/*     */       
/* 171 */       if (charsLeft == curString.length()) {
/*     */         
/* 173 */         charsLeft = cont.setFirstString(curString, true);
/*     */       }
/*     */       else {
/*     */         
/* 177 */         charsLeft = cont.setFirstString(curString.substring(curString.length() - charsLeft), false);
/*     */       } 
/*     */ 
/*     */       
/* 181 */       if (charsLeft != 0) {
/*     */         
/* 183 */         outputFile.write((ByteData)cont);
/* 184 */         cont = new SSTContinueRecord();
/*     */       } 
/*     */     } 
/*     */     
/* 188 */     return cont;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\SharedStrings.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
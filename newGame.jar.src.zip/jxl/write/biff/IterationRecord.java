/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class IterationRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean iterate;
/*    */   private byte[] data;
/*    */   
/*    */   public IterationRecord(boolean it) {
/* 48 */     super(Type.ITERATION);
/*    */     
/* 50 */     this.iterate = it;
/*    */     
/* 52 */     this.data = new byte[2];
/*    */     
/* 54 */     if (this.iterate)
/*    */     {
/* 56 */       this.data[0] = 1;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 67 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\IterationRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.CellType;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.biff.CellReferenceHelper;
/*     */ import jxl.biff.IndexMapping;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.write.Number;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class RowRecord
/*     */   extends WritableRecordData
/*     */ {
/*  44 */   private static final Logger logger = Logger.getLogger(RowRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CellValue[] cells;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int rowHeight;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean collapsed;
/*     */ 
/*     */ 
/*     */   
/*     */   private int rowNumber;
/*     */ 
/*     */ 
/*     */   
/*     */   private int numColumns;
/*     */ 
/*     */ 
/*     */   
/*     */   private int xfIndex;
/*     */ 
/*     */ 
/*     */   
/*     */   private XFRecord style;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean defaultFormat;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean matchesDefFontHeight;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int growSize = 10;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int maxRKValue = 536870911;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int minRKValue = -536870912;
/*     */ 
/*     */ 
/*     */   
/* 104 */   private static int defaultHeightIndicator = 255;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private static int maxColumns = 256;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RowRecord(int rn) {
/* 119 */     super(Type.ROW);
/* 120 */     this.rowNumber = rn;
/* 121 */     this.cells = new CellValue[0];
/* 122 */     this.numColumns = 0;
/* 123 */     this.rowHeight = defaultHeightIndicator;
/* 124 */     this.collapsed = false;
/* 125 */     this.matchesDefFontHeight = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowHeight(int h) {
/* 135 */     if (h == 0) {
/*     */       
/* 137 */       setCollapsed(true);
/* 138 */       this.matchesDefFontHeight = false;
/*     */     }
/*     */     else {
/*     */       
/* 142 */       this.rowHeight = h;
/* 143 */       this.matchesDefFontHeight = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setRowDetails(int height, boolean mdfh, boolean col, XFRecord xfr) {
/* 158 */     this.rowHeight = height;
/* 159 */     this.collapsed = col;
/* 160 */     this.matchesDefFontHeight = mdfh;
/*     */     
/* 162 */     if (xfr != null) {
/*     */       
/* 164 */       this.defaultFormat = true;
/* 165 */       this.style = xfr;
/* 166 */       this.xfIndex = this.style.getXFIndex();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCollapsed(boolean c) {
/* 177 */     this.collapsed = c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowNumber() {
/* 187 */     return this.rowNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCell(CellValue cv) {
/* 197 */     int col = cv.getColumn();
/*     */     
/* 199 */     if (col >= maxColumns) {
/*     */       
/* 201 */       logger.warn("Could not add cell at " + CellReferenceHelper.getCellReference(cv.getRow(), cv.getColumn()) + " because it exceeds the maximum column limit");
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 211 */     if (col >= this.cells.length) {
/*     */       
/* 213 */       CellValue[] oldCells = this.cells;
/* 214 */       this.cells = new CellValue[Math.max(oldCells.length + 10, col + 1)];
/* 215 */       System.arraycopy(oldCells, 0, this.cells, 0, oldCells.length);
/* 216 */       oldCells = null;
/*     */     } 
/*     */     
/* 219 */     this.cells[col] = cv;
/*     */     
/* 221 */     this.numColumns = Math.max(col + 1, this.numColumns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeCell(int col) {
/* 232 */     if (col >= this.numColumns) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 237 */     this.cells[col] = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(File outputFile) throws IOException {
/* 248 */     outputFile.write((ByteData)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeCells(File outputFile) throws IOException {
/* 263 */     ArrayList integerValues = new ArrayList();
/* 264 */     boolean integerValue = false;
/*     */ 
/*     */     
/* 267 */     for (int i = 0; i < this.numColumns; i++) {
/*     */       
/* 269 */       integerValue = false;
/* 270 */       if (this.cells[i] != null) {
/*     */ 
/*     */ 
/*     */         
/* 274 */         if (this.cells[i].getType() == CellType.NUMBER) {
/*     */           
/* 276 */           Number nc = (Number)this.cells[i];
/* 277 */           if (nc.getValue() == (int)nc.getValue() && nc.getValue() < 5.36870911E8D && nc.getValue() > -5.36870912E8D && nc.getCellFeatures() == null)
/*     */           {
/*     */ 
/*     */ 
/*     */             
/* 282 */             integerValue = true;
/*     */           }
/*     */         } 
/*     */         
/* 286 */         if (integerValue)
/*     */         {
/*     */           
/* 289 */           integerValues.add(this.cells[i]);
/*     */         
/*     */         }
/*     */         else
/*     */         {
/*     */           
/* 295 */           writeIntegerValues(integerValues, outputFile);
/* 296 */           outputFile.write((ByteData)this.cells[i]);
/*     */ 
/*     */ 
/*     */           
/* 300 */           if (this.cells[i].getType() == CellType.STRING_FORMULA)
/*     */           {
/* 302 */             StringRecord sr = new StringRecord(this.cells[i].getContents());
/* 303 */             outputFile.write((ByteData)sr);
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 311 */         writeIntegerValues(integerValues, outputFile);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 316 */     writeIntegerValues(integerValues, outputFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeIntegerValues(ArrayList integerValues, File outputFile) throws IOException {
/* 330 */     if (integerValues.size() == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 335 */     if (integerValues.size() >= 3) {
/*     */ 
/*     */       
/* 338 */       MulRKRecord mulrk = new MulRKRecord(integerValues);
/* 339 */       outputFile.write((ByteData)mulrk);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 344 */       Iterator i = integerValues.iterator();
/* 345 */       while (i.hasNext())
/*     */       {
/* 347 */         outputFile.write((ByteData)i.next());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 352 */     integerValues.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 363 */     byte[] data = new byte[16];
/* 364 */     IntegerHelper.getTwoBytes(this.rowNumber, data, 0);
/* 365 */     IntegerHelper.getTwoBytes(this.numColumns, data, 4);
/* 366 */     IntegerHelper.getTwoBytes(this.rowHeight, data, 6);
/*     */     
/* 368 */     int options = 256;
/*     */     
/* 370 */     if (this.collapsed)
/*     */     {
/* 372 */       options |= 0x20;
/*     */     }
/*     */     
/* 375 */     if (!this.matchesDefFontHeight)
/*     */     {
/* 377 */       options |= 0x40;
/*     */     }
/*     */     
/* 380 */     if (this.defaultFormat) {
/*     */       
/* 382 */       options |= 0x80;
/* 383 */       options |= this.xfIndex << 16;
/*     */     } 
/*     */     
/* 386 */     IntegerHelper.getFourBytes(options, data, 12);
/*     */     
/* 388 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxColumn() {
/* 398 */     return this.numColumns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellValue getCell(int col) {
/* 410 */     return (col >= 0 && col < this.numColumns) ? this.cells[col] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void incrementRow() {
/* 419 */     this.rowNumber++;
/*     */     
/* 421 */     for (int i = 0; i < this.cells.length; i++) {
/*     */       
/* 423 */       if (this.cells[i] != null)
/*     */       {
/* 425 */         this.cells[i].incrementRow();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void decrementRow() {
/* 436 */     this.rowNumber--;
/* 437 */     for (int i = 0; i < this.cells.length; i++) {
/*     */       
/* 439 */       if (this.cells[i] != null)
/*     */       {
/* 441 */         this.cells[i].decrementRow();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void insertColumn(int col) {
/* 455 */     if (col >= this.numColumns) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 460 */     if (this.numColumns >= maxColumns) {
/*     */       
/* 462 */       logger.warn("Could not insert column because maximum column limit has been reached");
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 468 */     CellValue[] oldCells = this.cells;
/*     */     
/* 470 */     if (this.numColumns >= this.cells.length - 1) {
/*     */       
/* 472 */       this.cells = new CellValue[oldCells.length + 10];
/*     */     }
/*     */     else {
/*     */       
/* 476 */       this.cells = new CellValue[oldCells.length];
/*     */     } 
/*     */ 
/*     */     
/* 480 */     System.arraycopy(oldCells, 0, this.cells, 0, col);
/*     */ 
/*     */     
/* 483 */     System.arraycopy(oldCells, col, this.cells, col + 1, this.numColumns - col);
/*     */ 
/*     */     
/* 486 */     for (int i = col + 1; i <= this.numColumns; i++) {
/*     */       
/* 488 */       if (this.cells[i] != null)
/*     */       {
/* 490 */         this.cells[i].incrementColumn();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 495 */     this.numColumns++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeColumn(int col) {
/* 507 */     if (col >= this.numColumns) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 513 */     CellValue[] oldCells = this.cells;
/*     */     
/* 515 */     this.cells = new CellValue[oldCells.length];
/*     */ 
/*     */     
/* 518 */     System.arraycopy(oldCells, 0, this.cells, 0, col);
/*     */ 
/*     */     
/* 521 */     System.arraycopy(oldCells, col + 1, this.cells, col, this.numColumns - col + 1);
/*     */ 
/*     */     
/* 524 */     for (int i = col; i < this.numColumns; i++) {
/*     */       
/* 526 */       if (this.cells[i] != null)
/*     */       {
/* 528 */         this.cells[i].decrementColumn();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 533 */     this.numColumns--;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefaultHeight() {
/* 543 */     return (this.rowHeight == defaultHeightIndicator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRowHeight() {
/* 553 */     return this.rowHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCollapsed() {
/* 563 */     return this.collapsed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rationalize(IndexMapping xfmapping) {
/* 572 */     if (this.defaultFormat)
/*     */     {
/* 574 */       this.xfIndex = xfmapping.getNewIndex(this.xfIndex);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   XFRecord getStyle() {
/* 586 */     return this.style;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasDefaultFormat() {
/* 596 */     return this.defaultFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean matchesDefaultFontHeight() {
/* 606 */     return this.matchesDefFontHeight;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\RowRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import jxl.Cell;
/*     */ import jxl.CellReferenceHelper;
/*     */ import jxl.CellType;
/*     */ import jxl.Sheet;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.FormattingRecords;
/*     */ import jxl.biff.FormulaData;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WorkbookMethods;
/*     */ import jxl.biff.formula.ExternalSheet;
/*     */ import jxl.biff.formula.FormulaException;
/*     */ import jxl.biff.formula.FormulaParser;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.WritableCell;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FormulaRecord
/*     */   extends CellValue
/*     */   implements FormulaData
/*     */ {
/*  52 */   private static Logger logger = Logger.getLogger(FormulaRecord.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String formulaToParse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FormulaParser parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String formulaString;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] formulaBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CellValue copiedFrom;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormulaRecord(int c, int r, String f) {
/*  87 */     super(Type.FORMULA2, c, r);
/*  88 */     this.formulaToParse = f;
/*  89 */     this.copiedFrom = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FormulaRecord(int c, int r, String f, CellFormat st) {
/*  99 */     super(Type.FORMULA, c, r, st);
/* 100 */     this.formulaToParse = f;
/* 101 */     this.copiedFrom = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FormulaRecord(int c, int r, FormulaRecord fr) {
/* 113 */     super(Type.FORMULA, c, r, fr);
/* 114 */     this.copiedFrom = fr;
/* 115 */     this.formulaBytes = new byte[fr.formulaBytes.length];
/* 116 */     System.arraycopy(fr.formulaBytes, 0, this.formulaBytes, 0, this.formulaBytes.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected FormulaRecord(int c, int r, ReadFormulaRecord rfr) {
/* 128 */     super(Type.FORMULA, c, r, rfr);
/*     */     
/*     */     try {
/* 131 */       this.copiedFrom = rfr;
/* 132 */       byte[] readFormulaData = rfr.getFormulaData();
/* 133 */       this.formulaBytes = new byte[readFormulaData.length - 16];
/* 134 */       System.arraycopy(readFormulaData, 16, this.formulaBytes, 0, this.formulaBytes.length);
/*     */     
/*     */     }
/* 137 */     catch (FormulaException e) {
/*     */ 
/*     */       
/* 140 */       logger.error("", (Throwable)e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initialize(WorkbookSettings ws, ExternalSheet es, WorkbookMethods nt) {
/* 156 */     if (this.copiedFrom != null) {
/*     */       
/* 158 */       initializeCopiedFormula(ws, es, nt);
/*     */       
/*     */       return;
/*     */     } 
/* 162 */     this.parser = new FormulaParser(this.formulaToParse, es, nt, ws);
/*     */ 
/*     */     
/*     */     try {
/* 166 */       this.parser.parse();
/* 167 */       this.formulaString = this.parser.getFormula();
/* 168 */       this.formulaBytes = this.parser.getBytes();
/*     */     }
/* 170 */     catch (FormulaException e) {
/*     */       
/* 172 */       logger.warn(e.getMessage() + " when parsing formula " + this.formulaToParse + " in cell " + getSheet().getName() + "!" + CellReferenceHelper.getCellReference(getColumn(), getRow()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 181 */         this.formulaToParse = "ERROR(1)";
/* 182 */         this.parser = new FormulaParser(this.formulaToParse, es, nt, ws);
/* 183 */         this.parser.parse();
/* 184 */         this.formulaString = this.parser.getFormula();
/* 185 */         this.formulaBytes = this.parser.getBytes();
/*     */       }
/* 187 */       catch (FormulaException e2) {
/*     */ 
/*     */         
/* 190 */         logger.error("", (Throwable)e2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeCopiedFormula(WorkbookSettings ws, ExternalSheet es, WorkbookMethods nt) {
/*     */     try {
/* 208 */       this.parser = new FormulaParser(this.formulaBytes, (Cell)this, es, nt, ws);
/* 209 */       this.parser.parse();
/* 210 */       this.parser.adjustRelativeCellReferences(getColumn() - this.copiedFrom.getColumn(), getRow() - this.copiedFrom.getRow());
/*     */ 
/*     */       
/* 213 */       this.formulaString = this.parser.getFormula();
/* 214 */       this.formulaBytes = this.parser.getBytes();
/*     */     }
/* 216 */     catch (FormulaException e) {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 221 */         this.formulaToParse = "ERROR(1)";
/* 222 */         this.parser = new FormulaParser(this.formulaToParse, es, nt, ws);
/* 223 */         this.parser.parse();
/* 224 */         this.formulaString = this.parser.getFormula();
/* 225 */         this.formulaBytes = this.parser.getBytes();
/*     */       
/*     */       }
/* 228 */       catch (FormulaException e2) {
/*     */ 
/*     */         
/* 231 */         logger.error("", (Throwable)e2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setCellDetails(FormattingRecords fr, SharedStrings ss, WritableSheetImpl s) {
/* 248 */     super.setCellDetails(fr, ss, s);
/* 249 */     initialize(s.getWorkbookSettings(), s.getWorkbook(), s.getWorkbook());
/* 250 */     s.getWorkbook().addRCIRCell(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 260 */     byte[] celldata = super.getData();
/* 261 */     byte[] formulaData = getFormulaData();
/* 262 */     byte[] data = new byte[formulaData.length + celldata.length];
/* 263 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 264 */     System.arraycopy(formulaData, 0, data, celldata.length, formulaData.length);
/*     */     
/* 266 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 276 */     return CellType.ERROR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 288 */     return this.formulaString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getFormulaData() {
/* 299 */     byte[] data = new byte[this.formulaBytes.length + 16];
/* 300 */     System.arraycopy(this.formulaBytes, 0, data, 16, this.formulaBytes.length);
/*     */     
/* 302 */     data[6] = 16;
/* 303 */     data[7] = 64;
/* 304 */     data[12] = -32;
/* 305 */     data[13] = -4;
/*     */     
/* 307 */     data[8] = (byte)(data[8] | 0x2);
/*     */ 
/*     */     
/* 310 */     IntegerHelper.getTwoBytes(this.formulaBytes.length, data, 14);
/*     */     
/* 312 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableCell copyTo(int col, int row) {
/* 325 */     Assert.verify(false);
/* 326 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnInserted(Sheet s, int sheetIndex, int col) {
/* 339 */     this.parser.columnInserted(sheetIndex, col, (s == getSheet()));
/* 340 */     this.formulaBytes = this.parser.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void columnRemoved(Sheet s, int sheetIndex, int col) {
/* 353 */     this.parser.columnRemoved(sheetIndex, col, (s == getSheet()));
/* 354 */     this.formulaBytes = this.parser.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowInserted(Sheet s, int sheetIndex, int row) {
/* 367 */     this.parser.rowInserted(sheetIndex, row, (s == getSheet()));
/* 368 */     this.formulaBytes = this.parser.getBytes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rowRemoved(Sheet s, int sheetIndex, int row) {
/* 381 */     this.parser.rowRemoved(sheetIndex, row, (s == getSheet()));
/* 382 */     this.formulaBytes = this.parser.getBytes();
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\FormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
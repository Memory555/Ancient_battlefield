/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.TreeSet;
/*     */ import jxl.Cell;
/*     */ import jxl.Range;
/*     */ import jxl.SheetSettings;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.biff.WorkspaceInformationRecord;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.biff.drawing.Chart;
/*     */ import jxl.biff.drawing.SheetDrawingWriter;
/*     */ import jxl.format.Border;
/*     */ import jxl.format.BorderLineStyle;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.format.Colour;
/*     */ import jxl.write.Blank;
/*     */ import jxl.write.WritableCell;
/*     */ import jxl.write.WritableCellFormat;
/*     */ import jxl.write.WritableHyperlink;
/*     */ import jxl.write.WriteException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SheetWriter
/*     */ {
/*  61 */   private static Logger logger = Logger.getLogger(SheetWriter.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File outputFile;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RowRecord[] rows;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int numRows;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int numCols;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private HeaderRecord header;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FooterRecord footer;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SheetSettings settings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings workbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList rowBreaks;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList hyperlinks;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private DataValidation dataValidation;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MergedCells mergedCells;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PLSRecord plsRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ButtonPropertySetRecord buttonPropertySet;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkspaceInformationRecord workspaceOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TreeSet columnFormats;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SheetDrawingWriter drawingWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean chartOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WritableSheetImpl sheet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SheetWriter(File of, WritableSheetImpl wsi, WorkbookSettings ws) {
/* 163 */     this.outputFile = of;
/* 164 */     this.sheet = wsi;
/* 165 */     this.workspaceOptions = new WorkspaceInformationRecord();
/* 166 */     this.workbookSettings = ws;
/* 167 */     this.chartOnly = false;
/* 168 */     this.drawingWriter = new SheetDrawingWriter(ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write() throws IOException {
/* 181 */     Assert.verify((this.rows != null));
/*     */ 
/*     */     
/* 184 */     if (this.chartOnly) {
/*     */       
/* 186 */       this.drawingWriter.write(this.outputFile);
/*     */       
/*     */       return;
/*     */     } 
/* 190 */     int bofpos = this.outputFile.getPos();
/*     */     
/* 192 */     BOFRecord bof = new BOFRecord(BOFRecord.sheet);
/* 193 */     this.outputFile.write((ByteData)bof);
/*     */ 
/*     */     
/* 196 */     int numBlocks = this.numRows / 32;
/* 197 */     if (this.numRows - numBlocks * 32 != 0)
/*     */     {
/* 199 */       numBlocks++;
/*     */     }
/*     */     
/* 202 */     int indexPos = this.outputFile.getPos();
/*     */ 
/*     */ 
/*     */     
/* 206 */     IndexRecord indexRecord = new IndexRecord(0, this.numRows, numBlocks);
/* 207 */     this.outputFile.write((ByteData)indexRecord);
/*     */     
/* 209 */     CalcModeRecord cmr = new CalcModeRecord(CalcModeRecord.automatic);
/* 210 */     this.outputFile.write((ByteData)cmr);
/*     */     
/* 212 */     CalcCountRecord ccr = new CalcCountRecord(100);
/* 213 */     this.outputFile.write((ByteData)ccr);
/*     */     
/* 215 */     RefModeRecord rmr = new RefModeRecord();
/* 216 */     this.outputFile.write((ByteData)rmr);
/*     */     
/* 218 */     IterationRecord itr = new IterationRecord(false);
/* 219 */     this.outputFile.write((ByteData)itr);
/*     */     
/* 221 */     DeltaRecord dtr = new DeltaRecord(0.001D);
/* 222 */     this.outputFile.write((ByteData)dtr);
/*     */     
/* 224 */     SaveRecalcRecord srr = new SaveRecalcRecord(true);
/* 225 */     this.outputFile.write((ByteData)srr);
/*     */     
/* 227 */     PrintHeadersRecord phr = new PrintHeadersRecord(this.settings.getPrintHeaders());
/*     */     
/* 229 */     this.outputFile.write((ByteData)phr);
/*     */     
/* 231 */     PrintGridLinesRecord pglr = new PrintGridLinesRecord(this.settings.getPrintGridLines());
/*     */     
/* 233 */     this.outputFile.write((ByteData)pglr);
/*     */     
/* 235 */     GridSetRecord gsr = new GridSetRecord(true);
/* 236 */     this.outputFile.write((ByteData)gsr);
/*     */     
/* 238 */     GuttersRecord gutr = new GuttersRecord();
/* 239 */     this.outputFile.write((ByteData)gutr);
/*     */     
/* 241 */     DefaultRowHeightRecord drhr = new DefaultRowHeightRecord(this.settings.getDefaultRowHeight(), (this.settings.getDefaultRowHeight() != 255));
/*     */ 
/*     */     
/* 244 */     this.outputFile.write((ByteData)drhr);
/*     */     
/* 246 */     this.workspaceOptions.setFitToPages(this.settings.getFitToPages());
/* 247 */     this.outputFile.write((ByteData)this.workspaceOptions);
/*     */     
/* 249 */     if (this.rowBreaks.size() > 0) {
/*     */       
/* 251 */       int[] rb = new int[this.rowBreaks.size()];
/*     */       
/* 253 */       for (int i = 0; i < rb.length; i++)
/*     */       {
/* 255 */         rb[i] = ((Integer)this.rowBreaks.get(i)).intValue();
/*     */       }
/*     */       
/* 258 */       HorizontalPageBreaksRecord hpbr = new HorizontalPageBreaksRecord(rb);
/* 259 */       this.outputFile.write((ByteData)hpbr);
/*     */     } 
/*     */     
/* 262 */     HeaderRecord header = new HeaderRecord(this.settings.getHeader().toString());
/* 263 */     this.outputFile.write((ByteData)header);
/*     */     
/* 265 */     FooterRecord footer = new FooterRecord(this.settings.getFooter().toString());
/* 266 */     this.outputFile.write((ByteData)footer);
/*     */     
/* 268 */     HorizontalCentreRecord hcr = new HorizontalCentreRecord(this.settings.isHorizontalCentre());
/*     */     
/* 270 */     this.outputFile.write((ByteData)hcr);
/*     */     
/* 272 */     VerticalCentreRecord vcr = new VerticalCentreRecord(this.settings.isVerticalCentre());
/*     */     
/* 274 */     this.outputFile.write((ByteData)vcr);
/*     */ 
/*     */     
/* 277 */     if (this.settings.getLeftMargin() != this.settings.getDefaultWidthMargin()) {
/*     */       
/* 279 */       MarginRecord mr = new LeftMarginRecord(this.settings.getLeftMargin());
/* 280 */       this.outputFile.write((ByteData)mr);
/*     */     } 
/*     */     
/* 283 */     if (this.settings.getRightMargin() != this.settings.getDefaultWidthMargin()) {
/*     */       
/* 285 */       MarginRecord mr = new RightMarginRecord(this.settings.getRightMargin());
/* 286 */       this.outputFile.write((ByteData)mr);
/*     */     } 
/*     */     
/* 289 */     if (this.settings.getTopMargin() != this.settings.getDefaultHeightMargin()) {
/*     */       
/* 291 */       MarginRecord mr = new TopMarginRecord(this.settings.getTopMargin());
/* 292 */       this.outputFile.write((ByteData)mr);
/*     */     } 
/*     */     
/* 295 */     if (this.settings.getBottomMargin() != this.settings.getDefaultHeightMargin()) {
/*     */       
/* 297 */       MarginRecord mr = new BottomMarginRecord(this.settings.getBottomMargin());
/* 298 */       this.outputFile.write((ByteData)mr);
/*     */     } 
/*     */     
/* 301 */     if (this.plsRecord != null)
/*     */     {
/* 303 */       this.outputFile.write((ByteData)this.plsRecord);
/*     */     }
/*     */     
/* 306 */     SetupRecord setup = new SetupRecord(this.settings);
/* 307 */     this.outputFile.write((ByteData)setup);
/*     */     
/* 309 */     if (this.settings.isProtected()) {
/*     */       
/* 311 */       ProtectRecord pr = new ProtectRecord(this.settings.isProtected());
/* 312 */       this.outputFile.write((ByteData)pr);
/*     */       
/* 314 */       ScenarioProtectRecord spr = new ScenarioProtectRecord(this.settings.isProtected());
/*     */       
/* 316 */       this.outputFile.write((ByteData)spr);
/*     */       
/* 318 */       ObjectProtectRecord opr = new ObjectProtectRecord(this.settings.isProtected());
/*     */       
/* 320 */       this.outputFile.write((ByteData)opr);
/*     */       
/* 322 */       if (this.settings.getPassword() != null) {
/*     */         
/* 324 */         PasswordRecord pw = new PasswordRecord(this.settings.getPassword());
/* 325 */         this.outputFile.write((ByteData)pw);
/*     */       }
/* 327 */       else if (this.settings.getPasswordHash() != 0) {
/*     */         
/* 329 */         PasswordRecord pw = new PasswordRecord(this.settings.getPasswordHash());
/* 330 */         this.outputFile.write((ByteData)pw);
/*     */       } 
/*     */     } 
/*     */     
/* 334 */     indexRecord.setDataStartPosition(this.outputFile.getPos());
/* 335 */     DefaultColumnWidth dcw = new DefaultColumnWidth(this.settings.getDefaultColumnWidth());
/*     */     
/* 337 */     this.outputFile.write((ByteData)dcw);
/*     */ 
/*     */     
/* 340 */     WritableCellFormat normalStyle = this.sheet.getWorkbook().getStyles().getNormalStyle();
/*     */     
/* 342 */     WritableCellFormat defaultDateFormat = this.sheet.getWorkbook().getStyles().getDefaultDateFormat();
/*     */ 
/*     */ 
/*     */     
/* 346 */     ColumnInfoRecord cir = null;
/* 347 */     int tmpi = 0;
/* 348 */     for (Iterator colit = this.columnFormats.iterator(); colit.hasNext(); ) {
/*     */       
/* 350 */       cir = colit.next();
/*     */ 
/*     */       
/* 353 */       if (cir.getColumn() < 256)
/*     */       {
/* 355 */         this.outputFile.write((ByteData)cir);
/*     */       }
/*     */       
/* 358 */       XFRecord xfr = cir.getCellFormat();
/*     */       
/* 360 */       if (xfr != normalStyle && cir.getColumn() < 256) {
/*     */ 
/*     */         
/* 363 */         Cell[] cells = getColumn(cir.getColumn());
/*     */         
/* 365 */         for (int i = 0; i < cells.length; i++) {
/*     */           
/* 367 */           if (cells[i] != null && (cells[i].getCellFormat() == normalStyle || cells[i].getCellFormat() == defaultDateFormat))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 373 */             ((WritableCell)cells[i]).setCellFormat((CellFormat)xfr);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 379 */     DimensionRecord dr = new DimensionRecord(this.numRows, this.numCols);
/* 380 */     this.outputFile.write((ByteData)dr);
/*     */ 
/*     */     
/* 383 */     for (int block = 0; block < numBlocks; block++) {
/*     */       
/* 385 */       DBCellRecord dbcell = new DBCellRecord(this.outputFile.getPos());
/*     */       
/* 387 */       int blockRows = Math.min(32, this.numRows - block * 32);
/* 388 */       boolean firstRow = true;
/*     */       
/*     */       int i;
/* 391 */       for (i = block * 32; i < block * 32 + blockRows; i++) {
/*     */         
/* 393 */         if (this.rows[i] != null) {
/*     */           
/* 395 */           this.rows[i].write(this.outputFile);
/* 396 */           if (firstRow) {
/*     */             
/* 398 */             dbcell.setCellOffset(this.outputFile.getPos());
/* 399 */             firstRow = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 405 */       for (i = block * 32; i < block * 32 + blockRows; i++) {
/*     */         
/* 407 */         if (this.rows[i] != null) {
/*     */           
/* 409 */           dbcell.addCellRowPosition(this.outputFile.getPos());
/* 410 */           this.rows[i].writeCells(this.outputFile);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 415 */       indexRecord.addBlockPosition(this.outputFile.getPos());
/*     */ 
/*     */ 
/*     */       
/* 419 */       dbcell.setPosition(this.outputFile.getPos());
/* 420 */       this.outputFile.write((ByteData)dbcell);
/*     */     } 
/*     */ 
/*     */     
/* 424 */     if (this.dataValidation != null)
/*     */     {
/* 426 */       this.dataValidation.write(this.outputFile);
/*     */     }
/*     */ 
/*     */     
/* 430 */     if (!this.workbookSettings.getDrawingsDisabled())
/*     */     {
/* 432 */       this.drawingWriter.write(this.outputFile);
/*     */     }
/*     */     
/* 435 */     Window2Record w2r = new Window2Record(this.settings);
/* 436 */     this.outputFile.write((ByteData)w2r);
/*     */ 
/*     */     
/* 439 */     if (this.settings.getHorizontalFreeze() != 0 || this.settings.getVerticalFreeze() != 0) {
/*     */ 
/*     */       
/* 442 */       PaneRecord pr = new PaneRecord(this.settings.getHorizontalFreeze(), this.settings.getVerticalFreeze());
/*     */       
/* 444 */       this.outputFile.write((ByteData)pr);
/*     */ 
/*     */       
/* 447 */       SelectionRecord sr = new SelectionRecord(SelectionRecord.upperLeft, 0, 0);
/*     */       
/* 449 */       this.outputFile.write((ByteData)sr);
/*     */ 
/*     */       
/* 452 */       if (this.settings.getHorizontalFreeze() != 0) {
/*     */         
/* 454 */         sr = new SelectionRecord(SelectionRecord.upperRight, this.settings.getHorizontalFreeze(), 0);
/*     */         
/* 456 */         this.outputFile.write((ByteData)sr);
/*     */       } 
/*     */ 
/*     */       
/* 460 */       if (this.settings.getVerticalFreeze() != 0) {
/*     */         
/* 462 */         sr = new SelectionRecord(SelectionRecord.lowerLeft, 0, this.settings.getVerticalFreeze());
/*     */         
/* 464 */         this.outputFile.write((ByteData)sr);
/*     */       } 
/*     */ 
/*     */       
/* 468 */       if (this.settings.getHorizontalFreeze() != 0 && this.settings.getVerticalFreeze() != 0) {
/*     */ 
/*     */         
/* 471 */         sr = new SelectionRecord(SelectionRecord.lowerRight, this.settings.getHorizontalFreeze(), this.settings.getVerticalFreeze());
/*     */ 
/*     */ 
/*     */         
/* 475 */         this.outputFile.write((ByteData)sr);
/*     */       } 
/*     */       
/* 478 */       Weird1Record w1r = new Weird1Record();
/* 479 */       this.outputFile.write((ByteData)w1r);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 485 */       SelectionRecord sr = new SelectionRecord(SelectionRecord.upperLeft, 0, 0);
/*     */       
/* 487 */       this.outputFile.write((ByteData)sr);
/*     */     } 
/*     */ 
/*     */     
/* 491 */     if (this.settings.getZoomFactor() != 100) {
/*     */       
/* 493 */       SCLRecord sclr = new SCLRecord(this.settings.getZoomFactor());
/* 494 */       this.outputFile.write((ByteData)sclr);
/*     */     } 
/*     */ 
/*     */     
/* 498 */     this.mergedCells.write(this.outputFile);
/*     */ 
/*     */     
/* 501 */     Iterator hi = this.hyperlinks.iterator();
/* 502 */     WritableHyperlink hlr = null;
/* 503 */     while (hi.hasNext()) {
/*     */       
/* 505 */       hlr = hi.next();
/* 506 */       this.outputFile.write((ByteData)hlr);
/*     */     } 
/*     */     
/* 509 */     if (this.buttonPropertySet != null)
/*     */     {
/* 511 */       this.outputFile.write((ByteData)this.buttonPropertySet);
/*     */     }
/*     */ 
/*     */     
/* 515 */     EOFRecord eof = new EOFRecord();
/* 516 */     this.outputFile.write((ByteData)eof);
/*     */ 
/*     */ 
/*     */     
/* 520 */     this.outputFile.setData(indexRecord.getData(), indexPos + 4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final HeaderRecord getHeader() {
/* 530 */     return this.header;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final FooterRecord getFooter() {
/* 540 */     return this.footer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setWriteData(RowRecord[] rws, ArrayList rb, ArrayList hl, MergedCells mc, TreeSet cf) {
/* 555 */     this.rows = rws;
/* 556 */     this.rowBreaks = rb;
/* 557 */     this.hyperlinks = hl;
/* 558 */     this.mergedCells = mc;
/* 559 */     this.columnFormats = cf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setDimensions(int rws, int cls) {
/* 571 */     this.numRows = rws;
/* 572 */     this.numCols = cls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSettings(SheetSettings sr) {
/* 583 */     this.settings = sr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WorkspaceInformationRecord getWorkspaceOptions() {
/* 593 */     return this.workspaceOptions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setWorkspaceOptions(WorkspaceInformationRecord wo) {
/* 603 */     if (wo != null)
/*     */     {
/* 605 */       this.workspaceOptions = wo;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setCharts(Chart[] ch) {
/* 617 */     this.drawingWriter.setCharts(ch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setDrawings(ArrayList dr, boolean mod) {
/* 628 */     this.drawingWriter.setDrawings(dr, mod);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Chart[] getCharts() {
/* 638 */     return this.drawingWriter.getCharts();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void checkMergedBorders() {
/* 649 */     Range[] mcells = this.mergedCells.getMergedCells();
/* 650 */     ArrayList borderFormats = new ArrayList();
/* 651 */     for (int mci = 0; mci < mcells.length; mci++) {
/*     */       
/* 653 */       Range range = mcells[mci];
/* 654 */       Cell topLeft = range.getTopLeft();
/* 655 */       XFRecord tlformat = (XFRecord)topLeft.getCellFormat();
/*     */       
/* 657 */       if (tlformat != null && tlformat.hasBorders() == true && !tlformat.isRead()) {
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */           
/* 663 */           CellXFRecord cf1 = new CellXFRecord(tlformat);
/* 664 */           Cell bottomRight = range.getBottomRight();
/*     */           
/* 666 */           cf1.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/* 667 */           cf1.setBorder(Border.LEFT, tlformat.getBorderLine(Border.LEFT), tlformat.getBorderColour(Border.LEFT));
/*     */ 
/*     */           
/* 670 */           cf1.setBorder(Border.TOP, tlformat.getBorderLine(Border.TOP), tlformat.getBorderColour(Border.TOP));
/*     */ 
/*     */ 
/*     */           
/* 674 */           if (topLeft.getRow() == bottomRight.getRow())
/*     */           {
/* 676 */             cf1.setBorder(Border.BOTTOM, tlformat.getBorderLine(Border.BOTTOM), tlformat.getBorderColour(Border.BOTTOM));
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 681 */           if (topLeft.getColumn() == bottomRight.getColumn())
/*     */           {
/* 683 */             cf1.setBorder(Border.RIGHT, tlformat.getBorderLine(Border.RIGHT), tlformat.getBorderColour(Border.RIGHT));
/*     */           }
/*     */ 
/*     */ 
/*     */           
/* 688 */           int index = borderFormats.indexOf(cf1);
/* 689 */           if (index != -1) {
/*     */             
/* 691 */             cf1 = borderFormats.get(index);
/*     */           }
/*     */           else {
/*     */             
/* 695 */             borderFormats.add(cf1);
/*     */           } 
/* 697 */           ((WritableCell)topLeft).setCellFormat((CellFormat)cf1);
/*     */ 
/*     */           
/* 700 */           if (bottomRight.getRow() > topLeft.getRow()) {
/*     */ 
/*     */             
/* 703 */             if (bottomRight.getColumn() != topLeft.getColumn()) {
/*     */               
/* 705 */               CellXFRecord cf2 = new CellXFRecord(tlformat);
/* 706 */               cf2.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/* 707 */               cf2.setBorder(Border.LEFT, tlformat.getBorderLine(Border.LEFT), tlformat.getBorderColour(Border.LEFT));
/*     */ 
/*     */               
/* 710 */               cf2.setBorder(Border.BOTTOM, tlformat.getBorderLine(Border.BOTTOM), tlformat.getBorderColour(Border.BOTTOM));
/*     */ 
/*     */ 
/*     */               
/* 714 */               index = borderFormats.indexOf(cf2);
/* 715 */               if (index != -1) {
/*     */                 
/* 717 */                 cf2 = borderFormats.get(index);
/*     */               }
/*     */               else {
/*     */                 
/* 721 */                 borderFormats.add(cf2);
/*     */               } 
/*     */               
/* 724 */               this.sheet.addCell((WritableCell)new Blank(topLeft.getColumn(), bottomRight.getRow(), (CellFormat)cf2));
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 730 */             for (int i = topLeft.getRow() + 1; i < bottomRight.getRow(); i++) {
/*     */               
/* 732 */               CellXFRecord cf3 = new CellXFRecord(tlformat);
/* 733 */               cf3.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/* 734 */               cf3.setBorder(Border.LEFT, tlformat.getBorderLine(Border.LEFT), tlformat.getBorderColour(Border.LEFT));
/*     */ 
/*     */ 
/*     */               
/* 738 */               if (topLeft.getColumn() == bottomRight.getColumn())
/*     */               {
/* 740 */                 cf3.setBorder(Border.RIGHT, tlformat.getBorderLine(Border.RIGHT), tlformat.getBorderColour(Border.RIGHT));
/*     */               }
/*     */ 
/*     */ 
/*     */               
/* 745 */               index = borderFormats.indexOf(cf3);
/* 746 */               if (index != -1) {
/*     */                 
/* 748 */                 cf3 = borderFormats.get(index);
/*     */               }
/*     */               else {
/*     */                 
/* 752 */                 borderFormats.add(cf3);
/*     */               } 
/*     */               
/* 755 */               this.sheet.addCell((WritableCell)new Blank(topLeft.getColumn(), i, (CellFormat)cf3));
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 760 */           if (bottomRight.getColumn() > topLeft.getColumn()) {
/*     */             
/* 762 */             if (bottomRight.getRow() != topLeft.getRow()) {
/*     */ 
/*     */               
/* 765 */               CellXFRecord cf6 = new CellXFRecord(tlformat);
/* 766 */               cf6.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/* 767 */               cf6.setBorder(Border.RIGHT, tlformat.getBorderLine(Border.RIGHT), tlformat.getBorderColour(Border.RIGHT));
/*     */ 
/*     */               
/* 770 */               cf6.setBorder(Border.TOP, tlformat.getBorderLine(Border.TOP), tlformat.getBorderColour(Border.TOP));
/*     */ 
/*     */               
/* 773 */               index = borderFormats.indexOf(cf6);
/* 774 */               if (index != -1) {
/*     */                 
/* 776 */                 cf6 = borderFormats.get(index);
/*     */               }
/*     */               else {
/*     */                 
/* 780 */                 borderFormats.add(cf6);
/*     */               } 
/*     */               
/* 783 */               this.sheet.addCell((WritableCell)new Blank(bottomRight.getColumn(), topLeft.getRow(), (CellFormat)cf6));
/*     */             } 
/*     */ 
/*     */ 
/*     */             
/* 788 */             int i = topLeft.getRow() + 1;
/* 789 */             for (; i < bottomRight.getRow(); i++) {
/*     */               
/* 791 */               CellXFRecord cf7 = new CellXFRecord(tlformat);
/* 792 */               cf7.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/* 793 */               cf7.setBorder(Border.RIGHT, tlformat.getBorderLine(Border.RIGHT), tlformat.getBorderColour(Border.RIGHT));
/*     */ 
/*     */ 
/*     */               
/* 797 */               index = borderFormats.indexOf(cf7);
/* 798 */               if (index != -1) {
/*     */                 
/* 800 */                 cf7 = borderFormats.get(index);
/*     */               }
/*     */               else {
/*     */                 
/* 804 */                 borderFormats.add(cf7);
/*     */               } 
/*     */               
/* 807 */               this.sheet.addCell((WritableCell)new Blank(bottomRight.getColumn(), i, (CellFormat)cf7));
/*     */             } 
/*     */ 
/*     */             
/* 811 */             i = topLeft.getColumn() + 1;
/* 812 */             for (; i < bottomRight.getColumn(); i++) {
/*     */               
/* 814 */               CellXFRecord cf8 = new CellXFRecord(tlformat);
/* 815 */               cf8.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/* 816 */               cf8.setBorder(Border.TOP, tlformat.getBorderLine(Border.TOP), tlformat.getBorderColour(Border.TOP));
/*     */ 
/*     */ 
/*     */               
/* 820 */               if (topLeft.getRow() == bottomRight.getRow())
/*     */               {
/* 822 */                 cf8.setBorder(Border.BOTTOM, tlformat.getBorderLine(Border.BOTTOM), tlformat.getBorderColour(Border.BOTTOM));
/*     */               }
/*     */ 
/*     */ 
/*     */               
/* 827 */               index = borderFormats.indexOf(cf8);
/* 828 */               if (index != -1) {
/*     */                 
/* 830 */                 cf8 = borderFormats.get(index);
/*     */               }
/*     */               else {
/*     */                 
/* 834 */                 borderFormats.add(cf8);
/*     */               } 
/*     */               
/* 837 */               this.sheet.addCell((WritableCell)new Blank(i, topLeft.getRow(), (CellFormat)cf8));
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 842 */           if (bottomRight.getColumn() > topLeft.getColumn() || bottomRight.getRow() > topLeft.getRow()) {
/*     */ 
/*     */ 
/*     */             
/* 846 */             CellXFRecord cf4 = new CellXFRecord(tlformat);
/* 847 */             cf4.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/* 848 */             cf4.setBorder(Border.RIGHT, tlformat.getBorderLine(Border.RIGHT), tlformat.getBorderColour(Border.RIGHT));
/*     */ 
/*     */             
/* 851 */             cf4.setBorder(Border.BOTTOM, tlformat.getBorderLine(Border.BOTTOM), tlformat.getBorderColour(Border.BOTTOM));
/*     */ 
/*     */ 
/*     */             
/* 855 */             if (bottomRight.getRow() == topLeft.getRow())
/*     */             {
/* 857 */               cf4.setBorder(Border.TOP, tlformat.getBorderLine(Border.TOP), tlformat.getBorderColour(Border.TOP));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 862 */             if (bottomRight.getColumn() == topLeft.getColumn())
/*     */             {
/* 864 */               cf4.setBorder(Border.LEFT, tlformat.getBorderLine(Border.LEFT), tlformat.getBorderColour(Border.LEFT));
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 869 */             index = borderFormats.indexOf(cf4);
/* 870 */             if (index != -1) {
/*     */               
/* 872 */               cf4 = borderFormats.get(index);
/*     */             }
/*     */             else {
/*     */               
/* 876 */               borderFormats.add(cf4);
/*     */             } 
/*     */             
/* 879 */             this.sheet.addCell((WritableCell)new Blank(bottomRight.getColumn(), bottomRight.getRow(), (CellFormat)cf4));
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 884 */             int i = topLeft.getColumn() + 1;
/* 885 */             for (; i < bottomRight.getColumn(); i++)
/*     */             {
/* 887 */               CellXFRecord cf5 = new CellXFRecord(tlformat);
/* 888 */               cf5.setBorder(Border.ALL, BorderLineStyle.NONE, Colour.BLACK);
/* 889 */               cf5.setBorder(Border.BOTTOM, tlformat.getBorderLine(Border.BOTTOM), tlformat.getBorderColour(Border.BOTTOM));
/*     */ 
/*     */ 
/*     */               
/* 893 */               if (topLeft.getRow() == bottomRight.getRow())
/*     */               {
/* 895 */                 cf5.setBorder(Border.TOP, tlformat.getBorderLine(Border.TOP), tlformat.getBorderColour(Border.TOP));
/*     */               }
/*     */ 
/*     */ 
/*     */               
/* 900 */               index = borderFormats.indexOf(cf5);
/* 901 */               if (index != -1) {
/*     */                 
/* 903 */                 cf5 = borderFormats.get(index);
/*     */               }
/*     */               else {
/*     */                 
/* 907 */                 borderFormats.add(cf5);
/*     */               } 
/*     */               
/* 910 */               this.sheet.addCell((WritableCell)new Blank(i, bottomRight.getRow(), (CellFormat)cf5));
/*     */             }
/*     */           
/*     */           } 
/* 914 */         } catch (WriteException e) {
/*     */ 
/*     */           
/* 917 */           logger.warn(e.toString());
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Cell[] getColumn(int col) {
/* 931 */     boolean found = false;
/* 932 */     int row = this.numRows - 1;
/*     */     
/* 934 */     while (row >= 0 && !found) {
/*     */       
/* 936 */       if (this.rows[row] != null && this.rows[row].getCell(col) != null) {
/*     */ 
/*     */         
/* 939 */         found = true;
/*     */         
/*     */         continue;
/*     */       } 
/* 943 */       row--;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 948 */     Cell[] cells = new Cell[row + 1];
/*     */     
/* 950 */     for (int i = 0; i <= row; i++)
/*     */     {
/* 952 */       cells[i] = (this.rows[i] != null) ? (Cell)this.rows[i].getCell(col) : null;
/*     */     }
/*     */     
/* 955 */     return cells;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setChartOnly() {
/* 963 */     this.chartOnly = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setPLS(PLSRecord pls) {
/* 973 */     this.plsRecord = pls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setButtonPropertySet(ButtonPropertySetRecord bps) {
/* 983 */     this.buttonPropertySet = bps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setDataValidation(DataValidation dv) {
/* 993 */     this.dataValidation = dv;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\SheetWriter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
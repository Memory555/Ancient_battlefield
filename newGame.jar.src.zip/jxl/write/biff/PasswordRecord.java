/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PasswordRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private String password;
/*     */   private byte[] data;
/*     */   
/*     */   public PasswordRecord(String pw) {
/*  50 */     super(Type.PASSWORD);
/*     */     
/*  52 */     this.password = pw;
/*     */     
/*  54 */     if (pw == null) {
/*     */       
/*  56 */       this.data = new byte[2];
/*  57 */       IntegerHelper.getTwoBytes(0, this.data, 0);
/*     */     }
/*     */     else {
/*     */       
/*  61 */       byte[] passwordBytes = pw.getBytes();
/*  62 */       int passwordHash = 0;
/*  63 */       for (int a = 0; a < passwordBytes.length; a++) {
/*     */         
/*  65 */         int shifted = rotLeft15Bit(passwordBytes[a], a + 1);
/*  66 */         passwordHash ^= shifted;
/*     */       } 
/*  68 */       passwordHash ^= passwordBytes.length;
/*  69 */       passwordHash ^= 0xCE4B;
/*     */       
/*  71 */       this.data = new byte[2];
/*  72 */       IntegerHelper.getTwoBytes(passwordHash, this.data, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PasswordRecord(int ph) {
/*  83 */     super(Type.PASSWORD);
/*     */     
/*  85 */     this.data = new byte[2];
/*  86 */     IntegerHelper.getTwoBytes(ph, this.data, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/*  96 */     return this.data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int rotLeft15Bit(int val, int rotate) {
/* 108 */     val &= 0x7FFF;
/*     */     
/* 110 */     for (; rotate > 0; rotate--) {
/*     */       
/* 112 */       if ((val & 0x4000) != 0) {
/*     */         
/* 114 */         val = (val << 1 & 0x7FFF) + 1;
/*     */       }
/*     */       else {
/*     */         
/* 118 */         val = val << 1 & 0x7FFF;
/*     */       } 
/*     */     } 
/*     */     
/* 122 */     return val;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\PasswordRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
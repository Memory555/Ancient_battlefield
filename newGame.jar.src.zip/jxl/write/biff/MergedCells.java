/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Assert;
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.Range;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.biff.SheetRangeImpl;
/*     */ import jxl.write.Blank;
/*     */ import jxl.write.WritableCell;
/*     */ import jxl.write.WritableSheet;
/*     */ import jxl.write.WriteException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MergedCells
/*     */ {
/*  46 */   private static Logger logger = Logger.getLogger(MergedCells.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList ranges;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WritableSheet sheet;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int maxRangesPerSheet = 1020;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MergedCells(WritableSheet ws) {
/*  68 */     this.ranges = new ArrayList();
/*  69 */     this.sheet = ws;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void add(Range r) {
/*  80 */     this.ranges.add(r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void insertRow(int row) {
/*  89 */     SheetRangeImpl sr = null;
/*  90 */     Iterator i = this.ranges.iterator();
/*  91 */     while (i.hasNext()) {
/*     */       
/*  93 */       sr = i.next();
/*  94 */       sr.insertRow(row);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void insertColumn(int col) {
/* 103 */     SheetRangeImpl sr = null;
/* 104 */     Iterator i = this.ranges.iterator();
/* 105 */     while (i.hasNext()) {
/*     */       
/* 107 */       sr = i.next();
/* 108 */       sr.insertColumn(col);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeColumn(int col) {
/* 117 */     SheetRangeImpl sr = null;
/* 118 */     Iterator i = this.ranges.iterator();
/* 119 */     while (i.hasNext()) {
/*     */       
/* 121 */       sr = i.next();
/* 122 */       if (sr.getTopLeft().getColumn() == col && sr.getBottomRight().getColumn() == col) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 127 */         this.ranges.remove(this.ranges.indexOf(sr));
/*     */         
/*     */         continue;
/*     */       } 
/* 131 */       sr.removeColumn(col);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeRow(int row) {
/* 141 */     SheetRangeImpl sr = null;
/* 142 */     Iterator i = this.ranges.iterator();
/* 143 */     while (i.hasNext()) {
/*     */       
/* 145 */       sr = i.next();
/* 146 */       if (sr.getTopLeft().getRow() == row && sr.getBottomRight().getRow() == row) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 151 */         i.remove();
/*     */         
/*     */         continue;
/*     */       } 
/* 155 */       sr.removeRow(row);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Range[] getMergedCells() {
/* 167 */     Range[] cells = new Range[this.ranges.size()];
/*     */     
/* 169 */     for (int i = 0; i < cells.length; i++)
/*     */     {
/* 171 */       cells[i] = this.ranges.get(i);
/*     */     }
/*     */     
/* 174 */     return cells;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unmergeCells(Range r) {
/* 185 */     int index = this.ranges.indexOf(r);
/*     */     
/* 187 */     if (index != -1)
/*     */     {
/* 189 */       this.ranges.remove(index);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void checkIntersections() {
/* 198 */     ArrayList newcells = new ArrayList(this.ranges.size());
/*     */     
/* 200 */     for (Iterator mci = this.ranges.iterator(); mci.hasNext(); ) {
/*     */       
/* 202 */       SheetRangeImpl r = mci.next();
/*     */ 
/*     */       
/* 205 */       Iterator i = newcells.iterator();
/* 206 */       SheetRangeImpl range = null;
/* 207 */       boolean intersects = false;
/* 208 */       while (i.hasNext() && !intersects) {
/*     */         
/* 210 */         range = i.next();
/*     */         
/* 212 */         if (range.intersects(r)) {
/*     */           
/* 214 */           logger.warn("Could not merge cells " + r + " as they clash with an existing set of merged cells.");
/*     */ 
/*     */           
/* 217 */           intersects = true;
/*     */         } 
/*     */       } 
/*     */       
/* 221 */       if (!intersects)
/*     */       {
/* 223 */         newcells.add(r);
/*     */       }
/*     */     } 
/*     */     
/* 227 */     this.ranges = newcells;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkRanges() {
/*     */     try {
/* 238 */       SheetRangeImpl range = null;
/*     */ 
/*     */       
/* 241 */       for (int i = 0; i < this.ranges.size(); i++) {
/*     */         
/* 243 */         range = this.ranges.get(i);
/*     */ 
/*     */         
/* 246 */         Cell tl = range.getTopLeft();
/* 247 */         Cell br = range.getBottomRight();
/* 248 */         boolean found = false;
/*     */         
/* 250 */         for (int c = tl.getColumn(); c <= br.getColumn(); c++) {
/*     */           
/* 252 */           for (int r = tl.getRow(); r <= br.getRow(); r++) {
/*     */             
/* 254 */             Cell cell = this.sheet.getCell(c, r);
/* 255 */             if (cell.getType() != CellType.EMPTY)
/*     */             {
/* 257 */               if (!found)
/*     */               {
/* 259 */                 found = true;
/*     */               }
/*     */               else
/*     */               {
/* 263 */                 logger.warn("Range " + range + " contains more than one data cell.  " + "Setting the other cells to blank.");
/*     */ 
/*     */                 
/* 266 */                 Blank b = new Blank(c, r);
/* 267 */                 this.sheet.addCell((WritableCell)b);
/*     */               }
/*     */             
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/* 274 */     } catch (WriteException e) {
/*     */ 
/*     */       
/* 277 */       Assert.verify(false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void write(File outputFile) throws IOException {
/* 283 */     if (this.ranges.size() == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 288 */     checkIntersections();
/* 289 */     checkRanges();
/*     */ 
/*     */ 
/*     */     
/* 293 */     if (this.ranges.size() < 1020) {
/*     */       
/* 295 */       MergedCellsRecord mcr = new MergedCellsRecord(this.ranges);
/* 296 */       outputFile.write((ByteData)mcr);
/*     */       
/*     */       return;
/*     */     } 
/* 300 */     int numRecordsRequired = this.ranges.size() / 1020 + 1;
/* 301 */     int pos = 0;
/*     */     
/* 303 */     for (int i = 0; i < numRecordsRequired; i++) {
/*     */       
/* 305 */       int numranges = Math.min(1020, this.ranges.size() - pos);
/*     */       
/* 307 */       ArrayList cells = new ArrayList(numranges);
/* 308 */       for (int j = 0; j < numranges; j++)
/*     */       {
/* 310 */         cells.add(this.ranges.get(pos + j));
/*     */       }
/*     */       
/* 313 */       MergedCellsRecord mcr = new MergedCellsRecord(cells);
/* 314 */       outputFile.write((ByteData)mcr);
/*     */       
/* 316 */       pos += numranges;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\MergedCells.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.SheetSettings;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Window2Record
/*     */   extends WritableRecordData
/*     */ {
/*     */   private byte[] data;
/*     */   
/*     */   public Window2Record(SheetSettings settings) {
/*  43 */     super(Type.WINDOW2);
/*     */     
/*  45 */     int selected = settings.isSelected() ? 6 : 0;
/*     */     
/*  47 */     int options = 0;
/*     */     
/*  49 */     options |= 0x0;
/*     */     
/*  51 */     if (settings.getShowGridLines())
/*     */     {
/*  53 */       options |= 0x2;
/*     */     }
/*     */     
/*  56 */     options |= 0x4;
/*     */     
/*  58 */     options |= 0x0;
/*     */     
/*  60 */     if (settings.getDisplayZeroValues())
/*     */     {
/*  62 */       options |= 0x10;
/*     */     }
/*     */     
/*  65 */     options |= 0x20;
/*     */     
/*  67 */     options |= 0x80;
/*     */ 
/*     */     
/*  70 */     if (settings.getHorizontalFreeze() != 0 || settings.getVerticalFreeze() != 0) {
/*     */ 
/*     */       
/*  73 */       options |= 0x8;
/*  74 */       selected |= 0x1;
/*     */     } 
/*     */ 
/*     */     
/*  78 */     this.data = new byte[] { (byte)options, (byte)selected, 0, 0, 0, 0, 64, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 106 */     return this.data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\Window2Record.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
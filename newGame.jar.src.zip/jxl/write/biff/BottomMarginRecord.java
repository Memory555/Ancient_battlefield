/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.Type;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BottomMarginRecord
/*    */   extends MarginRecord
/*    */ {
/*    */   BottomMarginRecord(double v) {
/* 31 */     super(Type.BOTTOMMARGIN, v);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\BottomMarginRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
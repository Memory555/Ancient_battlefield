/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CalcModeRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private CalcMode calculationMode;
/*    */   
/*    */   private static class CalcMode
/*    */   {
/*    */     int value;
/*    */     
/*    */     public CalcMode(int m) {
/* 52 */       this.value = m;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 59 */   static CalcMode manual = new CalcMode(0);
/*    */ 
/*    */ 
/*    */   
/* 63 */   static CalcMode automatic = new CalcMode(1);
/*    */ 
/*    */ 
/*    */   
/* 67 */   static CalcMode automaticNoTables = new CalcMode(-1);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CalcModeRecord(CalcMode cm) {
/* 76 */     super(Type.CALCMODE);
/* 77 */     this.calculationMode = cm;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 88 */     byte[] data = new byte[2];
/*    */     
/* 90 */     IntegerHelper.getTwoBytes(this.calculationMode.value, data, 0);
/*    */     
/* 92 */     return data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\CalcModeRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
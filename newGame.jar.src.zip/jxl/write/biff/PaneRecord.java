/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PaneRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private int rowsVisible;
/*     */   private int columnsVisible;
/*     */   private static final int topLeftPane = 3;
/*     */   private static final int bottomLeftPane = 2;
/*     */   private static final int topRightPane = 1;
/*     */   private static final int bottomRightPane = 0;
/*     */   
/*     */   public PaneRecord(int cols, int rows) {
/*  58 */     super(Type.PANE);
/*     */     
/*  60 */     this.rowsVisible = rows;
/*  61 */     this.columnsVisible = cols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/*  71 */     byte[] data = new byte[10];
/*     */ 
/*     */     
/*  74 */     IntegerHelper.getTwoBytes(this.columnsVisible, data, 0);
/*     */ 
/*     */     
/*  77 */     IntegerHelper.getTwoBytes(this.rowsVisible, data, 2);
/*     */ 
/*     */     
/*  80 */     if (this.rowsVisible > 0)
/*     */     {
/*  82 */       IntegerHelper.getTwoBytes(this.rowsVisible, data, 4);
/*     */     }
/*     */ 
/*     */     
/*  86 */     if (this.columnsVisible > 0)
/*     */     {
/*  88 */       IntegerHelper.getTwoBytes(this.columnsVisible, data, 6);
/*     */     }
/*     */ 
/*     */     
/*  92 */     int activePane = 3;
/*     */     
/*  94 */     if (this.rowsVisible > 0 && this.columnsVisible == 0) {
/*     */       
/*  96 */       activePane = 2;
/*     */     }
/*  98 */     else if (this.rowsVisible == 0 && this.columnsVisible > 0) {
/*     */       
/* 100 */       activePane = 1;
/*     */     }
/* 102 */     else if (this.rowsVisible > 0 && this.columnsVisible > 0) {
/*     */       
/* 104 */       activePane = 0;
/*     */     } 
/*     */     
/* 107 */     IntegerHelper.getTwoBytes(activePane, data, 8);
/*     */     
/* 109 */     return data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\PaneRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
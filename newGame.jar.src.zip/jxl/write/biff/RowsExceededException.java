/*    */ package jxl.write.biff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RowsExceededException
/*    */   extends JxlWriteException
/*    */ {
/*    */   public RowsExceededException() {
/* 35 */     super(maxRowsExceeded);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\RowsExceededException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
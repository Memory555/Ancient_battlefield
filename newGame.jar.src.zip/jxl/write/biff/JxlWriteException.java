/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.write.WriteException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JxlWriteException
/*    */   extends WriteException
/*    */ {
/*    */   private static class WriteMessage
/*    */   {
/*    */     public String message;
/*    */     
/*    */     WriteMessage(String m) {
/* 39 */       this.message = m;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/* 44 */   static WriteMessage formatInitialized = new WriteMessage("Attempt to modify a referenced format");
/*    */ 
/*    */ 
/*    */   
/* 48 */   static WriteMessage cellReferenced = new WriteMessage("Cell has already been added to a worksheet");
/*    */ 
/*    */   
/* 51 */   static WriteMessage maxRowsExceeded = new WriteMessage("The maximum number of rows permitted on a worksheet been exceeded");
/*    */ 
/*    */ 
/*    */   
/* 55 */   static WriteMessage maxColumnsExceeded = new WriteMessage("The maximum number of columns permitted on a worksheet has been exceeded");
/*    */ 
/*    */ 
/*    */   
/* 59 */   static WriteMessage copyPropertySets = new WriteMessage("Error encounted when copying additional property sets");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public JxlWriteException(WriteMessage m) {
/* 69 */     super(m.message);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\JxlWriteException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.text.NumberFormat;
/*     */ import jxl.Cell;
/*     */ import jxl.CellType;
/*     */ import jxl.NumberCell;
/*     */ import jxl.biff.DoubleHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.format.CellFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class NumberRecord
/*     */   extends CellValue
/*     */ {
/*     */   private double value;
/*     */   
/*     */   protected NumberRecord(int c, int r, double val) {
/*  50 */     super(Type.NUMBER, c, r);
/*  51 */     this.value = val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NumberRecord(int c, int r, double val, CellFormat st) {
/*  65 */     super(Type.NUMBER, c, r, st);
/*  66 */     this.value = val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NumberRecord(NumberCell nc) {
/*  76 */     super(Type.NUMBER, (Cell)nc);
/*  77 */     this.value = nc.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NumberRecord(int c, int r, NumberRecord nr) {
/*  89 */     super(Type.NUMBER, c, r, nr);
/*  90 */     this.value = nr.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CellType getType() {
/* 100 */     return CellType.NUMBER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 110 */     byte[] celldata = super.getData();
/* 111 */     byte[] data = new byte[celldata.length + 8];
/* 112 */     System.arraycopy(celldata, 0, data, 0, celldata.length);
/* 113 */     DoubleHelper.getIEEEBytes(this.value, data, celldata.length);
/*     */     
/* 115 */     return data;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getContents() {
/* 127 */     return Double.toString(this.value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public double getValue() {
/* 137 */     return this.value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(double val) {
/* 147 */     this.value = val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NumberFormat getNumberFormat() {
/* 158 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\NumberRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
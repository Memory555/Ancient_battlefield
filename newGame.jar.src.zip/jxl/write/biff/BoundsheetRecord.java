/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BoundsheetRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private boolean hidden;
/*     */   private boolean chartOnly;
/*     */   private String name;
/*     */   private byte[] data;
/*     */   
/*     */   public BoundsheetRecord(String n) {
/*  60 */     super(Type.BOUNDSHEET);
/*  61 */     this.name = n;
/*  62 */     this.hidden = false;
/*  63 */     this.chartOnly = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setHidden() {
/*  71 */     this.hidden = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setChartOnly() {
/*  79 */     this.chartOnly = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/*  89 */     this.data = new byte[this.name.length() * 2 + 8];
/*     */     
/*  91 */     if (this.chartOnly) {
/*     */       
/*  93 */       this.data[5] = 2;
/*     */     }
/*     */     else {
/*     */       
/*  97 */       this.data[5] = 0;
/*     */     } 
/*     */     
/* 100 */     if (this.hidden) {
/*     */       
/* 102 */       this.data[4] = 1;
/* 103 */       this.data[5] = 0;
/*     */     } 
/*     */     
/* 106 */     this.data[6] = (byte)this.name.length();
/* 107 */     this.data[7] = 1;
/* 108 */     StringHelper.getUnicodeBytes(this.name, this.data, 8);
/*     */     
/* 110 */     return this.data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\BoundsheetRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
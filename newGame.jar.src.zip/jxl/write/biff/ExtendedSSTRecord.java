/*     */ package jxl.write.biff;
/*     */ 
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExtendedSSTRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private static final int infoRecordSize = 8;
/*     */   private int numberOfStrings;
/*     */   private int[] absoluteStreamPositions;
/*     */   private int[] relativeStreamPositions;
/*  39 */   private int currentStringIndex = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ExtendedSSTRecord(int newNumberOfStrings) {
/*  50 */     super(Type.EXTSST);
/*  51 */     this.numberOfStrings = newNumberOfStrings;
/*  52 */     int numberOfBuckets = getNumberOfBuckets();
/*  53 */     this.absoluteStreamPositions = new int[numberOfBuckets];
/*  54 */     this.relativeStreamPositions = new int[numberOfBuckets];
/*  55 */     this.currentStringIndex = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getNumberOfBuckets() {
/*  60 */     int numberOfStringsPerBucket = getNumberOfStringsPerBucket();
/*  61 */     return (numberOfStringsPerBucket != 0) ? ((this.numberOfStrings + numberOfStringsPerBucket - 1) / numberOfStringsPerBucket) : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfStringsPerBucket() {
/*  73 */     int bucketLimit = 128;
/*  74 */     return (this.numberOfStrings + 128 - 1) / 128;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addString(int absoluteStreamPosition, int relativeStreamPosition) {
/*  80 */     this.absoluteStreamPositions[this.currentStringIndex] = absoluteStreamPosition + relativeStreamPosition;
/*     */     
/*  82 */     this.relativeStreamPositions[this.currentStringIndex] = relativeStreamPosition;
/*  83 */     this.currentStringIndex++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/*  93 */     int numberOfBuckets = getNumberOfBuckets();
/*  94 */     byte[] data = new byte[2 + 8 * numberOfBuckets];
/*     */     
/*  96 */     IntegerHelper.getTwoBytes(getNumberOfStringsPerBucket(), data, 0);
/*     */     
/*  98 */     for (int i = 0; i < numberOfBuckets; i++) {
/*     */ 
/*     */       
/* 101 */       IntegerHelper.getFourBytes(this.absoluteStreamPositions[i], data, 2 + i * 8);
/*     */ 
/*     */ 
/*     */       
/* 105 */       IntegerHelper.getTwoBytes(this.relativeStreamPositions[i], data, 6 + i * 8);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     return data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ExtendedSSTRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FunctionGroupCountRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private int numFunctionGroups;
/*    */   
/*    */   public FunctionGroupCountRecord() {
/* 46 */     super(Type.FNGROUPCOUNT);
/*    */     
/* 48 */     this.numFunctionGroups = 14;
/*    */     
/* 50 */     this.data = new byte[2];
/*    */     
/* 52 */     IntegerHelper.getTwoBytes(this.numFunctionGroups, this.data, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 62 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\FunctionGroupCountRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import jxl.biff.DisplayFormat;
/*     */ import jxl.biff.FontRecord;
/*     */ import jxl.biff.XFRecord;
/*     */ import jxl.format.Font;
/*     */ import jxl.write.DateFormat;
/*     */ import jxl.write.DateFormats;
/*     */ import jxl.write.NumberFormats;
/*     */ import jxl.write.WritableCellFormat;
/*     */ import jxl.write.WritableFont;
/*     */ import jxl.write.WritableWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Styles
/*     */ {
/*  42 */   private static Logger logger = Logger.getLogger(Styles.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   private WritableFont arial10pt = null;
/*  80 */   private WritableFont hyperlinkFont = null;
/*  81 */   private WritableCellFormat normalStyle = null;
/*  82 */   private WritableCellFormat hyperlinkStyle = null;
/*  83 */   private WritableCellFormat hiddenStyle = null;
/*     */   
/*     */   private WritableCellFormat defaultDateFormat;
/*     */   
/*     */   private synchronized void initNormalStyle() {
/*  88 */     this.normalStyle = new WritableCellFormat(getArial10Pt(), NumberFormats.DEFAULT);
/*     */     
/*  90 */     this.normalStyle.setFont((FontRecord)getArial10Pt());
/*     */   }
/*     */ 
/*     */   
/*     */   public WritableCellFormat getNormalStyle() {
/*  95 */     if (this.normalStyle == null)
/*     */     {
/*  97 */       initNormalStyle();
/*     */     }
/*     */     
/* 100 */     return this.normalStyle;
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized void initHiddenStyle() {
/* 105 */     this.hiddenStyle = new WritableCellFormat(getArial10Pt(), (DisplayFormat)new DateFormat(";;;"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableCellFormat getHiddenStyle() {
/* 111 */     if (this.hiddenStyle == null)
/*     */     {
/* 113 */       initHiddenStyle();
/*     */     }
/*     */     
/* 116 */     return this.hiddenStyle;
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized void initHyperlinkStyle() {
/* 121 */     this.hyperlinkStyle = new WritableCellFormat(getHyperlinkFont(), NumberFormats.DEFAULT);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableCellFormat getHyperlinkStyle() {
/* 127 */     if (this.hyperlinkStyle == null)
/*     */     {
/* 129 */       initHyperlinkStyle();
/*     */     }
/*     */     
/* 132 */     return this.hyperlinkStyle;
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized void initArial10Pt() {
/* 137 */     this.arial10pt = new WritableFont((Font)WritableWorkbook.ARIAL_10_PT);
/*     */   }
/*     */ 
/*     */   
/*     */   public WritableFont getArial10Pt() {
/* 142 */     if (this.arial10pt == null)
/*     */     {
/* 144 */       initArial10Pt();
/*     */     }
/*     */     
/* 147 */     return this.arial10pt;
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized void initHyperlinkFont() {
/* 152 */     this.hyperlinkFont = new WritableFont((Font)WritableWorkbook.HYPERLINK_FONT);
/*     */   }
/*     */ 
/*     */   
/*     */   public WritableFont getHyperlinkFont() {
/* 157 */     if (this.hyperlinkFont == null)
/*     */     {
/* 159 */       initHyperlinkFont();
/*     */     }
/*     */     
/* 162 */     return this.hyperlinkFont;
/*     */   }
/*     */ 
/*     */   
/*     */   private synchronized void initDefaultDateFormat() {
/* 167 */     this.defaultDateFormat = new WritableCellFormat(DateFormats.DEFAULT);
/*     */   }
/*     */ 
/*     */   
/*     */   public WritableCellFormat getDefaultDateFormat() {
/* 172 */     if (this.defaultDateFormat == null)
/*     */     {
/* 174 */       initDefaultDateFormat();
/*     */     }
/*     */     
/* 177 */     return this.defaultDateFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XFRecord getFormat(XFRecord wf) {
/*     */     WritableCellFormat writableCellFormat;
/* 192 */     XFRecord format = wf;
/*     */ 
/*     */ 
/*     */     
/* 196 */     if (format == WritableWorkbook.NORMAL_STYLE) {
/*     */       
/* 198 */       writableCellFormat = getNormalStyle();
/*     */     }
/* 200 */     else if (writableCellFormat == WritableWorkbook.HYPERLINK_STYLE) {
/*     */       
/* 202 */       writableCellFormat = getHyperlinkStyle();
/*     */     }
/* 204 */     else if (writableCellFormat == WritableWorkbook.HIDDEN_STYLE) {
/*     */       
/* 206 */       writableCellFormat = getHiddenStyle();
/*     */     }
/* 208 */     else if (writableCellFormat == DateRecord.defaultDateFormat) {
/*     */       
/* 210 */       writableCellFormat = getDefaultDateFormat();
/*     */     } 
/*     */ 
/*     */     
/* 214 */     if (writableCellFormat.getFont() == WritableWorkbook.ARIAL_10_PT) {
/*     */       
/* 216 */       writableCellFormat.setFont((FontRecord)getArial10Pt());
/*     */     }
/* 218 */     else if (writableCellFormat.getFont() == WritableWorkbook.HYPERLINK_FONT) {
/*     */       
/* 220 */       writableCellFormat.setFont((FontRecord)getHyperlinkFont());
/*     */     } 
/*     */     
/* 223 */     return (XFRecord)writableCellFormat;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\Styles.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.ErrorFormulaCell;
/*    */ import jxl.biff.FormulaData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReadErrorFormulaRecord
/*    */   extends ReadFormulaRecord
/*    */   implements ErrorFormulaCell
/*    */ {
/*    */   public ReadErrorFormulaRecord(FormulaData f) {
/* 38 */     super(f);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getErrorCode() {
/* 48 */     return ((ErrorFormulaCell)getReadFormula()).getErrorCode();
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ReadErrorFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
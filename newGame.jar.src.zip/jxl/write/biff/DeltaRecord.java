/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.DoubleHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DeltaRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private double iterationValue;
/*    */   
/*    */   public DeltaRecord(double itval) {
/* 50 */     super(Type.DELTA);
/* 51 */     this.iterationValue = itval;
/*    */     
/* 53 */     this.data = new byte[8];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 64 */     DoubleHelper.getIEEEBytes(this.iterationValue, this.data, 0);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 77 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\DeltaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RefreshAllRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean refreshall;
/*    */   private byte[] data;
/*    */   
/*    */   public RefreshAllRecord(boolean refresh) {
/* 48 */     super(Type.REFRESHALL);
/*    */     
/* 50 */     this.refreshall = refresh;
/*    */ 
/*    */     
/* 53 */     this.data = new byte[2];
/*    */     
/* 55 */     if (this.refreshall)
/*    */     {
/* 57 */       IntegerHelper.getTwoBytes(1, this.data, 0);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 68 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\RefreshAllRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
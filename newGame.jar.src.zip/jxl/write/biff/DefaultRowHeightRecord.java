/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class DefaultRowHeightRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private int rowHeight;
/*    */   private boolean changed;
/*    */   
/*    */   public DefaultRowHeightRecord(int h, boolean ch) {
/* 55 */     super(Type.DEFAULTROWHEIGHT);
/* 56 */     this.data = new byte[4];
/* 57 */     this.rowHeight = h;
/* 58 */     this.changed = ch;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 68 */     if (this.changed)
/*    */     {
/* 70 */       this.data[0] = (byte)(this.data[0] | 0x1);
/*    */     }
/*    */     
/* 73 */     IntegerHelper.getTwoBytes(this.rowHeight, this.data, 2);
/* 74 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\DefaultRowHeightRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
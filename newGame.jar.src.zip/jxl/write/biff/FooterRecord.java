/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.StringHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FooterRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private byte[] data;
/*    */   private String footer;
/*    */   
/*    */   public FooterRecord(String s) {
/* 49 */     super(Type.FOOTER);
/*    */     
/* 51 */     this.footer = s;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public FooterRecord(FooterRecord fr) {
/* 62 */     super(Type.FOOTER);
/*    */     
/* 64 */     this.footer = fr.footer;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 74 */     if (this.footer == null || this.footer.length() == 0) {
/*    */       
/* 76 */       this.data = new byte[0];
/* 77 */       return this.data;
/*    */     } 
/*    */     
/* 80 */     this.data = new byte[this.footer.length() * 2 + 3];
/* 81 */     IntegerHelper.getTwoBytes(this.footer.length(), this.data, 0);
/* 82 */     this.data[2] = 1;
/*    */     
/* 84 */     StringHelper.getUnicodeBytes(this.footer, this.data, 3);
/*    */     
/* 86 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\FooterRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
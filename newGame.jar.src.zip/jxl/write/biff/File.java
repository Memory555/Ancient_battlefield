/*     */ package jxl.write.biff;
/*     */ 
/*     */ import common.Logger;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import jxl.WorkbookSettings;
/*     */ import jxl.biff.ByteData;
/*     */ import jxl.read.biff.CompoundFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class File
/*     */ {
/*  40 */   private static Logger logger = Logger.getLogger(File.class);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] data;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int pos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private OutputStream outputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int initialFileSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int arrayGrowSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WorkbookSettings workbookSettings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CompoundFile readCompoundFile;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   File(OutputStream os, WorkbookSettings ws, CompoundFile rcf) {
/*  81 */     this.initialFileSize = ws.getInitialFileSize();
/*  82 */     this.arrayGrowSize = ws.getArrayGrowSize();
/*  83 */     this.data = new byte[this.initialFileSize];
/*  84 */     this.pos = 0;
/*  85 */     this.outputStream = os;
/*  86 */     this.workbookSettings = ws;
/*  87 */     this.readCompoundFile = rcf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void close(boolean cs) throws IOException, JxlWriteException {
/* 101 */     CompoundFile cf = new CompoundFile(this.data, this.pos, this.outputStream, this.readCompoundFile);
/*     */     
/* 103 */     cf.write();
/*     */     
/* 105 */     this.outputStream.flush();
/*     */     
/* 107 */     if (cs)
/*     */     {
/* 109 */       this.outputStream.close();
/*     */     }
/*     */ 
/*     */     
/* 113 */     this.data = null;
/*     */     
/* 115 */     if (!this.workbookSettings.getGCDisabled())
/*     */     {
/* 117 */       System.gc();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(ByteData record) throws IOException {
/*     */     try {
/* 131 */       byte[] bytes = record.getBytes();
/*     */       
/* 133 */       while (this.pos + bytes.length > this.data.length) {
/*     */ 
/*     */         
/* 136 */         byte[] newdata = new byte[this.data.length + this.arrayGrowSize];
/* 137 */         System.arraycopy(this.data, 0, newdata, 0, this.pos);
/* 138 */         this.data = newdata;
/*     */       } 
/*     */       
/* 141 */       System.arraycopy(bytes, 0, this.data, this.pos, bytes.length);
/* 142 */       this.pos += bytes.length;
/*     */     }
/* 144 */     catch (Throwable t) {
/*     */       
/* 146 */       t.printStackTrace();
/* 147 */       throw new RuntimeException(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getPos() {
/* 159 */     return this.pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setData(byte[] newdata, int pos) {
/* 171 */     System.arraycopy(newdata, 0, this.data, pos, newdata.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOutputFile(OutputStream os) {
/* 183 */     if (this.data != null)
/*     */     {
/* 185 */       logger.warn("Rewriting a workbook with non-empty data");
/*     */     }
/*     */     
/* 188 */     this.outputStream = os;
/* 189 */     this.data = new byte[this.initialFileSize];
/* 190 */     this.pos = 0;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\File.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
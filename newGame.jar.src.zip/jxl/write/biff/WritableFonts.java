/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.FontRecord;
/*    */ import jxl.biff.Fonts;
/*    */ import jxl.write.WritableFont;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WritableFonts
/*    */   extends Fonts
/*    */ {
/*    */   public WritableFonts(WritableWorkbookImpl w) {
/* 40 */     addFont((FontRecord)w.getStyles().getArial10Pt());
/*    */ 
/*    */     
/* 43 */     WritableFont f = new WritableFont(WritableFont.ARIAL);
/* 44 */     addFont((FontRecord)f);
/*    */     
/* 46 */     f = new WritableFont(WritableFont.ARIAL);
/* 47 */     addFont((FontRecord)f);
/*    */     
/* 49 */     f = new WritableFont(WritableFont.ARIAL);
/* 50 */     addFont((FontRecord)f);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\WritableFonts.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.BooleanFormulaCell;
/*    */ import jxl.biff.FormulaData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ReadBooleanFormulaRecord
/*    */   extends ReadFormulaRecord
/*    */   implements BooleanFormulaCell
/*    */ {
/*    */   public ReadBooleanFormulaRecord(FormulaData f) {
/* 38 */     super(f);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getValue() {
/* 48 */     return ((BooleanFormulaCell)getReadFormula()).getValue();
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ReadBooleanFormulaRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
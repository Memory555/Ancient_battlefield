/*    */ package jxl.write.biff;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopyAdditionalPropertySetsException
/*    */   extends JxlWriteException
/*    */ {
/*    */   public CopyAdditionalPropertySetsException() {
/* 35 */     super(copyPropertySets);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\CopyAdditionalPropertySetsException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
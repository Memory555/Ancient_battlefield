/*     */ package jxl.write.biff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import jxl.biff.IntegerHelper;
/*     */ import jxl.biff.StringHelper;
/*     */ import jxl.biff.Type;
/*     */ import jxl.biff.WritableRecordData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SSTRecord
/*     */   extends WritableRecordData
/*     */ {
/*     */   private int numReferences;
/*     */   private int numStrings;
/*     */   private ArrayList strings;
/*     */   private ArrayList stringLengths;
/*     */   private byte[] data;
/*     */   private int byteCount;
/*  62 */   private static int maxBytes = 8216;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SSTRecord(int numRefs, int s) {
/*  74 */     super(Type.SST);
/*     */     
/*  76 */     this.numReferences = numRefs;
/*  77 */     this.numStrings = s;
/*  78 */     this.byteCount = 0;
/*  79 */     this.strings = new ArrayList(50);
/*  80 */     this.stringLengths = new ArrayList(50);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int add(String s) {
/*  93 */     int bytes = s.length() * 2 + 3;
/*     */ 
/*     */ 
/*     */     
/*  97 */     if (this.byteCount >= maxBytes - 5)
/*     */     {
/*  99 */       return s.length();
/*     */     }
/*     */     
/* 102 */     this.stringLengths.add(new Integer(s.length()));
/*     */     
/* 104 */     if (bytes + this.byteCount < maxBytes) {
/*     */ 
/*     */       
/* 107 */       this.strings.add(s);
/* 108 */       this.byteCount += bytes;
/* 109 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 113 */     int bytesLeft = maxBytes - 3 - this.byteCount;
/* 114 */     int charsAvailable = (bytesLeft % 2 == 0) ? (bytesLeft / 2) : ((bytesLeft - 1) / 2);
/*     */ 
/*     */ 
/*     */     
/* 118 */     this.strings.add(s.substring(0, charsAvailable));
/* 119 */     this.byteCount += charsAvailable * 2 + 3;
/*     */     
/* 121 */     return s.length() - charsAvailable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOffset() {
/* 131 */     return this.byteCount + 8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getData() {
/* 141 */     this.data = new byte[this.byteCount + 8];
/* 142 */     IntegerHelper.getFourBytes(this.numReferences, this.data, 0);
/* 143 */     IntegerHelper.getFourBytes(this.numStrings, this.data, 4);
/*     */     
/* 145 */     int pos = 8;
/* 146 */     int count = 0;
/*     */     
/* 148 */     Iterator i = this.strings.iterator();
/* 149 */     String s = null;
/* 150 */     int length = 0;
/* 151 */     while (i.hasNext()) {
/*     */       
/* 153 */       s = i.next();
/* 154 */       length = ((Integer)this.stringLengths.get(count)).intValue();
/* 155 */       IntegerHelper.getTwoBytes(length, this.data, pos);
/* 156 */       this.data[pos + 2] = 1;
/* 157 */       StringHelper.getUnicodeBytes(s, this.data, pos + 3);
/* 158 */       pos += s.length() * 2 + 3;
/* 159 */       count++;
/*     */     } 
/*     */     
/* 162 */     return this.data;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\SSTRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write.biff;
/*    */ 
/*    */ import common.Logger;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ArbitraryRecord
/*    */   extends WritableRecordData
/*    */ {
/* 37 */   private static Logger logger = Logger.getLogger(ArbitraryRecord.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private byte[] data;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ArbitraryRecord(int type, byte[] d) {
/* 52 */     super(Type.createType(type));
/*    */     
/* 54 */     this.data = d;
/* 55 */     logger.warn("ArbitraryRecord of type " + type + " created");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 65 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\ArbitraryRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write.biff;
/*    */ 
/*    */ import jxl.biff.IntegerHelper;
/*    */ import jxl.biff.Type;
/*    */ import jxl.biff.WritableRecordData;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class HideobjRecord
/*    */   extends WritableRecordData
/*    */ {
/*    */   private boolean hideAll;
/*    */   private byte[] data;
/*    */   
/*    */   public HideobjRecord(boolean hide) {
/* 49 */     super(Type.HIDEOBJ);
/*    */     
/* 51 */     this.hideAll = hide;
/* 52 */     this.data = new byte[2];
/*    */     
/* 54 */     if (this.hideAll)
/*    */     {
/* 56 */       IntegerHelper.getTwoBytes(2, this.data, 0);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public byte[] getData() {
/* 67 */     return this.data;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\biff\HideobjRecord.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
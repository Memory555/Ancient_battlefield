package jxl.write;

import jxl.Cell;
import jxl.format.CellFormat;

public interface WritableCell extends Cell {
  void setCellFormat(CellFormat paramCellFormat);
  
  WritableCell copyTo(int paramInt1, int paramInt2);
  
  WritableCellFeatures getWritableCellFeatures();
  
  void setCellFeatures(WritableCellFeatures paramWritableCellFeatures);
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\WritableCell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
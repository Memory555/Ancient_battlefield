package jxl.write;

import jxl.CellView;
import jxl.Range;
import jxl.Sheet;
import jxl.format.CellFormat;
import jxl.format.PageOrientation;
import jxl.format.PaperSize;
import jxl.write.biff.RowsExceededException;

public interface WritableSheet extends Sheet {
  void addCell(WritableCell paramWritableCell) throws WriteException, RowsExceededException;
  
  void setName(String paramString);
  
  void setHidden(boolean paramBoolean);
  
  void setProtected(boolean paramBoolean);
  
  void setColumnView(int paramInt1, int paramInt2);
  
  void setColumnView(int paramInt1, int paramInt2, CellFormat paramCellFormat);
  
  void setColumnView(int paramInt, CellView paramCellView);
  
  void setRowView(int paramInt1, int paramInt2) throws RowsExceededException;
  
  void setRowView(int paramInt, boolean paramBoolean) throws RowsExceededException;
  
  void setRowView(int paramInt1, int paramInt2, boolean paramBoolean) throws RowsExceededException;
  
  WritableCell getWritableCell(int paramInt1, int paramInt2);
  
  WritableHyperlink[] getWritableHyperlinks();
  
  void insertRow(int paramInt);
  
  void insertColumn(int paramInt);
  
  void removeColumn(int paramInt);
  
  void removeRow(int paramInt);
  
  Range mergeCells(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws WriteException, RowsExceededException;
  
  void unmergeCells(Range paramRange);
  
  void addHyperlink(WritableHyperlink paramWritableHyperlink) throws WriteException, RowsExceededException;
  
  void removeHyperlink(WritableHyperlink paramWritableHyperlink);
  
  void removeHyperlink(WritableHyperlink paramWritableHyperlink, boolean paramBoolean);
  
  void setHeader(String paramString1, String paramString2, String paramString3);
  
  void setFooter(String paramString1, String paramString2, String paramString3);
  
  void setPageSetup(PageOrientation paramPageOrientation);
  
  void setPageSetup(PageOrientation paramPageOrientation, double paramDouble1, double paramDouble2);
  
  void setPageSetup(PageOrientation paramPageOrientation, PaperSize paramPaperSize, double paramDouble1, double paramDouble2);
  
  void addRowPageBreak(int paramInt);
  
  void addImage(WritableImage paramWritableImage);
  
  int getNumberOfImages();
  
  WritableImage getImage(int paramInt);
  
  void removeImage(WritableImage paramWritableImage);
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\WritableSheet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
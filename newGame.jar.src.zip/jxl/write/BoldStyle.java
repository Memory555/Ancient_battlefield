/*    */ package jxl.write;
/*    */ 
/*    */ import jxl.format.BoldStyle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BoldStyle
/*    */   extends BoldStyle
/*    */ {
/*    */   private BoldStyle(int val) {
/* 34 */     super(0, "");
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\BoldStyle.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
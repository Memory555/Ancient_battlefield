/*     */ package jxl.write;
/*     */ 
/*     */ import jxl.BooleanCell;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.biff.BooleanRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Boolean
/*     */   extends BooleanRecord
/*     */   implements WritableCell, BooleanCell
/*     */ {
/*     */   public Boolean(int c, int r, boolean val) {
/*  42 */     super(c, r, val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean(int c, int r, boolean val, CellFormat st) {
/*  57 */     super(c, r, val, st);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean(BooleanCell nc) {
/*  68 */     super(nc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Boolean(int col, int row, Boolean b) {
/*  80 */     super(col, row, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(boolean val) {
/*  89 */     super.setValue(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableCell copyTo(int col, int row) {
/* 101 */     return new Boolean(col, row, this);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\Boolean.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package jxl.write;
/*    */ 
/*    */ import jxl.format.Border;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Border
/*    */   extends Border
/*    */ {
/*    */   private Border() {
/* 32 */     super(null);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\Border.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import jxl.Hyperlink;
/*     */ import jxl.write.biff.HyperlinkRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WritableHyperlink
/*     */   extends HyperlinkRecord
/*     */   implements Hyperlink
/*     */ {
/*     */   public WritableHyperlink(Hyperlink h, WritableSheet ws) {
/*  42 */     super(h, ws);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableHyperlink(int col, int row, URL url) {
/*  54 */     this(col, row, col, row, url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableHyperlink(int col, int row, int lastcol, int lastrow, URL url) {
/*  68 */     this(col, row, lastcol, lastrow, url, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableHyperlink(int col, int row, int lastcol, int lastrow, URL url, String desc) {
/*  85 */     super(col, row, lastcol, lastrow, url, desc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableHyperlink(int col, int row, File file) {
/*  97 */     this(col, row, col, row, file, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableHyperlink(int col, int row, File file, String desc) {
/* 110 */     this(col, row, col, row, file, desc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableHyperlink(int col, int row, int lastcol, int lastrow, File file) {
/* 125 */     super(col, row, lastcol, lastrow, file, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableHyperlink(int col, int row, int lastcol, int lastrow, File file, String desc) {
/* 141 */     super(col, row, lastcol, lastrow, file, desc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableHyperlink(int col, int row, String desc, WritableSheet sheet, int destcol, int destrow) {
/* 159 */     this(col, row, col, row, desc, sheet, destcol, destrow, destcol, destrow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableHyperlink(int col, int row, int lastcol, int lastrow, String desc, WritableSheet sheet, int destcol, int destrow, int lastdestcol, int lastdestrow) {
/* 185 */     super(col, row, lastcol, lastrow, desc, sheet, destcol, destrow, lastdestcol, lastdestrow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setURL(URL url) {
/* 198 */     super.setURL(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFile(File file) {
/* 208 */     super.setFile(file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String desc) {
/* 218 */     setContents(desc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLocation(String desc, WritableSheet sheet, int destcol, int destrow, int lastdestcol, int lastdestrow) {
/* 236 */     super.setLocation(desc, sheet, destcol, destrow, lastdestcol, lastdestrow);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\WritableHyperlink.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package jxl.write;
/*     */ 
/*     */ import java.util.Date;
/*     */ import jxl.DateCell;
/*     */ import jxl.format.CellFormat;
/*     */ import jxl.write.biff.DateRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateTime
/*     */   extends DateRecord
/*     */   implements WritableCell, DateCell
/*     */ {
/*  46 */   public static final DateRecord.GMTDate GMT = new DateRecord.GMTDate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(int c, int r, Date d) {
/*  57 */     super(c, r, d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(int c, int r, Date d, DateRecord.GMTDate a) {
/*  71 */     super(c, r, d, a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(int c, int r, Date d, CellFormat st) {
/*  84 */     super(c, r, d, st);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(int c, int r, Date d, CellFormat st, DateRecord.GMTDate a) {
/*  99 */     super(c, r, d, st, a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(int c, int r, Date d, CellFormat st, boolean tim) {
/* 116 */     super(c, r, d, st, tim);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DateTime(DateCell dc) {
/* 127 */     super(dc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DateTime(int col, int row, DateTime dt) {
/* 139 */     super(col, row, dt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDate(Date d) {
/* 150 */     super.setDate(d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDate(Date d, DateRecord.GMTDate a) {
/* 161 */     super.setDate(d, a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WritableCell copyTo(int col, int row) {
/* 173 */     return new DateTime(col, row, this);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\write\DateTime.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
package jxl;

import jxl.format.CellFormat;

public interface Sheet {
  Cell getCell(int paramInt1, int paramInt2);
  
  int getRows();
  
  int getColumns();
  
  Cell[] getRow(int paramInt);
  
  Cell[] getColumn(int paramInt);
  
  String getName();
  
  boolean isHidden();
  
  boolean isProtected();
  
  Cell findCell(String paramString);
  
  LabelCell findLabelCell(String paramString);
  
  Hyperlink[] getHyperlinks();
  
  Range[] getMergedCells();
  
  SheetSettings getSettings();
  
  CellFormat getColumnFormat(int paramInt);
  
  int getColumnWidth(int paramInt);
  
  CellView getColumnView(int paramInt);
  
  int getRowHeight(int paramInt);
  
  CellView getRowView(int paramInt);
  
  int getNumberOfImages();
  
  Image getDrawing(int paramInt);
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\Sheet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
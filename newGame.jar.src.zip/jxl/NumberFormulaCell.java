package jxl;

public interface NumberFormulaCell extends NumberCell, FormulaCell {}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\NumberFormulaCell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
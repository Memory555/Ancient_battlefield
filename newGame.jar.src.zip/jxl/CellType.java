/*    */ package jxl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class CellType
/*    */ {
/*    */   private String description;
/*    */   
/*    */   private CellType(String desc) {
/* 39 */     this.description = desc;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     return this.description;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 54 */   public static final CellType EMPTY = new CellType("Empty");
/*    */ 
/*    */   
/* 57 */   public static final CellType LABEL = new CellType("Label");
/*    */ 
/*    */   
/* 60 */   public static final CellType NUMBER = new CellType("Number");
/*    */ 
/*    */   
/* 63 */   public static final CellType BOOLEAN = new CellType("Boolean");
/*    */ 
/*    */   
/* 66 */   public static final CellType ERROR = new CellType("Error");
/*    */ 
/*    */   
/* 69 */   public static final CellType NUMBER_FORMULA = new CellType("Numerical Formula");
/*    */ 
/*    */ 
/*    */   
/* 73 */   public static final CellType DATE_FORMULA = new CellType("Date Formula");
/*    */ 
/*    */   
/* 76 */   public static final CellType STRING_FORMULA = new CellType("String Formula");
/*    */ 
/*    */   
/* 79 */   public static final CellType BOOLEAN_FORMULA = new CellType("Boolean Formula");
/*    */ 
/*    */ 
/*    */   
/* 83 */   public static final CellType FORMULA_ERROR = new CellType("Formula Error");
/*    */ 
/*    */   
/* 86 */   public static final CellType DATE = new CellType("Date");
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\CellType.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
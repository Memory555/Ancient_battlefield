package jxl;

import java.io.File;
import java.net.URL;

public interface Hyperlink {
  int getRow();
  
  int getColumn();
  
  Range getRange();
  
  boolean isFile();
  
  boolean isURL();
  
  boolean isLocation();
  
  int getLastRow();
  
  int getLastColumn();
  
  URL getURL();
  
  File getFile();
}


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\jxl\Hyperlink.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Assert
/*    */ {
/*    */   public static void verify(boolean condition) {
/* 35 */     if (!condition)
/*    */     {
/* 37 */       throw new AssertionFailed();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void verify(boolean condition, String message) {
/* 49 */     if (!condition)
/*    */     {
/* 51 */       throw new AssertionFailed(message);
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\common\Assert.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
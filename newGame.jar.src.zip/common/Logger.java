/*    */ package common;
/*    */ 
/*    */ import common.log.LoggerName;
/*    */ import common.log.SimpleLogger;
/*    */ import java.security.AccessControlException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Logger
/*    */ {
/* 33 */   private static Logger logger = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final Logger getLogger(Class cl) {
/* 40 */     if (logger == null)
/*    */     {
/* 42 */       initializeLogger();
/*    */     }
/*    */     
/* 45 */     return logger.getLoggerImpl(cl);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static synchronized void initializeLogger() {
/* 53 */     if (logger != null) {
/*    */       return;
/*    */     }
/*    */ 
/*    */     
/* 58 */     String loggerName = LoggerName.NAME;
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 63 */       loggerName = System.getProperty("logger");
/*    */       
/* 65 */       if (loggerName == null)
/*    */       {
/*    */         
/* 68 */         loggerName = LoggerName.NAME;
/*    */       }
/*    */       
/* 71 */       logger = (Logger)Class.forName(loggerName).newInstance();
/*    */     }
/* 73 */     catch (IllegalAccessException e) {
/*    */       
/* 75 */       logger = (Logger)new SimpleLogger();
/* 76 */       logger.warn("Could not instantiate logger " + loggerName + " using default");
/*    */     
/*    */     }
/* 79 */     catch (InstantiationException e) {
/*    */       
/* 81 */       logger = (Logger)new SimpleLogger();
/* 82 */       logger.warn("Could not instantiate logger " + loggerName + " using default");
/*    */     
/*    */     }
/* 85 */     catch (AccessControlException e) {
/*    */       
/* 87 */       logger = (Logger)new SimpleLogger();
/* 88 */       logger.warn("Could not instantiate logger " + loggerName + " using default");
/*    */     
/*    */     }
/* 91 */     catch (ClassNotFoundException e) {
/*    */       
/* 93 */       logger = (Logger)new SimpleLogger();
/* 94 */       logger.warn("Could not instantiate logger " + loggerName + " using default");
/*    */     } 
/*    */   }
/*    */   
/*    */   public abstract void debug(Object paramObject);
/*    */   
/*    */   public abstract void debug(Object paramObject, Throwable paramThrowable);
/*    */   
/*    */   public abstract void error(Object paramObject);
/*    */   
/*    */   public abstract void error(Object paramObject, Throwable paramThrowable);
/*    */   
/*    */   public abstract void fatal(Object paramObject);
/*    */   
/*    */   public abstract void fatal(Object paramObject, Throwable paramThrowable);
/*    */   
/*    */   public abstract void info(Object paramObject);
/*    */   
/*    */   public abstract void info(Object paramObject, Throwable paramThrowable);
/*    */   
/*    */   public abstract void warn(Object paramObject);
/*    */   
/*    */   public abstract void warn(Object paramObject, Throwable paramThrowable);
/*    */   
/*    */   protected abstract Logger getLoggerImpl(Class paramClass);
/*    */   
/*    */   public void setSuppressWarnings(boolean w) {}
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\common\Logger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
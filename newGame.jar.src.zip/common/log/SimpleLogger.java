/*     */ package common.log;
/*     */ 
/*     */ import common.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleLogger
/*     */   extends Logger
/*     */ {
/*     */   private boolean suppressWarnings = false;
/*     */   
/*     */   public void debug(Object message) {
/*  47 */     if (!this.suppressWarnings) {
/*     */       
/*  49 */       System.out.print("Debug: ");
/*  50 */       System.out.println(message);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void debug(Object message, Throwable t) {
/*  59 */     if (!this.suppressWarnings) {
/*     */       
/*  61 */       System.out.print("Debug: ");
/*  62 */       System.out.println(message);
/*  63 */       t.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(Object message) {
/*  72 */     System.err.print("Error: ");
/*  73 */     System.err.println(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void error(Object message, Throwable t) {
/*  81 */     System.err.print("Error: ");
/*  82 */     System.err.println(message);
/*  83 */     t.printStackTrace();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fatal(Object message) {
/*  91 */     System.err.print("Fatal: ");
/*  92 */     System.err.println(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fatal(Object message, Throwable t) {
/* 100 */     System.err.print("Fatal:  ");
/* 101 */     System.err.println(message);
/* 102 */     t.printStackTrace();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void info(Object message) {
/* 110 */     if (!this.suppressWarnings)
/*     */     {
/* 112 */       System.out.println(message);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void info(Object message, Throwable t) {
/* 122 */     if (!this.suppressWarnings) {
/*     */       
/* 124 */       System.out.println(message);
/* 125 */       t.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warn(Object message) {
/* 134 */     if (!this.suppressWarnings) {
/*     */       
/* 136 */       System.err.print("Warning:  ");
/* 137 */       System.err.println(message);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void warn(Object message, Throwable t) {
/* 146 */     if (!this.suppressWarnings) {
/*     */       
/* 148 */       System.err.print("Warning:  ");
/* 149 */       System.err.println(message);
/* 150 */       t.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Logger getLoggerImpl(Class c) {
/* 159 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSuppressWarnings(boolean w) {
/* 174 */     this.suppressWarnings = w;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\common\log\SimpleLogger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */
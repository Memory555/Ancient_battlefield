/*    */ package com.sxt;
/*    */ 
/*    */ import com.sxt.beast.Beast;
/*    */ import java.awt.Color;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Rectangle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bullet
/*    */   extends GameObject
/*    */ {
/*    */   GameObject attacker;
/*    */   GameObject target;
/*    */   int ad;
/*    */   
/*    */   public Bullet(GameFrame gameFrame, GameObject attacker, GameObject target, int ad, int spd) {
/* 19 */     super(attacker.getX(), attacker.getY(), gameFrame);
/* 20 */     this.attacker = attacker;
/* 21 */     this.target = target;
/* 22 */     setAd(ad);
/* 23 */     setSpd(spd);
/*    */   }
/*    */ 
/*    */   
/*    */   public Bullet(GameFrame gameFrame, GameObject attacker, GameObject target, int ad, int spd, String img) {
/* 28 */     super(attacker.getX(), attacker.getY(), gameFrame);
/* 29 */     this.attacker = attacker;
/* 30 */     this.target = target;
/* 31 */     setImg(img);
/* 32 */     setAd(ad);
/* 33 */     setSpd(spd);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Bullet() {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void move() {
/* 43 */     if (recIntersectsRec(getRec(), this.target.getRec())) {
/* 44 */       if (Beast.class.isAssignableFrom(this.target.getClass())) {
/* 45 */         this.target.setTarget(this.gameFrame.player);
/* 46 */         this.target.setHasTarget(true);
/*    */       } 
/*    */       
/* 49 */       this.target.setCurrentHp(this.target.getCurrentHp() - getAd());
/* 50 */       this.gameFrame.removeList.add(this);
/*    */     } 
/* 52 */     double dis = getDis(getX(), getY(), this.target.getX(), this.target.getY());
/* 53 */     int xSpeed = (int)((getSpd() * (this.target.getX() - getX())) / dis);
/* 54 */     int ySpeed = (int)((getSpd() * (this.target.getY() - getY())) / dis);
/* 55 */     setX(getX() + xSpeed);
/* 56 */     setY(getY() + ySpeed);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintSelf(Graphics g) {
/* 62 */     g.drawImage(getImg(), getX() - 16, getY() - 16, null);
/* 63 */     if (getImg() == null) {
/* 64 */       g.setColor(Color.BLACK);
/* 65 */       g.fillOval(getX() - 5, getY() - 5, 10, 10);
/* 66 */       g.drawRect(getX() - 5, getY() - 5, 10, 10);
/*    */     } 
/* 68 */     move();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Rectangle getRec() {
/* 74 */     return new Rectangle(getX() - 5, getY() - 5, 10, 10);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getAd() {
/* 81 */     return this.ad;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAd(int ad) {
/* 88 */     this.ad = ad;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\Bullet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
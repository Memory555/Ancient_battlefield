/*    */ package com.sxt;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Image;
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.Toolkit;
/*    */ 
/*    */ public class Background extends GameObject {
/*    */   public Background(GameFrame gameFrame) {
/*  9 */     super(gameFrame);
/*    */ 
/*    */ 
/*    */     
/* 13 */     this.bg = Toolkit.getDefaultToolkit().getImage("img/Map.jpg");
/*    */   } Image bg; public void paintSelf(Graphics g) {
/* 15 */     g.drawImage(this.bg, 0, 0, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Rectangle getRec() {
/* 24 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\Background.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
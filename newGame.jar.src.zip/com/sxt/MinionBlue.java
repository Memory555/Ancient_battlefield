/*    */ package com.sxt;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class MinionBlue
/*    */   extends Minion {
/*    */   public MinionBlue(GameFrame gameFrame) {
/*  9 */     super(gameFrame);
/* 10 */     setImg("img/minion/blue.png");
/* 11 */     int[] ii1 = { 850, 1220 };
/* 12 */     int test = getRandom(ii1);
/* 13 */     if (test == 850) {
/* 14 */       setX(850);
/* 15 */       setY(3230);
/*    */     } 
/* 17 */     if (test == 1220) {
/* 18 */       setX(1220);
/* 19 */       setY(3920);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static int getRandom(int[] array) {
/* 25 */     int rnd = (new Random()).nextInt(array.length);
/* 26 */     return array[rnd];
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void move(ArrayList<GameObject> objList) {
/* 32 */     if (isIfFindTarget()) {
/*    */       
/* 34 */       if (!recIntersectsCir(getTarget().getRec(), getX(), getY(), 200)) {
/* 35 */         setIfFindTarget(false);
/*    */       } else {
/* 37 */         if (!isHasTarget()) {
/* 38 */           moveToTarget();
/*    */         }
/* 40 */         attack(objList);
/*    */       } 
/*    */     } else {
/* 43 */       findTarget(objList);
/*    */       
/* 45 */       if (getX() < 4925 && getY() >= 3920) {
/* 46 */         setSpd(15);
/* 47 */         if (!hitMinion(getX() + getSpd(), getY(), this.gameFrame.blueList)) {
/* 48 */           setX(getX() + getSpd());
/*    */         }
/*    */       } 
/*    */       
/* 52 */       if (getX() >= 4925 && getY() > 1125) {
/* 53 */         setSpd(10);
/* 54 */         if (!hitMinion(getY(), getY() - getSpd(), this.gameFrame.blueList)) {
/* 55 */           setY(getY() - getSpd());
/*    */         }
/*    */       } 
/*    */       
/* 59 */       if (getX() <= 850 && getY() > 610) {
/* 60 */         setSpd(15);
/* 61 */         if (!hitMinion(getY(), getY() - getSpd(), this.gameFrame.blueList)) {
/* 62 */           setY(getY() - getSpd());
/*    */         }
/*    */       } 
/*    */       
/* 66 */       if (getX() <= 4920 && getY() <= 610) {
/* 67 */         setSpd(10);
/* 68 */         if (!hitMinion(getX(), getX() - getSpd(), this.gameFrame.blueList))
/* 69 */           setX(getX() + getSpd()); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\MinionBlue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
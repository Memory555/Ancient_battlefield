/*    */ package com.sxt;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import javax.sound.sampled.AudioFormat;
/*    */ import javax.sound.sampled.AudioInputStream;
/*    */ import javax.sound.sampled.AudioSystem;
/*    */ import javax.sound.sampled.DataLine;
/*    */ import javax.sound.sampled.FloatControl;
/*    */ import javax.sound.sampled.LineUnavailableException;
/*    */ import javax.sound.sampled.SourceDataLine;
/*    */ import javax.sound.sampled.UnsupportedAudioFileException;
/*    */ 
/*    */ public class Music
/*    */   extends Thread
/*    */ {
/*    */   private String fileName;
/* 18 */   private final int EXTERNAL_BUFFER_SIZE = 524288;
/*    */   
/*    */   public Music(String wavFile) {
/* 21 */     this.fileName = wavFile;
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 26 */     File soundFile = new File(this.fileName);
/* 27 */     if (!soundFile.exists()) {
/* 28 */       System.err.println("Wave file not found:" + this.fileName);
/*    */       return;
/*    */     } 
/*    */     while (true) {
/* 32 */       AudioInputStream audioInputStream = null;
/*    */       try {
/* 34 */         audioInputStream = AudioSystem.getAudioInputStream(soundFile);
/* 35 */       } catch (UnsupportedAudioFileException e1) {
/* 36 */         e1.printStackTrace();
/*    */         return;
/* 38 */       } catch (IOException e1) {
/* 39 */         e1.printStackTrace();
/*    */         return;
/*    */       } 
/* 42 */       AudioFormat format = audioInputStream.getFormat();
/* 43 */       SourceDataLine auline = null;
/* 44 */       DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
/*    */       try {
/* 46 */         auline = (SourceDataLine)AudioSystem.getLine(info);
/* 47 */         auline.open(format);
/* 48 */       } catch (LineUnavailableException e) {
/* 49 */         e.printStackTrace();
/*    */         return;
/* 51 */       } catch (Exception e) {
/* 52 */         e.printStackTrace();
/*    */         return;
/*    */       } 
/* 55 */       if (auline.isControlSupported(FloatControl.Type.PAN)) {
/* 56 */         FloatControl floatControl = (FloatControl)auline.getControl(FloatControl.Type.PAN);
/*    */       }
/* 58 */       auline.start();
/* 59 */       int nBytesRead = 0;
/* 60 */       byte[] abData = new byte[524288];
/*    */       try {
/* 62 */         while (nBytesRead != -1) {
/* 63 */           nBytesRead = audioInputStream.read(abData, 0, abData.length);
/* 64 */           if (nBytesRead >= 0)
/* 65 */             auline.write(abData, 0, nBytesRead); 
/*    */         } 
/* 67 */       } catch (IOException e) {
/* 68 */         e.printStackTrace();
/*    */         return;
/*    */       } finally {
/* 71 */         auline.drain();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\Music.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
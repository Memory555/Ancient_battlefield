/*    */ package com.sxt;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.DatagramPacket;
/*    */ import java.net.DatagramSocket;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class PingServer {
/*    */   private static final double LOSS_RATE = 0.3D;
/*    */   
/*    */   public static void main(String[] args) throws Exception {
/* 11 */     if (args.length != 1) {
/* 12 */       System.out.println("Required arguments:port");
/*    */       return;
/*    */     } 
/* 15 */     int port = Integer.parseInt(args[0]);
/* 16 */     Random random = new Random();
/* 17 */     DatagramSocket socket = new DatagramSocket(port);
/*    */     while (true) {
/* 19 */       DatagramPacket requset = new DatagramPacket(new byte[1024], 1024);
/* 20 */       socket.receive(requset);
/* 21 */       printData(requset);
/* 22 */       if (random.nextDouble() < 0.3D) {
/* 23 */         System.out.println("Reply not sent");
/*    */         continue;
/*    */       } 
/* 26 */       Thread.sleep((int)(random.nextDouble() * 2.0D * 100.0D));
/* 27 */       InetAddress clientHost = requset.getAddress();
/* 28 */       int clientPort = requset.getPort();
/* 29 */       byte[] buf = requset.getData();
/* 30 */       DatagramPacket reply = new DatagramPacket(buf, buf.length, clientHost, clientPort);
/* 31 */       socket.send(reply);
/* 32 */       System.out.println("Reply sent");
/*    */     } 
/*    */   }
/*    */   private static final int AVERAGE_DELAY = 100;
/*    */   private static void printData(DatagramPacket requset) throws Exception {
/* 37 */     byte[] buf = requset.getData();
/* 38 */     ByteArrayInputStream bais = new ByteArrayInputStream(buf);
/* 39 */     InputStreamReader isr = new InputStreamReader(bais);
/* 40 */     BufferedReader br = new BufferedReader(isr);
/* 41 */     String line = br.readLine();
/* 42 */     System.out.println("Received from" + requset.getAddress().getHostAddress() + "." + new String(line));
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\PingServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
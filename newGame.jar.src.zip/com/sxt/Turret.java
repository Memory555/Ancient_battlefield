/*     */ package com.sxt;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ public class Turret extends GameObject {
/*   9 */   ArrayList<Turret> turretList = new ArrayList<>();
/*     */   public Turret turretBlueOne;
/*     */   public Turret turretBlueTwo;
/*     */   public Turret turretBlueThree;
/*     */   public Turret turretBlueFour;
/*     */   public Turret turretBlueFive;
/*     */   public Turret turretBlueSix;
/*     */   public Turret turretBlueBase;
/*     */   public Turret turretRedOne;
/*     */   public Turret turretRedTwo;
/*     */   public Turret turretRedThree;
/*     */   public Turret turretRedBase;
/*     */   public Turret turretRedFour;
/*     */   public Turret turretRedFive;
/*     */   public Turret turretRedSix;
/*     */   
/*     */   public Turret(GameFrame gameFrame) {
/*  26 */     super(gameFrame);
/*  27 */     setImg("img/turret.png");
/*     */ 
/*     */     
/*  30 */     this.turretList.add(this.turretBlueOne = new TurretBlue(2460, 3910, gameFrame));
/*  31 */     this.turretList.add(this.turretBlueTwo = new TurretBlue(3670, 3910, gameFrame));
/*     */     
/*  33 */     this.turretList.add(this.turretBlueThree = new TurretBlue(810, 610, gameFrame));
/*  34 */     this.turretList.add(this.turretBlueFour = new TurretBlue(860, 1875, gameFrame));
/*     */     
/*  36 */     this.turretList.add(this.turretBlueFive = new TurretBlue(1980, 2810, gameFrame));
/*  37 */     this.turretList.add(this.turretBlueSix = new TurretBlue(2520, 2480, gameFrame));
/*     */     
/*  39 */     this.turretList.add(this.turretBlueBase = new TurretBlue(1030, 3590, gameFrame));
/*     */     
/*  41 */     this.turretList.add(this.turretRedOne = new TurretRed(4985, 2650, gameFrame));
/*  42 */     this.turretList.add(this.turretRedTwo = new TurretRed(4985, 3910, gameFrame));
/*     */     
/*  44 */     this.turretList.add(this.turretRedThree = new TurretRed(2955, 610, gameFrame));
/*  45 */     this.turretList.add(this.turretRedFour = new TurretRed(2000, 610, gameFrame));
/*     */     
/*  47 */     this.turretList.add(this.turretRedFive = new TurretRed(3780, 1730, gameFrame));
/*  48 */     this.turretList.add(this.turretRedSix = new TurretRed(3100, 2110, gameFrame));
/*     */     
/*  50 */     this.turretList.add(this.turretRedBase = new TurretRed(5170, 1010, gameFrame));
/*     */   }
/*     */ 
/*     */   
/*     */   public Turret(int x, int y, GameFrame gameFrame) {
/*  55 */     super(x, y, gameFrame);
/*  56 */     setImg("img/turret.png");
/*  57 */     setHp(6000);
/*  58 */     setCurrentHp(getHp());
/*  59 */     setAttackCoolDownTime(1000);
/*  60 */     setDis(300);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTurret() {
/*  67 */     if (!this.gameFrame.turret.turretBlueTwo.isAlive() && this.gameFrame.turret.turretBlueOne.isAlive() && this.gameFrame.blueList
/*  68 */       .indexOf(this.gameFrame.turret.turretBlueOne) == -1) {
/*  69 */       this.gameFrame.blueList.add(this.gameFrame.turret.turretBlueOne);
/*     */     }
/*  71 */     if (!this.gameFrame.turret.turretBlueFour.isAlive() && this.gameFrame.turret.turretBlueThree.isAlive() && this.gameFrame.blueList
/*  72 */       .indexOf(this.gameFrame.turret.turretBlueThree) == -1) {
/*  73 */       this.gameFrame.blueList.add(this.gameFrame.turret.turretBlueThree);
/*     */     }
/*  75 */     if (!this.gameFrame.turret.turretBlueSix.isAlive() && this.gameFrame.turret.turretBlueFive.isAlive() && this.gameFrame.blueList
/*  76 */       .indexOf(this.gameFrame.turret.turretBlueFive) == -1) {
/*  77 */       this.gameFrame.blueList.add(this.gameFrame.turret.turretBlueFive);
/*     */     }
/*  79 */     if (!this.gameFrame.turret.turretBlueOne.isAlive() && !this.gameFrame.turret.turretBlueThree.isAlive() && this.gameFrame.turret.turretBlueFive
/*  80 */       .isAlive() && this.gameFrame.turret.turretBlueBase.isAlive() && this.gameFrame.blueList
/*  81 */       .indexOf(this.gameFrame.turret.turretBlueBase) == -1) {
/*  82 */       this.gameFrame.blueList.add(this.gameFrame.turret.turretBlueBase);
/*     */     }
/*  84 */     if (!this.gameFrame.turret.turretBlueBase.isAlive())
/*     */     {
/*  86 */       this.gameFrame.state = 3;
/*     */     }
/*     */     
/*  89 */     if (!this.gameFrame.turret.turretRedTwo.isAlive() && this.gameFrame.turret.turretRedOne.isAlive() && this.gameFrame.redList
/*  90 */       .indexOf(this.gameFrame.turret.turretRedOne) == -1) {
/*  91 */       this.gameFrame.redList.add(this.gameFrame.turret.turretRedOne);
/*     */     }
/*  93 */     if (!this.gameFrame.turret.turretRedFour.isAlive() && this.gameFrame.turret.turretRedThree.isAlive() && this.gameFrame.redList
/*  94 */       .indexOf(this.gameFrame.turret.turretRedThree) == -1) {
/*  95 */       this.gameFrame.redList.add(this.gameFrame.turret.turretRedThree);
/*     */     }
/*  97 */     if (!this.gameFrame.turret.turretRedSix.isAlive() && this.gameFrame.turret.turretRedFive.isAlive() && this.gameFrame.redList
/*  98 */       .indexOf(this.gameFrame.turret.turretRedFive) == -1) {
/*  99 */       this.gameFrame.redList.add(this.gameFrame.turret.turretRedFive);
/*     */     }
/* 101 */     if (!this.gameFrame.turret.turretRedOne.isAlive() && !this.gameFrame.turret.turretRedThree.isAlive() && 
/* 102 */       !this.gameFrame.turret.turretRedFive.isAlive() && this.gameFrame.turret.turretRedBase.isAlive() && this.gameFrame.redList
/* 103 */       .indexOf(this.gameFrame.turret.turretRedBase) == -1) {
/* 104 */       this.gameFrame.redList.add(this.gameFrame.turret.turretRedBase);
/*     */     }
/* 106 */     if (!this.gameFrame.turret.turretRedBase.isAlive() && getScore() > 2000)
/*     */     {
/* 108 */       this.gameFrame.state = 2;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintSelf(Graphics g) {
/* 116 */     if (getCurrentHp() <= 0) {
/* 117 */       this.gameFrame.removeList.add(this);
/* 118 */       if (this instanceof TurretBlue) {
/* 119 */         this.gameFrame.blueList.remove(this);
/*     */       } else {
/* 121 */         System.out.println("Turret die");
/* 122 */         setAlive(false);
/* 123 */         setScore(getScore() + 100);
/* 124 */         this.gameFrame.redList.remove(this);
/*     */       } 
/*     */     } else {
/*     */       
/* 128 */       if (this instanceof TurretBlue) {
/* 129 */         addHp(g, 50, 130, 100, 20, Color.GREEN);
/* 130 */         attack(this.gameFrame.redList);
/*     */       } else {
/* 132 */         addHp(g, 50, 130, 100, 20, Color.RED);
/* 133 */         attack(this.gameFrame.blueList);
/*     */       } 
/* 135 */       g.drawImage(getImg(), getX() - 50, getY() - 100, null);
/* 136 */       g.drawOval(getX() - 300, getY() - 300, 600, 600);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getRec() {
/* 143 */     return new Rectangle(getX() - 50, getY() - 100, 100, 180);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\Turret.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
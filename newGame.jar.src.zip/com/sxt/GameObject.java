/*     */ package com.sxt;
/*     */ 
/*     */ import com.sxt.beast.Beast;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Toolkit;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class GameObject
/*     */ {
/*     */   private int x;
/*     */   private int y;
/*     */   private Image img;
/*     */   public GameFrame gameFrame;
/*     */   private int spd;
/*     */   private int hp;
/*     */   private int currentHp;
/*     */   private static int score;
/*     */   private GameObject target;
/*     */   private boolean hasTarget = false;
/*     */   private int dis;
/*     */   private int attackCoolDownTime;
/*     */   private boolean attackCoolDown = true;
/*     */   private boolean alive = true;
/*     */   boolean beControlled = false;
/*     */   File file;
/*     */   File file1;
/*     */   
/*     */   public void addHp(Graphics g, int difX, int difY, int width, int height, Color color) {
/*  61 */     g.setColor(Color.black);
/*  62 */     g.drawRect(getX() - difX, getY() - difY, width, height);
/*     */     
/*  64 */     g.setColor(color);
/*  65 */     g.fillRect(getX() - difX, getY() - difY, width * getCurrentHp() / getHp(), height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int addscore(Graphics g, int difX, int difY, int score) {
/*  73 */     Font font = new Font("Arial", 0, 30);
/*  74 */     Color mycolor = Color.BLACK;
/*  75 */     g.setFont(font);
/*  76 */     g.setColor(mycolor);
/*  77 */     g.setFont(font);
/*  78 */     g.drawString("Score: " + score, getX() - difX + 500, getY() - difY - 150);
/*  79 */     return score;
/*     */   }
/*     */   
/*     */   public int addtime(Graphics g, int difX, int difY) {
/*  83 */     Font font = new Font("Arial", 0, 30);
/*  84 */     Color mycolor = Color.BLACK;
/*  85 */     g.setFont(font);
/*  86 */     g.setColor(mycolor);
/*  87 */     g.setFont(font);
/*  88 */     this.gameFrame.endTime = System.currentTimeMillis();
/*  89 */     this.gameFrame.differ = (this.gameFrame.endTime - this.gameFrame.startTime) / 1000L;
/*  90 */     g.drawString("Time: " + this.gameFrame.differ + "s", getX() - difX + 500, getY() - difY - 115);
/*  91 */     return (int)this.gameFrame.differ;
/*     */   }
/*     */ 
/*     */   
/*     */   public GameObject(GameFrame gameFrame)
/*     */   {
/*  97 */     this.file = new File("Ranking_List.txt");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     this.file1 = new File("Time_List.txt"); this.gameFrame = gameFrame; } public GameObject(int x, int y, GameFrame gameFrame) { this.file = new File("Ranking_List.txt"); this.file1 = new File("Time_List.txt"); this.x = x; this.y = y; this.gameFrame = gameFrame; } public int getScorefile() { BufferedReader br = null; int score = 0; try { br = new BufferedReader(new FileReader(this.file)); score = Integer.parseInt(br.readLine()); } catch (IOException e) { e.printStackTrace(); } finally { try { br.close(); } catch (IOException e) { e.printStackTrace(); }  }  return score; } public GameObject() { this.file = new File("Ranking_List.txt"); this.file1 = new File("Time_List.txt"); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int gettimefile() {
/* 147 */     BufferedReader br = null;
/* 148 */     int ti = 0;
/*     */     try {
/* 150 */       br = new BufferedReader(new FileReader(this.file1));
/* 151 */       ti = Integer.parseInt(br.readLine());
/* 152 */     } catch (IOException e) {
/* 153 */       e.printStackTrace();
/*     */     } finally {
/*     */       try {
/* 156 */         br.close();
/* 157 */       } catch (IOException e) {
/* 158 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */     
/* 162 */     return ti; } public void setScore(String str) { FileWriter fw = null; try { fw = new FileWriter(this.file); fw.write(str); }
/*     */     catch (IOException e) { e.printStackTrace(); }
/*     */     finally { try { fw.close(); }
/*     */       catch (IOException e)
/*     */       { e.printStackTrace(); }
/*     */        }
/*     */      }
/* 169 */   public void settime(String str) { FileWriter fw = null;
/*     */     try {
/* 171 */       fw = new FileWriter(this.file1);
/* 172 */       fw.write(str);
/* 173 */     } catch (IOException e) {
/* 174 */       e.printStackTrace();
/*     */     } finally {
/*     */       try {
/* 177 */         fw.close();
/* 178 */       } catch (IOException e) {
/* 179 */         e.printStackTrace();
/*     */       } 
/*     */     }  }
/*     */ 
/*     */ 
/*     */   
/*     */   public double getDis(int x1, int y1, int x2, int y2) {
/* 186 */     return Math.sqrt(Math.pow((x1 - x2), 2.0D) + Math.pow((y1 - y2), 2.0D));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean recIntersectsRec(Rectangle r1, Rectangle r2) {
/* 191 */     return r1.intersects(r2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean recIntersectsCir(Rectangle rec, int x, int y, int r) {
/* 196 */     if (getDis(x, y, rec.x, rec.y) < r || getDis(x, y, rec.x, rec.y + rec.height) < r || 
/* 197 */       getDis(x, y, rec.x + rec.width, rec.y) < r || 
/* 198 */       getDis(x, y, rec.x + rec.width, rec.y + rec.height) < r) {
/* 199 */       return true;
/*     */     }
/* 201 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void attack(ArrayList<GameObject> gameObjList) {
/* 206 */     if (this.hasTarget) {
/*     */       
/* 208 */       if (!recIntersectsCir(this.target.getRec(), getX(), getY(), getDis())) {
/* 209 */         setHasTarget(false);
/*     */       
/*     */       }
/* 212 */       else if (!this.target.isAlive()) {
/* 213 */         setHasTarget(false);
/* 214 */       } else if (isAttackCoolDown() && isAlive()) {
/* 215 */         Bullet bullet = null;
/*     */         
/* 217 */         if (Turret.class.isAssignableFrom(getClass())) {
/* 218 */           bullet = new Bullet(this.gameFrame, this, getTarget(), 500, 50);
/*     */         
/*     */         }
/* 221 */         else if (Minion.class.isAssignableFrom(getClass())) {
/* 222 */           bullet = new Bullet(this.gameFrame, this, getTarget(), 50, 30);
/*     */         
/*     */         }
/* 225 */         else if (this instanceof Champion) {
/* 226 */           bullet = new Bullet(this.gameFrame, this, getTarget(), 250, 50, "img/bullet.gif");
/*     */         } 
/* 228 */         this.gameFrame.objList.add(bullet);
/*     */         
/* 230 */         (new AttackCD()).start();
/*     */       } 
/*     */     } else {
/*     */       
/* 234 */       for (GameObject obj : gameObjList) {
/*     */         
/* 236 */         if (recIntersectsCir(obj.getRec(), getX(), getY(), getDis())) {
/*     */           
/* 238 */           setTarget(obj);
/* 239 */           setHasTarget(true);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 245 */       if (!this.hasTarget && gameObjList == this.gameFrame.blueList) {
/* 246 */         if (recIntersectsCir(this.gameFrame.player.getRec(), getX(), getY(), getDis()))
/*     */         {
/* 248 */           setTarget(this.gameFrame.player);
/* 249 */           setHasTarget(true);
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 257 */         for (GameObject obj : this.gameFrame.beast.beastList) {
/*     */           
/* 259 */           if (recIntersectsCir(obj.getRec(), getX(), getY(), getDis())) {
/*     */             
/* 261 */             setTarget(obj);
/* 262 */             setHasTarget(true);
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   class AttackCD
/*     */     extends Thread
/*     */   {
/*     */     public void run() {
/* 274 */       GameObject.this.setAttackCoolDown(false);
/*     */       
/*     */       try {
/* 277 */         Thread.sleep(GameObject.this.attackCoolDownTime);
/* 278 */       } catch (Exception e) {
/* 279 */         e.printStackTrace();
/*     */       } 
/*     */       
/* 282 */       GameObject.this.setAttackCoolDown(true);
/*     */       
/* 284 */       stop();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getX() {
/* 298 */     return this.x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setX(int x) {
/* 305 */     this.x = x;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getY() {
/* 312 */     return this.y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setY(int y) {
/* 319 */     this.y = y;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Image getImg() {
/* 326 */     return this.img;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImg(String img) {
/* 333 */     this.img = Toolkit.getDefaultToolkit().getImage(img);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSpd() {
/* 340 */     return this.spd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSpd(int spd) {
/* 347 */     this.spd = spd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHp() {
/* 354 */     return this.hp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHp(int hp) {
/* 361 */     this.hp = hp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCurrentHp() {
/* 368 */     return this.currentHp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentHp(int currentHp) {
/* 375 */     if (currentHp < getHp() && 
/* 376 */       Beast.class.isAssignableFrom(getClass())) {
/*     */       
/* 378 */       setTarget(this.gameFrame.player);
/* 379 */       setHasTarget(true);
/*     */     } 
/*     */     
/* 382 */     this.currentHp = currentHp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GameObject getTarget() {
/* 389 */     return this.target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTarget(GameObject target) {
/* 396 */     this.target = target;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isHasTarget() {
/* 403 */     return this.hasTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHasTarget(boolean hasTarget) {
/* 410 */     this.hasTarget = hasTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDis() {
/* 417 */     return this.dis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDis(int dis) {
/* 424 */     this.dis = dis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAttackCoolDownTime() {
/* 431 */     return this.attackCoolDownTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttackCoolDownTime(int attackCoolDownTime) {
/* 438 */     this.attackCoolDownTime = attackCoolDownTime;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAttackCoolDown() {
/* 445 */     return this.attackCoolDown;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttackCoolDown(boolean attackCoolDown) {
/* 452 */     this.attackCoolDown = attackCoolDown;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAlive() {
/* 459 */     return this.alive;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAlive(boolean alive) {
/* 466 */     this.alive = alive;
/*     */   }
/*     */   
/*     */   public int getScore() {
/* 470 */     return score;
/*     */   }
/*     */   
/*     */   public void setScore(int score) {
/* 474 */     this; GameObject.score = score;
/*     */   }
/*     */   
/*     */   public abstract void paintSelf(Graphics paramGraphics);
/*     */   
/*     */   public abstract Rectangle getRec();
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\GameObject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
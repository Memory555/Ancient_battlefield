/*     */ package com.sxt;
/*     */ 
/*     */ import com.sxt.beast.Beast;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ 
/*     */ public class GameFrame
/*     */   extends JFrame {
/*  18 */   int state = 0;
/*     */   
/*  20 */   private int windowWidth = 1400;
/*  21 */   private int windowHeight = 700;
/*     */   
/*  23 */   private Image offScreenImage = null;
/*     */   
/*     */   public long startTime;
/*     */   
/*     */   public long endTime;
/*     */   
/*     */   public long differ;
/*     */   
/*     */   public static int getAsk() {
/*  32 */     return ask;
/*     */   }
/*     */   
/*     */   public static void setAsk(int ask) {
/*  36 */     GameFrame.ask = ask;
/*     */   }
/*     */ 
/*     */   
/*  40 */   public static int ask = 0;
/*     */   
/*  42 */   private Image attack = Toolkit.getDefaultToolkit().getImage("img/attack.png");
/*     */   
/*  44 */   private Image answer = Toolkit.getDefaultToolkit().getImage("img/answer.png");
/*     */   
/*  46 */   private Image gameWin = Toolkit.getDefaultToolkit().getImage("img/gameWin.png");
/*  47 */   private Image gameLose = Toolkit.getDefaultToolkit().getImage("img/gameLose.png");
/*     */   
/*  49 */   Background background = new Background(this);
/*     */   
/*     */   Champion player;
/*  52 */   Champion champion = new Player(this, 1210, 3470);
/*     */   
/*  54 */   MinionBlue mb = new MinionBlue(this);
/*  55 */   MinionRed mr = new MinionRed(this);
/*     */   
/*  57 */   Turret turret = new Turret(this);
/*     */   
/*  59 */   public Beast beast = new Beast(this);
/*     */ 
/*     */   
/*     */   JButton attackButton;
/*     */   
/*     */   JButton answerButton;
/*     */   
/*  66 */   public ArrayList<GameObject> objList = new ArrayList<>();
/*  67 */   ArrayList<GameObject> redList = new ArrayList<>();
/*  68 */   ArrayList<GameObject> blueList = new ArrayList<>();
/*  69 */   public ArrayList<GameObject> removeList = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public void launch() {
/*  73 */     setSize(this.windowWidth, this.windowHeight);
/*     */     
/*  75 */     setLocation(1000, 400);
/*     */ 
/*     */     
/*  78 */     setDefaultCloseOperation(3);
/*     */     
/*  80 */     setResizable(false);
/*     */     
/*  82 */     setTitle("远古战场");
/*     */     
/*  84 */     setVisible(true);
/*     */     
/*  86 */     addKeyListener(new KeyMonitor());
/*     */     
/*  88 */     this.objList.add(this.background);
/*  89 */     this.objList.addAll((Collection)this.turret.turretList);
/*  90 */     this.objList.addAll(this.beast.beastList);
/*  91 */     this.blueList.add(this.turret.turretList.get(1));
/*  92 */     this.blueList.add(this.turret.turretList.get(3));
/*  93 */     this.blueList.add(this.turret.turretList.get(5));
/*  94 */     this.redList.add(this.turret.turretList.get(8));
/*  95 */     this.redList.add(this.turret.turretList.get(10));
/*  96 */     this.redList.add(this.turret.turretList.get(12));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     this.attackButton = new JButton();
/* 102 */     this.attackButton.setSize(130, 132);
/* 103 */     this.attackButton.setLocation(1200, 430);
/* 104 */     this.attackButton.addActionListener(new ActionListener()
/*     */         {
/*     */           
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 109 */             Music1 audioPlayWave1 = new Music1("music/bullet.wav");
/* 110 */             audioPlayWave1.start();
/*     */             
/* 112 */             int musicOpenLab = 1;
/* 113 */             GameFrame.this.player.attack(GameFrame.this.redList);
/*     */           }
/*     */         });
/* 116 */     add(this.attackButton);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     this.answerButton = new JButton();
/* 122 */     this.answerButton.setSize(130, 132);
/* 123 */     this.answerButton.setLocation(20, 430);
/* 124 */     this.answerButton.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent e)
/*     */           {
/* 128 */             Question qq1 = new Question();
/*     */           }
/*     */         });
/* 131 */     add(this.answerButton);
/*     */     
/*     */     while (true) {
/* 134 */       if (this.state == 1) {
/*     */         
/* 136 */         this.mb.createMinion(this, this.blueList);
/* 137 */         this.mr.createMinion(this, this.redList);
/*     */         
/* 139 */         this.turret.addTurret();
/*     */       } 
/* 141 */       repaint();
/*     */       try {
/* 143 */         Thread.sleep(17L);
/* 144 */       } catch (Exception e) {
/* 145 */         e.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paint(Graphics g) {
/* 151 */     if (this.offScreenImage == null) {
/* 152 */       this.offScreenImage = createImage(5984, 4452);
/*     */     }
/* 154 */     Graphics gImage = this.offScreenImage.getGraphics();
/* 155 */     if (this.state == 0) {
/* 156 */       for (int i = 0; i < this.champion.championList.size(); i++) {
/*     */         
/* 158 */         Image classical = ((Champion)this.champion.championList.get(i)).classical;
/* 159 */         gImage.drawImage(classical, i * 160, 20, null);
/*     */ 
/*     */         
/* 162 */         JButton championButton = new JButton();
/* 163 */         championButton.setSize(1400, 700);
/* 164 */         championButton.setLocation(i * 150, 0);
/* 165 */         final int a = i;
/* 166 */         championButton.addActionListener(new ActionListener()
/*     */             {
/*     */               public void actionPerformed(ActionEvent e) {
/* 169 */                 GameFrame.this.state = 1;
/* 170 */                 GameFrame.this.player = GameFrame.this.champion.championList.get(a);
/* 171 */                 GameFrame.this.objList.add(GameFrame.this.player);
/*     */               }
/*     */             });
/* 174 */         add(championButton);
/* 175 */         this.startTime = System.currentTimeMillis();
/*     */       } 
/* 177 */     } else if (this.state == 1) {
/* 178 */       for (int i = 0; i < this.objList.size(); i++) {
/* 179 */         ((GameObject)this.objList.get(i)).paintSelf(gImage);
/*     */       }
/*     */       
/* 182 */       gImage.drawImage(this.attack, this.player.getX() + 500, this.player.getY() + 115, null);
/*     */       
/* 184 */       gImage.drawImage(this.answer, this.player.getX() - 642, this.player.getY() + 100, null);
/* 185 */       this.objList.removeAll(this.removeList);
/*     */     
/*     */     }
/* 188 */     else if (this.state == 2) {
/* 189 */       gImage.drawImage(this.gameWin, 0, 5, null);
/* 190 */     } else if (this.state == 3) {
/* 191 */       gImage.drawImage(this.gameLose, 0, 5, null);
/*     */     } 
/* 193 */     if (this.state != 1) {
/* 194 */       g.drawImage(this.offScreenImage, 0, 0, null);
/*     */     } else {
/* 196 */       g.drawImage(this.offScreenImage, -this.player.getX() + 700, -this.player.getY() + 350, null);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 201 */     requestFocus();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 207 */     Music audioPlayWave = new Music("music/bensound-intothenight.wav");
/* 208 */     audioPlayWave.start();
/*     */     
/* 210 */     int musicOpenLab = 1;
/*     */     
/* 212 */     GameFrame gameFrame = new GameFrame();
/* 213 */     gameFrame.launch();
/*     */   }
/*     */   
/*     */   private class KeyMonitor extends KeyAdapter {
/*     */     private KeyMonitor() {}
/*     */     
/*     */     public void keyPressed(KeyEvent e) {
/* 220 */       int key = e.getKeyCode();
/* 221 */       GameFrame.this.player.keyPressed(e);
/*     */     }
/*     */ 
/*     */     
/*     */     public void keyReleased(KeyEvent e) {
/* 226 */       int key = e.getKeyCode();
/* 227 */       GameFrame.this.player.keyReleased(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\GameFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package com.sxt;
/*    */ 
/*    */ public class TurretRed
/*    */   extends Turret {
/*    */   public TurretRed(GameFrame gameFrame) {
/*  6 */     super(gameFrame);
/*    */   }
/*    */ 
/*    */   
/*    */   public TurretRed(int x, int y, GameFrame gameFrame) {
/* 11 */     super(x, y, gameFrame);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\TurretRed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
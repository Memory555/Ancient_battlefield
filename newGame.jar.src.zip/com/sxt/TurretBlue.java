/*    */ package com.sxt;
/*    */ 
/*    */ public class TurretBlue
/*    */   extends Turret {
/*    */   public TurretBlue(GameFrame gameFrame) {
/*  6 */     super(gameFrame);
/*    */   }
/*    */ 
/*    */   
/*    */   public TurretBlue(int x, int y, GameFrame gameFrame) {
/* 11 */     super(x, y, gameFrame);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\TurretBlue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
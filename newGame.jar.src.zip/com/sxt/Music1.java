/*    */ package com.sxt;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import javax.sound.sampled.AudioInputStream;
/*    */ import javax.sound.sampled.FloatControl;
/*    */ import javax.sound.sampled.SourceDataLine;
/*    */ 
/*    */ public class Music1 extends Thread {
/*  9 */   private final int EXTERNAL_BUFFER_SIZE = 524288; private String fileName;
/*    */   
/*    */   public Music1(String wavFile) {
/* 12 */     this.fileName = wavFile;
/*    */   }
/*    */ 
/*    */   
/*    */   public void run() {
/* 17 */     File soundFile = new File(this.fileName);
/* 18 */     if (!soundFile.exists()) {
/* 19 */       System.err.println("Wave file not found:" + this.fileName);
/*    */       
/*    */       return;
/*    */     } 
/* 23 */     AudioInputStream audioInputStream = null;
/*    */     try {
/* 25 */       audioInputStream = AudioSystem.getAudioInputStream(soundFile);
/* 26 */     } catch (UnsupportedAudioFileException e1) {
/* 27 */       e1.printStackTrace();
/*    */       return;
/* 29 */     } catch (IOException e1) {
/* 30 */       e1.printStackTrace();
/*    */       return;
/*    */     } 
/* 33 */     AudioFormat format = audioInputStream.getFormat();
/* 34 */     SourceDataLine auline = null;
/* 35 */     DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
/*    */     try {
/* 37 */       auline = (SourceDataLine)AudioSystem.getLine(info);
/* 38 */       auline.open(format);
/* 39 */     } catch (LineUnavailableException e) {
/* 40 */       e.printStackTrace();
/*    */       return;
/* 42 */     } catch (Exception e) {
/* 43 */       e.printStackTrace();
/*    */       return;
/*    */     } 
/* 46 */     if (auline.isControlSupported(FloatControl.Type.PAN)) {
/* 47 */       FloatControl floatControl = (FloatControl)auline.getControl(FloatControl.Type.PAN);
/*    */     }
/* 49 */     auline.start();
/* 50 */     int nBytesRead = 0;
/* 51 */     byte[] abData = new byte[524288];
/*    */     try {
/* 53 */       while (nBytesRead != -1) {
/* 54 */         nBytesRead = audioInputStream.read(abData, 0, abData.length);
/* 55 */         if (nBytesRead >= 0)
/* 56 */           auline.write(abData, 0, nBytesRead); 
/*    */       } 
/* 58 */     } catch (IOException e) {
/* 59 */       e.printStackTrace();
/*    */       return;
/*    */     } finally {
/* 62 */       auline.drain();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\Music1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package com.sxt;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ public abstract class Champion
/*     */   extends GameObject {
/*     */   public boolean up;
/*     */   public boolean down;
/*     */   public boolean left;
/*     */   public boolean right;
/*  16 */   static String[] imgs = new String[8];
/*     */   
/*  18 */   int moveCount = 1;
/*     */   
/*     */   Image classical;
/*     */   
/*  22 */   ArrayList<Champion> championList = new ArrayList<>();
/*     */   
/*  24 */   int count = 0;
/*     */   
/*     */   static {
/*  27 */     for (int i = 1; i < 8; i++) {
/*  28 */       imgs[i] = "img/move/" + i + ".png";
/*     */     }
/*     */   }
/*     */   
/*     */   public Champion(GameFrame gameFrame, int x, int y) {
/*  33 */     super(gameFrame);
/*  34 */     setImg("img/stand.png");
/*  35 */     setX(x);
/*  36 */     setY(y);
/*  37 */     setSpd(15);
/*  38 */     setHp(240000);
/*  39 */     setDis(250);
/*  40 */     setAttackCoolDownTime(100);
/*  41 */     setCurrentHp(getHp());
/*     */     
/*  43 */     this.championList.add(new Player(gameFrame));
/*     */   }
/*     */ 
/*     */   
/*     */   public Champion(GameFrame gameFrame) {
/*  48 */     super(gameFrame);
/*  49 */     setImg("img/stand.png");
/*  50 */     setX(1210);
/*  51 */     setY(3470);
/*  52 */     setSpd(10);
/*  53 */     setHp(24000);
/*  54 */     setDis(250);
/*  55 */     setAttackCoolDownTime(100);
/*  56 */     setCurrentHp(getHp());
/*     */   }
/*     */   
/*     */   public void keyPressed(KeyEvent e) {
/*  60 */     int key = e.getKeyCode();
/*  61 */     if (key == 68) {
/*  62 */       this.right = true;
/*     */     }
/*  64 */     if (key == 65) {
/*  65 */       this.left = true;
/*     */     }
/*  67 */     if (key == 87) {
/*  68 */       this.up = true;
/*     */     }
/*  70 */     if (key == 83) {
/*  71 */       this.down = true;
/*     */     }
/*     */   }
/*     */   
/*     */   public void keyReleased(KeyEvent e) {
/*  76 */     int key = e.getKeyCode();
/*  77 */     if (key == 68) {
/*  78 */       this.right = false;
/*     */     }
/*  80 */     if (key == 65) {
/*  81 */       this.left = false;
/*     */     }
/*  83 */     if (key == 87) {
/*  84 */       this.up = false;
/*     */     }
/*  86 */     if (key == 83) {
/*  87 */       this.down = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public void move() {
/*  92 */     if (this.up) {
/*  93 */       setY(getY() - getSpd());
/*     */     }
/*  95 */     if (this.down) {
/*  96 */       setY(getY() + getSpd());
/*     */     }
/*  98 */     if (this.left) {
/*  99 */       setX(getX() - getSpd());
/*     */     }
/* 101 */     if (this.right) {
/* 102 */       setX(getX() + getSpd());
/*     */     }
/* 104 */     if (this.up || this.down || this.left || this.right) {
/* 105 */       setImg(imgs[this.moveCount]);
/* 106 */       this.moveCount++;
/* 107 */       if (this.moveCount == 8) {
/* 108 */         this.moveCount = 1;
/*     */       }
/*     */     } else {
/* 111 */       setImg("img/stand.png");
/*     */     } 
/*     */     
/* 114 */     if (getX() >= 850 && getX() <= 1210 && getY() <= 3740 && getY() >= 3365) {
/* 115 */       setHp(24000);
/* 116 */       setCurrentHp(getHp());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 121 */     if (GameFrame.getAsk() == 1) {
/* 122 */       setScore(getScore() + 300);
/* 123 */       GameFrame.setAsk(0);
/*     */     } 
/* 125 */     if (GameFrame.getAsk() == 2) {
/* 126 */       setScore(getScore() - 50);
/* 127 */       GameFrame.setAsk(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintSelf(Graphics g) {
/* 136 */     if (getCurrentHp() <= 20) {
/* 137 */       System.out.println("die");
/* 138 */       this.count++;
/*     */       
/* 140 */       setX(1210);
/* 141 */       setY(3470);
/* 142 */       setSpd((int)(10.0D - 0.5D * this.count));
/* 143 */       setHp(24000 - this.count * 400);
/*     */       
/* 145 */       setCurrentHp(getHp());
/*     */       
/* 147 */       g.drawImage(getImg(), getX() - 33, getY() - 50, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 154 */       move();
/*     */     } else {
/*     */       int MaxScore, MaxTime;
/*     */ 
/*     */       
/* 159 */       addHp(g, 30, 80, 80, 20, Color.GREEN);
/*     */       
/* 161 */       int score = addscore(g, 30, 80, getScore());
/*     */       
/* 163 */       int differ = addtime(g, 30, 80);
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 168 */         MaxScore = getScorefile();
/* 169 */         MaxTime = gettimefile();
/* 170 */       } catch (Exception e) {
/* 171 */         MaxScore = 0;
/* 172 */         MaxTime = 0;
/*     */       } 
/* 174 */       if (differ <= MaxTime)
/* 175 */         g.drawString("Max Time:" + MaxTime, getX() + 472, getY() - 95); 
/* 176 */       if (differ > MaxTime) {
/* 177 */         settime(String.valueOf(differ));
/* 178 */         g.drawString("Max Time: " + differ, getX() + 472, getY() - 95);
/*     */       } 
/* 180 */       if (score <= MaxScore)
/* 181 */         g.drawString("Max Score:" + MaxScore, getX() + 472, getY() - 140); 
/* 182 */       if (score > MaxScore) {
/* 183 */         setScore(String.valueOf(score));
/* 184 */         g.drawString("Max Score: " + score, getX() + 472, getY() - 140);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 191 */       g.drawImage(getImg(), getX() - 33, getY() - 50, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 198 */       move();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getRec() {
/* 206 */     return new Rectangle(getX() - 30, getY() - 60, 60, 120);
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\Champion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
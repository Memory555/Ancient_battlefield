/*    */ package com.sxt;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class MinionRed
/*    */   extends Minion {
/*    */   public MinionRed(GameFrame gameFrame) {
/*  8 */     super(gameFrame);
/*  9 */     setImg("img/minion/red.png");
/* 10 */     int[] ii1 = { 4925, 4920 };
/* 11 */     int test = MinionBlue.getRandom(ii1);
/* 12 */     if (test == 4925) {
/* 13 */       setX(4925);
/* 14 */       setY(1125);
/*    */     } 
/* 16 */     if (test == 4920) {
/* 17 */       setX(4920);
/* 18 */       setY(610);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void move(ArrayList<GameObject> objList) {
/* 26 */     if (isIfFindTarget()) {
/*    */       
/* 28 */       if (!recIntersectsCir(getTarget().getRec(), getX(), getY(), 200)) {
/* 29 */         setIfFindTarget(false);
/*    */       } else {
/* 31 */         if (!isHasTarget()) {
/* 32 */           moveToTarget();
/*    */         }
/* 34 */         attack(objList);
/*    */       } 
/*    */     } else {
/* 37 */       findTarget(objList);
/*    */       
/* 39 */       if (getX() >= 4925 && getY() <= 3920) {
/* 40 */         setSpd(15);
/* 41 */         if (!hitMinion(getX(), getY() + getSpd(), this.gameFrame.redList)) {
/* 42 */           setY(getY() + getSpd());
/*    */         }
/*    */       } 
/* 45 */       if (getY() > 3820 && getX() > 1120) {
/* 46 */         setSpd(10);
/* 47 */         if (!hitMinion(getX() - getSpd(), getY(), this.gameFrame.redList)) {
/* 48 */           setX(getX() - getSpd());
/*    */         }
/*    */       } 
/* 51 */       if (getX() > 850 && getY() <= 610) {
/* 52 */         setSpd(15);
/* 53 */         if (!hitMinion(getX() - getSpd(), getY(), this.gameFrame.redList)) {
/* 54 */           setX(getX() - getSpd());
/*    */         }
/*    */       } 
/* 57 */       if (getY() < 3230 && getX() <= 850) {
/* 58 */         setSpd(10);
/* 59 */         if (!hitMinion(getX(), getY() + getSpd(), this.gameFrame.redList))
/* 60 */           setY(getY() + getSpd()); 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\MinionRed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
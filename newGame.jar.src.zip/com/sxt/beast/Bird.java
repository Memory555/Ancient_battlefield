/*    */ package com.sxt.beast;
/*    */ 
/*    */ import com.sxt.GameFrame;
/*    */ 
/*    */ public class Bird
/*    */   extends Beast {
/*    */   public Bird(int x, int y, GameFrame gameFrame) {
/*  8 */     super(x, y, gameFrame);
/*  9 */     setImg("img/beast/Bird.jpg");
/* 10 */     this.width = 122;
/* 11 */     this.height = 98;
/* 12 */     setDis(125);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\beast\Bird.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package com.sxt.beast;
/*    */ 
/*    */ import com.sxt.GameFrame;
/*    */ 
/*    */ public class Xiyi
/*    */   extends Beast {
/*    */   public Xiyi(int x, int y, GameFrame gameFrame) {
/*  8 */     super(x, y, gameFrame);
/*  9 */     setImg("img/beast/Xiyi.jpg");
/* 10 */     this.width = 111;
/* 11 */     this.height = 65;
/* 12 */     setDis(125);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\beast\Xiyi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
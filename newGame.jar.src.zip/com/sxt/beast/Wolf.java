/*    */ package com.sxt.beast;
/*    */ 
/*    */ import com.sxt.GameFrame;
/*    */ 
/*    */ public class Wolf
/*    */   extends Beast {
/*    */   public Wolf(int x, int y, GameFrame gameFrame) {
/*  8 */     super(x, y, gameFrame);
/*  9 */     setImg("img/beast/wolf.jpg");
/* 10 */     this.width = 145;
/* 11 */     this.height = 140;
/*    */     
/* 13 */     setDis(65);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\beast\Wolf.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package com.sxt.beast;
/*    */ 
/*    */ import com.sxt.GameFrame;
/*    */ 
/*    */ public class BlueBuff
/*    */   extends Beast {
/*    */   public BlueBuff(int x, int y, GameFrame gameFrame) {
/*  8 */     super(x, y, gameFrame);
/*  9 */     setImg("img/beast/blueBuff.jpg");
/* 10 */     this.width = 142;
/* 11 */     this.height = 176;
/* 12 */     setDis(70);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\beast\BlueBuff.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
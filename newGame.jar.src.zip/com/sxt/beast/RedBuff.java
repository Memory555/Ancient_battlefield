/*    */ package com.sxt.beast;
/*    */ 
/*    */ import com.sxt.GameFrame;
/*    */ 
/*    */ public class RedBuff
/*    */   extends Beast {
/*    */   public RedBuff(int x, int y, GameFrame gameFrame) {
/*  8 */     super(x, y, gameFrame);
/*  9 */     setImg("img/beast/redBuff.jpg");
/* 10 */     this.width = 103;
/* 11 */     this.height = 150;
/* 12 */     setDis(70);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\beast\RedBuff.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
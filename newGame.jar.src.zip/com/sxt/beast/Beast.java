/*     */ package com.sxt.beast;
/*     */ import com.sxt.Bullet;
/*     */ import com.sxt.GameFrame;
/*     */ import com.sxt.GameObject;
/*     */ import com.sxt.Music1;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ public class Beast extends GameObject {
/*  12 */   public ArrayList<Beast> beastList = new ArrayList<>();
/*     */   
/*     */   int width;
/*     */   
/*     */   int height;
/*     */   
/*     */   int initialX;
/*     */   
/*     */   int initialY;
/*     */   
/*     */   public boolean isAggressive = false;
/*     */   
/*  24 */   Beast beast = null;
/*     */   
/*     */   public Beast(GameFrame gameFrame) {
/*  27 */     super(gameFrame);
/*  28 */     this.beastList.add(new RedBuff(2580, 3210, gameFrame));
/*  29 */     this.beastList.add(new Bear(1165, 1575, gameFrame));
/*  30 */     this.beastList.add(new Xiyi(4090, 2230, gameFrame));
/*  31 */     this.beastList.add(new Bird(1755, 2100, gameFrame));
/*  32 */     this.beastList.add(new BlueBuff(3085, 1335, gameFrame));
/*  33 */     this.beastList.add(new Wolf(4600, 2780, gameFrame));
/*     */   }
/*     */   
/*     */   public Beast(int x, int y, GameFrame gameFrame) {
/*  37 */     super(x, y, gameFrame);
/*  38 */     setHp(1000);
/*  39 */     setCurrentHp(getHp());
/*  40 */     setSpd(10);
/*  41 */     setAttackCoolDownTime(4000);
/*  42 */     this.initialX = getX();
/*  43 */     this.initialY = getY();
/*  44 */     this.beast = this;
/*     */   }
/*     */   
/*     */   public void moveToTarget() {
/*  48 */     double dis = getDis(getX(), getY(), getTarget().getX(), getTarget().getY());
/*  49 */     if (dis > 500.0D) {
/*  50 */       this.isAggressive = false;
/*  51 */       setHasTarget(false);
/*     */     } else {
/*  53 */       int xSpeed = (int)((getSpd() * (getTarget().getX() - getX())) / dis);
/*  54 */       int ySpeed = (int)((getSpd() * (getTarget().getY() - getY())) / dis);
/*  55 */       setX(getX() + xSpeed);
/*  56 */       setY(getY() + ySpeed);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void moveToInitialLocation() {
/*  61 */     double dis = getDis(getX(), getY(), this.initialX, this.initialY);
/*  62 */     if (dis < getSpd()) {
/*  63 */       setX(this.initialX);
/*  64 */       setY(this.initialY);
/*  65 */       this.isAggressive = true;
/*     */     } else {
/*  67 */       int xSpeed = (int)((getSpd() * (this.initialX - getX())) / dis);
/*  68 */       int ySpeed = (int)((getSpd() * (this.initialY - getY())) / dis);
/*  69 */       setX(getX() + xSpeed);
/*  70 */       setY(getY() + ySpeed);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void move() {
/*  82 */     if (isHasTarget() && this.isAggressive) {
/*  83 */       if (!recIntersectsCir(getTarget().getRec(), getX(), getY(), getDis())) {
/*  84 */         moveToTarget();
/*  85 */       } else if (isAttackCoolDown() && isAlive()) {
/*  86 */         Bullet bullet = new Bullet(this.gameFrame, this, getTarget(), 500, 50, "img/bullet.gif");
/*  87 */         this.gameFrame.objList.add(bullet);
/*  88 */         (new AttackCD()).start();
/*  89 */         Music1 audioPlayWave2 = new Music1("music/beast.wav");
/*  90 */         audioPlayWave2.start();
/*     */         
/*  92 */         boolean bool = true;
/*     */       } 
/*     */     } else {
/*  95 */       moveToInitialLocation();
/*  96 */       if (getCurrentHp() < getHp()) {
/*  97 */         setCurrentHp(getCurrentHp() + 100);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintSelf(Graphics g) {
/* 106 */     if (getCurrentHp() <= 0) {
/* 107 */       System.out.println("beast die");
/* 108 */       setAlive(false);
/* 109 */       setScore(getScore() + 50);
/* 110 */       System.out.println("score" + getScore());
/* 111 */       this.gameFrame.removeList.add(this);
/* 112 */       this.gameFrame.beast.beastList.remove(this);
/* 113 */       (new ReviveCD()).start();
/*     */     } else {
/*     */       
/* 116 */       addHp(g, this.width / 2, 80, this.width, 20, Color.GREEN);
/* 117 */       g.drawImage(getImg(), getX() - this.width / 2, getY() - this.height / 2, null);
/* 118 */       g.setColor(Color.RED);
/* 119 */       g.fillOval(getX(), getY(), 10, 10);
/* 120 */       g.drawOval(getX() - getDis(), getY() - getDis(), 2 * getDis(), 2 * getDis());
/* 121 */       move();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getRec() {
/* 128 */     return new Rectangle(getX() - this.width / 2, getY() - this.height / 2, this.width, this.height);
/*     */   }
/*     */   
/*     */   class AttackCD
/*     */     extends Thread {
/*     */     public void run() {
/* 134 */       Beast.this.setAttackCoolDown(false);
/*     */       
/*     */       try {
/* 137 */         Thread.sleep(Beast.this.getAttackCoolDownTime());
/* 138 */       } catch (Exception e) {
/* 139 */         e.printStackTrace();
/*     */       } 
/*     */       
/* 142 */       Beast.this.setAttackCoolDown(true);
/*     */       
/* 144 */       stop();
/*     */     }
/*     */   }
/*     */   
/*     */   class ReviveCD extends Thread {
/*     */     public void run() {
/*     */       Beast reviveBeast;
/*     */       try {
/* 152 */         Thread.sleep(5000L);
/* 153 */       } catch (Exception e) {
/* 154 */         e.printStackTrace();
/*     */       } 
/*     */       
/* 157 */       if (Beast.this.beast instanceof RedBuff) {
/* 158 */         reviveBeast = new RedBuff(2580, 3210, Beast.this.gameFrame);
/* 159 */       } else if (Beast.this.beast instanceof Bear) {
/* 160 */         reviveBeast = new Bear(1165, 1575, Beast.this.gameFrame);
/* 161 */       } else if (Beast.this.beast instanceof Bird) {
/* 162 */         reviveBeast = new Bird(1755, 2100, Beast.this.gameFrame);
/* 163 */       } else if (Beast.this.beast instanceof Xiyi) {
/* 164 */         reviveBeast = new Xiyi(4090, 2230, Beast.this.gameFrame);
/* 165 */       } else if (Beast.this.beast instanceof BlueBuff) {
/* 166 */         reviveBeast = new BlueBuff(3085, 1335, Beast.this.gameFrame);
/*     */       } else {
/* 168 */         reviveBeast = new Wolf(4600, 2780, Beast.this.gameFrame);
/*     */       } 
/* 170 */       Beast.this.gameFrame.objList.add(reviveBeast);
/* 171 */       Beast.this.gameFrame.beast.beastList.add(reviveBeast);
/*     */     }
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\beast\Beast.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
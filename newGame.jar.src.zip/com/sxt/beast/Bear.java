/*    */ package com.sxt.beast;
/*    */ 
/*    */ import com.sxt.GameFrame;
/*    */ 
/*    */ public class Bear
/*    */   extends Beast {
/*    */   public Bear(int x, int y, GameFrame gameFrame) {
/*  8 */     super(x, y, gameFrame);
/*  9 */     setImg("img/beast/bear.jpg");
/* 10 */     this.width = 85;
/* 11 */     this.height = 112;
/* 12 */     setDis(65);
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\beast\Bear.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package com.sxt;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Random;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JRadioButton;
/*     */ import jxl.Cell;
/*     */ import jxl.Sheet;
/*     */ import jxl.Workbook;
/*     */ import jxl.read.biff.BiffException;
/*     */ 
/*     */ public class Question extends JFrame {
/*     */   public Question() {
/*  23 */     setTitle("知识战场");
/*  24 */     setSize(1000, 450);
/*  25 */     setLocation(20, 450);
/*  26 */     setLayout((LayoutManager)null);
/*     */     
/*  28 */     File f = new File("excel/table1.xls");
/*     */     try {
/*  30 */       Workbook book = Workbook.getWorkbook(f);
/*  31 */       Sheet sheet = book.getSheet(0);
/*     */       
/*  33 */       Random rand = new Random();
/*  34 */       int rows = sheet.getRows();
/*  35 */       int n1 = rand.nextInt(rows) + 1;
/*  36 */       Cell cell = sheet.getCell(0, n1);
/*  37 */       String s = cell.getContents();
/*  38 */       Cell cell1 = sheet.getCell(1, n1);
/*  39 */       String s1 = cell1.getContents();
/*  40 */       Cell cell2 = sheet.getCell(2, n1);
/*  41 */       String s2 = cell2.getContents();
/*  42 */       Cell cell3 = sheet.getCell(3, n1);
/*  43 */       String s3 = cell3.getContents();
/*  44 */       Cell cell4 = sheet.getCell(4, n1);
/*  45 */       String s4 = cell4.getContents();
/*  46 */       Cell cell5 = sheet.getCell(5, n1);
/*  47 */       final String s5 = cell5.getContents();
/*     */       
/*  49 */       JLabel lbl1 = new JLabel(s);
/*     */       
/*  51 */       lbl1.setForeground(Color.black);
/*  52 */       Font font = new Font("宋体", 0, 20);
/*  53 */       lbl1.setFont(font);
/*  54 */       lbl1.setBounds(50, 20, 1000, 40);
/*  55 */       add(lbl1);
/*     */       
/*  57 */       final JRadioButton rbt1 = new JRadioButton(s1);
/*  58 */       rbt1.setFont(font);
/*  59 */       rbt1.setBounds(50, 70, 170, 30);
/*  60 */       rbt1.addActionListener(new ActionListener()
/*     */           {
/*     */             public void actionPerformed(ActionEvent e) {}
/*     */           });
/*     */ 
/*     */ 
/*     */       
/*  67 */       final JRadioButton rbt2 = new JRadioButton(s2);
/*  68 */       rbt2.setBounds(50, 120, 170, 30);
/*  69 */       rbt2.setFont(font);
/*  70 */       rbt2.addActionListener(new ActionListener()
/*     */           {
/*     */             public void actionPerformed(ActionEvent e) {}
/*     */           });
/*     */ 
/*     */ 
/*     */       
/*  77 */       final JRadioButton rbt3 = new JRadioButton(s3);
/*  78 */       rbt3.setFont(font);
/*  79 */       rbt3.setBounds(50, 170, 170, 30);
/*  80 */       rbt3.addActionListener(new ActionListener()
/*     */           {
/*     */             public void actionPerformed(ActionEvent e) {}
/*     */           });
/*     */ 
/*     */ 
/*     */       
/*  87 */       final JRadioButton rbt4 = new JRadioButton(s4);
/*  88 */       rbt4.setFont(font);
/*  89 */       rbt4.setBounds(50, 220, 170, 30);
/*  90 */       rbt4.addActionListener(new ActionListener()
/*     */           {
/*     */             public void actionPerformed(ActionEvent e) {}
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  98 */       ButtonGroup btng = new ButtonGroup();
/*     */       
/* 100 */       btng.add(rbt1);
/* 101 */       btng.add(rbt2);
/* 102 */       btng.add(rbt3);
/* 103 */       btng.add(rbt4);
/* 104 */       add(rbt1);
/* 105 */       add(rbt2);
/* 106 */       add(rbt3);
/* 107 */       add(rbt4);
/*     */       
/* 109 */       JButton btn1 = new JButton("Sure");
/*     */       
/* 111 */       btn1.setBounds(50, 270, 65, 30);
/* 112 */       int count = 0;
/* 113 */       btn1.addActionListener(new ActionListener()
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 122 */               int ss = Integer.parseInt(s5);
/* 123 */               if (ss == 1 && rbt1.isSelected() == true) {
/* 124 */                 Question.this.setScore(Question.this.getScore() + 1);
/*     */               }
/*     */               
/* 127 */               if (ss == 2 && rbt2.isSelected() == true) {
/* 128 */                 Question.this.setScore(Question.this.getScore() + 1);
/*     */               }
/*     */               
/* 131 */               if (ss == 3 && rbt3.isSelected() == true) {
/* 132 */                 Question.this.setScore(Question.this.getScore() + 1);
/*     */               }
/*     */               
/* 135 */               if (ss == 4 && rbt4.isSelected() == true) {
/* 136 */                 Question.this.setScore(Question.this.getScore() + 1);
/*     */               }
/*     */               
/* 139 */               if (Question.this.getScore() >= 1) {
/* 140 */                 GameFrame.setAsk(1);
/*     */               }
/*     */               else {
/*     */                 
/* 144 */                 GameFrame.setAsk(2);
/*     */               } 
/* 146 */               Question.this.dispose();
/*     */             }
/*     */           });
/*     */ 
/*     */       
/* 151 */       JButton btn3 = new JButton("Quit");
/* 152 */       btn3.setBounds(190, 270, 65, 30);
/* 153 */       btn3.addActionListener(new ActionListener()
/*     */           {
/*     */             public void actionPerformed(ActionEvent e)
/*     */             {
/* 157 */               if (Question.this.getScore() >= 1) {
/* 158 */                 GameFrame.setAsk(1);
/*     */               }
/* 160 */               Question.this.dispose();
/*     */             }
/*     */           });
/*     */       
/* 164 */       add(btn1);
/*     */       
/* 166 */       add(btn3);
/*     */       
/* 168 */       setVisible(true);
/*     */     }
/* 170 */     catch (BiffException e) {
/*     */       
/* 172 */       e.printStackTrace();
/* 173 */     } catch (IOException e) {
/*     */       
/* 175 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   int score;
/*     */   
/*     */   public int getScore() {
/* 182 */     return this.score;
/*     */   }
/*     */   
/*     */   public void setScore(int score) {
/* 186 */     this.score = score;
/*     */   }
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\Question.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*     */ package com.sxt;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ public abstract class Minion
/*     */   extends GameObject
/*     */ {
/*  12 */   int road = 0;
/*     */   
/*     */   private boolean nextMinion = true;
/*     */   
/*     */   private boolean nextLine = true;
/*     */   
/*  18 */   private int minionCount = 0;
/*     */   
/*     */   private boolean ifFindTarget = false;
/*     */   
/*     */   public Minion(GameFrame gameFrame) {
/*  23 */     super(gameFrame);
/*  24 */     setHp(800);
/*  25 */     setCurrentHp(getHp());
/*  26 */     setDis(100);
/*  27 */     setAttackCoolDownTime(2000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hitMinion(int x, int y, ArrayList<GameObject> objList) {
/*  45 */     Rectangle r = new Rectangle(x - 16, y - 16, 45, 45);
/*  46 */     for (GameObject obj : objList) {
/*     */       
/*  48 */       if (obj.getClass() == getClass() && obj != this && 
/*  49 */         r.intersects(obj.getRec())) {
/*  50 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  54 */     return false;
/*     */   }
/*     */   
/*     */   public void findTarget(ArrayList<GameObject> objList) {
/*  58 */     for (GameObject obj : objList) {
/*  59 */       if (recIntersectsCir(obj.getRec(), getX(), getY(), 200)) {
/*  60 */         setTarget(obj);
/*  61 */         setIfFindTarget(true);
/*     */       } 
/*     */     } 
/*  64 */     if (objList == this.gameFrame.blueList && 
/*  65 */       recIntersectsCir(this.gameFrame.player.getRec(), getX(), getY(), 200)) {
/*  66 */       setTarget(this.gameFrame.player);
/*  67 */       setIfFindTarget(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void moveToTarget() {
/*  73 */     double dis = getDis(getX(), getY(), getTarget().getX(), getTarget().getY());
/*  74 */     int xSpeed = (int)((getSpd() * (getTarget().getX() - getX())) / dis);
/*  75 */     int ySpeed = (int)((getSpd() * (getTarget().getY() - getY())) / dis);
/*  76 */     if (!hitMinion(getX() + xSpeed, getY(), this.gameFrame.objList)) {
/*  77 */       setX(getX() + xSpeed);
/*     */     }
/*  79 */     if (!hitMinion(getX(), getY() + ySpeed, this.gameFrame.objList)) {
/*  80 */       setY(getY() + ySpeed);
/*     */     }
/*     */   }
/*     */   
/*     */   public void createMinion(GameFrame gameFrame, ArrayList<GameObject> minionList) {
/*  85 */     if (this.nextLine) {
/*  86 */       if (this.nextMinion) {
/*     */         
/*  88 */         if (minionList == this.gameFrame.blueList) {
/*  89 */           MinionBlue mb = new MinionBlue(gameFrame);
/*  90 */           gameFrame.objList.add(mb);
/*  91 */           minionList.add(mb);
/*     */         }
/*     */         else {
/*     */           
/*  95 */           MinionRed mr = new MinionRed(gameFrame);
/*  96 */           gameFrame.objList.add(mr);
/*  97 */           minionList.add(mr);
/*     */         } 
/*  99 */         this.minionCount++;
/* 100 */         (new NextMinion()).start();
/*     */       } 
/* 102 */       if (this.minionCount == 6) {
/* 103 */         this.minionCount = 0;
/* 104 */         (new NextLine()).start();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   class NextMinion
/*     */     extends Thread {
/*     */     public void run() {
/* 112 */       Minion.this.nextMinion = false;
/*     */       
/*     */       try {
/* 115 */         Thread.sleep(1500L);
/* 116 */       } catch (Exception e) {
/* 117 */         e.printStackTrace();
/*     */       } 
/* 119 */       Minion.this.nextMinion = true;
/*     */       
/* 121 */       stop();
/*     */     }
/*     */   }
/*     */   
/*     */   class NextLine
/*     */     extends Thread {
/*     */     public void run() {
/* 128 */       Minion.this.nextLine = false;
/*     */       
/*     */       try {
/* 131 */         Thread.sleep(15000L);
/* 132 */       } catch (Exception e) {
/* 133 */         e.printStackTrace();
/*     */       } 
/* 135 */       Minion.this.nextLine = true;
/*     */       
/* 137 */       stop();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintSelf(Graphics g) {
/* 145 */     if (getCurrentHp() <= 0) {
/* 146 */       this.gameFrame.removeList.add(this);
/* 147 */       if (this instanceof MinionBlue) {
/* 148 */         this.gameFrame.blueList.remove(this);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 153 */         System.out.println("Minion die");
/* 154 */         setAlive(false);
/* 155 */         setScore(getScore() + 20);
/* 156 */         this.gameFrame.redList.remove(this);
/*     */       } 
/*     */     } else {
/*     */       
/* 160 */       if (this instanceof MinionBlue) {
/* 161 */         addHp(g, 17, 28, 45, 10, Color.GREEN);
/*     */       }
/*     */       else {
/*     */         
/* 165 */         addHp(g, 17, 28, 45, 10, Color.RED);
/*     */       } 
/* 167 */       g.drawImage(getImg(), getX() - 16, getY() - 16, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 173 */       if (!this.beControlled) {
/* 174 */         if (this instanceof MinionBlue) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 180 */           move(this.gameFrame.redList);
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */           
/* 188 */           move(this.gameFrame.blueList);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getRec() {
/* 197 */     return new Rectangle(getX() - 16, getY() - 16, 45, 45);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIfFindTarget() {
/* 204 */     return this.ifFindTarget;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIfFindTarget(boolean ifFindTarget) {
/* 211 */     this.ifFindTarget = ifFindTarget;
/*     */   }
/*     */   
/*     */   public abstract void move(ArrayList<GameObject> paramArrayList);
/*     */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\Minion.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */
/*    */ package com.sxt;
/*    */ 
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.event.MouseAdapter;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class Player
/*    */   extends Champion {
/*    */   public Player(GameFrame gameFrame) {
/* 10 */     super(gameFrame);
/* 11 */     this.classical = Toolkit.getDefaultToolkit().getImage("img/player.png");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Player(GameFrame gameFrame, int i, int j) {
/* 17 */     super(gameFrame, i, j);
/*    */   }
/*    */   
/*    */   public void exit(MouseAdapter ma) {
/* 21 */     this.gameFrame.removeMouseListener(ma);
/*    */   }
/*    */   
/*    */   public void attack() {
/* 25 */     if (isAttackCoolDown()) {
/* 26 */       ArrayList<GameObject> targets = new ArrayList<>();
/*    */ 
/*    */       
/* 29 */       for (GameObject redObj : this.gameFrame.redList) {
/* 30 */         if (recIntersectsCir(redObj.getRec(), getX() - 250, getY() - 250, 500)) {
/* 31 */           targets.add(redObj);
/* 32 */           if (targets.size() == 3) {
/*    */             break;
/*    */           }
/*    */         } 
/*    */       } 
/* 37 */       for (GameObject beastObj : this.gameFrame.beast.beastList) {
/* 38 */         if (recIntersectsCir(beastObj.getRec(), getX() - 250, getY() - 250, 500)) {
/* 39 */           targets.add(beastObj);
/* 40 */           if (targets.size() == 3) {
/*    */             break;
/*    */           }
/*    */         } 
/*    */       } 
/* 45 */       for (int i = 0; i < targets.size(); i++) {
/*    */         Bullet bullet;
/* 47 */         if (i == 0) {
/* 48 */           bullet = new Bullet(this.gameFrame, this, targets.get(i), 400, 50, "img/bullet.gif");
/*    */         } else {
/* 50 */           bullet = new Bullet(this.gameFrame, this, targets.get(i), 200, 50, "img/bullet.gif");
/*    */         } 
/* 52 */         this.gameFrame.objList.add(bullet);
/*    */       } 
/* 54 */       (new AttackCD()).start();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   class AttackCD
/*    */     extends Thread
/*    */   {
/*    */     public void run() {
/* 63 */       Player.this.setAttackCoolDown(false);
/*    */       
/*    */       try {
/* 66 */         Thread.sleep(Player.this.getAttackCoolDownTime());
/* 67 */       } catch (Exception e) {
/* 68 */         e.printStackTrace();
/*    */       } 
/*    */       
/* 71 */       Player.this.setAttackCoolDown(true);
/*    */       
/* 73 */       stop();
/*    */     }
/*    */   }
/*    */ }


/* Location:              E:\personal\JAVA\JAVA大作业\Ancient_battlefield\newGame.jar!\com\sxt\Player.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */